# Network features: what is built, what you must set up, what is not verified

Built (v1.18.0): Local Sync (desktop browser over the LAN) and Cloud backup (encrypted, Google Drive appDataFolder), exactly within `SANDPIPER_NET_ARCHITECTURE_PLAN.md`. The Little brain (`llm/`) is unchanged and has no network code.

## Google Drive setup (one time, by you; code cannot do this)
Cloud backup uses Google's authorization API, so Google must recognise the app:
1. Google Cloud Console: create a project, enable the **Google Drive API**.
2. OAuth consent screen: add the scope `.../auth/drive.appdata`; while in Testing, add your Google account as a test user.
3. Credentials > Create OAuth client ID > **Android**: package `com.vastanzil.sandpiper` and the **SHA-1 of the key that signs your APK** (your CI uses the debug key, so use that SHA-1; a different key = a different SHA-1 = Google refuses with "forbidden").
No client secret or ID is put in the app. If this is missing, Back up shows "Google refused access".

## Deviations from the plan (and why)
- **Argon2id** via `bcprov-jdk18on:1.78.1` (pure Java). The plan's `at.favre.lib:bcrypt` is bcrypt, not Argon2, and the plan said to swap it. Adds roughly 5 to 8 MB to the APK while minify is off.
- **No WebSocket / no `nanohttpd-websocket`.** The web UI reads native return values synchronously, so calls are relayed as the plan's Bridge v2 envelope over synchronous same-origin HTTP (`POST /rpc`), and phone-side changes reach the desktop by long-poll (`GET /poll`). Same function, fewer unverified APIs.
- **One registry permission** `network` (INTERNET + ACCESS_WIFI_STATE) instead of two ids pointing at the same manifest entry.
- **Weekly auto-backup is a reminder**, because the passphrase is never stored (the plan's own rule), so the app cannot encrypt on its own.
- `NetworkBoundaryTest`: the analytics marker `amplitude` became `com.amplitude` (a vibration "amplitude" variable in `BrainyService` would otherwise fail it).
- Diagnostics categories for Local Sync / Cloud backup were not added (would change the Diag enums and their tests).
- Assist "Cloud (your key)" / "own model link" were **not** built: the plan allows a socket only for Local Sync and Drive backup, and forbids changes under `llm/`.

## Local Sync notes
Desktop UI files, caching and live sync are described in `DESKTOP_UI.md`. The menu is now Settings > Backup and sync (Local Sync and Cloud backup sit under the existing backup settings).

Desktop and phone both edit the web-only stores (`sandpiper_state_v2`, reminders, fitness blob). Changes are applied live on the other side without a reload; last writer wins. Pairings are memory-only. HTTP, not HTTPS: use trusted Wi-Fi.

## Verification status
Verified in headless Chromium: the settings cards, and the desktop bridge against a fake phone server that mimics the protocol (pairing page, cookie, snapshot, write-back, relay, change banner). **Not compiled, not run on a device:** every Kotlin file (`remote/*`, `backup/*`, Bridge/MainActivity/LifeBus edits), the NanoHTTPD server, Google authorization, Drive REST calls, and all new JUnit tests (`PairingManagerTest`, `RemoteRpcTest`, `LifeBusRemoteSyncTest`, `BackupCryptoTest`, `CloudBackupManifestTest`, `NetworkBoundaryTest`). Dependency versions (`nanohttpd 2.3.1`, `play-services-auth 21.2.0`, `bcprov-jdk18on 1.78.1`) were not resolved here (no network).
