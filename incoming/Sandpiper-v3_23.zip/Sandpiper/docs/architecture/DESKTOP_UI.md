# Sandpiper Desktop (the web UI a paired computer opens)

The desktop view has its own folder and entry file, so you can restyle or replace it without touching the phone UI.

```
app/src/main/assets/desktop/
  sandpiper-desktop.html   the shell a desktop browser opens at "/" (the "Sandpiper Desktop" page)
  desktop.css              desktop-only theme, injected into the app frame (retheme here)
  desktop.js               desktop-only behaviour (window title, shortcuts), runs in the shell
  remote-bridge.js         the link to the phone (window.SandpiperNative over Local Sync). Edit only to change the protocol.
```

How it fits together
- The phone serves `/` as `desktop/sandpiper-desktop.html`. The shell hosts the normal app (`/index.html`) in a full-window frame, then `desktop.js` injects `desktop.css` into that frame. The phone's own WebView never loads anything in `desktop/`.
- To change the desktop look: edit `desktop.css` (the app's design tokens `--bg`, `--text`, `--accent` ... can be overridden there). To change layout or add desktop-only features: edit `sandpiper-desktop.html` / `desktop.js`. To replace the whole desktop UI: keep the file name and the `<iframe id="spApp">` contract (the bridge reaches `SpApp.reloadState()` inside it), or update `remote-bridge.js` accordingly.
- Every HTML file the phone serves gets `/desktop/remote-bridge.js` injected automatically.

Speed
- Static files are gzip-compressed once, served with ETag and a 1-hour cache, so repeat loads come from the browser cache. Right after pairing, the pairing page fetches every asset in parallel (`/_manifest`) with a progress bar, so the first real load is already warm.
- The app makes hundreds of tiny native calls at start-up. The bridge fetches all settings in one call and answers reads from memory, sends settings/log writes in the background, and briefly caches repeated polling reads.

Live sync (both directions)
- Desktop edit: the changed web state is sent to the phone (`POST /ls`), the phone page re-reads it at once (`SpApp.reloadState()`), including the Planner list and reminders.
- Phone edit: the phone page notifies the server (`remoteChanged`), the desktop long-poll wakes, pulls the phone data and calls `SpApp.reloadState()`. Nothing reloads and nothing you are typing is lost.
- Both sides edit one shared blob per store, last writer wins. Native-backed data (finance, planner tasks) goes through the phone directly.
