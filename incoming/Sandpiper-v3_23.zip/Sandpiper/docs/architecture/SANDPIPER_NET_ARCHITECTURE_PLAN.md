# Sandpiper: Network Boundary, Local Desktop Sync & Encrypted Cloud Backup — Plan, Schematics and the One Command

> Local-first, not offline-first. Exactly one on-device source of truth. The network is a transport the user
> explicitly turns on for two purposes only: (1) talking to a paired desktop browser on the same LAN, (2) uploading
> a client-encrypted backup blob to a cloud store the user controls. Nothing else ever opens a socket.
> **The AI subsystem (Little Brain) keeps zero network code, unchanged.**

Developer/maintainer document. Lives in `docs/architecture/`, outside `app/`, so Gradle never packages it into the
APK. This file supersedes the network-related clauses of `docs/architecture/SANDPIPER_CENTRAL_BACKEND_PLAN.md`
(see §0.1) without touching anything else that plan already achieved.

---

## 0. Ground truth this plan was written against

This plan is written against the uploaded **v3.20 / versionCode 20 / versionName 1.16.0** source tree, not the
original v3.3 snapshot. Specifically verified in the real code before writing a single instruction below:

- `AndroidManifest.xml` currently declares **no `INTERNET` permission**, with the comment `<!-- No INTERNET
  permission on purpose: Sandpiper is fully offline. -->` directly above the permission block.
- `app/src/test/java/com/vastanzil/sandpiper/NoNetworkTest.kt` is a **mandatory, currently-passing JVM test** that
  (a) walks every `.kt`/`.xml` file under `src/main` and fails the build if it contains any of
  `java.net.`, `HttpURLConnection`, `HttpsURLConnection`, `okhttp`, `android.permission.INTERNET`,
  `ACCESS_NETWORK_STATE`, `DownloadManager`, `URLConnection`; and (b) fails the build if `app/build.gradle.kts`
  contains `okhttp`, `retrofit`, `volley`, `ktor`, or `httpclient`. **This test will fail the moment `INTERNET` is
  added and must be deliberately rewritten, not deleted**, as part of Stage N1 below — if whatever executes this
  plan does not touch this file, the whole plan cannot pass its own gate, by design.
- `docs/architecture/SANDPIPER_CENTRAL_BACKEND_PLAN.md` §1, §10 and the literal "ONE COMMAND" prompt in its §14
  currently instruct future work to "Never add the INTERNET permission, cloud, accounts..." and list cloud sync as
  an explicit non-goal. That document is the project's own standing instruction set, so it is **patched, not
  ignored** — see §0.1.
- Persistent storage is centered on `sandpiper_central.db` via `CentralDb.kt`, located by `DbLocation.kt` (which
  already does: shared-vs-private resolution, `PRAGMA quick_check` integrity verification before adopting a copy,
  a `db_live` marker instead of guessing from file dates, and `snapshotLive()` — a lock-respecting live copy of the
  open database used for safe export).
- `LifeBus.kt` already exists and is already called after every native write, from every current writer (web layer,
  widgets, SMS receiver, scheduler): `LifeBus.changed(c)` → currently fans out to `Widgets.refreshSoon(c)` and
  `StorageJobs.schedule(c)`, wrapped so a subscriber failure can never break a writer.
- `docs/architecture/SANDPIPER_CENTRAL_BACKEND_PLAN.md` §3.9 already specifies a Bridge v2 JSON-RPC envelope
  (`{v,id,m,p}` request / `{v,id,ok,d,e}` response, allow-listed methods, schema versioning, 1 MB payload cap).
  This plan reuses that exact envelope shape over WebSocket rather than inventing a second protocol.
- `app/build.gradle.kts` dependencies today: `core-ktx`, `appcompat`, `activity-ktx`, `webkit`, `work-runtime-ktx`,
  plus test-only `junit` and `org.json`. No DI framework, no networking library, no Room (the backend plan's Room
  migration is a separate, independent track — this plan does not assume Room exists; where it names a table it
  means a raw `sandpiper_central.db` table via `CentralDb`, matching what the repo actually has today).
- `features.json` + `FeatureRegistry.kt` are the existing data-driven source of truth for every permission and
  setting shown in the UI. New permissions/settings are **registry entries**, not new hand-built screens, matching
  the existing pattern exactly.
- The AI subsystem lives under `app/src/main/java/com/vastanzil/sandpiper/llm/` (`LlmCore`, `LlmEngine`, `LlmGuard`,
  `LlmStore`, `LocalModelProvider`, `ModelImporter`) and is covered by `LlmCoreTest.kt`. `NoNetworkTest`'s own
  doc-comment states the product promise it enforces: *"The Little brain adds NO network code and NO INTERNET
  permission: models come from the phone's own AI or from a file the user picks."* This plan does not touch any
  file under `llm/` and explicitly re-asserts that boundary in the replacement test (§6.1).

Nothing below assumes a file, class, or test exists unless it was confirmed above or is new code this plan
introduces by name.

### 0.1 Patch to `SANDPIPER_CENTRAL_BACKEND_PLAN.md`

Before Stage N0 runs, apply this exact textual change to the existing plan file (do this first; it is not optional
— every stage below depends on the project's own standing instructions no longer contradicting it):

- In §1 "Principles", row 1: change `Offline-first | No INTERNET permission, no cloud, no accounts, no analytics`
  to `Local-first | No INTERNET permission unless the user turns on Local Sync or Cloud Backup; no analytics, no
  ads, no accounts beyond the user's own Google Drive sign-in for an opt-in encrypted backup`.
- In §10 "Explicit non-goals": remove `Cloud sync, accounts,` from the list (keep everything else: analytics, ads,
  Hilt/Koin, event-bus libraries, dynamic code loading, password-protected backups deferred, etc. — those remain
  real non-goals).
- In §14's literal command text, rule 5: change `Never add the INTERNET permission, cloud, accounts, analytics,
  ads,...` to `Never add analytics, ads, or dynamic code loading. INTERNET permission, Local Sync and encrypted
  Google Drive backup are governed exclusively by docs/architecture/SANDPIPER_NET_ARCHITECTURE_PLAN.md — do not
  add or remove network code outside that plan.`
- Add one line to §2 "What already exists": `Change notification | LifeBus.changed() after every native write |
  Declare RemoteSync as a third subscriber; do not change existing subscribers`.

Do not otherwise edit that file. Do not re-run its own Stage S-sequence as part of this plan.

---

## 1. Scope and non-goals

**In scope:** one new permission (`INTERNET`) gated behind two explicit opt-in features; a local HTTP/WebSocket
server for pairing a desktop browser to the phone over LAN; a remote-bridge JS shim that lets the existing
`index.html`/`planner.html`/`fitness.html`/`piper.html` run unmodified on a desktop browser; client-side
AES-256-GCM encryption with an Argon2id-derived key for an opt-in Google Drive backup; registry entries in
`features.json`; diagnostics categories; the mandatory rewrite of `NoNetworkTest.kt`; a full test matrix; a staged
Claude Code execution command that ends in a built, zipped debug APK plus its test reports.

**Out of scope (do not implement, do not stub):** multi-device fleets, remote access from outside the LAN, NAT
traversal/relay/STUN, any analytics or crash-reporting SDK, any change to `llm/*`, any change to Brainy's detection
logic, any change to the reward/Day-Hub pipeline, Room migration (tracked separately in the central backend plan),
password manager integration, biometric unlock for the passphrase (reasonable v2, not this plan).

---

## 2. Target architecture

```mermaid
flowchart LR
  subgraph PHONE[Android phone - source of truth]
    DB[(sandpiper_central.db via CentralDb / DbLocation)]
    LB[LifeBus.changed]
    RSS[RemoteSyncServer - NanoHTTPD + WebSocket]
    PM[PairingManager]
    CB[CloudBackup + BackupCrypto]
    WV[WebView - index.html etc, unchanged]
  end
  subgraph DESKTOP[Desktop browser - same Wi-Fi]
    BR[Browser tab]
    RB[remote-bridge.js]
  end
  subgraph DRIVE[Google Drive - opaque storage only]
    APPDATA[appDataFolder: one encrypted blob]
  end
  WV -- existing JavascriptInterface, unchanged --> DB
  DB -- LifeBus.changed --> LB
  LB -- new subscriber --> RSS
  RSS <-- "ws://<lan-ip>:<port> JSON-RPC (Bridge v2 envelope)" --> RB
  RB -- "same window.SandpiperNative surface" --> BR
  PM -- "6-digit code, LAN only, never leaves PHONE" --> BR
  CB -- "ciphertext only, key never uploaded" --> APPDATA
  PHONE -. "no other socket, ever" .-> INTERNET((rest of the internet))
```

### 2.1 Why the existing web UI needs zero changes

`index.html`/`planner.html`/`fitness.html`/`piper.html` call `window.SandpiperNative.*` (the `@JavascriptInterface`
object from `Bridge.kt`) and, for the parts not yet migrated to native storage, read/write `localStorage` directly.
On desktop:

- `remote-bridge.js` is served to the desktop only (never loaded into the phone's own WebView) and implements an
  object with the **same method names** `Bridge.kt` exposes today, each one serializing the call into the Bridge v2
  JSON-RPC envelope and sending it over the already-open WebSocket, then resolving/rejecting a Promise (or calling
  the expected `window.on<Thing>` callback) when the matching response arrives. `index.html` et al. call
  `SandpiperNative.foo(...)`; they do not know or care whether that object is backed by a real `@JavascriptInterface`
  or a WebSocket relay.
- `localStorage`-only state (`sandpiper_state_v2`, `sandpiper_reminders`, fitness blob) is **mirrored**, not
  bridged: on pairing, the phone pushes a one-time snapshot of these keys to the desktop tab's own `localStorage`
  (desktop page boots with phone's current data), and from then on `planner-bridge.js`'s existing
  `Storage.prototype.setItem` monkey-patch pattern is reused on the desktop side to intercept writes and ship them
  back over the socket to the phone, which writes them into its own real `localStorage` via
  `MainActivity.runOnUiThread { webView.evaluateJavascript(...) }`. This is a stopgap, not the target state — the
  real fix is finishing the central backend plan's Stage S5 (Bridge v2 + legacy migration) so these three keys
  become native-backed like Finance already is, at which point this mirroring code deletes itself (see §7).

---

## 3. Permission and manifest changes

Add exactly these two lines to `AndroidManifest.xml`, replacing the existing "no INTERNET" comment with an
accurate one:

```xml
<!-- INTERNET is used ONLY for: (1) a local HTTP/WebSocket server reachable on the same LAN for desktop
     pairing, started only while the user has Settings > Local Sync turned on; (2) uploading a client-encrypted
     backup blob to the signed-in user's own Google Drive appDataFolder, only when Settings > Cloud Backup is
     turned on. No analytics, no telemetry, no third-party endpoint, ever. -->
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
```

Do not add `ACCESS_NETWORK_STATE`, `CHANGE_WIFI_MULTICAST_STATE`, or any broader networking permission in this
plan. (`ACCESS_NETWORK_STATE` is explicitly still forbidden by the replacement test in §6.1 — it is not needed
because the server simply fails closed if it cannot bind, and the UI reports that rather than pre-checking
connectivity state.)

`android:usesCleartextTraffic="false"` on the `<application>` tag **stays exactly as-is**. The local server is
plain HTTP/WS on the LAN (cleartext does not apply to it — that flag governs the app's own outgoing requests, i.e.
the Drive upload, which is HTTPS-only via Google's REST endpoint and therefore already compliant). Do not weaken
this flag.

---

## 4. New Kotlin modules

All new files go directly under `app/src/main/java/com/vastanzil/sandpiper/` and
`app/src/main/java/com/vastanzil/sandpiper/remote/` (new package), matching the project's existing flat/by-feature
layout (compare `llm/` as the precedent for a sub-package).

### 4.1 `remote/RemoteSyncServer.kt`

- Wraps a `NanoHTTPD` instance (add dependency, see §5) bound explicitly to the device's current Wi-Fi interface
  address (read via `WifiManager`/`ConnectivityManager` link properties — never `0.0.0.0` bound without first
  resolving and logging the actual LAN address the UI will display), fixed port (default `8787`, configurable in
  Settings, range-validated 1024–65535).
- Exposes two endpoints:
  - `GET /` and `GET /assets/*` → streams `index.html`/`planner.html`/`fitness.html`/`piper.html`/`remote-bridge.js`
    and the rest of `app/src/main/assets/` straight from `AssetManager`, with one substitution: injects a `<script
    src="remote-bridge.js"></script>` tag and strips/no-ops the real `window.SandpiperNative` bridge object if it
    were ever present (it never is on desktop, since this is a plain browser, but guard it anyway for defense in
    depth).
  - `GET /ws` (upgrade) → the WebSocket channel carrying the Bridge v2 envelope both directions.
- Lifecycle: `start()`/`stop()` called only from the Settings-driven toggle (§5.2), never auto-started on boot,
  never started by `BootReceiver`. Stops itself automatically if no client has been connected for 10 minutes after
  being idle-started by mistake (safety net, logged as `REMOTE_SYNC/idle_stop`).
- On every inbound Bridge v2 request: validate `v==1`, allow-list `m` against the exact same method allow-list
  `Bridge.kt` itself exposes (do not invent new native methods for this — every `m` this server accepts must
  already be a real `@JavascriptInterface` method on `Bridge`; the server is a dumb relay, not a second bridge
  implementation), enforce the 1 MB payload cap, run the actual call on a background thread, post the result back
  on the WebSocket send thread. Reject anything else with `{ok:false,e:{code:"E_METHOD_NOT_ALLOWED"}}`.

### 4.2 `remote/PairingManager.kt`

- `startPairing(): PairingState` generates a random 6-digit code (`SecureRandom`, not `Random`), valid for 90
  seconds, regenerated automatically on expiry while the pairing screen is open, invalidated immediately on first
  successful use.
- On successful code entry from a client: issue a random 256-bit session token (`SecureRandom`), store it
  **in-memory only** (a `ConcurrentHashMap<token, PairedDevice>`, never written to disk, never in
  `sp_app_settings`/`SharedPreferences`/the DB) so a force-stop or reboot invalidates every pairing and the user
  must re-pair — this is a deliberate simplicity/safety tradeoff for v1, not an oversight; document it as such in
  the in-app copy ("you'll need to re-enter the code after restarting Sandpiper").
- Rate limiting: 5 wrong attempts from a given source IP within 60 seconds → that IP is locked out for 60 seconds,
  tracked in-memory, logged as `REMOTE_SYNC/code_rejected` with a count, never the attempted code itself.
- The paired device list (so far: zero persistence) means every `/ws` request must carry the session token as a
  query param or header; the server checks it against the in-memory map before accepting any Bridge v2 call.

### 4.3 `remote/RemoteSyncSettings.kt` (thin, mirrors `AppSettings.kt`'s existing pattern)

Native-only tunables: port, auto-stop-when-idle on/off, "require code every pairing" vs "remember this browser for
this app-session" (still memory-only either way — "remember" just means don't re-prompt while the server process
is alive).

### 4.4 `LifeBus.kt` — one-line addition, nothing else in the file changes

```kotlin
internal object LifeBus {
    fun changed(c: Context) {
        try { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(c) } catch (e: Throwable) { }
        try { StorageJobs.schedule(c) } catch (e: Throwable) { }
        try { com.vastanzil.sandpiper.remote.RemoteSyncServer.notifyChanged(c) } catch (e: Throwable) { }
    }
}
```

`RemoteSyncServer.notifyChanged` must be a no-op cheaply (return immediately) when the server is not running —
check an in-memory flag before doing any work, so this addition has zero cost for the 99% of app lifetime the
feature is off.

### 4.5 `backup/BackupCrypto.kt`

- **Pure Kotlin, zero Android imports** (matches the project's existing precedent — `DocChunker.kt`,
  `SwipeDetector.kt`, `WebReels.kt` are all pure-Kotlin and JVM-unit-tested for exactly this auditability reason;
  this file must follow the same discipline since it is the one place a bug is catastrophic).
- `deriveKey(passphrase: CharArray, salt: ByteArray): SecretKey` — Argon2id via a small, explicitly-added,
  **non-networking** dependency (see §5 — this is the one new runtime dependency besides NanoHTTPD, and it must be
  verified to contain no networking code the same way `NoNetworkTest` verifies the rest of the app, see §6.1).
  Parameters: memory 19 MiB minimum, iterations 2, parallelism 1 (OWASP's current baseline minimums for a
  mobile-constrained Argon2id; do not go lower) — tune up, never down, if device testing shows headroom.
- `encrypt(plaintext: ByteArray, key: SecretKey): EncryptedBlob` — AES-256-GCM, random 96-bit nonce per call, nonce
  prepended to ciphertext, GCM tag included (standard AEAD construction). Returns `{salt, nonce, ciphertext+tag,
  kdfParams}` — all four fields are needed to decrypt later and all four are non-secret (safe to store alongside
  the ciphertext in Drive).
- `decrypt(blob: EncryptedBlob, key: SecretKey): ByteArray` — throws a typed `BackupCryptoException` (wrong
  passphrase / corrupt blob / unsupported version) that the UI maps to a plain-language message. Never logs the
  passphrase, the derived key, or plaintext size beyond a rounded bucket.
- **Explicit, user-facing commitment to bake into the UI copy wherever the passphrase is set:** *"This passphrase
  encrypts your backup before it leaves your phone. Sandpiper does not store it and cannot recover it. If you lose
  it, that backup cannot be restored — not by you, not by us."* Do not soften this. Do not add a "recovery key"
  mechanism that would make the sentence false.

### 4.6 `backup/CloudBackup.kt`

- Google Sign-In (`drive.appdata` scope only — never broader Drive scope; this keeps the backup invisible in the
  user's normal Drive UI and keeps the permission request itself legible: "see and manage its own configuration
  data in Google Drive," not "see all your files").
- Upload/download via plain HTTPS REST calls to `https://www.googleapis.com/upload/drive/v3/files` and
  `https://www.googleapis.com/drive/v3/files` using `HttpURLConnection` (already permitted once `NoNetworkTest` is
  rewritten per §6.1 to allow it specifically for files under `backup/`) — **do not add OkHttp/Retrofit/Ktor**; the
  existing `NoNetworkTest.gradleAddsNoNetworkLibraries` check stays intact for those four names and this plan does
  not touch that assertion (see §6.1, only the file-path assertion is narrowed).
- Builds the uploaded object as: `manifest.json` (app id, format version, app version, DB schema version, KDF
  params, salt, nonce — everything non-secret needed to attempt a decrypt) + one `.bin` ciphertext file, matching
  the manifest-plus-archive shape already specified for local backup v3 in the central backend plan §3.7, so the
  two backup systems share one mental model even though this plan does not implement v3 local backup itself.
- `logBackup(restore, ok)` (already exists on `Bridge.kt` per the original project context) is extended with a
  `cloud: Boolean` parameter; the `DCat`/enum logging discipline from the central backend plan (§4 there) is
  followed exactly — counts and enums only, never passphrase, never file size beyond a rounded bucket, never the
  Google account email.

---

## 5. Dependency changes

Add to `app/build.gradle.kts`, nothing else:

```kotlin
dependencies {
    // existing lines unchanged...
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("org.nanohttpd:nanohttpd-websocket:2.3.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("at.favre.lib:bcrypt:0.10.2") // Argon2id — swap for a maintained Argon2 JVM impl if unavailable; do not substitute PBKDF2 without updating §4.5
}
```

Before relying on exact version numbers above, **verify current stable releases** (this plan was written without
live network access to Maven Central; treat `2.3.1`/`21.2.0`/`0.10.2` as placeholders to confirm, not facts to
trust blindly — this is the one place in this document where a number must be re-checked against reality before
the build, and the executing agent must record what it actually resolved to in the final report per §9).

Do **not** add `okhttp`, `retrofit`, `volley`, `ktor`, or any generic `httpclient` — `CloudBackup.kt` uses the
platform's own `HttpURLConnection`, both because it is sufficient for two REST calls and because it keeps
`NoNetworkTest.gradleAddsNoNetworkLibraries` passing unmodified.

---

## 6. `features.json` / `FeatureRegistry` additions

Add one new feature group `local_sync` and extend `backup`:

```json
{
  "features": {
    "local_sync": {
      "label": "Local Sync (Desktop)",
      "settings": [
        { "id": "local_sync.enabled", "type": "toggle", "default": false },
        { "id": "local_sync.port", "type": "number", "default": 8787, "min": 1024, "max": 65535 },
        { "id": "local_sync.remember_session", "type": "toggle", "default": true }
      ]
    },
    "backup": {
      "settings": [
        { "id": "backup.cloud.enabled", "type": "toggle", "default": false, "requiresPermission": "internet_cloud" },
        { "id": "backup.cloud.auto_weekly", "type": "toggle", "default": false }
      ]
    }
  },
  "permissions": [
    { "id": "internet_local_sync", "manifestPermission": "INTERNET", "why": "Lets a desktop browser on your Wi-Fi connect to this phone when Local Sync is on." },
    { "id": "internet_cloud", "manifestPermission": "INTERNET", "why": "Lets Sandpiper upload your encrypted backup to your own Google Drive when Cloud Backup is on." }
  ]
}
```

Both registry permission entries map to the **same single manifest permission** (`INTERNET`) — this is intentional
and must be handled by `FeatureRegistry.kt`/the Permissions panel the same way it already handles any other
one-manifest-permission-many-features case, if one exists, or added as a small, explicit special case if not: the
live `permState()`-style check for `INTERNET` is simply "is this permission present in the manifest" (always true
once added) gated by the feature's own `*.enabled` setting, not by a runtime grant dialog — `INTERNET` is a normal
(non-dangerous) permission and Android grants it at install time with no runtime prompt. The Settings UI's "why
this exists" sheet is therefore the *only* user-facing gate, and it must be shown and explicitly accepted once per
feature before its toggle can be turned on for the first time.

---

## 7. What this plan deliberately does NOT fix (tracked debt, not oversight)

- `sandpiper_state_v2`, `sandpiper_reminders`, and the fitness `localStorage` blob remain web-only until the
  central backend plan's Stage S5 lands. §2.1's mirroring approach is a bridge (pun acknowledged), not a
  replacement for finishing that migration. Do not attempt to migrate these stores as part of this plan — that is
  explicitly out of scope per §1 and belongs to the other document.
- Voice-note audio (`recordings/` + `voice_note` table per `STORAGE.md`) is **not** streamed to desktop in this
  plan. Desktop can list/play already-synced metadata once Bridge v2 methods for it exist, but live recording stays
  phone-only — same scoping decision as discussed for the original local-hosting concept, still correct here.
- No mDNS/NSD discovery. The pairing screen shows the resolved LAN IP and port as text; the user types it into the
  desktop browser. This is a conscious simplicity choice, not a limitation to silently fix later without
  discussion.

---

## 6.1 `NoNetworkTest.kt` → `NetworkBoundaryTest.kt` (mandatory, exact replacement)

Delete `NoNetworkTest.kt` and create `NetworkBoundaryTest.kt` in the same package and directory. This is the single
highest-risk step in this plan — get it narrow, not permissive:

```kotlin
package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * The product promise, updated: Sandpiper opens a socket ONLY from files under remote/ and backup/, and ONLY for
 * Local Sync (LAN) and Cloud Backup (the user's own Google Drive appDataFolder). The Little Brain (llm/) adds NO
 * network code and NO reference to any networking API, ever — that boundary is unchanged and re-checked here.
 * Nothing outside remote/ and backup/ may reference a networking API. No analytics/crash-reporting/ad SDK anywhere.
 */
class NetworkBoundaryTest {
    private val networkApis = listOf("java.net.", "HttpURLConnection", "HttpsURLConnection", "okhttp",
        "ACCESS_NETWORK_STATE", "DownloadManager", "URLConnection", "WebSocket", "NanoHTTPD")
    private val allowedDirs = listOf("remote/", "backup/")
    private val analyticsMarkers = listOf("firebase", "crashlytics", "analytics", "mixpanel", "amplitude", "sentry")

    @Test fun networkApisOnlyInRemoteOrBackupPackages() {
        val hits = ArrayList<String>()
        File("src/main").walkTopDown().filter { it.isFile && it.extension == "kt" }.forEach { f ->
            val rel = f.path.substringAfter("java/com/vastanzil/sandpiper/").replace('\\', '/')
            val inAllowed = allowedDirs.any { rel.startsWith(it) }
            val text = f.readText()
            if (!inAllowed) for (w in networkApis) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun llmPackageStillHasNoNetworkCodeOrPermissionReference() {
        val hits = ArrayList<String>()
        File("src/main/java/com/vastanzil/sandpiper/llm").walkTopDown().filter { it.isFile }.forEach { f ->
            val text = f.readText()
            for (w in networkApis + listOf("INTERNET")) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun noAnalyticsOrAdSdkAnywhere() {
        val hits = ArrayList<String>()
        File("src/main").walkTopDown().filter { it.isFile }.forEach { f ->
            val text = f.readText().lowercase()
            for (w in analyticsMarkers) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun manifestInternetPermissionHasAnExplanatoryCommentAboveIt() {
        val m = File("src/main/AndroidManifest.xml").readText()
        assertTrue(m.contains("INTERNET"))
        val idx = m.indexOf("android.permission.INTERNET")
        val before = m.substring(maxOf(0, idx - 400), idx)
        assertTrue(before.contains("<!--") && before.contains("Local Sync") && before.contains("Google Drive"))
    }

    @Test fun gradleNetworkingLibrariesAreExactlyTheAllowedSet() {
        val g = File("build.gradle.kts").readText().lowercase()
        for (forbidden in listOf("retrofit", "volley", "ktor")) assertEquals(false, g.contains(forbidden))
        assertTrue(g.contains("nanohttpd"))
    }
}
```

Note the last test asserts `okhttp` is **absent** implicitly (it is not in the forbidden-check list above only
because `nanohttpd` and the Drive REST calls use `HttpURLConnection`, not OkHttp — if a future dependency ever adds
OkHttp transitively, add an explicit assertion against it at that time; do not pre-empt it here with a guess).

---

## 8. Testing matrix (every row is a real gate, not a suggestion)

| Area | Test file | Must assert |
|---|---|---|
| Network boundary | `NetworkBoundaryTest.kt` | Exactly as written in §6.1 |
| Pairing | `PairingManagerTest.kt` (pure Kotlin, no Android) | Code is 6 digits; expires at 90s; single-use; lockout after 5 wrong attempts/60s; lockout clears after window; two concurrent `startPairing()` calls never produce the same code in the same window |
| Bridge relay allow-list | `RemoteSyncServerMethodTest.kt` | Every `m` value the server accepts has a matching real method on `Bridge`; an unlisted `m` returns `E_METHOD_NOT_ALLOWED`; payload over 1 MB is rejected before being parsed |
| Crypto round-trip | `BackupCryptoTest.kt` (pure Kotlin) | encrypt→decrypt with correct passphrase recovers original bytes exactly; wrong passphrase throws the typed exception and never returns partial plaintext; two encrypts of the same plaintext produce different ciphertext (nonce uniqueness); tampering one byte of ciphertext fails GCM auth rather than decrypting silently |
| Cloud backup manifest | `CloudBackupManifestTest.kt` | Manifest round-trips through JSON with all required fields; a manifest missing any required field is rejected before any decrypt is attempted |
| LifeBus integration | `LifeBusRemoteSyncTest.kt` | `notifyChanged` is a no-op (measured: does not touch the filesystem or network) when the server is stopped; existing `Widgets.refreshSoon`/`StorageJobs.schedule` calls are unchanged in count/order versus before this plan (regression guard against breaking the existing subscribers) |
| Settings registry | `FeatureRegistryTest.kt` (existing file, extend) | New `local_sync`/`backup.cloud.*` entries pass the file's existing consistency rules (unique ids, valid defaults) without modifying its existing assertions |
| Existing suite, unmodified | `AppSettingsTest`, `BrainyAppsTest`, `DiagnosticsTest`, `DocChunkerTest`, `SwipeDetectorTest`, `WebReelsTest`, `PlannerCoreTest`, `DayEndTest`, `ActivityCoreTest`, `widget/WidgetCoreTest`, `llm/LlmCoreTest`, `SmsFilterTest` | All still pass, zero changes to these files |
| Packaging | manual check in the one command | Merged manifest contains exactly one `INTERNET` permission with the required comment; `docs/` absent from the APK (reuses the existing check pattern from the central backend plan) |

---

## 9. Stages and gates

Each stage ends with `./gradlew testDebugUnitTest assembleDebug`. A stage is not done until its gate passes.

| Stage | Work | Gate |
|---|---|---|
| **N0** | Git branch `net-architecture`; apply the §0.1 patch to `SANDPIPER_CENTRAL_BACKEND_PLAN.md`; confirm baseline build green before any other change | Baseline green |
| **N1** | Add `INTERNET`/`ACCESS_WIFI_STATE` to manifest with the required comment; delete `NoNetworkTest.kt`; add `NetworkBoundaryTest.kt` exactly as in §6.1 | `NetworkBoundaryTest` passes (it will fail until N2–N5 exist in the right packages, which is expected — the gate for N1 specifically is just the manifest comment + file swap compiling) |
| **N2** | Add dependencies (§5), resolving real current versions; `BackupCrypto.kt` + its test | `BackupCryptoTest` passes; `NetworkBoundaryTest.llmPackageStillHasNoNetworkCodeOrPermissionReference` passes |
| **N3** | `PairingManager.kt` + its test | `PairingManagerTest` passes |
| **N4** | `RemoteSyncServer.kt`, `RemoteSyncSettings.kt`, the `LifeBus.kt` one-line addition, `assets/remote-bridge.js` | `RemoteSyncServerMethodTest`, `LifeBusRemoteSyncTest` pass |
| **N5** | `CloudBackup.kt`, Google Sign-In wiring, Settings UI entries for both features in `features.json`, the mandatory passphrase-loss copy from §4.5 present in the actual UI string resources | `CloudBackupManifestTest` passes; `FeatureRegistryTest` passes with the new entries |
| **N6** | Full regression pass of every existing test file listed in §8's last row, unmodified | All green, zero diffs to those files |
| **N7** | Final packaging: `./gradlew assembleDebug`, `unzip -l` check for manifest permission + absence of `docs/`, zip the APK together with the full test report directory into one deliverable archive | Archive produced; every claim in the final report labeled compiled / unit-tested / device-tested, with device-tested explicitly marked **not performed** unless a real device/emulator run actually happened |

---

## 10. Definition of done and honest reporting

Done only if: every gate in §9 is green; the merged manifest contains `INTERNET` and `ACCESS_WIFI_STATE` and
nothing broader; `NetworkBoundaryTest` (not the deleted `NoNetworkTest`) is the file present in the final tree;
`llm/*` has zero diffs; the final deliverable is a single zip containing the debug APK, the Gradle test reports
directory, and this plan file as executed. The final report must state plainly whether Gradle actually ran in the
execution environment, whether any device/emulator test ran, and must not claim "device-tested" for anything that
only ran as a JVM unit test. If the exact dependency versions in §5 do not resolve, the report must say what was
substituted and why, not silently change the plan without flagging it.

---

## 11. THE ONE COMMAND (paste this as a single message into Claude Code)

```text
You are a senior Android architect and Kotlin engineer working in the existing Sandpiper project
(package com.vastanzil.sandpiper; versionCode 20, versionName 1.16.0; AGP + Kotlin 1.9.x line already pinned in
the repo's own build files — read them, do not assume a version; Java 17, compileSdk/targetSdk 34, minSdk 29;
Kotlin shell + WebView UI). Execute docs/architecture/SANDPIPER_NET_ARCHITECTURE_PLAN.md in ONE continuous run,
stages N0 through N7 in order, exactly as written.

RULES
1. Implement; do not propose. Preserve every existing feature, UI behaviour, reward calculation and currently-
   passing test unchanged, except the one deliberate, explicit replacement of NoNetworkTest.kt with
   NetworkBoundaryTest.kt described in the plan's section 6.1 — do this replacement exactly as specified, do not
   simply delete the old test without adding the new one.
2. Before editing: inspect git status, create branch `net-architecture`, commit after each stage. No destructive
   git operations.
3. Apply the plan's section 0.1 patch to docs/architecture/SANDPIPER_CENTRAL_BACKEND_PLAN.md FIRST, before any
   code change, exactly as that section specifies, touching only the lines it names.
4. After EVERY stage run: ./gradlew testDebugUnitTest assembleDebug. If it fails, fix and re-run. Do not start the
   next stage until the current stage's gate in section 9 passes. If a gate cannot pass, STOP and report the exact
   blocker; never skip, stub, or fake a passing result.
5. Do not touch any file under app/src/main/java/com/vastanzil/sandpiper/llm/ for any reason. Do not add network
   code, the INTERNET permission reference, or any new dependency anywhere outside the remote/ and backup/
   packages named in the plan.
6. Do not add OkHttp, Retrofit, Ktor, Volley, any analytics/crash-reporting/ad SDK, or any DI/event-bus framework.
   CloudBackup.kt uses HttpURLConnection only, as specified.
7. Before trusting the dependency version numbers in section 5, check what actually resolves in this build
   environment and record in the final report exactly what was used and why, if different from the plan's
   placeholders.
8. The passphrase-loss warning text in section 4.5 must appear verbatim (or a faithful equivalent you note as
   such) in the real UI, not just in a code comment.
9. Final deliverables, zipped into one archive: the debug APK, the full ./gradlew test report directory, this plan
   file, and a final report covering: every file added/changed, the real dependency versions used, every test run
   with its real result, the exact diff applied to SANDPIPER_CENTRAL_BACKEND_PLAN.md, and a plain statement of
   what was and was not device-tested. Do not invent results.
10. Label every claim compiled / unit-tested / device-tested. If Gradle could not be run at all in this
    environment, say so explicitly at the top of the final report before anything else.

Begin with N0 now and continue until N7 is complete or a gate blocks you.
```

---

*Plan version 1.0, written against the uploaded v3.20 (versionCode 20) source tree. Update this file and
`SANDPIPER_CENTRAL_BACKEND_PLAN.md`'s §0.1 patch together whenever either architecture changes — they are now
cross-referenced and must not be allowed to drift apart again.*
