package com.vastanzil.sandpiper.backup

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.fail
import org.junit.Test

class BackupCryptoTest {
    private val plain = "{\"app\":\"sandpiper\",\"state\":{\"txs\":[1,2,3]}} \u09f3 \uD83D\uDE00".toByteArray(Charsets.UTF_8)
    private val pass = "correct horse battery".toCharArray()

    @Test fun roundTrip() { assertArrayEquals(plain, BackupCrypto.decrypt(BackupCrypto.encrypt(plain, pass), pass)) }

    @Test fun wrongPassphraseThrowsTypedErrorAndNoPlaintext() {
        val b = BackupCrypto.encrypt(plain, pass)
        try { BackupCrypto.decrypt(b, "wrong".toCharArray()); fail() }
        catch (e: BackupCryptoException) { assertEquals(BackupCryptoException.Kind.WRONG_PASSPHRASE_OR_CORRUPT, e.kind) }
    }

    @Test fun twoEncryptionsDiffer() {
        val a = BackupCrypto.encrypt(plain, pass); val b = BackupCrypto.encrypt(plain, pass)
        assertFalse(a.payload.contentEquals(b.payload)); assertFalse(a.salt.contentEquals(b.salt))
    }

    @Test fun tamperedCiphertextFailsAuthentication() {
        val b = BackupCrypto.encrypt(plain, pass)
        val bad = b.payload.copyOf(); bad[bad.size - 1] = (bad[bad.size - 1].toInt() xor 1).toByte()
        try { BackupCrypto.decrypt(EncryptedBlob(b.version, b.salt, b.kdf, bad), pass); fail() }
        catch (e: BackupCryptoException) { assertEquals(BackupCryptoException.Kind.WRONG_PASSPHRASE_OR_CORRUPT, e.kind) }
    }

    @Test fun unsupportedVersionAndEmptyPassphrase() {
        val b = BackupCrypto.encrypt(plain, pass)
        try { BackupCrypto.decrypt(EncryptedBlob(99, b.salt, b.kdf, b.payload), pass); fail() }
        catch (e: BackupCryptoException) { assertEquals(BackupCryptoException.Kind.UNSUPPORTED_VERSION, e.kind) }
        try { BackupCrypto.encrypt(plain, CharArray(0)); fail() }
        catch (e: BackupCryptoException) { assertEquals(BackupCryptoException.Kind.EMPTY_PASSPHRASE, e.kind) }
    }

    @Test fun kdfDefaultsAreAtLeastTheOwaspBaseline() {
        val k = Kdf(); assertEquals(true, k.memKb >= 19_456 && k.iterations >= 2 && k.parallelism >= 1)
    }
}
