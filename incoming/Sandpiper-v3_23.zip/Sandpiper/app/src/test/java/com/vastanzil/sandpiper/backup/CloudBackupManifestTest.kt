package com.vastanzil.sandpiper.backup

import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test

class CloudBackupManifestTest {
    private val m = CloudManifest("sandpiper", 1, "1.18.0", 2, ByteArray(16) { it.toByte() }, Kdf(), 1234L)

    @Test fun roundTrips() {
        val r = CloudManifest.parse(m.toJson())
        assertEquals(m.appVersion, r.appVersion); assertEquals(m.dbSchema, r.dbSchema); assertEquals(m.kdf, r.kdf); assertEquals(1234L, r.createdAt)
        assertArrayEquals(m.salt, r.salt)
    }

    @Test fun anyMissingFieldIsRejected() {
        for (k in listOf("app", "format", "appVersion", "dbSchema", "salt", "kdfMemKb", "kdfIter", "kdfPar", "createdAt")) {
            val o = JSONObject(m.toJson()); o.remove(k)
            try { CloudManifest.parse(o.toString()); fail("accepted without $k") } catch (e: BackupCryptoException) { assertEquals(BackupCryptoException.Kind.BAD_MANIFEST, e.kind) }
        }
    }

    @Test fun wrongAppGarbageAndAbsurdKdfAreRejected() {
        for (t in listOf("nope", JSONObject(m.toJson()).put("app", "other").toString(), JSONObject(m.toJson()).put("kdfMemKb", 99_999_999).toString(), JSONObject(m.toJson()).put("salt", "***").toString())) {
            try { CloudManifest.parse(t); fail() } catch (e: BackupCryptoException) { assertEquals(BackupCryptoException.Kind.BAD_MANIFEST, e.kind) }
        }
    }
}
