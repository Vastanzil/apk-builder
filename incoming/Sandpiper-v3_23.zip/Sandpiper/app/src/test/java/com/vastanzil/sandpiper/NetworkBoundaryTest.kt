package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * The product promise, updated: Sandpiper opens a socket ONLY from files under remote/ and backup/, and ONLY for
 * Local Sync (LAN) and Cloud Backup (the user's own Google Drive appDataFolder). The Little Brain (llm/) adds NO
 * network code and NO reference to any networking API, ever. Nothing outside remote/ and backup/ may reference a
 * networking API. No analytics/crash-reporting/ad SDK anywhere.
 */
class NetworkBoundaryTest {
    private val networkApis = listOf("java.net.", "HttpURLConnection", "HttpsURLConnection", "okhttp",
        "ACCESS_NETWORK_STATE", "DownloadManager", "URLConnection", "WebSocket", "NanoHTTPD")
    private val allowedDirs = listOf("remote/", "backup/")
    private val analyticsMarkers = listOf("firebase", "crashlytics", "analytics", "mixpanel", "com.amplitude", "sentry")

    @Test fun networkApisOnlyInRemoteOrBackupPackages() {
        val hits = ArrayList<String>()
        File("src/main").walkTopDown().filter { it.isFile && it.extension == "kt" }.forEach { f ->
            val rel = f.path.replace('\\', '/').substringAfter("java/com/vastanzil/sandpiper/")
            val inAllowed = allowedDirs.any { rel.startsWith(it) }
            val text = f.readText()
            if (!inAllowed) for (w in networkApis) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun llmPackageStillHasNoNetworkCodeOrPermissionReference() {
        val hits = ArrayList<String>()
        File("src/main/java/com/vastanzil/sandpiper/llm").walkTopDown().filter { it.isFile }.forEach { f ->
            val text = f.readText()
            for (w in networkApis + listOf("INTERNET")) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun noAnalyticsOrAdSdkAnywhere() {
        val hits = ArrayList<String>()
        File("src/main").walkTopDown().filter { it.isFile }.forEach { f ->
            val text = f.readText().lowercase()
            for (w in analyticsMarkers) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun manifestInternetPermissionHasAnExplanatoryCommentAboveIt() {
        val m = File("src/main/AndroidManifest.xml").readText()
        assertTrue(m.contains("INTERNET"))
        val idx = m.indexOf("android.permission.INTERNET")
        val before = m.substring(maxOf(0, idx - 700), idx)
        assertTrue(before.contains("<!--") && before.contains("Local Sync") && before.contains("Google Drive"))
        assertEquals(1, Regex("android.permission.INTERNET").findAll(m).count())
    }

    @Test fun gradleNetworkingLibrariesAreExactlyTheAllowedSet() {
        val g = File("build.gradle.kts").readText().lowercase()
        for (forbidden in listOf("retrofit", "volley", "ktor", "okhttp", "httpclient")) assertEquals(forbidden, false, g.contains(forbidden))
        assertTrue(g.contains("nanohttpd"))
    }
}
