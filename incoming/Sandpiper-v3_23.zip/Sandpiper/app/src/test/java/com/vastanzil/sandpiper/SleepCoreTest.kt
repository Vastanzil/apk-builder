package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SleepCoreTest {
    private val h = 3_600_000L
    private val m = 60_000L

    @Test fun longestIdleBlockIsTheNight() {
        val e = SleepCore.estimate(listOf(longArrayOf(0, h), longArrayOf(5 * h, 13 * h)), 0, 20 * h)
        assertNotNull(e)
        assertEquals(5 * h, e!!.bed); assertEquals(13 * h, e.wake); assertEquals(480L, e.mins)
    }

    @Test fun briefCheckDoesNotSplitTheNight() {
        val e = SleepCore.estimate(listOf(longArrayOf(0, 4 * h), longArrayOf(4 * h + 5 * m, 8 * h)), 0, 20 * h)!!
        assertEquals(0L, e.bed); assertEquals(8 * h, e.wake); assertEquals(1, e.checks.size)
    }

    @Test fun shortBlocksAreRejected() {
        assertNull(SleepCore.estimate(listOf(longArrayOf(0, 2 * h), longArrayOf(3 * h, 4 * h)), 0, 20 * h))
    }

    @Test fun clipsToWindowAndEmptyIsNull() {
        assertNull(SleepCore.estimate(emptyList(), 0, h))
        val e = SleepCore.estimate(listOf(longArrayOf(-5 * h, 6 * h)), 0, 10 * h)!!
        assertEquals(0L, e.bed)
    }

    @Test fun checksLowerConfidence() {
        val clean = SleepCore.estimate(listOf(longArrayOf(0, 8 * h)), 0, 20 * h)!!
        val noisy = SleepCore.estimate(listOf(longArrayOf(0, 3 * h), longArrayOf(3 * h + 5 * m, 8 * h)), 0, 20 * h)!!
        assertTrue(noisy.confidence < clean.confidence)
        assertTrue(clean.confidence in 30..95)
    }

    /** The reported case: asleep 02:00 to 09:25, phone checked at 09:25, then left idle until 11:15. */
    @Test fun morningCheckEndsTheNightEvenIfThePhoneIsThenLeftAlone() {
        val e = SleepCore.estimate(listOf(longArrayOf(2 * h, 9 * h + 25 * m), longArrayOf(9 * h + 26 * m, 11 * h + 15 * m)), -4 * h, 12 * h)!!
        assertEquals(2 * h, e.bed); assertEquals(9 * h + 25 * m, e.wake); assertEquals(445L, e.mins)
    }

    @Test fun nightCheckBeforeMorningStillMerges() {
        val e = SleepCore.estimate(listOf(longArrayOf(23 * h, 27 * h), longArrayOf(27 * h + 10 * m, 33 * h)), 20 * h, 36 * h)!!
        assertEquals(23 * h, e.bed); assertEquals(33 * h, e.wake)
    }

    @Test fun daytimeIdlenessIsNeverSleep() {
        assertNull(SleepCore.estimate(listOf(longArrayOf(13 * h, 19 * h)), 12 * h, 20 * h))
    }
}
