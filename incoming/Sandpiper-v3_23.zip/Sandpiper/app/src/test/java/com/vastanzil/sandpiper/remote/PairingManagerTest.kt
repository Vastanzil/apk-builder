package com.vastanzil.sandpiper.remote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PairingManagerTest {
    private var t = 1_000_000L
    private val pm = PairingManager(now = { t })

    @Test fun codeIsSixDigits() { assertTrue(Regex("\\d{6}").matches(pm.startPairing().value)) }

    @Test fun sameWindowSameCodeThenFreshAfterExpiry() {
        val a = pm.startPairing(); val b = pm.startPairing()
        assertEquals(a.value, b.value)
        t += PairingManager.CODE_MS + 1
        assertTrue(pm.startPairing().expiresAt > t)
    }

    @Test fun expiresAfterNinetySeconds() {
        val c = pm.startPairing()
        t += 90_001
        assertTrue(pm.redeem("1.1.1.1", c.value) is PairingManager.Redeem.Expired)
    }

    @Test fun singleUse() {
        val c = pm.startPairing()
        val ok = pm.redeem("1.1.1.1", c.value)
        assertTrue(ok is PairingManager.Redeem.Ok)
        assertTrue(pm.valid((ok as PairingManager.Redeem.Ok).token))
        assertTrue(pm.redeem("1.1.1.1", c.value) is PairingManager.Redeem.Expired)
    }

    @Test fun lockoutAfterFiveWrongThenClears() {
        val c = pm.startPairing()
        val wrong = if (c.value == "000000") "000001" else "000000"
        repeat(4) { assertTrue(pm.redeem("9.9.9.9", wrong) is PairingManager.Redeem.Wrong) }
        assertTrue(pm.redeem("9.9.9.9", wrong) is PairingManager.Redeem.Locked)
        assertTrue(pm.redeem("9.9.9.9", c.value) is PairingManager.Redeem.Locked)      // even the right code is refused while locked
        assertTrue(pm.redeem("8.8.8.8", wrong) is PairingManager.Redeem.Wrong)          // other addresses are unaffected
        t += PairingManager.LOCK_MS + 1
        val c2 = pm.startPairing()
        assertTrue(pm.redeem("9.9.9.9", c2.value) is PairingManager.Redeem.Ok)
    }

    @Test fun unknownTokenAndRevokeAll() {
        assertFalse(pm.valid(null)); assertFalse(pm.valid("nope"))
        val ok = pm.redeem("1.1.1.1", pm.startPairing().value) as PairingManager.Redeem.Ok
        pm.revokeAll()
        assertFalse(pm.valid(ok.token)); assertEquals(0, pm.count())
    }

    @Test fun idleSessionExpiresWhenNotRemembered() {
        pm.rememberSession = false
        val ok = pm.redeem("1.1.1.1", pm.startPairing().value) as PairingManager.Redeem.Ok
        t += PairingManager.IDLE_TTL_MS + 1
        assertFalse(pm.valid(ok.token))
    }

    @Test fun concurrentStartPairingAgrees() {
        val out = java.util.Collections.synchronizedList(ArrayList<String>())
        val ts = (1..8).map { Thread { out.add(pm.startPairing().value) } }
        ts.forEach { it.start() }; ts.forEach { it.join() }
        assertEquals(1, out.toSet().size)
    }
}
