package com.vastanzil.sandpiper.remote

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class RemoteRpcTest {
    private val known = setOf("plannerList", "appGet", "saveFile", "remoteStart")
    private fun run(body: String, onCall: (String) -> Unit = {}) = JSONObject(RemoteRpc.handle(body, known) { m, p -> onCall(m); if (m == "appGet") p.optString(0) else null })

    @Test fun relaysAKnownMethod() {
        val r = run("""{"v":1,"id":7,"m":"appGet","p":["x"]}""")
        assertTrue(r.getBoolean("ok")); assertEquals("x", r.getString("d")); assertEquals(7, r.getInt("id"))
    }

    @Test fun unlistedOrDeniedMethodIsRefusedAndNeverCalled() {
        var called = false
        for (m in listOf("nope", "saveFile", "remoteStart", "")) {
            val r = run("""{"v":1,"id":1,"m":"$m","p":[]}""") { called = true }
            assertFalse(r.getBoolean("ok")); assertEquals("E_METHOD_NOT_ALLOWED", r.getJSONObject("e").getString("code"))
        }
        assertFalse(called)
    }

    @Test fun oversizeBodyIsRejectedBeforeParsing() {
        val r = JSONObject(RemoteRpc.handle("x".repeat(RemoteRpc.MAX_BYTES + 1), known) { _, _ -> null })
        assertEquals("E_TOO_LARGE", r.getJSONObject("e").getString("code"))
    }

    @Test fun badVersionAndBadJson() {
        assertEquals("E_VERSION", run("""{"v":2,"id":1,"m":"appGet","p":[]}""").getJSONObject("e").getString("code"))
        assertEquals("E_BAD_REQUEST", run("not json").getJSONObject("e").getString("code"))
    }

    @Test fun aThrowingCallBecomesAnErrorNotACrash() {
        val r = JSONObject(RemoteRpc.handle("""{"v":1,"id":1,"m":"appGet","p":[]}""", known) { _, _ -> throw IllegalStateException() })
        assertEquals("E_CALL_FAILED", r.getJSONObject("e").getString("code"))
    }

    /** Every denied name must be a real Bridge method (a typo would silently leave a method relayed). */
    @Test fun deniedNamesExistOnBridge() {
        val src = File("src/main/java/com/vastanzil/sandpiper/Bridge.kt").readText()
        val missing = RemoteRpc.DENIED.filter { !Regex("fun " + it + "\\(").containsMatchIn(src) }
        // llmRun / llmImport / pickModel may live elsewhere in this tree; every other name must exist on Bridge.
        assertEquals(emptyList<String>(), missing.filter { it !in setOf("llmRun", "llmImport", "pickModel", "previewTone", "stopPreview") })
    }
}
