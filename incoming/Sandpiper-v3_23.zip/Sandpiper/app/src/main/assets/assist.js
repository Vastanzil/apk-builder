/* Sandpiper Assist: floating bubble on Home + full-screen chat.
   Rules do the understanding and the work; the optional brain (Settings > Assist) only maps a sentence to one intent.
   Everything is local. Needs window.SpApp (exposed by index.html). */
(function(){'use strict';
const A=window.SpApp;if(!A)return;
const q=s=>document.querySelector(s),N=A.N,S=()=>A.S,esc=A.esc;
const KEY='sp_assist_pos',td=()=>A.today();

/* ---------- styles (app tokens, light + dark) ---------- */
const st=document.createElement('style');st.textContent=`
#spBubble{position:fixed;z-index:9;right:16px;bottom:calc(92px + env(safe-area-inset-bottom,0px));width:58px;height:58px;border-radius:50%;border:0;display:none;place-items:center;font-size:24px;color:#031420;background:linear-gradient(135deg,var(--accent),var(--accent2));box-shadow:0 14px 34px rgba(14,165,233,.38);touch-action:none;transition:transform .2s}
#spBubble.show{display:grid}#spBubble:active{transform:scale(.94)}#spBubble.drag{transition:none}
#spBubble::after{content:"";position:absolute;inset:-5px;border-radius:50%;border:2px solid var(--accent);opacity:0;animation:spPulse 3.2s ease-out 1.2s 2}
@keyframes spPulse{0%{opacity:.6;transform:scale(.9)}100%{opacity:0;transform:scale(1.25)}}
@media(min-width:701px){#spBubble{bottom:30px}}
#spAssist{position:fixed;inset:0;z-index:40;background:var(--bg);display:none;flex-direction:column;padding-top:env(safe-area-inset-top,0px)}
#spAssist.open{display:flex;animation:spUp .25s ease}@keyframes spUp{from{transform:translateY(18px);opacity:0}to{transform:none;opacity:1}}
.spw{max-width:640px;width:100%;margin:0 auto;display:flex;flex-direction:column;flex:1;min-height:0;padding:0 16px;position:relative}
.sph{display:flex;align-items:center;gap:6px;padding:10px 0 8px}.sph h2{margin:0;font-size:18px;flex:1;display:flex;align-items:center;gap:8px}
.spi{width:38px;height:38px;border-radius:12px;border:0;background:transparent;color:var(--text);font-size:19px;display:grid;place-items:center}.spi:hover{background:var(--panel)}
.spe{font-size:11px;font-weight:600;color:var(--muted);display:inline-flex;align-items:center;gap:5px}.spe i{width:7px;height:7px;border-radius:50%;background:var(--mint)}.spe.warn i{background:var(--gold)}
#spMsgs{flex:1;overflow:auto;display:flex;flex-direction:column;gap:14px;padding:6px 0 12px}
.spm{max-width:88%;font-size:14.5px;line-height:1.5;word-wrap:break-word;animation:spIn .22s ease}
@keyframes spIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.spm.me{align-self:flex-end;padding:9px 14px;border-radius:18px 18px 4px 18px;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#031420;font-weight:600}
.spm.ai{align-self:flex-start;padding:2px 2px}
.spm small.mic{display:block;opacity:.7;font-size:11px;margin-bottom:2px}
.spa{margin-top:8px;border-radius:14px;padding:11px 13px;background:var(--panel);border:1px solid var(--line)}.spa b{display:block;font-size:14px;font-weight:650}.spa .muted{display:block;margin-top:2px;font-size:12.5px}
.spr{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}.spr button{border:0;background:rgba(127,127,127,.16);border-radius:10px;padding:7px 12px;font-size:13px;font-weight:600;color:var(--text)}.spr button.p{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#031420}.spr button:disabled{opacity:.5}
#spChips{display:flex;gap:6px;overflow-x:auto;padding:4px 0 8px;scrollbar-width:none}#spChips button{flex:none;border:1px solid var(--line);background:transparent;color:var(--muted);border-radius:99px;padding:6px 12px;font-size:12.5px;font-weight:600}#spChips button:hover{color:var(--text);background:var(--panel)}
#spLive{display:none;font-size:13px;color:var(--muted);margin:0 6px 6px}#spAssist.listening #spLive{display:block}
.spbar{display:flex;align-items:center;gap:4px;background:var(--panel);border:1px solid var(--line);border-radius:26px;padding:4px 4px 4px 14px;margin-bottom:calc(12px + env(safe-area-inset-bottom,0px))}
.spbar input{flex:1;min-width:0;background:transparent;border:0;color:var(--text);font-size:14.5px;outline:none;padding:9px 0}
.spo{width:38px;height:38px;border-radius:50%;border:0;display:grid;place-items:center;font-size:17px;flex:none;background:transparent;color:var(--text)}.spo.on{background:var(--rose);color:#fff}
#spSend{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#031420}
#spHist{position:absolute;inset:0;background:var(--bg);display:none;flex-direction:column;z-index:2;padding:0 16px}#spHist.open{display:flex}
#spHist .row{display:flex;align-items:center;gap:8px;padding:12px 4px;border-bottom:1px solid var(--line)}#spHist .row button.o{flex:1;text-align:left;background:none;border:0;color:var(--text);min-width:0}
#spHist .row b{display:block;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#spHist .row span{font-size:12px;color:var(--muted)}
@media(prefers-reduced-motion:reduce){#spAssist.open,.spm,#spBubble::after{animation:none}}`;
document.head.appendChild(st);

/* ---------- bubble (Home only, draggable, snaps to a side) ---------- */
const bub=document.createElement('button');bub.id='spBubble';bub.type='button';bub.setAttribute('aria-label','Open Assist');bub.textContent='✦';document.body.appendChild(bub);
function place(){let p;try{p=JSON.parse(localStorage.getItem(KEY)||'null')}catch(e){}if(!p)return;
 bub.style.left=p.side==='l'?'16px':'auto';bub.style.right=p.side==='l'?'auto':'16px';
 if(p.y!=null){const y=Math.min(Math.max(p.y,0.08),0.84)*innerHeight;bub.style.top=y+'px';bub.style.bottom='auto'}}
place();
function sync(){const h=q('#home'),on=h&&h.classList.contains('active')&&!q('#spAssist.open');bub.classList.toggle('show',!!on)}
new MutationObserver(sync).observe(q('main')||document.body,{attributes:true,subtree:true,attributeFilter:['class']});sync();
let dr=null;
bub.addEventListener('pointerdown',e=>{dr={x:e.clientX,y:e.clientY,moved:false};try{bub.setPointerCapture(e.pointerId)}catch(x){}});
bub.addEventListener('pointermove',e=>{if(!dr)return;if(!dr.moved&&Math.hypot(e.clientX-dr.x,e.clientY-dr.y)<8)return;dr.moved=true;bub.classList.add('drag');
 bub.style.left=(e.clientX-29)+'px';bub.style.right='auto';bub.style.top=(e.clientY-29)+'px';bub.style.bottom='auto'});
bub.addEventListener('pointerup',e=>{const d=dr;dr=null;bub.classList.remove('drag');if(!d)return;
 if(!d.moved){openAssist();return}
 const side=e.clientX<innerWidth/2?'l':'r',y=Math.min(Math.max(e.clientY/innerHeight,.08),.84);
 try{localStorage.setItem(KEY,JSON.stringify({side,y}))}catch(x){}place()});
bub.addEventListener('pointercancel',()=>{dr=null;bub.classList.remove('drag')});

/* ---------- layer ---------- */
const L=document.createElement('div');L.id='spAssist';L.setAttribute('role','dialog');L.setAttribute('aria-label','Assist');
L.innerHTML=`<div class="spw"><div class="sph"><button class="spi" id="spBack" type="button" aria-label="Close">‹</button><h2>Assist <span class="spe" id="spEng"></span></h2><button class="spi" id="spHistBtn" type="button" aria-label="History" title="History">🕘</button><button class="spi" id="spNew" type="button" aria-label="New chat" title="New chat">＋</button></div>
<div id="spMsgs" aria-live="polite"></div>
<div id="spChips"><button data-q="Summarise my day">Summarise my day</button><button data-q="Plan my day">Plan my day</button><button data-q="Report this week">Weekly report</button><button data-q="How did I sleep?">Sleep</button><button data-q="Add 500 ml water">+500 ml water</button></div>
<div id="spLive">Listening…</div>
<div class="spbar"><input id="spInp" placeholder="Message Assist" aria-label="Message" autocomplete="off"><button class="spo" id="spMic" type="button" aria-label="Speak" aria-pressed="false">🎙</button><button class="spo" id="spSend" type="button" aria-label="Send">➤</button></div>
<div id="spHist"><div class="sph"><button class="spi" id="spHistBack" type="button" aria-label="Back">‹</button><h2>Chat history</h2><button class="spi" id="spHistClear" type="button" aria-label="Delete all" title="Delete all">🗑</button></div><div id="spHistList" style="overflow:auto;flex:1"></div></div></div>`;
document.body.appendChild(L);
const msgs=q('#spMsgs'),inp=q('#spInp');
/* ---------- chat history (this device only; never part of backups) ---------- */
const HK='sp_assist_chats';let chats=[];try{chats=JSON.parse(localStorage.getItem(HK)||'[]');if(!Array.isArray(chats))chats=[]}catch(e){chats=[]}
let chat={id:Date.now(),t:Date.now(),title:'',msgs:[]};
function clean(h){const t=document.createElement('div');t.innerHTML=h;t.querySelectorAll('.spr').forEach(r=>{if(r.querySelector('[data-ok],[data-no],[data-edit],[data-undo]'))r.remove()});return t.innerHTML}
function persist(){const me=chat.msgs.find(m=>m.c==='me');if(!me)return;chat.title=plain(me.h).replace(/^Voice\s*/,'').slice(0,60);chat.t=Date.now();
 if(!chats.includes(chat))chats.unshift(chat);chats.sort((a,b)=>b.t-a.t);chats=chats.slice(0,40);chat.msgs=chat.msgs.slice(-80);
 try{let j=JSON.stringify(chats);while(j.length>400000&&chats.length>1){chats.pop();j=JSON.stringify(chats)}localStorage.setItem(HK,j)}catch(e){}}
function add(c,h,keep){const d=document.createElement('div');d.className='spm '+c;d.innerHTML=h;msgs.appendChild(d);d.scrollIntoView({block:'nearest'});if(!keep){chat.msgs.push({c,h:clean(h)});persist()}return d}
function newChat(){stopMic();chat={id:Date.now(),t:Date.now(),title:'',msgs:[]};msgs.innerHTML='';welcome();hist(false)}
function loadChat(c){stopMic();chat=c;msgs.innerHTML='';c.msgs.forEach(m=>add(m.c,m.h,true));hist(false);msgs.lastElementChild&&msgs.lastElementChild.scrollIntoView({block:'end'})}
function hist(on){const h=q('#spHist');if(!on){h.classList.remove('open');return}
 const l=q('#spHistList');l.innerHTML=chats.length?chats.map((c,i)=>`<div class="row"><button class="o" data-h="${i}" type="button"><b>${esc(c.title||'Chat')}</b><span>${new Date(c.t).toLocaleString([],{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'})} · ${c.msgs.filter(m=>m.c==='me').length} message${c.msgs.filter(m=>m.c==='me').length===1?'':'s'}</span></button><button class="spi" data-hd="${i}" type="button" aria-label="Delete">🗑</button></div>`).join(''):'<p class="muted" style="padding:20px 4px">No saved chats yet. Chats are kept on this device only.</p>';h.classList.add('open')}
const plain=h=>{const t=document.createElement('div');t.innerHTML=h;return t.textContent.replace(/\s+/g,' ').trim()};
const lang=()=>S().assistLang||'auto',trust=()=>S().assistTrust||'balanced';
function say(h){const d=add('ai',h);if(S().assistSpeak&&N&&N.assistSpeak)try{N.assistSpeak(plain(h),lang())}catch(e){}return d}

function engine(){const e=q('#spEng');let s=null;try{s=N&&N.llmStatus?JSON.parse(N.llmStatus()):null}catch(x){}
 let t='Built-in',w=false;
 if(s&&s.provider&&s.provider!=='NONE'){t=(s.provider==='AICORE'?'System AI':'Local model')+' · '+s.usageToday+'/'+s.budget;if(s.guard&&!s.guard.ok){t+=' · paused';w=true}}
 e.className='spe'+(w?' warn':'');e.innerHTML='<i></i>'+esc(t)}
function welcome(){say('Hi'+(S().name?' '+esc(S().name):'')+'. Ask about your day, week or sleep, or tell me what to do: log water, add a task, note or reminder, calculate, or write an expense (expenses always ask first).')}
function openAssist(){L.classList.add('open');sync();engine();hist(false);if(!msgs.children.length)welcome();
 setTimeout(()=>inp.focus({preventScroll:true}),300)}
function closeAssist(){stopMic();hist(false);L.classList.remove('open');sync()}
function back(){if(!L.classList.contains('open'))return false;if(q('#spHist').classList.contains('open')){hist(false);return true}closeAssist();return true}
q('#spBack').onclick=closeAssist;q('#spNew').onclick=newChat;q('#spHistBtn').onclick=()=>hist(true);q('#spHistBack').onclick=()=>hist(false);
q('#spHistClear').onclick=()=>{if(!chats.length)return;A.ask('Delete all saved Assist chats on this device?',()=>{chats=[];chat={id:Date.now(),t:Date.now(),title:'',msgs:[]};try{localStorage.removeItem(HK)}catch(e){}msgs.innerHTML='';welcome();hist(true)})};
q('#spHistList').addEventListener('click',e=>{const o=e.target.closest('[data-h]'),d=e.target.closest('[data-hd]');
 if(o){loadChat(chats[+o.dataset.h]);return}
 if(d){const i=+d.dataset.hd,c=chats[i];chats.splice(i,1);try{localStorage.setItem(HK,JSON.stringify(chats))}catch(x){}if(c===chat){chat={id:Date.now(),t:Date.now(),title:'',msgs:[]};msgs.innerHTML='';welcome()}hist(true)}});
window.SpAssist={open:openAssist,close:closeAssist,back,ask:t=>{openAssist();send(t)}};

/* ---------- actions with Undo / confirm ---------- */
const UNDO=new Map();let un=0;
/* every change redraws the real screens at once (To-do list, Planner, Home, Finance, Notes, Hydration ...) */
const R=()=>{try{A.refresh()}catch(e){}};
function card(title,sub,btns){return `<div class="spa"><b>${title}</b>${sub?`<span class="muted small">${sub}</span>`:''}${btns?`<div class="spr">${btns}</div>`:''}</div>`}
/* act = {title, sub, money, run(): undoFn|false} */
function propose(lead,act){
 const ask=act.money||trust()==='careful';
 if(!ask){const u=act.run();R();if(u===false){say('I could not do that here.');return}
  const id=++un;UNDO.set(id,u);say(lead+card(act.title,act.sub,u?`<button data-undo="${id}">Undo</button>`:''));return}
 const id=++un;UNDO.set(id,act);
 say((act.money?'Money always asks first. This is exactly what I will write:':lead)+card(act.title,act.sub,`<button class="p" data-ok="${id}">Confirm</button>${act.edit?`<button data-edit="${id}">Edit</button>`:''}<button data-no="${id}">Cancel</button>`))}
L.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const D=b.dataset;
 if(D.q){send(D.q);return}
 if(D.undo){const u=UNDO.get(+D.undo);UNDO.delete(+D.undo);if(typeof u==='function')try{u()}catch(x){}R();b.textContent='Undone ✓';b.disabled=true;return}
 if(D.ok||D.no||D.edit){const id=+(D.ok||D.no||D.edit),act=UNDO.get(id),row=b.parentElement;if(!act)return;
  if(D.edit){act.edit();return}
  row.querySelectorAll('button').forEach(x=>x.disabled=true);UNDO.delete(id);
  if(D.no){b.textContent='Cancelled';A.toast('Cancelled. Nothing was written.');return}
  const u=act.run();R();if(u===false){b.textContent='Failed';return}b.textContent='Saved ✓';
  if(typeof u==='function'){const i2=++un;UNDO.set(i2,u);const nb=document.createElement('button');nb.dataset.undo=i2;nb.textContent='Undo';row.appendChild(nb)}return}
 if(D.go){closeAssist();if(D.go==='sleep'){A.go('more');setTimeout(()=>{const t=q('#sleepAuto');if(t)t.scrollIntoView({block:'center'})},60)}else if(D.go.startsWith('tr:'))A.openTR(null,D.go.slice(3));else A.go(D.go)}});
const go=(t,label)=>`<button data-go="${t}">${label}</button>`;

/* ---------- parsing helpers ---------- */
const BN='০১২৩৪৫৬৭৮৯';
const norm=t=>t.replace(/[০-৯]/g,c=>BN.indexOf(c)).replace(/[,]/g,'').replace(/\s+/g,' ').trim();
const num=m=>parseFloat(m);
function calc(t){let s=t.replace(/^(what is|what's|calculate|calc|=)\s*/i,'').replace(/[×x]/gi,'*').replace(/÷/g,'/').replace(/\s/g,'');
 if(!/^[\d+\-*/%().]+$/.test(s)||!/\d/.test(s))return null;
 let i=0;const peek=()=>s[i];
 function ex(){let v=tm();while(peek()==='+'||peek()==='-'){const o=s[i++],r=tm();v=o==='+'?v+r:v-r}return v}
 function tm(){let v=un_();while(peek()==='*'||peek()==='/'){const o=s[i++],r=un_();v=o==='*'?v*r:v/r}return v}
 function un_(){if(peek()==='-'){i++;return -un_()}if(peek()==='+'){i++;return un_()}return pr()}
 function pr(){let v;if(peek()==='('){i++;v=ex();if(peek()!==')')throw 0;i++}else{const m=/^\d+(\.\d+)?/.exec(s.slice(i));if(!m)throw 0;v=parseFloat(m[0]);i+=m[0].length}
  if(peek()==='%'){i++;v/=100}return v}
 try{const v=ex();if(i!==s.length||!isFinite(v))return null;return parseFloat(v.toPrecision(12))}catch(e){return null}}
const CATKW={Food:/lunch|dinner|breakfast|food|snack|coffee|tea|restaurant|grocer|meal|খাবার/,Transport:/uber|taxi|bus|rickshaw|cng|fuel|petrol|metro|fare|train|ride/,Bills:/bill|electric|gas|rent|internet|wifi|water bill|recharge/,Health:/doctor|medicine|pharmacy|hospital|dentist/,Shopping:/shirt|shoes|clothes|shopping|bought/,Salary:/salary|wage|paycheck/};
function category(t,kind){const cs=A.cats();const hit=cs.find(c=>new RegExp('\\b'+c.toLowerCase().replace(/[^a-z0-9 ]/g,'')+'\\b').test(t.toLowerCase()));if(hit)return hit;
 for(const k in CATKW)if(CATKW[k].test(t.toLowerCase())){const m=cs.find(c=>c.toLowerCase()===k.toLowerCase());if(m)return m}
 return cs.find(c=>/^other$/i.test(c))||cs[0]||'Other'}
const pad=n=>String(n).padStart(2,'0'),DAYS=['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
function when(t){const now=new Date();let d=new Date(now),h=null,m=0,m1;
 if(m1=/\bin (\d+) ?(min|minute|minutes|hour|hours|hr|hrs)\b/.exec(t)){const n=+m1[1]*(/^h/.test(m1[2])?60:1);d=new Date(now.getTime()+n*60000);return{date:A.iso(d),time:pad(d.getHours())+':'+pad(d.getMinutes()),rest:t.replace(m1[0],'')}}
 let rest=t;
 if(m1=/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/.exec(t)){h=+m1[1]%12+(m1[3]==='pm'?12:0);m=+(m1[2]||0);rest=rest.replace(m1[0],'')}
 else if(m1=/\bat (\d{1,2}):(\d{2})\b/.exec(t)){h=+m1[1];m=+m1[2];rest=rest.replace(m1[0],'')}
 else if(m1=/\bat (\d{1,2})\b/.exec(t)){h=+m1[1]<7?+m1[1]+12:+m1[1];rest=rest.replace(m1[0],'')}
 let dayGiven=false;
 if(/\btomorrow\b/.test(t)){d.setDate(d.getDate()+1);dayGiven=true;rest=rest.replace(/\btomorrow\b/,'')}
 else if(/\btoday|tonight\b/.test(t)){dayGiven=true;rest=rest.replace(/\btoday|tonight\b/,'');if(/tonight/.test(t)&&h!=null&&h<12)h+=12}
 else{const wd=DAYS.findIndex(x=>new RegExp('\\b(on )?'+x+'\\b').test(t));if(wd>=0){let k=(wd-d.getDay()+7)%7;if(k===0)k=7;d.setDate(d.getDate()+k);dayGiven=true;rest=rest.replace(new RegExp('\\b(on )?'+DAYS[wd]+'\\b'),'')}}
 if(h==null){if(!dayGiven)return null;h=9;m=0}
 d.setHours(h,m,0,0);if(!dayGiven&&d<=now)d.setDate(d.getDate()+1);
 return{date:A.iso(d),time:pad(h)+':'+pad(m),rest}}

/* ---------- actions ---------- */
function actWater(ml){const k=td();return{title:'Water · +'+ml+' ml',sub:'Written to Hydration',run(){const s=S();s.water[k]=(s.water[k]||0)+ml;A.save();A.renderMore();A.renderHome();
 return()=>{s.water[k]=Math.max(0,(s.water[k]||0)-ml);A.save();A.renderMore();A.renderHome()}}}}
function actTx(kind,amount,name,cat){
 const a={money:true,title:(kind==='income'?'Income ':'Expense ')+A.money(amount)+' · '+esc(cat)+' · today',sub:esc(name),
 run(){const tx={id:A.uid(),name,cat,amount:Math.round(amount*100)/100,kind,ts:Date.now()},s=S();s.txs.unshift(tx);A.finPush(tx);A.save();A.renderFinance();A.renderHome();
  return()=>{s.txs=s.txs.filter(z=>z.id!==tx.id);A.finDel(tx.id);A.save();A.renderFinance();A.renderHome()}},
 edit(){closeAssist();const $=id=>document.getElementById(id);$('txAmount').value=amount;$('txName').value=name;try{$('txCategory').value=cat}catch(e){}
  document.querySelectorAll('[data-kind]').forEach(b=>b.classList.toggle('active',b.dataset.kind===kind));$('txKind').value=kind;$('transactionModal').classList.add('open')}};return a}
function actTask(text){return{title:'Task · '+esc(text),sub:'Added to today in your Planner list',run(){if(!(N&&N.plannerAdd))return false;const id=N.plannerAdd('daily',text);if(!id)return false;return()=>{try{N.plannerDelete(id)}catch(e){}}}}}
function actRemind(title,date,time){const id='as'+A.uid(),rk='sandpiper_reminders';
 return{title:'Reminder · '+esc(title),sub:new Date(date+'T'+time+':00').toLocaleString([],{weekday:'short',day:'numeric',month:'short',hour:'numeric',minute:'2-digit'})+(N&&N.notifEnabled&&!N.notifEnabled()?' · allow notifications so it can ring':''),
 run(){let L=[];try{L=JSON.parse(localStorage.getItem(rk)||'[]')}catch(e){}if(!Array.isArray(L))L=[];L.push({id,title,date,time});try{localStorage.setItem(rk,JSON.stringify(L))}catch(e){return false}
  if(N&&N.schedule){const t=time.split(':');try{N.schedule(JSON.stringify({id:'pl_'+id,kind:'reminder',title,date,h:+t[0],m:+t[1],repeat:'none'}))}catch(e){}}A.renderHome();
  return()=>{try{localStorage.setItem(rk,JSON.stringify(L.filter(z=>z.id!==id)))}catch(e){}try{N&&N.cancel&&N.cancel('pl_'+id)}catch(e){}A.renderHome()}}}}
function actNote(title,body){return{title:'Note · '+esc(title),sub:'Saved to Notes',run(){const n={id:A.uid(),title,body,ts:Date.now()},s=S();s.notes.unshift(n);A.save();A.renderAll();return()=>{s.notes=s.notes.filter(z=>z.id!==n.id);A.save();A.renderAll()}}}}
function actHabit(h){const k=td();return{title:'Habit done · '+esc(h.name),sub:'Marked for today',run(){if(h.done.includes(k))return()=>{};h.done=[...h.done,k];A.save();A.renderMore();A.renderHome();return()=>{h.done=h.done.filter(x=>x!==k);A.save();A.renderMore();A.renderHome()}}}}

/* ---------- reads ---------- */
function tasksToday(){try{const l=JSON.parse(N&&N.plannerList?N.plannerList('daily'):'[]');return Array.isArray(l)?l:[]}catch(e){return[]}}
function lines(){const s=S(),k=td(),X=A.dayIndex()[k]||{focus:0,spend:0},ts=tasksToday(),dn=ts.filter(t=>t.done).length,L=[];
 L.push(['Tasks',ts.length?dn+' of '+ts.length+' done':'none today']);
 L.push(['Focus',(X.focus||0)+' min']);
 if(s.stepHist[k]!=null)L.push(['Steps',s.stepHist[k].toLocaleString('en-US')+' / '+s.stepGoal.toLocaleString('en-US')]);
 L.push(['Water',((s.water[k]||0)/1000).toFixed(2).replace(/\.?0+$/,'')+' of '+s.waterGoal/1000+' L']);
 L.push(['Spent',A.money(X.spend||0)]);
 const r=A.reelsOn(k),lim=A.limitGoal();if(r!=null)L.push(['Reels',r+(lim?' of '+lim:'')]);
 if(s.habits.length)L.push(['Habits',s.habits.filter(h=>h.done.includes(k)).length+' of '+s.habits.length]);return L}
function doDay(){say('Your day so far, from your own data.'+card(lines().map(l=>esc(l[0])+': '+esc(l[1])).join(' · '),'',go('tr:day','Open Track Record →')))}
function doPlan(){const ts=tasksToday().filter(t=>!t.done),rem=A.planRem().filter(r=>r.date===td());
 if(!ts.length&&!rem.length){say('Nothing is planned for today yet. Say “add a task to …” or “remind me to … at 5pm”.');return}
 const items=[...rem.map(r=>(r.time||'09:00')+' '+r.title),...ts.map(t=>t.text)],body=items.map((x,i)=>(i+1)+'. '+esc(x)).join('<br>');
 const pn=actNote('Plan · '+td(),items.map((x,i)=>(i+1)+'. '+x).join('\n'));if(trust()==='hands'){propose('Plan saved as a note.',pn);return}
 const id=++un;UNDO.set(id,pn);
 say('Today, in order: reminders by time, then open tasks. Nothing moves until you confirm.'+card(body,'',`<button class="p" data-ok="${id}">Save plan as a note</button><button data-no="${id}">Not now</button>`))}
function doWeek(){const I=window.SpInsights,w=I&&I.weekSummary();say(w?esc(w)+card('Weekly report','Same page as Track Record › Week',go('tr:week','Open Track Record →')):'Track Record › Week has the full report.'+card('Weekly report','',go('tr:week','Open Track Record →')))}
function doSleep(){const I=window.SpInsights,n=I&&I.lastNight();
 if(!n){say('I have no sleep for last night yet. Log it in Sleep, or turn on the automatic estimate in Settings › Assist.'+card('Sleep','',go('sleep','Open Sleep →')));return}
 const h=Math.floor(n.mins/60)+' h '+pad(n.mins%60)+' m';say('About '+h+' last night'+(n.mins<480?', short of your 8 h target.':'.')+card('Sleep · '+h+(n.auto?' (estimated)':''),n.auto?'From phone idle time. Your own entry always wins.':'Your own entry',go('sleep','Open Sleep →')))}

/* ---------- understanding ---------- */
function understand(raw){const t=norm(raw),l=t.toLowerCase();
 const c=calc(t);if(c!=null)return{k:'calc',expr:t,v:c};
 let m;
 if(/^(remind|reminder)/.test(l)){const body=t.replace(/^remind(er)?( me)?( to| about)?\s*/i,''),w=when(body.toLowerCase());
  if(!w)return{k:'ask',msg:'When should I remind you? Add a time, like “at 5pm”, “tomorrow 9am” or “in 30 minutes”.'};
  const title=body.replace(new RegExp(w.rest===body.toLowerCase()?'$^':'x^'),'').trim();
  let ti=(w.rest||body).replace(/\b(at|on|by)\s*$/i,'').replace(/\s+/g,' ').trim();ti=ti.replace(/^(to|about)\s+/i,'');
  return{k:'remind',title:(ti||title||'Reminder').replace(/^./,x=>x.toUpperCase()).slice(0,100),date:w.date,time:w.time}}
 if(m=/^(?:add |create |new )?(?:a )?(?:task|todo)\s*(?:to|:|-)?\s*(.+)$/i.exec(t))return{k:'task',text:m[1].slice(0,200)};
 if(m=/^(?:take a note|save a note|note|jot down|jot)\s*[:\-]?\s*(.+)$/i.exec(t))return{k:'note',text:m[1]};
 if(m=/(?:^|\b)(spent|paid|bought|expense|cost)\b\D{0,12}?(\d+(?:\.\d+)?)(?:\s*(?:tk|taka|৳|\$|bdt))?\s*(?:on|for|at)?\s*(.*)$/i.exec(t)||/(\d+(?:\.\d+)?)\s*(?:tk|taka|৳|bdt)?\s*(?:on|for)\s+(.+)$/i.exec(t)&&(/\b(spent|paid|bought)\b/i.test(t)?/(\d+(?:\.\d+)?)\s*(?:tk|taka|৳|bdt)?\s*(?:on|for)\s+(.+)$/i.exec(t):null)){
  const a=m.length===4?num(m[2]):num(m[1]),w=(m.length===4?m[3]:m[2])||'';return{k:'tx',kind:'expense',amount:a,name:(w.trim()||'Expense').replace(/^./,x=>x.toUpperCase()),text:t}}
 if(m=/\b(received|earned|got paid|income|salary)\b\D{0,12}?(\d+(?:\.\d+)?)/i.exec(t))return{k:'tx',kind:'income',amount:num(m[2]),name:/salary/i.test(t)?'Salary':'Income',text:t}
 if(/water|drank|drink|পানি/.test(l)&&(m=/(\d+(?:\.\d+)?)\s*(ml|l|litres?|liters?|glass(?:es)?|bottles?)?/.exec(l))){let n=num(m[1]),u=m[2]||'';
  const ml=/^l|litre|liter/.test(u)&&u!=='ml'?n*1000:/glass/.test(u)?n*250:/bottle/.test(u)?n*500:!u&&n<20?n*250:n;return{k:'water',ml:Math.round(ml)}}
 if(/\bplan\b/.test(l))return{k:'plan'};
 if(/\bweek|weekly|report\b/.test(l))return{k:'week'};
 if(/\bsleep|slept|ঘুম/.test(l))return{k:'sleep'};
 if(/\bday\b|summar|today|how am i|status/.test(l))return{k:'day'};
 if(m=/^(?:i )?(?:did|done|finished|completed|mark)\s+(.+?)(?:\s+done)?$/i.exec(t)){const h=S().habits.find(x=>m[1].toLowerCase().includes(x.name.toLowerCase())||x.name.toLowerCase().includes(m[1].toLowerCase()));if(h)return{k:'habit',h}}
 return{k:'none'}}

function dispatch(u,spoken){
 switch(u.k){
  case 'calc':say('Calculated by the app.'+card(esc(u.expr),'')+'<b style="display:block;margin-top:6px;font-size:20px">= '+esc(u.v.toLocaleString('en-US',{maximumFractionDigits:10}))+'</b>');break;
  case 'water':if(!(u.ml>0&&u.ml<=5000)){say('That amount looks off. Try something like “add 500 ml water”.');break}propose('Logged.',actWater(u.ml));break;
  case 'tx':{if(!(u.amount>0)||u.amount>1e9){say('I could not read a valid amount.');break}const cat=category(u.text+' '+u.name,u.kind);propose('',actTx(u.kind,u.amount,u.name,cat));break}
  case 'task':if(!(N&&N.plannerAdd)){say('Tasks are saved by the Android app. Open Sandpiper there to add them.');break}propose('Done.',actTask(u.text));break;
  case 'remind':propose('Done.',actRemind(u.title,u.date,u.time));break;
  case 'note':propose('Saved.',actNote(u.text.slice(0,40),u.text));break;
  case 'habit':propose('Done.',actHabit(u.h));break;
  case 'day':doDay();break;case 'plan':doPlan();break;case 'week':doWeek();break;case 'sleep':doSleep();break;
  case 'ask':say(esc(u.msg));break;
  default:say('I can read or change things in Sandpiper. Try a chip, or ask me to remind, calculate, log water, add a task or note, or write an expense.')}}

/* optional brain: only for sentences the rules did not understand; the result is re-validated in Kotlin, then run through the same actions */
function viaBrain(text,done){let on=false;try{on=!!(N&&N.appGet&&N.appGet('brainChat')==='true'&&window.SpBrain)}catch(e){}
 if(!on){done(null);return}
 SpBrain.run('ask_data',{text},o=>{const g=o&&o.ok&&o.suggestion;if(!g||g.intent==='none'){done(null);return}
  const M={water:{k:'water',ml:g.amount},expense:{k:'tx',kind:'expense',amount:g.amount,name:g.text||'Expense',text:text},income:{k:'tx',kind:'income',amount:g.amount,name:g.text||'Income',text:text},
   task:{k:'task',text:g.text},note:{k:'note',text:g.text},day:{k:'day'},plan:{k:'plan'},week:{k:'week'},sleep:{k:'sleep'}};
  if(g.intent==='reminder'){const w=when((g.text||'').toLowerCase()+' '+text.toLowerCase());done(w?{k:'remind',title:g.text,date:w.date,time:w.time}:{k:'ask',msg:'When should I remind you?'});return}
  if(g.intent==='habit'){const h=S().habits.find(x=>(g.text||'').toLowerCase().includes(x.name.toLowerCase()));done(h?{k:'habit',h}:null);return}
  done(M[g.intent]||null)})}

function send(text,voiced){text=(text||'').trim();if(!text)return;
 add('me',(voiced?'<small class="mic">🎙 Voice</small>':'')+esc(text));
 setTimeout(()=>{const u=understand(text);
  if(u.k==='none')viaBrain(text,r=>dispatch(r||u));else dispatch(u)},250)}
q('#spSend').onclick=()=>{const v=inp.value;inp.value='';send(v)};inp.onkeydown=e=>{if(e.key==='Enter')q('#spSend').click()};

/* ---------- voice ---------- */
let rec=false,wr=null;
function setRec(on){rec=on;q('#spMic').classList.toggle('on',on);q('#spMic').setAttribute('aria-pressed',on);L.classList.toggle('listening',on);if(!on)q('#spLive').textContent='Listening…'}
function stopMic(){if(!rec)return;setRec(false);try{N&&N.assistStop&&N.assistStop()}catch(e){}try{wr&&wr.stop()}catch(e){}}
window.onAssistHeard=(text,fin,err)=>{if(!fin){q('#spLive').textContent='Listening… “'+text+'”';return}
 setRec(false);if(text)send(text,true);else A.toast(err==='unavailable'?'No speech service on this phone.':err==='empty'?'I did not catch that.':'Voice is not available right now.')};
q('#spMic').onclick=()=>{
 if(rec){stopMic();return}
 if(N&&N.assistListen){if(!A.permOK('microphone')){A.needPerm('microphone');return}setRec(true);try{N.assistListen(lang())}catch(e){setRec(false)}return}
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){A.toast('Voice needs the Android app.');return}
 wr=new SR();wr.lang=lang()==='bn'?'bn-BD':lang()==='en'?'en-US':'';wr.interimResults=true;
 wr.onresult=e=>{const r=e.results[e.results.length-1];window.onAssistHeard(r[0].transcript,r.isFinal,'')};wr.onerror=()=>window.onAssistHeard('',true,'error');wr.onend=()=>{if(rec)setRec(false)};
 setRec(true);try{wr.start()}catch(e){setRec(false)}};
})();
