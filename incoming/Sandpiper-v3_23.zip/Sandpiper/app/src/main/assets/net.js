/* Settings cards for Local Sync (desktop pairing) and Cloud backup (encrypted, Google Drive). Both are opt-in and phone-only.
   The native side does the work; this file only draws the cards and calls the bridge. Needs window.SpApp. */
(function(){'use strict';
const A=window.SpApp;if(!A)return;
const N=A.N,S=()=>A.S,$=id=>document.getElementById(id),holder=$('cardHolder');if(!holder)return;
function mk(id,html){const c=document.createElement('div');c.className='card';c.id=id;c.innerHTML=html;holder.appendChild(c);return c}
const inp='class="sin" style="width:100%;margin-top:8px"';

/* ---------- Local Sync ---------- */
mk('remoteSyncCard',`<div class="card-head"><h2 style="font-size:16px">Local Sync</h2><span class="tag" id="rsTag">Off</span></div>
<p class="small muted">Use Sandpiper in a desktop browser on the same Wi-Fi. It works only while this is on, only on your own network, and never through the internet. After Sandpiper restarts you enter a new code.</p>
<div id="rsOn" hidden><div class="small muted">Open this address on your computer</div><div class="stat-value" style="font-size:20px;word-break:break-all" id="rsUrl"></div>
<div class="small muted" style="margin-top:8px">Pairing code (new one every 90 seconds)</div><div class="stat-value" id="rsCode" style="letter-spacing:6px">······</div><div class="small muted" id="rsInfo"></div></div>
<div class="small muted" id="rsErr" style="color:var(--rose)"></div>
<div class="actions" style="margin-top:10px"><button class="btn" id="rsBtn" type="button">Start Local Sync</button></div>
<p class="small muted" style="margin-top:10px">The phone and the desktop edit the same data, so use one at a time. The connection is plain HTTP on your network: use a Wi-Fi you trust.</p>`);
let on=false,timer=0;
const E={no_wifi:'Connect to Wi-Fi (or turn on your hotspot) first.',bind:'That port is busy. Change it under Port, then try again.',no_bridge:'Not ready yet. Try again in a moment.'};
function status(){let s=null;try{s=JSON.parse(N.remoteStatus())}catch(e){}return s}
function paint(){const c=$('remoteSyncCard');if(!c||!c.offsetParent){return}
 if(!(N&&N.remoteStart)){$('rsTag').textContent='Phone only';$('rsBtn').hidden=true;$('rsErr').textContent='Local Sync is started from the Android app.';return}
 const s=status();on=!!(s&&s.running);$('rsTag').textContent=on?'On':'Off';$('rsBtn').textContent=on?'Stop Local Sync':'Start Local Sync';$('rsOn').hidden=!on;
 if(on){$('rsUrl').textContent=s.url;let p=null;try{p=JSON.parse(N.remotePairCode())}catch(e){}
  $('rsCode').textContent=p&&p.code?p.code:'······';$('rsInfo').textContent=(s.paired?s.paired+' browser'+(s.paired>1?'s':'')+' paired':'No browser paired yet')+(p&&p.secs?' · code valid '+p.secs+' s':'')}}
function loop(){clearInterval(timer);timer=setInterval(()=>{if(!$('remoteSyncCard')||!$('remoteSyncCard').offsetParent){return}paint()},1500)}
$('rsBtn').onclick=()=>{
 const go=()=>{$('rsErr').textContent='';let r=null;
  if(on){try{N.remoteStop()}catch(e){}}else{try{r=JSON.parse(N.remoteStart(+S().remotePort||8787,S().remoteRemember!==false))}catch(e){}
   if(r&&!r.running)$('rsErr').textContent=E[r.error]||'Could not start.'}
  paint()};
 if(on||S().netOkLocal){go();return}
 A.ask('Local Sync starts a small server on this phone so a computer on your Wi-Fi can open Sandpiper. It uses the Network permission only for your local network and stops when you turn it off. Continue?',()=>{S().netOkLocal=true;A.save();go()})};
loop();

/* ---------- Cloud backup ---------- */
mk('cloudBackupCard',`<div class="card-head"><h2 style="font-size:16px">Cloud backup (Google Drive)</h2><span class="tag" id="cbTag">Not used yet</span></div>
<p class="small muted">An encrypted copy of your Sandpiper backup, kept in a hidden app folder in your own Google Drive. It is encrypted on this phone before it is sent.</p>
<p class="small" style="border:1px solid var(--line);border-radius:12px;padding:10px"><b>This passphrase encrypts your backup before it leaves your phone. Sandpiper does not store it and cannot recover it. If you lose it, that backup cannot be restored — not by you, not by us.</b></p>
<input ${inp} id="cbPass" type="password" placeholder="Passphrase (8 or more characters)" autocomplete="new-password" aria-label="Passphrase">
<input ${inp} id="cbPass2" type="password" placeholder="Repeat passphrase (only for Back up)" autocomplete="new-password" aria-label="Repeat passphrase">
<div class="actions" style="margin-top:10px;flex-wrap:wrap"><button class="btn" id="cbUp" type="button">Back up now</button><button class="btn secondary" id="cbDown" type="button">Restore from Drive</button></div>
<div class="small muted" id="cbMsg" style="margin-top:8px" aria-live="polite"></div>`);
let busy=null;
function tag(){const t=$('cbTag');if(!t)return;const l=S().cloudLast;t.textContent=l?'Last: '+new Date(l).toLocaleDateString([],{day:'numeric',month:'short'}):'Not used yet'}tag();
const M={auth:'Google sign-in did not finish. Nothing was changed.',forbidden:'Google refused access. The app needs its Google Drive setup (see docs/architecture/NET_SETUP.md).',no_backup:'No cloud backup was found in this Google account.',
 WRONG_PASSPHRASE_OR_CORRUPT:'Wrong passphrase, or the backup is damaged. Nothing was changed.',BAD_MANIFEST:'The cloud backup description is damaged. Nothing was changed.',UNSUPPORTED_VERSION:'That backup was made by a newer Sandpiper.',EMPTY_PASSPHRASE:'Enter a passphrase first.',network:'Could not reach Google Drive. Check your connection.'};
window.onCloudResult=o=>{const op=busy||o.op;busy=null;$('cbUp').disabled=$('cbDown').disabled=false;
 try{N.logBackup(op==='restore',!!o.ok)}catch(e){}
 if(!o.ok){$('cbMsg').textContent=M[o.code]||'Something went wrong ('+o.code+'). Nothing was changed.';return}
 if(op==='backup'){S().cloudLast=Date.now();A.save();tag();$('cbMsg').textContent='Encrypted backup uploaded to your Google Drive.';A.toast('Cloud backup done.');return}
 $('cbMsg').textContent='';let t='';try{t=N.cloudTake()}catch(e){}
 if(t)A.restoreText(t);else $('cbMsg').textContent='The backup was empty.'};
function run(op){
 if(!(N&&N.cloudRun)){$('cbMsg').textContent='Cloud backup works in the Android app.';return}
 const p=$('cbPass').value;
 if(p.length<8){$('cbMsg').textContent='Use a passphrase of 8 or more characters.';return}
 if(op==='backup'&&p!==$('cbPass2').value){$('cbMsg').textContent='The two passphrases do not match.';return}
 const go=()=>{busy=op;$('cbUp').disabled=$('cbDown').disabled=true;$('cbMsg').textContent=op==='backup'?'Encrypting and uploading…':'Downloading and decrypting…';
  let json='';if(op==='backup')json=JSON.stringify(A.collectBackup(S().backupPiper!==false));
  const pw=p;$('cbPass').value=$('cbPass2').value='';try{N.cloudRun(op,pw,json)}catch(e){busy=null;$('cbUp').disabled=$('cbDown').disabled=false;$('cbMsg').textContent='Could not start.'}};
 if(S().netOkCloud){go();return}
 A.ask('Cloud backup signs in to your Google account (Drive app folder only) and uploads an encrypted file. It uses the Network permission only when you press Back up or Restore. Continue?',()=>{S().netOkCloud=true;A.save();go()})}
$('cbUp').onclick=()=>run('backup');$('cbDown').onclick=()=>run('restore');
setTimeout(()=>{const s=S();if(N&&N.cloudRun&&s.cloudWeekly&&Date.now()-(s.cloudLast||0)>7*864e5)A.toast('A week has passed since your last cloud backup. Settings › Backup and sync.',5000)},5000);
})();
