/* Sandpiper Desktop behaviour layer (see sandpiper-desktop.html). Runs in the shell, reaches into the same-origin app frame. */
(function(){'use strict';
var f=document.getElementById('spApp');
function inject(){try{var d=f.contentDocument;if(!d||d.getElementById('spDesktopCss'))return;
  var l=d.createElement('link');l.id='spDesktopCss';l.rel='stylesheet';l.href='/desktop/desktop.css';d.head.appendChild(l);
  d.documentElement.classList.add('sp-desktop');
  var t=d.title;if(t)document.title=t}catch(e){}}
f.addEventListener('load',inject);
/* shortcut: "/" opens Assist */
window.addEventListener('keydown',function(e){if(e.key==='/'&&!/INPUT|TEXTAREA/.test((document.activeElement||{}).tagName||'')){try{f.contentWindow.SpAssist.open();e.preventDefault()}catch(x){}}});
document.addEventListener('keydown',function(){},true);
})();
