/* Sandpiper Local Sync: runs in a DESKTOP browser only (the phone serves it to a paired browser; the phone's own WebView never loads it).
   It gives the web UI the same window.SandpiperNative surface as the phone, relayed to the real Bridge over the Bridge v2 envelope
   {v,id,m,p} -> {v,id,ok,d|e}. Calls are synchronous XHRs to the phone (same origin), because the UI reads return values directly. */
(function(){'use strict';
if(window.SandpiperNative)return;
const KEYS=['sandpiper_state_v2','sandpiper_reminders','sandpiper.fitness.v1'];
let id=0,own=0;
function xhr(method,url,body){const x=new XMLHttpRequest();x.open(method,url,false);if(body!=null)x.setRequestHeader('Content-Type','text/plain');x.send(body==null?null:body);return x}
function toLogin(){if(location.pathname!=='/pair')location.href='/pair'}

/* 1. boot from the phone's data once per tab (iframes share sessionStorage, so they do not re-apply it) */
let booted=false;try{booted=sessionStorage.getItem('sp_remote_boot')==='1'}catch(e){}
if(!booted){try{const r=xhr('GET','/snapshot');if(r.status===401){toLogin();return}
 if(r.status===200){const o=JSON.parse(r.responseText);KEYS.forEach(k=>{if(o[k]!=null)localStorage.setItem(k,o[k]);else localStorage.removeItem(k)});sessionStorage.setItem('sp_remote_boot','1')}}catch(e){}}

/* 2. send changes of the mirrored keys back to the phone (debounced, last write wins) */
const queue={};let tm=0;
function flush(){tm=0;Object.keys(queue).forEach(k=>{const v=queue[k];delete queue[k];
 try{const r=xhr('POST','/ls',JSON.stringify({k,v}));if(r.status===401)toLogin()}catch(e){}})}
const set=Storage.prototype.setItem;
Storage.prototype.setItem=function(k,v){set.call(this,k,v);if(this===localStorage&&KEYS.indexOf(k)>=0){queue[k]=String(v);if(!tm)tm=setTimeout(flush,400)}};
window.addEventListener('pagehide',()=>{if(tm){clearTimeout(tm);flush()}});

/* 3. the bridge */
const HIDE=new Set(['assistListen','assistStop','assistSpeak','savePdf','llmRun','pickTone','pickModel','previewTone','stopPreview','requestNotif','requestActivity','openPermission','openAppInfo','sleepEstimate','remoteStart','remoteStop','remoteStatus','remotePairCode','cloudRun','cloudTake','remoteChanged']);
const LOCAL={
 saveFile:(name,mime,b64)=>{try{const bin=atob(b64),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);
  const u=URL.createObjectURL(new Blob([a],{type:mime||'application/octet-stream'})),l=document.createElement('a');l.href=u;l.download=name;document.body.appendChild(l);l.click();l.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);return true}catch(e){return false}},
 openUrl:u=>{try{window.open(u,'_blank','noopener');return true}catch(e){return false}},
 notifEnabled:()=>false};
/* Start-up speed: the app makes hundreds of tiny native calls. Settings are fetched in ONE call and answered from memory,
   writes that need no answer go out in the background, and repeated polling reads are answered from memory for a moment. */
const SHORT={permissions:2000,permState:2000,settingsAll:2000,llmStatus:2000,notifEnabled:5000,brainrotToday:3000,usageToday:3000,focusState:1500,widgetInboxPending:2000,registry:60000,appVersion:60000,trackedAppsCount:5000},
 KEYED=new Set(['appGet','islandGet']),BG=new Set(['settingSet','appSet','islandSet','logSettingChange','logBackup','logSeeded']),memo=new Map(),bgq=[];let ALL=null,bgBusy=false;
function bg(m,a){bgq.push([m,a]);if(bgBusy)return;bgBusy=true;(function next(){const j=bgq.shift();if(!j){bgBusy=false;return}
 fetch('/rpc',{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify({v:1,id:++id,m:j[0],p:j[1]})}).then(r=>r.json()).then(r=>{if(r&&typeof r.n==='number'&&r.n>own)own=r.n}).catch(()=>{}).then(next)})()}
function settings(){if(ALL===null){let r=null;try{r=call2('settingsAll',[])}catch(e){}try{ALL=r?JSON.parse(r):{}}catch(e){ALL={}}}return ALL}
function call(m,a){
 if(m==='settingGet'){const f=settings()[a[0]];return f&&f[a[1]]!==undefined?f[a[1]]:null}
 if(m==='settingSet'){const s=settings();(s[a[0]]=s[a[0]]||{})[a[1]]=String(a[2]);bg(m,a);return true}
 if(m==='appSet'||m==='islandSet'){memo.set(KEYED_KEY(m==='appSet'?'appGet':'islandGet',[a[0]]),{v:String(a[1]),t:Infinity});bg(m,a);return true}
 if(BG.has(m)){bg(m,a);return null}
 if(KEYED.has(m)){const k=KEYED_KEY(m,a),h=memo.get(k);if(h)return h.v;const v=call2(m,a);memo.set(k,{v,t:Infinity});return v}
 if(SHORT[m]){const k=m+'\u0001'+JSON.stringify(a),h=memo.get(k);if(h&&Date.now()<h.t)return h.v;const v=call2(m,a);if(v!==null)memo.set(k,{v,t:Date.now()+SHORT[m]});return v}
 return call2(m,a)}
function KEYED_KEY(m,a){return m+'\u0001'+JSON.stringify(a)}
function call2(m,a){let x;try{x=xhr('POST','/rpc',JSON.stringify({v:1,id:++id,m,p:a}))}catch(e){return null}
 if(x.status===401){toLogin();return null}if(x.status!==200)return null;
 let r;try{r=JSON.parse(x.responseText)}catch(e){return null}if(r&&typeof r.n==='number'&&r.n>own)own=r.n;return r&&r.ok?r.d:null}
window.SandpiperNative=new Proxy({},{get:(_,m)=>{if(typeof m!=='string'||m==='then'||HIDE.has(m))return undefined;if(LOCAL[m])return LOCAL[m];return(...a)=>call(m,a)},has:(_,m)=>!HIDE.has(m)});

/* 4. phone-side changes are applied live: pull the phone's data, then let the app re-read it (no reload, nothing you are typing is lost) */
if(window.top===window){
 let busy=false;
 function applyRemote(){if(busy)return;busy=true;if(tm){clearTimeout(tm);flush()}
  fetch('/snapshot',{cache:'no-store'}).then(r=>r.json()).then(o=>{KEYS.forEach(k=>{if(o[k]!=null&&localStorage.getItem(k)!==o[k])set.call(localStorage,k,o[k])});memo.clear();ALL=null;
   const f=document.getElementById('spApp'),w=f&&f.contentWindow;try{w&&w.SpApp&&w.SpApp.reloadState()}catch(e){}}).catch(()=>{}).then(()=>{busy=false})}
 (function poll(since){const x=new XMLHttpRequest();x.open('GET','/poll?since='+since);
  x.onload=()=>{let v=since;try{v=JSON.parse(x.responseText).v}catch(e){}
   if(x.status===401){toLogin();return}
   if(since!==-1&&v>own&&v!==since){own=v;applyRemote()}setTimeout(()=>poll(v),v===since?0:300)};
  x.onerror=()=>setTimeout(()=>poll(since),4000);x.send()})(-1);
}
})();
