/* Sandpiper insights: automatic sleep estimate (inside More > Sleep journal) and Week / Month reports (inside Track Record).
   Estimates come from phone idle time (native, needs Usage Access). Your own entries always win. Needs window.SpApp. */
(function(){'use strict';
const A=window.SpApp;if(!A)return;
const S=()=>A.S,N=A.N,esc=A.esc,pad=n=>String(n).padStart(2,'0'),$=id=>document.getElementById(id);
const hm=ms=>{const d=new Date(ms);return pad(d.getHours())+':'+pad(d.getMinutes())};
const fh=m=>Math.floor(m/60)+' h '+pad(Math.round(m%60))+' m';
const day=(k,n)=>{const d=A.pd(k);d.setDate(d.getDate()+n);return A.iso(d)};
const range=(a,b)=>{const o=[];for(let k=a;k<=b;k=day(k,1))o.push(k);return o};

/* ================= sleep ================= */
function auto(){const s=S();if(!s.sleepEst||typeof s.sleepEst!=='object')s.sleepEst={};if(!s.sleepBias||typeof s.sleepBias!=='object')s.sleepBias={bed:[],wake:[]};return s}
const med=a=>{if(!a.length)return 0;const b=a.slice().sort((x,y)=>x-y);return b[Math.floor(b.length/2)]};
const bias=k=>Math.max(-120,Math.min(120,med(auto().sleepBias[k]||[])));
const manual=k=>S().sleep.find(z=>z.date===k&&!z.auto);
function sleepMins(k){const m=manual(k);if(m)return{mins:m.mins,auto:false};const a=S().sleep.find(z=>z.date===k&&z.auto);if(a)return{mins:a.mins,auto:true};
 const e=auto().sleepEst[k];return e?{mins:e.mins,auto:true}:null}
function lastNight(){const k=A.today();return sleepMins(k)}
function enabled(){return S().sleepAuto!==false}
function refresh(){try{
 if(N&&N.sleepEstimate&&enabled()){const s=auto(),now=new Date(),t=A.today();if(s.sleepEstV!==2){s.sleepEst={};s.sleepEstV=2}   // v2: night-only idleness, wake = first morning check
  for(let i=0;i<7;i++){const k=day(t,-i);if(i===0&&now.getHours()<6)continue;if(i>0&&s.sleepEst[k])continue;
   let r;try{r=JSON.parse(N.sleepEstimate(k))}catch(e){continue}
   if(r&&r.ok){const b=r.bed+bias('bed')*60000,w=r.wake+bias('wake')*60000;s.sleepEst[k]={bed:b,wake:w,mins:Math.round((w-b)/60000),conf:r.conf,checks:r.checks||[],ok:false}}
   else if(i>0)s.sleepEst[k]=s.sleepEst[k]||null}
  const ks=Object.keys(s.sleepEst).sort();while(ks.length>40)delete s.sleepEst[ks.shift()];A.save()}
 renderSleep();weeklyNotice()}catch(e){}}
function confirm(k,dBed,dWake){const s=auto(),e=s.sleepEst[k];if(!e)return;
 if(dBed||dWake){e.bed+=dBed*60000;e.wake+=dWake*60000;e.mins=Math.round((e.wake-e.bed)/60000);
  if(dBed){s.sleepBias.bed.push(dBed);s.sleepBias.bed=s.sleepBias.bed.slice(-7)}if(dWake){s.sleepBias.wake.push(dWake);s.sleepBias.wake=s.sleepBias.wake.slice(-7)}}
 e.ok=true;s.sleep=s.sleep.filter(z=>!(z.date===k&&z.auto));s.sleep.push({date:k,mins:e.mins,feel:'Okay',auto:true});A.save();A.renderMore();A.renderHome();renderSleep()}
function renderSleep(){const el=$('sleepAuto');if(!el)return;
 if(!N||!N.sleepEstimate||!enabled()){el.innerHTML='';return}
 const k=A.today(),s=auto(),e=s.sleepEst[k],m=manual(k);
 if(!A.permOK('usage')){el.innerHTML='<div class="small muted" style="margin-top:10px">Automatic estimate is on but needs Usage Access.</div><button class="btn secondary" style="margin-top:8px" id="slUse" type="button">Allow Usage Access</button>';$('slUse').onclick=()=>A.needPerm('usage');return}
 const nights=range(day(k,-6),k).map(d=>{const v=sleepMins(d);return v?v.mins/60:0}),
  bars='<div class="act-chart" style="height:70px;margin-top:10px">'+nights.map(h=>`<span class="bar ${h?(h<8?'over':''):'none'}" style="height:${h?Math.max(h/10*100,4):0}%;flex:1" title="${h.toFixed(1)} h"></span>`).join('')+'</div>';
 let top='';
 if(m)top='<div class="small muted" style="margin-top:10px">Your own entry for last night is used (estimate hidden).</div>';
 else if(!e)top='<div class="small muted" style="margin-top:10px">No estimate yet. It appears after a night with the screen off for 3 hours or more.</div>';
 else{const g=(e.checks||[]).length;top=`<div style="margin-top:10px"><span class="tag">Auto · estimated</span></div><div class="stat-value" style="margin-top:6px">${fh(e.mins)}</div>
  <div class="small muted">Bed ${hm(e.bed)} · Wake ${hm(e.wake)} · Confidence ${e.conf}%${g?' · '+g+' check'+(g>1?'s':''):''}</div>
  <p class="small muted" style="margin:6px 0 0">From how long the phone sat idle. Not a medical sensor.${e.ok?' Confirmed.':''}</p>
  ${e.ok?'':'<div class="actions" style="margin-top:10px;flex-wrap:wrap"><button class="btn secondary" data-sl="bed" type="button">Bed 15 min earlier</button><button class="btn secondary" data-sl="wake" type="button">Wake 15 min later</button><button class="btn secondary" data-sl="edit" type="button">Edit times</button><button class="btn" data-sl="ok" type="button">Looks right</button></div><div id="slEdit" hidden style="margin-top:10px;display:none;gap:8px;align-items:center;flex-wrap:wrap"><label class="small muted">Bed <input type="time" id="slBed" value="${hm(e.bed)}"></label><label class="small muted">Wake <input type="time" id="slWake" value="${hm(e.wake)}"></label><button class="btn" data-sl="save" type="button">Save</button></div>'}`}
 el.innerHTML=top+bars+'<div class="small muted" style="margin-top:4px">Last 7 nights · gold = under 8 h</div>'}
document.addEventListener('click',e=>{const b=e.target.closest('[data-sl]');if(!b)return;const k=A.today(),d=b.dataset.sl;
 if(d==='edit'){const x=$('slEdit');if(x){x.hidden=false;x.style.display='flex'}return}
 if(d==='save'){const e0=auto().sleepEst[k],bv=$('slBed').value,wv=$('slWake').value;if(!e0||!bv||!wv)return;
  const [bh,bm]=bv.split(':').map(Number),[wh,wm]=wv.split(':').map(Number),w=new Date(e0.wake);w.setHours(wh,wm,0,0);
  const bd=new Date(w);bd.setHours(bh,bm,0,0);if(bd>=w)bd.setDate(bd.getDate()-1);   // bed is the last time before wake
  if(w-bd<60*60000||w-bd>16*3600000){A.toast('Those times do not look like one night of sleep.');return}
  confirm(k,Math.round((bd-e0.bed)/60000),Math.round((w-e0.wake)/60000));A.toast('Saved. Future estimates learn from your times.');return}
 if(d==='bed'){confirm(k,-15,0);A.toast('Saved as your correction. Future estimates learn from it.')}else if(d==='wake'){confirm(k,0,15);A.toast('Saved as your correction.')}else{confirm(k,0,0);A.toast('Confirmed.')}});
new MutationObserver(()=>{const m=$('more');if(m&&m.classList.contains('active'))renderSleep()}).observe($('more'),{attributes:true,attributeFilter:['class']});

/* ================= reports ================= */
let per='day',anchor=null;
const mon=k=>{const d=A.pd(k),w=(d.getDay()+6)%7;d.setDate(d.getDate()-w);return A.iso(d)};
function span(){const t=A.today();
 if(per==='week'){const a=anchor||mon(t);return{a,b:day(a,6),pa:day(a,-7),pb:day(a,-1),name:'week'}}
 const d=A.pd(anchor||t.slice(0,8)+'01');const a=A.iso(new Date(d.getFullYear(),d.getMonth(),1)),b=A.iso(new Date(d.getFullYear(),d.getMonth()+1,0));
 return{a,b,pa:A.iso(new Date(d.getFullYear(),d.getMonth()-1,1)),pb:A.iso(new Date(d.getFullYear(),d.getMonth(),0)),name:'month'}}
function stats(a,b){const s=S(),t=A.today(),ks=range(a,b).filter(k=>k<=t),X=A.dayIndex(),o={days:ks.length,tasks:0,focus:0,spend:0,income:0,food:0,tx:0,steps:0,stepDays:0,water:0,waterDays:0,reels:0,reelDays:0,habit:0,sleepN:0,sleepSum:0,sleep8:0,hasData:false};
 const bed=[];
 ks.forEach(k=>{const x=X[k];
  o.tasks+=A.planTasks(k,s.days.find(d=>d.date===k)||null).filter(z=>z.done).length;
  const dbm=((A.dbDay(k)||{}).metrics)||{};o.focus+=x&&x.focus?x.focus:(dbm['focus.min']||0);
  if(x){x.tx.forEach(z=>{o.tx++;if(z.kind==='expense'){o.spend+=+z.amount;if(/food/i.test(z.cat))o.food+=+z.amount}else o.income+=+z.amount})}
  const st=s.stepHist[k]!=null?s.stepHist[k]:dbm['steps.count'];if(st!=null){o.steps+=st;if(st>=s.stepGoal)o.stepDays++}
  const w=s.water[k]!=null?s.water[k]:dbm['water.ml'];if(w!=null&&w>=s.waterGoal)o.waterDays++;
  const r=A.reelsOn(k);if(r!=null){o.reels+=r;o.reelDays++}
  o.habit+=s.habits.filter(h=>(h.done||[]).includes(k)).length;
  const sl=sleepMins(k);if(sl){o.sleepN++;o.sleepSum+=sl.mins;if(sl.mins>=480)o.sleep8++}
  const e=auto().sleepEst[k];if(e&&e.bed){const d=new Date(e.bed);let m=d.getHours()*60+d.getMinutes();if(m<720)m+=1440;bed.push(m)}});
 o.sleepAvg=o.sleepN?o.sleepSum/o.sleepN:null;
 if(bed.length>2){const mu=bed.reduce((x,y)=>x+y,0)/bed.length;o.bedVar=Math.round(Math.sqrt(bed.reduce((x,y)=>x+(y-mu)*(y-mu),0)/bed.length))}
 o.save=o.income>0?Math.round((o.income-o.spend)/o.income*100):null;
 o.hasData=!!(o.tasks||o.focus||o.tx||o.steps||o.sleepN||o.reels||o.habit);return o}
const pc=(a,b)=>b?Math.round((a-b)/b*100):null;
function verdicts(c,p){const V={};
 V.time=!c.tasks&&!p.tasks?['No data','']:p.tasks&&c.tasks<p.tasks*.7?['Slipping','r']:p.tasks&&c.tasks>=p.tasks*.9||!p.tasks?['On track','g']:['Steady',''];
 V.money=!c.tx?['No data','']:p.spend&&c.spend>p.spend*1.15?['Slipping','w']:!p.spend||c.spend<=p.spend?['On track','g']:['Steady',''];
 V.body=c.sleepAvg==null&&!c.steps?['No data','']:c.sleepAvg!=null&&c.sleepAvg<420?['Slipping','w']:c.sleepAvg!=null&&c.sleepAvg>=480?['On track','g']:['Steady',''];
 const fd=pc(c.focus,p.focus),rd=p.reels?pc(c.reels,p.reels):null;
 V.mind=!c.focus&&!c.reelDays?['No data','']:fd!=null&&fd<-5&&rd!=null&&rd>10?['Slipping','r']:fd!=null&&fd>5||(rd!=null&&rd<-10)?['On track','g']:['Steady',''];return V}
const arrow=(v,good)=>v==null?'<span class="muted">–</span>':v===0?'<span class="muted">● steady</span>':`<span style="color:var(--${(v>0)===good?'mint':'rose'});font-weight:700">${v>0?'▲':'▼'} ${Math.abs(v)}%</span>`;
function label(sp){const f=k=>A.pd(k).toLocaleDateString('en-US',{day:'numeric',month:'short'});return sp.name==='week'?'Week '+f(sp.a)+' – '+f(sp.b):A.pd(sp.a).toLocaleDateString('en-US',{month:'long',year:'numeric'})}
function model(){const sp=span(),c=stats(sp.a,sp.b),p=stats(sp.pa,sp.pb),v=verdicts(c,p);return{sp,c,p,v}}
function render(){const{sp,c,p,v}=model(),t=A.today(),el=$('trBody');
 $('trTitle').textContent=label(sp);$('trSub').textContent=sp.b>=t?(sp.name==='week'?'This week, in progress':'This month, in progress'):'';
 $('trPick').parentElement.style.display='none';$('trPrev').disabled=false;$('trNext').disabled=sp.b>=t;
 if(!c.hasData){el.innerHTML='<div class="card"><div class="empty"><b style="display:block;margin-bottom:4px">Nothing recorded</b>Sandpiper has no entries in this '+sp.name+'. It is not counted as a zero.</div></div>';return}
 const tag=x=>`<span class="tag ${x[1]==='g'?'green':x[1]==='r'||x[1]==='w'?'bad':''}">${x[0]}</span>`,
  cmp=sp.name==='week'?'last week':'last month',
  tile=(n,x,w)=>`<div><b>${n}</b><span>${tag(x)}</span><span class="muted small" style="display:block;margin-top:4px">${w}</span></div>`,
  row=(g,vv)=>`<div class="tr-row"><span class="g">${g}</span><span class="v">${vv}</span></div>`,
  pgr=(n,a,b)=>{const pct=b?Math.round(a/b*100):0;return `<div style="margin:9px 0"><div style="display:flex;justify-content:space-between;font-size:13px"><span>${n}</span><b>${a}/${b}</b></div><div class="progress"><span style="width:${Math.min(100,pct)}%"></span></div></div>`};
 el.innerHTML=
 `<div class="card"><div class="card-head"><h2 style="font-size:15px">Where you stand</h2></div><div class="tr-strip" style="grid-template-columns:1fr 1fr">${
  tile('Time',v.time,c.tasks+' tasks done')+tile('Money',v.money,c.tx?'Spent '+A.money(c.spend)+(c.save!=null?' · saved '+c.save+'%':''):'No transactions')+
  tile('Body',v.body,c.sleepAvg!=null?'Sleep avg '+(c.sleepAvg/60).toFixed(1)+' h · '+c.sleep8+' nights ≥ 8 h':'Steps '+c.steps.toLocaleString('en-US'))+
  tile('Mind',v.mind,c.focus+' focus min'+(c.reelDays?' · '+c.reels+' reels':''))}</div></div>
 <div class="card"><div class="card-head"><h2 style="font-size:15px">What changed vs ${cmp}</h2></div>${
  row('Focus time',arrow(pc(c.focus,p.focus),true)+' <span class="muted small">'+Math.floor(c.focus/60)+'h '+c.focus%60+'m</span>')+
  (c.sleepAvg!=null?row('Sleep (avg)',arrow(p.sleepAvg?pc(c.sleepAvg,p.sleepAvg):null,true)+' <span class="muted small">'+(c.sleepAvg/60).toFixed(1)+' h</span>'):'')+
  (c.reelDays?row('Reels watched',arrow(pc(c.reels,p.reels),false)+' <span class="muted small">'+c.reels+'</span>'):'')+
  (c.tx?row('Spending',arrow(pc(c.spend,p.spend),false)+' <span class="muted small">'+A.money(c.spend)+'</span>'):'')+
  (c.save!=null?row('Savings rate','<span class="muted">'+c.save+'%'+(p.save!=null?' (was '+p.save+'%)':'')+'</span>'):'')+
  row('Tasks done',arrow(pc(c.tasks,p.tasks),true)+' <span class="muted small">'+c.tasks+'</span>')}</div>
 <div class="card"><div class="card-head"><h2 style="font-size:15px">Progress vs activity</h2></div><div class="small muted">Progress toward your goals</div>${
  pgr('Steps goal days',c.stepDays,c.days)+pgr('Sleep 8 h nights',c.sleep8,c.days)+pgr('Water goal days',c.waterDays,c.days)+(S().habits.length?pgr('Habit check-ins',c.habit,S().habits.length*c.days):'')}
  <div class="small muted" style="margin-top:10px">Activity (volume only)</div>${row('Tasks',c.tasks)+row('Transactions',c.tx)+row('Focus min',c.focus)}
  ${c.bedVar!=null?'<div class="small muted" style="margin-top:8px">Bedtime varies about ±'+c.bedVar+' min (estimated nights).</div>':''}</div>
 <div class="actions" style="margin-top:4px"><button class="btn secondary" data-rx="md" type="button">Markdown</button><button class="btn secondary" data-rx="csv" type="button">CSV</button><button class="btn" data-rx="pdf" type="button">PDF</button></div>`}
function text(m){const{sp,c,p,v}=m,L=[label(sp),'',
 'Time: '+v.time[0]+' ('+c.tasks+' tasks done, was '+p.tasks+')','Money: '+v.money[0]+' (spent '+A.money(c.spend)+', was '+A.money(p.spend)+(c.save!=null?', savings rate '+c.save+'%':'')+')',
 'Body: '+v.body[0]+(c.sleepAvg!=null?' (sleep avg '+(c.sleepAvg/60).toFixed(1)+' h, '+c.sleep8+' nights of 8 h or more; estimated nights come from phone idle time)':'')+(c.steps?', steps '+c.steps:''),
 'Mind: '+v.mind[0]+' (focus '+c.focus+' min, was '+p.focus+(c.reelDays?'; reels '+c.reels+', was '+p.reels:'')+')','',
 'Goals: steps goal on '+c.stepDays+' of '+c.days+' days; water goal on '+c.waterDays+'; habit check-ins '+c.habit+'.','Transactions: '+c.tx+'.'];return L.join('\n')}
document.addEventListener('click',e=>{const b=e.target.closest('[data-rx]');if(!b||per==='day')return;const m=model(),n='sandpiper-'+m.sp.name+'-'+m.sp.a;
 if(b.dataset.rx==='md')A.saveFile(n+'.md','text/markdown',new Blob(['# '+label(m.sp)+'\n\n'+text(m).split('\n').slice(2).map(x=>'- '+x).join('\n')+'\n'],{type:'text/markdown'}));
 else if(b.dataset.rx==='csv'){const c=m.c,p=m.p,r=[['Metric','This period','Previous period'],['Tasks done',c.tasks,p.tasks],['Focus min',c.focus,p.focus],['Spent',c.spend,p.spend],['Income',c.income,p.income],['Transactions',c.tx,p.tx],['Sleep avg h',c.sleepAvg!=null?(c.sleepAvg/60).toFixed(2):'',p.sleepAvg!=null?(p.sleepAvg/60).toFixed(2):''],['Steps',c.steps,p.steps],['Reels',c.reels,p.reels],['Habit check-ins',c.habit,p.habit]];
  A.saveFile(n+'.csv','text/csv',new Blob(['\ufeff'+r.map(x=>x.join(',')).join('\r\n')],{type:'text/csv'}))}
 else{if(N&&N.savePdf)A.toast(N.savePdf(n+'.pdf',label(m.sp),text(m))?'Saved: '+n+'.pdf':'Could not save the PDF.');else A.toast('PDF export works in the Android app.')}});
function weekSummary(){const sp={a:mon(A.today())},c=stats(sp.a,A.today()),p=stats(day(sp.a,-7),day(sp.a,-1));if(!c.hasData)return '';
 const v=verdicts(c,p);return 'This week so far: Time '+v.time[0].toLowerCase()+', Money '+v.money[0].toLowerCase()+', Body '+v.body[0].toLowerCase()+', Mind '+v.mind[0].toLowerCase()+'.'}
function weeklyNotice(){const s=S();if(s.weeklyPrep===false)return;const lw=day(mon(A.today()),-7);if(s.weeklySeen===lw)return;
 if(stats(lw,day(lw,6)).hasData){s.weeklySeen=lw;A.save();setTimeout(()=>A.toast('Last week’s report is ready in Track Record.',4500),1500)}else{s.weeklySeen=lw;A.save()}}

/* period switch inside the Track Record sheet */
const bar=document.createElement('div');bar.className='act-chips';bar.id='trPer';bar.style.cssText='margin:6px 0 10px';
bar.innerHTML=['day','week','month'].map(k=>`<button class="act-chip" type="button" data-per="${k}" aria-pressed="${k==='day'}">${k[0].toUpperCase()+k.slice(1)}</button>`).join('');
$('trBody').parentElement.insertBefore(bar,$('trBody'));
function setPer(k){per=k;anchor=null;bar.querySelectorAll('[data-per]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.per===k)));
 $('trPick').parentElement.style.display=k==='day'?'':'none';A.renderTR()}
bar.addEventListener('click',e=>{const b=e.target.closest('[data-per]');if(b)setPer(b.dataset.per)});
window.SpInsights={active:()=>per!=='day',render,reset:k=>{if(k==='week'||k==='month')setPer(k);else if(per!=='day')setPer('day')},
 step:n=>{const sp=span();if(n===0)anchor=null;else anchor=n<0?sp.pa:day(sp.b,1);A.renderTR()},refresh,lastNight,weekSummary};
setTimeout(refresh,1200);
})();
