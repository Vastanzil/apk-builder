package com.vastanzil.sandpiper.remote

import java.util.concurrent.atomic.AtomicLong

/** Pure, in-memory state shared by the Local Sync server and the change bus. No Android, no sockets. */
object RemoteState {
    @Volatile var running = false
    @Volatile var lastTouch = 0L
    @Volatile var dirty = false
    private val ver = AtomicLong(0)

    val version: Long get() = ver.get()

    /** Called by the change bus after every native write. Free when Local Sync is off. */
    fun bump(): Boolean {
        if (!running) return false
        ver.incrementAndGet()
        return true
    }

    fun touch(now: Long = System.currentTimeMillis()) { lastTouch = now }
    fun reset() { running = false; dirty = false; lastTouch = 0L }
}
