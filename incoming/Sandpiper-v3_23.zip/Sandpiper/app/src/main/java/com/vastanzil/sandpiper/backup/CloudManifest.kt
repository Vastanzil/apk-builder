package com.vastanzil.sandpiper.backup

import org.json.JSONObject
import java.util.Base64

/** The non-secret description stored beside the encrypted blob. Everything needed to attempt a decrypt except the passphrase. */
data class CloudManifest(
    val appId: String, val format: Int, val appVersion: String, val dbSchema: Int,
    val salt: ByteArray, val kdf: Kdf, val createdAt: Long
) {
    fun toJson(): String = JSONObject().put("app", appId).put("format", format).put("appVersion", appVersion).put("dbSchema", dbSchema)
        .put("salt", Base64.getEncoder().encodeToString(salt)).put("kdfMemKb", kdf.memKb).put("kdfIter", kdf.iterations)
        .put("kdfPar", kdf.parallelism).put("createdAt", createdAt).toString()

    companion object {
        private val REQUIRED = listOf("app", "format", "appVersion", "dbSchema", "salt", "kdfMemKb", "kdfIter", "kdfPar", "createdAt")

        fun parse(text: String): CloudManifest {
            val bad = BackupCryptoException(BackupCryptoException.Kind.BAD_MANIFEST)
            val o = try { JSONObject(text) } catch (e: Exception) { throw bad }
            for (k in REQUIRED) if (!o.has(k) || o.isNull(k)) throw bad
            try {
                if (o.getString("app") != "sandpiper") throw bad
                val kdf = Kdf(o.getInt("kdfMemKb"), o.getInt("kdfIter"), o.getInt("kdfPar"))
                if (kdf.memKb < 8 || kdf.iterations < 1 || kdf.parallelism < 1 || kdf.memKb > 1_048_576) throw bad
                return CloudManifest("sandpiper", o.getInt("format"), o.getString("appVersion"), o.getInt("dbSchema"),
                    Base64.getDecoder().decode(o.getString("salt")), kdf, o.getLong("createdAt"))
            } catch (e: BackupCryptoException) { throw e } catch (e: Exception) { throw bad }
        }
    }
}
