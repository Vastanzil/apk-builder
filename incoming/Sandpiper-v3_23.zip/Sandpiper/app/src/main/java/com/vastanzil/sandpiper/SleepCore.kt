package com.vastanzil.sandpiper

import org.json.JSONArray
import org.json.JSONObject

/**
 * Estimates last night's sleep from how long the screen stayed off. Pure Kotlin (no Android imports) so plain JUnit covers it.
 * Input: screen-off intervals as [startMs, endMs]. Brief screen-on checks (up to [MERGE_GAP_MS]) do not split the night; they are reported as gaps.
 * This is an estimate from phone idle time, not a medical measurement, and the user's own entry always wins.
 */
object SleepCore {
    const val MERGE_GAP_MS = 20L * 60_000
    const val MIN_NIGHT_MS = 3L * 3_600_000
    /** After 06:30, a screen-on that follows at least 4 h of idleness is the wake-up, even if the phone is then left alone again. */
    const val MORNING_FROM = 6 * 60 + 30
    const val MORNING_TO = 12 * 60
    const val SLEPT_ENOUGH_MS = 4L * 3_600_000
    /** Only idleness that STARTS at night counts as sleep: 20:00 to 06:00. Daytime idleness is never sleep. */
    const val NIGHT_FROM = 20 * 60
    const val NIGHT_TO = 6 * 60

    data class Est(val bed: Long, val wake: Long, val checks: List<Long>, val confidence: Int) {
        val mins: Long get() = (wake - bed) / 60_000
        fun json(): JSONObject = JSONObject().put("ok", true).put("bed", bed).put("wake", wake).put("mins", mins)
            .put("conf", confidence).put("checks", JSONArray(checks))
    }

    /** Minutes since local midnight for an epoch time. The default is UTC (tests); the Bridge passes the phone's zone. */
    val UTC_MINUTES: (Long) -> Int = { ms -> Math.floorMod(ms / 60_000L, 1440L).toInt() }

    private fun isNight(m: Int) = m >= NIGHT_FROM || m < NIGHT_TO
    private fun isMorning(m: Int) = m in MORNING_FROM until MORNING_TO

    fun estimate(off: List<LongArray>, winStart: Long, winEnd: Long, minuteOfDay: (Long) -> Int = UTC_MINUTES): Est? {
        val clipped = off.mapNotNull { v ->
            val s = maxOf(v[0], winStart); val e = minOf(v[1], winEnd)
            if (e > s) longArrayOf(s, e) else null
        }.sortedBy { it[0] }
        if (clipped.isEmpty()) return null
        val merged = ArrayList<LongArray>()
        val gapsOf = ArrayList<MutableList<Long>>()
        for (v in clipped) {
            val last = merged.lastOrNull()
            val joinable = last != null && v[0] - last[1] <= MERGE_GAP_MS &&
                !(isMorning(minuteOfDay(last[1])) && last[1] - last[0] >= SLEPT_ENOUGH_MS)
            if (last != null && joinable) {
                gapsOf.last().add(last[1])
                last[1] = maxOf(last[1], v[1])
            } else { merged.add(longArrayOf(v[0], v[1])); gapsOf.add(ArrayList()) }
        }
        var best = -1
        for (i in merged.indices) {
            if (!isNight(minuteOfDay(merged[i][0]))) continue
            if (best < 0 || merged[i][1] - merged[i][0] > merged[best][1] - merged[best][0]) best = i
        }
        if (best < 0) return null
        val b = merged[best]
        val len = b[1] - b[0]
        if (len < MIN_NIGHT_MS) return null
        val checks = gapsOf[best]
        val hours = len / 3_600_000.0
        val conf = (50 + minOf(30.0, (hours - 3) * 6) - 6 * minOf(checks.size, 4)).toInt().coerceIn(30, 95)
        return Est(b[0], b[1], checks, conf)
    }
}
