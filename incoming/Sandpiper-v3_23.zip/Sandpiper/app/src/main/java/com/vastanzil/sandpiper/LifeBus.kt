package com.vastanzil.sandpiper

import android.content.Context

/**
 * The change bus of the Life OS. Every native store calls changed() after a successful write, whoever made it (the app's web layer,
 * a widget, the SMS reader, the scheduler). Subscribers: the home-screen widgets, storage jobs and Local Sync (a free no-op while it is off); new surfaces subscribe here,
 * not in the writers. Debounced inside Widgets.refreshSoon, so a burst of writes refreshes once.
 */
internal object LifeBus {
    fun changed(c: Context) {
        try { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(c) } catch (e: Throwable) { /* a subscriber must never break a writer */ }
        try { StorageJobs.schedule(c) } catch (e: Throwable) { }
        try { com.vastanzil.sandpiper.remote.RemoteSyncServer.notifyChanged(c) } catch (e: Throwable) { }
    }
}
