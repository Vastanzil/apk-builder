package com.vastanzil.sandpiper.remote

import android.content.Context
import android.webkit.JavascriptInterface
import com.vastanzil.sandpiper.MainActivity
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.Timer
import java.util.TimerTask
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Local Sync: a small HTTP server on the phone's Wi-Fi address, started only from Settings > Local Sync, never at boot.
 * A desktop browser pairs with a 6-digit code, then loads the same web UI; every Bridge call is relayed through [RemoteRpc]
 * to the real Bridge on the phone. The phone stays the only source of truth. No internet access: LAN only.
 */
object RemoteSyncServer {
    const val DEFAULT_PORT = 8787
    private const val IDLE_STOP_MS = 10 * 60_000L
    /** localStorage keys mirrored to the desktop tab (the web-only stores; see the plan, section 2.1). */
    private val MIRRORED = setOf("sandpiper_state_v2", "sandpiper_reminders", "sandpiper.fitness.v1")

    val pairing = PairingManager()
    private var srv: Srv? = null
    private var host = ""
    private var port = DEFAULT_PORT
    private var timer: Timer? = null

    /** Called by the change bus after every native write. Returns at once when the server is off. */
    fun notifyChanged(@Suppress("UNUSED_PARAMETER") c: Context) { RemoteState.bump() }

    /** True once if the desktop changed data while the phone page was open; the activity then reloads the page. */
    fun consumeDirty(): Boolean { val d = RemoteState.dirty; RemoteState.dirty = false; return d }

    fun status(): String = JSONObject().put("running", RemoteState.running).put("url", if (RemoteState.running) "http://$host:$port" else "")
        .put("port", port).put("paired", pairing.count()).toString()

    fun pairCode(): String {
        if (!RemoteState.running) return JSONObject().put("code", "").put("secs", 0).toString()
        val c = pairing.startPairing()
        return JSONObject().put("code", c.value).put("secs", maxOf(0L, (c.expiresAt - System.currentTimeMillis()) / 1000)).toString()
    }

    @Synchronized fun start(a: MainActivity, portIn: Int, remember: Boolean): String {
        if (RemoteState.running) return status()
        val p = if (portIn in 1024..65535) portIn else DEFAULT_PORT
        val ip = lanIp() ?: return JSONObject().put("running", false).put("error", "no_wifi").toString()
        val b = a.remoteBridge() ?: return JSONObject().put("running", false).put("error", "no_bridge").toString()
        return try {
            val s = Srv(ip, p, a, b)
            s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            srv = s; host = ip; port = p
            RemoteState.reset(); RemoteState.running = true; RemoteState.touch()
            pairing.rememberSession = remember
            timer = Timer(true).also { t -> t.schedule(object : TimerTask() { override fun run() {
                if (System.currentTimeMillis() - RemoteState.lastTouch > IDLE_STOP_MS) stop()
            } }, 30_000L, 30_000L) }
            status()
        } catch (e: Exception) { JSONObject().put("running", false).put("error", "bind").toString() }
    }

    @Synchronized fun stop() {
        try { srv?.stop() } catch (e: Exception) { }
        srv = null
        timer?.cancel(); timer = null
        pairing.revokeAll()
        RemoteState.reset()
    }

    /** The phone's Wi-Fi (or hotspot) IPv4 address on the local network; null when there is none. */
    fun lanIp(): String? = try {
        val all = Collections.list(NetworkInterface.getNetworkInterfaces()).filter { it.isUp && !it.isLoopback }
        val addrs = all.sortedBy { if (it.name.startsWith("wlan") || it.name.startsWith("ap")) 0 else 1 }
            .flatMap { Collections.list(it.inetAddresses) }.filterIsInstance<Inet4Address>().filter { it.isSiteLocalAddress }
        addrs.firstOrNull()?.hostAddress
    } catch (e: Exception) { null }

    private class Srv(host: String, port: Int, val a: MainActivity, val bridge: Any) : NanoHTTPD(host, port) {
        private val methods = bridge.javaClass.methods.filter { it.isAnnotationPresent(JavascriptInterface::class.java) }
        private val known = methods.map { it.name }.toSet()

        private fun text(st: Response.IStatus, mime: String, s: String): Response = newFixedLengthResponse(st, mime, s)

        private fun token(s: IHTTPSession): String? =
            s.headers["cookie"]?.split(";")?.map { it.trim() }?.firstOrNull { it.startsWith("sp_t=") }?.substring(5)

        private fun body(s: IHTTPSession): String? {
            val len = s.headers["content-length"]?.toLongOrNull() ?: 0L
            if (len > RemoteRpc.MAX_BYTES) return null
            val files = HashMap<String, String>()
            s.parseBody(files)
            return files["postData"] ?: ""
        }

        override fun serve(s: IHTTPSession): Response {
            RemoteState.touch()
            return try { route(s) } catch (e: Throwable) { text(Response.Status.INTERNAL_ERROR, "text/plain", "error") }
        }

        private fun route(s: IHTTPSession): Response {
            val uri = s.uri
            val ip = s.remoteIpAddress ?: "?"
            if (uri == "/pair") {
                if (s.method == Method.POST) {
                    val b = body(s) ?: return text(Response.Status.BAD_REQUEST, "text/plain", "too large")
                    return when (val r = pairing.redeem(ip, b)) {
                        is PairingManager.Redeem.Ok -> text(Response.Status.OK, "text/plain", "ok").also { it.addHeader("Set-Cookie", "sp_t=${r.token}; Path=/; HttpOnly; SameSite=Strict") }
                        is PairingManager.Redeem.Locked -> text(Response.Status.FORBIDDEN, "text/plain", "locked:${r.seconds}")
                        is PairingManager.Redeem.Expired -> text(Response.Status.FORBIDDEN, "text/plain", "expired")
                        else -> text(Response.Status.FORBIDDEN, "text/plain", "wrong")
                    }
                }
                return text(Response.Status.OK, "text/html; charset=utf-8", PAIR_PAGE)
            }
            if (!pairing.valid(token(s))) {
                if (s.method == Method.GET && (uri == "/" || uri.endsWith(".html"))) return newFixedLengthResponse(Response.Status.REDIRECT_SEE_OTHER, "text/plain", "").also { it.addHeader("Location", "/pair") }
                return text(Response.Status.UNAUTHORIZED, "text/plain", "pair first")
            }
            when (uri) {
                "/rpc" -> {
                    val b = body(s) ?: return text(Response.Status.BAD_REQUEST, "application/json", "{\"v\":1,\"ok\":false,\"e\":{\"code\":\"E_TOO_LARGE\"}}")
                    val res = RemoteRpc.handle(b, known) { m, p -> invoke(m, p) }
                    // the version after this call lets the desktop tell its own changes from changes made on the phone
                    return text(Response.Status.OK, "application/json", JSONObject(res).put("n", RemoteState.version).toString())
                }
                "/_manifest" -> return text(Response.Status.OK, "application/json", manifest())
                "/snapshot" -> return text(Response.Status.OK, "application/json", snapshot())
                "/ls" -> {
                    val b = body(s) ?: return text(Response.Status.BAD_REQUEST, "text/plain", "too large")
                    val o = JSONObject(b)
                    val k = o.getString("k")
                    if (k !in MIRRORED) return text(Response.Status.FORBIDDEN, "text/plain", "key")
                    // write, then tell the live phone page to re-read it so the change shows at once (and is not overwritten by a stale copy)
                    a.js("localStorage.setItem(" + JSONObject.quote(k) + "," + JSONObject.quote(o.getString("v")) + ");" +
                        "window.SpApp&&(" + (if (k == "sandpiper_state_v2") "SpApp.reloadState()" else "SpApp.refresh()") + ")")
                    return text(Response.Status.OK, "text/plain", "ok")
                }
                "/poll" -> {
                    val since = s.parameters["since"]?.firstOrNull()?.toLongOrNull() ?: -1L
                    val end = System.currentTimeMillis() + 20_000L
                    while (RemoteState.running && RemoteState.version == since && System.currentTimeMillis() < end) Thread.sleep(300)
                    return text(Response.Status.OK, "application/json", "{\"v\":${RemoteState.version}}")
                }
            }
            return asset(s, uri)
        }

        private fun invoke(m: String, p: JSONArray): Any? {
            val mt = methods.firstOrNull { it.name == m && it.parameterTypes.size == p.length() } ?: throw NoSuchMethodException(m)
            val args = Array<Any?>(p.length()) { i ->
                val v = p.opt(i)
                when (mt.parameterTypes[i]) {
                    String::class.java -> if (v == null || v == JSONObject.NULL) "" else v.toString()
                    Int::class.javaPrimitiveType, Int::class.javaObjectType -> (v as Number).toInt()
                    Long::class.javaPrimitiveType, Long::class.javaObjectType -> (v as Number).toLong()
                    Double::class.javaPrimitiveType, Double::class.javaObjectType -> (v as Number).toDouble()
                    Boolean::class.javaPrimitiveType, Boolean::class.javaObjectType -> v as Boolean
                    else -> v
                }
            }
            return mt.invoke(bridge, *args)
        }

        /** The mirrored localStorage keys, read from the phone's own page. */
        private fun snapshot(): String {
            val latch = CountDownLatch(1)
            var out = "{}"
            a.evalJs("(function(){var o={};" + MIRRORED.joinToString("") { "var v=localStorage.getItem('$it');if(v!==null)o['$it']=v;" } + "return JSON.stringify(o)})()") { r ->
                try { out = (JSONTokener(r ?: "\"{}\"").nextValue() as? String) ?: "{}" } catch (e: Exception) { }
                latch.countDown()
            }
            latch.await(5, TimeUnit.SECONDS)
            return out
        }

        private class Cached(val raw: ByteArray, val gz: ByteArray?, val mime: String, val etag: String)
        private val cache = java.util.concurrent.ConcurrentHashMap<String, Cached>()
        private val TEXT = setOf("html", "js", "css", "json", "svg", "ttf")

        /** Every bundled file the desktop UI can ask for, so the browser can fetch them all in parallel right after pairing. */
        private fun manifest(): String {
            val out = JSONArray()
            fun walk(dir: String) {
                for (n in (a.assets.list(dir) ?: emptyArray())) {
                    val path = if (dir.isEmpty()) n else "$dir/$n"
                    val kids = a.assets.list(path)
                    if (kids != null && kids.isNotEmpty()) walk(path) else if (!n.endsWith(".ogg") && !n.endsWith(".mp3")) out.put(path)
                }
            }
            try { walk("") } catch (e: Exception) { }
            return out.toString()
        }

        private fun load(name: String): Cached? {
            cache[name]?.let { return it }
            val bytes = try { a.assets.open(name).use { it.readBytes() } } catch (e: Exception) { return null }
            val ext = name.substringAfterLast('.', "")
            val mime = when (ext) { "html" -> "text/html; charset=utf-8"; "js" -> "text/javascript; charset=utf-8"; "css" -> "text/css; charset=utf-8"; "json" -> "application/json"
                "png" -> "image/png"; "svg" -> "image/svg+xml"; "woff" -> "font/woff"; "woff2" -> "font/woff2"; "ttf" -> "font/ttf"; "ogg" -> "audio/ogg"; "mp3" -> "audio/mpeg"; else -> "application/octet-stream" }
            var out = bytes
            if (ext == "html") {
                val t = String(bytes, Charsets.UTF_8)
                val tag = "<script src=\"/desktop/remote-bridge.js\"></script>"
                val i = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(t)
                out = (if (i != null) t.substring(0, i.range.last + 1) + tag + t.substring(i.range.last + 1) else tag + t).toByteArray(Charsets.UTF_8)
            }
            val gz = if (ext in TEXT && out.size > 1024) {
                val bo = ByteArrayOutputStream()
                GZIPOutputStream(bo).use { it.write(out) }
                bo.toByteArray()
            } else null
            val c = Cached(out, gz, mime, "\"" + java.lang.Integer.toHexString(out.contentHashCode()) + "-" + out.size + "\"")
            cache[name] = c
            return c
        }

        private fun asset(s: IHTTPSession, uri: String): Response {
            var name = uri.trimStart('/')
            if (name.isEmpty()) name = "desktop/sandpiper-desktop.html"          // the desktop shell, not the phone's index.html
            if (name.contains("..") || name.contains('\\')) return text(Response.Status.FORBIDDEN, "text/plain", "no")
            val c = load(name) ?: return text(Response.Status.NOT_FOUND, "text/plain", "not found")
            val r: Response
            if (s.headers["if-none-match"] == c.etag) r = text(Response.Status.NOT_MODIFIED, c.mime, "")
            else if (c.gz != null && (s.headers["accept-encoding"] ?: "").contains("gzip")) {
                r = newFixedLengthResponse(Response.Status.OK, c.mime, ByteArrayInputStream(c.gz), c.gz.size.toLong())
                r.addHeader("Content-Encoding", "gzip")
            } else r = newFixedLengthResponse(Response.Status.OK, c.mime, ByteArrayInputStream(c.raw), c.raw.size.toLong())
            r.addHeader("ETag", c.etag)
            r.addHeader("Cache-Control", "private, max-age=3600")
            r.addHeader("Vary", "Accept-Encoding")
            return r
        }
    }

    private const val PAIR_PAGE = "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>Pair with Sandpiper</title>" +
        "<body style='font-family:system-ui;background:#050b16;color:#e6f3fb;display:grid;place-items:center;height:100vh;margin:0'><div style='max-width:340px;text-align:center'>" +
        "<h2>Pair with Sandpiper</h2><p style='color:#8fb0c4'>On your phone: Settings, Backup and sync, Local Sync. Type the 6-digit code shown there.</p>" +
        "<input id=c inputmode=numeric maxlength=6 autofocus style='font-size:28px;text-align:center;letter-spacing:8px;width:100%;padding:10px;border-radius:12px;border:1px solid #345;background:#0c1626;color:#fff'>" +
        "<p id=m style='color:#ff8d9b;min-height:22px'></p><div id=b style='height:6px;border-radius:9px;background:#13233a;overflow:hidden;display:none'><div id=f style='height:100%;width:0;background:#4cc2ff;transition:width .2s'></div></div></div><script>" +
        "var c=document.getElementById('c'),m=document.getElementById('m'),b=document.getElementById('b'),f=document.getElementById('f');" +
        "function warm(){m.style.color='#8fb0c4';m.textContent='Preparing Sandpiper\\u2026';b.style.display='block';" +
        "fetch('/_manifest').then(function(r){return r.json()}).then(function(l){var i=0,d=0;function next(){if(i>=l.length)return Promise.resolve();var u='/'+l[i++];return fetch(u).catch(function(){}).then(function(){d++;f.style.width=(d*100/l.length)+'%';return next()})}" +
        "return Promise.all([next(),next(),next(),next(),next(),next()])}).catch(function(){}).then(function(){location.href='/'})}" +
        "c.oninput=function(){if(c.value.length===6){fetch('/pair',{method:'POST',headers:{'Content-Type':'text/plain'},body:c.value}).then(function(r){return r.text().then(function(t){" +
        "if(r.ok){warm()}else{m.textContent=t.indexOf('locked')===0?'Too many tries. Wait a minute.':t==='expired'?'Code expired. Use the new one.':'Wrong code.';c.value=''}})})}}</script>"
}
