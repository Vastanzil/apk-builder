package com.vastanzil.sandpiper.backup

import org.bouncycastle.crypto.generators.Argon2BytesGenerator
import org.bouncycastle.crypto.params.Argon2Parameters
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class BackupCryptoException(val kind: Kind) : Exception(kind.name) {
    enum class Kind { WRONG_PASSPHRASE_OR_CORRUPT, UNSUPPORTED_VERSION, BAD_MANIFEST, EMPTY_PASSPHRASE }
}

/** Argon2id parameters. Defaults are OWASP's mobile-friendly baseline minimum (19 MiB, 2 passes, 1 lane): tune up, never down. */
data class Kdf(val memKb: Int = 19_456, val iterations: Int = 2, val parallelism: Int = 1)

/** Everything needed to decrypt except the passphrase. All fields are non-secret. [payload] = nonce (12 bytes) + ciphertext + GCM tag. */
class EncryptedBlob(val version: Int, val salt: ByteArray, val kdf: Kdf, val payload: ByteArray)

/**
 * Client-side backup encryption: Argon2id key from the passphrase, AES-256-GCM, fresh random salt and nonce per backup.
 * Pure (no Android). The passphrase is never stored and cannot be recovered. Never logs passphrase, key or plaintext.
 */
object BackupCrypto {
    const val VERSION = 1
    private const val NONCE = 12
    private val AAD = "sandpiper-backup-v1".toByteArray(Charsets.UTF_8)
    private val rnd = SecureRandom()

    fun deriveKey(passphrase: CharArray, salt: ByteArray, kdf: Kdf = Kdf()): SecretKey {
        if (passphrase.isEmpty()) throw BackupCryptoException(BackupCryptoException.Kind.EMPTY_PASSPHRASE)
        val p = Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
            .withVersion(Argon2Parameters.ARGON2_VERSION_13)
            .withIterations(kdf.iterations).withMemoryAsKB(kdf.memKb).withParallelism(kdf.parallelism)
            .withSalt(salt).build()
        val g = Argon2BytesGenerator()
        g.init(p)
        val out = ByteArray(32)
        g.generateBytes(passphrase, out)
        return SecretKeySpec(out, "AES")
    }

    fun encrypt(plaintext: ByteArray, passphrase: CharArray, kdf: Kdf = Kdf()): EncryptedBlob {
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val key = deriveKey(passphrase, salt, kdf)
        val nonce = ByteArray(NONCE).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        c.updateAAD(AAD)
        return EncryptedBlob(VERSION, salt, kdf, nonce + c.doFinal(plaintext))
    }

    fun decrypt(blob: EncryptedBlob, passphrase: CharArray): ByteArray {
        if (blob.version != VERSION) throw BackupCryptoException(BackupCryptoException.Kind.UNSUPPORTED_VERSION)
        if (blob.payload.size < NONCE + 16) throw BackupCryptoException(BackupCryptoException.Kind.WRONG_PASSPHRASE_OR_CORRUPT)
        val key = deriveKey(passphrase, blob.salt, blob.kdf)
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob.payload.copyOfRange(0, NONCE)))
            c.updateAAD(AAD)
            c.doFinal(blob.payload, NONCE, blob.payload.size - NONCE)
        } catch (e: Exception) { throw BackupCryptoException(BackupCryptoException.Kind.WRONG_PASSPHRASE_OR_CORRUPT) }
    }
}
