package com.vastanzil.sandpiper.remote

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

/**
 * Local Sync pairing: a 6-digit code (90 s, single use) swaps for a random session token that lives in memory only,
 * so a restart of Sandpiper forgets every paired browser. Wrong codes are rate-limited per source address.
 * Pure Kotlin (clock and randomness are injectable) so plain JUnit covers it.
 */
class PairingManager(
    private val now: () -> Long = { System.currentTimeMillis() },
    private val rnd: SecureRandom = SecureRandom()
) {
    companion object {
        const val CODE_MS = 90_000L
        const val MAX_FAILS = 5
        const val WINDOW_MS = 60_000L
        const val LOCK_MS = 60_000L
        const val IDLE_TTL_MS = 30 * 60_000L
    }

    data class Code(val value: String, val expiresAt: Long)
    sealed class Redeem {
        data class Ok(val token: String) : Redeem()
        object Wrong : Redeem()
        object Expired : Redeem()
        data class Locked(val seconds: Int) : Redeem()
    }

    private class Device(val ip: String, var last: Long)

    private var code: Code? = null
    private val tokens = ConcurrentHashMap<String, Device>()
    private val fails = HashMap<String, MutableList<Long>>()
    private val lockedUntil = HashMap<String, Long>()
    @Volatile var rememberSession = true

    /** The current code, or a fresh one when none is valid. Callers inside the same window always see the same code. */
    @Synchronized fun startPairing(): Code {
        val c = code
        if (c != null && c.expiresAt > now()) return c
        val fresh = Code("%06d".format(rnd.nextInt(1_000_000)), now() + CODE_MS)
        code = fresh
        return fresh
    }

    @Synchronized fun redeem(ip: String, entered: String): Redeem {
        val t = now()
        val lock = lockedUntil[ip]
        if (lock != null) { if (t < lock) return Redeem.Locked(((lock - t + 999) / 1000).toInt()) else lockedUntil.remove(ip) }
        val c = code
        if (c == null || c.expiresAt <= t) return Redeem.Expired
        val ok = MessageDigest.isEqual(c.value.toByteArray(Charsets.UTF_8), entered.trim().toByteArray(Charsets.UTF_8))
        if (ok) {
            code = null
            fails.remove(ip)
            val raw = ByteArray(32); rnd.nextBytes(raw)
            val token = raw.joinToString("") { "%02x".format(it) }
            tokens[token] = Device(ip, t)
            return Redeem.Ok(token)
        }
        val l = fails.getOrPut(ip) { ArrayList() }
        l.removeAll { it < t - WINDOW_MS }
        l.add(t)
        if (l.size >= MAX_FAILS) { lockedUntil[ip] = t + LOCK_MS; fails.remove(ip); return Redeem.Locked((LOCK_MS / 1000).toInt()) }
        return Redeem.Wrong
    }

    fun valid(token: String?): Boolean {
        if (token == null) return false
        val d = tokens[token] ?: return false
        val t = now()
        if (!rememberSession && t - d.last > IDLE_TTL_MS) { tokens.remove(token); return false }
        d.last = t
        return true
    }

    fun count(): Int = tokens.size
    @Synchronized fun revokeAll() { tokens.clear(); code = null; fails.clear(); lockedUntil.clear() }
}
