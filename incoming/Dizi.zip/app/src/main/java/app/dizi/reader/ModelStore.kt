package app.dizi.reader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import org.json.JSONObject
import java.io.File

/** Downloads model files with the system DownloadManager (retries, resume, notification) into app-private storage. */
class ModelStore(private val ctx: Context) {

    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val prefs = ctx.getSharedPreferences("models", Context.MODE_PRIVATE)

    // DownloadManager.setDestinationInExternalFilesDir always writes to the PRIMARY volume's own
    // external-files-dir - there is no DownloadManager API for targeting a secondary volume (e.g.
    // an SD card) directly. So downloads always land in this fixed staging folder first; file()/
    // tokFile() below then resolve to wherever the user actually chose (StorageLocations), moving
    // a finished download there with a plain File copy the first time it's looked up.
    private val stagingDir: File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "models").apply { mkdirs() }

    private companion object {
        /** Suffixes on the SharedPreferences key, so a model's two files track separate DownloadManager ids.
         *  PK_MODEL is "" so existing LLM entries (downloaded before this change) keep matching their old key. */
        const val PK_MODEL = ""
        const val PK_TOK = ":tok"
    }

    private fun finalDir(m: ModelSpec): File =
        StorageLocations.dirFor(ctx, if (m.kind == "asr") StorageLocations.CAT_ASR else StorageLocations.CAT_MODELS)

    /** Resolves to the file's real, final location - migrating it out of the DownloadManager
     *  staging folder the first time this is called after a download finishes there, if the
     *  user's chosen volume differs from the primary one DownloadManager had to use. */
    private fun resolve(m: ModelSpec, fileName: String, expectedBytes: Long): File {
        val final = File(finalDir(m), fileName)
        if (final.isFile) return final
        val staged = File(stagingDir, fileName)
        if (staged.isFile && staged.length() >= expectedBytes * 0.9 && staged.absolutePath != final.absolutePath) {
            try {
                staged.copyTo(final, overwrite = true)
                if (final.length() == staged.length()) staged.delete()
                DiagLog.i("Storage", "Moved ${fileName} to ${final.parent}")
            } catch (t: Throwable) {
                DiagLog.e("Storage", "Could not move $fileName to chosen folder, using staged copy instead", t)
                return staged
            }
        }
        return final
    }

    fun file(m: ModelSpec) = resolve(m, m.file, m.bytes)

    /** The companion tokenizer file for an ASR spec (null for LLM specs, which have none). */
    fun tokFile(m: ModelSpec): File? = m.tokFile?.let { resolve(m, it, m.tokBytes) }

    private fun fileReady(f: File, bytes: Long) = f.isFile && f.length() >= bytes * 0.9

    /** A "successful" download can still be a Hugging Face 404/redirect HTML page saved as if it
     *  were the model - DownloadManager only checks HTTP status, not content, and a wrong repo or
     *  file name (the exact risk flagged on the ModelCatalog ASR entries) hits this. Returns a short
     *  description of what was found if it looks wrong, or null if the content looks plausible. */
    private fun looksLikeErrorPage(f: File): String? {
        return try {
            val head = ByteArray(64)
            val n = f.inputStream().use { it.read(head) }
            if (n <= 0) return "empty file"
            val text = String(head, 0, n, Charsets.ISO_8859_1).trimStart().lowercase()
            if (text.startsWith("<!doctype") || text.startsWith("<html") || text.startsWith("<?xml") || text.startsWith("{\"error")) "starts with '${text.take(24)}'" else null
        } catch (_: Throwable) { null }
    }

    /** A finished download is at least 90% of the expected size (DownloadManager already checks Content-Length).
     *  For an ASR spec this also requires the tokenizer file, since transcription needs both. */
    fun isReady(m: ModelSpec): Boolean {
        if (!fileReady(file(m), m.bytes) || isDownloading(m, PK_MODEL)) return false
        val tf = tokFile(m) ?: return true
        return fileReady(tf, m.tokBytes) && !isDownloading(m, PK_TOK)
    }

    private fun isDownloading(m: ModelSpec, part: String): Boolean {
        val s = query(m, part)?.first
        return s == DownloadManager.STATUS_PENDING || s == DownloadManager.STATUS_RUNNING || s == DownloadManager.STATUS_PAUSED
    }

    /** Returns "" when started, otherwise an error code the web UI understands. */
    fun start(m: ModelSpec, wifiOnly: Boolean): String {
        if (isReady(m)) return ""
        val extra = m.tokBytes
        // The download always lands in the primary-volume staging folder first (see stagingDir's
        // comment), then gets moved to wherever the user actually chose - so both volumes need room.
        val need = m.bytes + extra + 300_000_000L
        val freeStaging = try { StatFs(stagingDir.path).availableBytes } catch (_: Exception) { Long.MAX_VALUE }
        val freeFinal = try { StatFs(finalDir(m).path).availableBytes } catch (_: Exception) { Long.MAX_VALUE }
        if (freeStaging < need || freeFinal < need) {
            DiagLog.w("Download", "${m.id}: not enough space (need ~${need / 1_000_000}MB, staging free ${freeStaging / 1_000_000}MB, chosen folder free ${freeFinal / 1_000_000}MB)")
            return "no_space"
        }
        if (!fileReady(file(m), m.bytes) && !isDownloading(m, PK_MODEL)) {
            enqueue(m, PK_MODEL, m.url, m.file, m.name, wifiOnly)
        }
        val tf = tokFile(m)
        if (tf != null && !fileReady(tf, m.tokBytes) && !isDownloading(m, PK_TOK)) {
            enqueue(m, PK_TOK, m.tokUrl!!, m.tokFile!!, m.name + " (tokenizer)", wifiOnly)
        }
        return ""
    }

    private fun enqueue(m: ModelSpec, part: String, url: String, fileName: String, title: String, wifiOnly: Boolean) {
        File(stagingDir, fileName).delete()
        DiagLog.i("Download", "Starting ${m.id}${part}: $url")
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(title)
            .setDescription("Dizi offline AI model")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setAllowedOverMetered(!wifiOnly)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(ctx, null, "models/$fileName")
        prefs.edit().putLong(m.id + part, dm.enqueue(req)).apply()
    }

    fun remove(m: ModelSpec) {
        for (part in listOf(PK_MODEL, PK_TOK)) {
            val id = prefs.getLong(m.id + part, -1L)
            if (id != -1L) dm.remove(id)
            prefs.edit().remove(m.id + part).apply()
        }
        file(m).delete()
        tokFile(m)?.delete()
        File(stagingDir, m.file).delete()
        m.tokFile?.let { File(stagingDir, it).delete() }
        DiagLog.i("Download", "Removed ${m.id}")
    }

    private fun query(m: ModelSpec, part: String): Triple<Int, Pair<Long, Long>, Int>? {
        val id = prefs.getLong(m.id + part, -1L)
        if (id == -1L) return null
        dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (c.moveToFirst()) {
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                return Triple(status, got to total, reason)
            }
        }
        prefs.edit().remove(m.id + part).apply() // removed from the system UI
        return null
    }

    /** Status of one file-part (model or tokenizer), folded into a single "worst of the two" state for ASR specs. */
    private fun statusOf(m: ModelSpec, part: String, f: File, bytes: Long): Triple<String, String, Pair<Long, Long>> {
        var state = "none"; var reason = ""; var got = 0L; var total = bytes
        val q = query(m, part)
        if (q != null) {
            got = q.second.first
            if (q.second.second > 0) total = q.second.second
            when (q.first) {
                DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING -> state = "downloading"
                DownloadManager.STATUS_PAUSED -> {
                    state = "paused"
                    reason = when (q.third) {
                        DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "wifi"
                        DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "network"
                        else -> "retry"
                    }
                }
                DownloadManager.STATUS_FAILED -> {
                    state = "failed"
                    reason = when (q.third) {
                        DownloadManager.ERROR_INSUFFICIENT_SPACE, DownloadManager.ERROR_DEVICE_NOT_FOUND -> "no_space"
                        401, 403 -> "denied"
                        404 -> "not_found"
                        else -> "network"
                    }
                }
                DownloadManager.STATUS_SUCCESSFUL -> {
                    if (!fileReady(f, bytes)) { state = "failed"; reason = "incomplete"; f.delete() }
                    else {
                        val bad = looksLikeErrorPage(f)
                        if (bad != null) {
                            state = "failed"; reason = "not_found"
                            DiagLog.e("Download", "${m.id}$part: saved file looks like an error page, not a model (${bad}) - check the URL in ModelCatalog.kt")
                            f.delete()
                        } else {
                            state = "ready"
                            DiagLog.i("Download", "${m.id}$part: ready (${f.length()} bytes at ${f.path})")
                        }
                    }
                }
            }
        }
        if (state == "none" && fileReady(f, bytes)) state = "ready"
        return Triple(state, reason, got to total)
    }

    fun status(m: ModelSpec): JSONObject {
        val (mState, mReason, mBytes) = statusOf(m, PK_MODEL, file(m), m.bytes)
        val tf = tokFile(m)
        var state = mState
        var reason = mReason
        var bytes = mBytes.first
        var total = if (mBytes.second > 0) mBytes.second else m.bytes
        if (tf != null) {
            val (tState, tReason, tBytes) = statusOf(m, PK_TOK, tf, m.tokBytes)
            // Combined state: ready only once both parts are; otherwise show whichever part is busiest.
            val order = listOf("downloading", "paused", "failed", "ready", "none")
            state = order.first { it == mState || it == tState }
            reason = if (state == mState) mReason else tReason
            bytes += tBytes.first
            total += if (tBytes.second > 0) tBytes.second else m.tokBytes
        }
        return JSONObject().put("state", state).put("reason", reason).put("bytes", bytes).put("total", total)
    }

    fun statusAll(): String {
        val o = JSONObject()
        for (m in ModelCatalog.ALL) o.put(m.id, status(m))
        return o.toString()
    }
}
