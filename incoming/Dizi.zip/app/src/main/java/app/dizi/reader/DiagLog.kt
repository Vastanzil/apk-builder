package app.dizi.reader

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * A small, always-on diagnostic log: this is what the Diagnostics panel in Settings reads.
 * Exists because "download not working" / "model not loading" are otherwise invisible - the web
 * UI only ever sees a generic error code, never the real exception. Every place that already
 * reports an error code to the web (ModelStore, AsrEngine, LlmEngine, AudioRecorder) should also
 * call DiagLog.e with the real detail, so the two stay in sync without the web side changing.
 *
 * In-memory ring buffer for the current session (fast, shown live) plus an append-only file
 * capped at MAX_FILE_BYTES (old entries dropped from the *front* on trim) so a crash right after
 * boot still leaves something to export. Not a general-purpose logging library - deliberately
 * tiny, synchronized, and dependency-free.
 */
object DiagLog {
    data class Entry(val time: Long, val level: String, val tag: String, val message: String)

    private const val MAX_MEMORY = 400
    private const val MAX_FILE_BYTES = 512 * 1024
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    private val buffer = ArrayDeque<Entry>()
    private lateinit var file: File
    private var inited = false

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        file = File(ctx.filesDir, "diag.log")
        i("App", "Dizi starting - Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, ex ->
            try { e("Crash", thread.name + ": " + traceOf(ex)) } catch (_: Throwable) {}
            previous?.uncaughtException(thread, ex)
        }
    }

    @Synchronized
    fun i(tag: String, message: String) = add("I", tag, message)
    @Synchronized
    fun w(tag: String, message: String) = add("W", tag, message)
    @Synchronized
    fun e(tag: String, message: String) = add("E", tag, message)
    fun e(tag: String, message: String, t: Throwable) = add("E", tag, message + ": " + traceOf(t))

    private fun traceOf(t: Throwable): String {
        val cause = t.cause
        val base = (t.javaClass.simpleName) + (t.message?.let { ": $it" } ?: "")
        return if (cause != null && cause !== t) base + " <- " + traceOf(cause) else base
    }

    @Synchronized
    private fun add(level: String, tag: String, message: String) {
        val entry = Entry(System.currentTimeMillis(), level, tag, message)
        buffer.addLast(entry)
        while (buffer.size > MAX_MEMORY) buffer.removeFirst()
        if (!inited) return
        try {
            val line = fmt.format(Date(entry.time)) + " " + level + "/" + tag + ": " + message + "\n"
            file.appendText(line)
            if (file.length() > MAX_FILE_BYTES) trimFile()
        } catch (_: Throwable) {
            // Logging must never itself crash the app.
        }
    }

    private fun trimFile() {
        try {
            val lines = file.readLines()
            val keep = lines.takeLast(lines.size / 2)
            file.writeText(keep.joinToString("\n") + "\n")
        } catch (_: Throwable) {}
    }

    /** JSON array of the most recent entries, newest last - what the web Diagnostics panel renders. */
    @Synchronized
    fun recentJson(limit: Int): String {
        val arr = JSONArray()
        buffer.toList().takeLast(limit.coerceIn(1, MAX_MEMORY)).forEach { e ->
            arr.put(JSONObject().put("t", e.time).put("level", e.level).put("tag", e.tag).put("msg", e.message))
        }
        return arr.toString()
    }

    /** Full text (memory + whatever survived on disk from before this session), for sharing/export. */
    @Synchronized
    fun fullText(): String {
        val sb = StringBuilder()
        try { if (::file.isInitialized && file.isFile) sb.append(file.readText()) } catch (_: Throwable) {}
        return sb.toString()
    }

    @Synchronized
    fun clear() {
        buffer.clear()
        try { if (::file.isInitialized) file.writeText("") } catch (_: Throwable) {}
        i("App", "Diagnostics cleared")
    }
}
