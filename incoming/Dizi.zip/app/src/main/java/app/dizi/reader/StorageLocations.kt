package app.dizi.reader

import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Where downloaded AI models and kept recordings live, and letting the user redirect that.
 *
 * Deliberately does NOT use the Storage Access Framework (an arbitrary folder anywhere, including
 * outside the app's own storage): both the LiteRT-LM Engine (LlmEngine.kt) and the TFLite
 * Interpreter (AsrEngine.kt) load models by real filesystem path, and neither is known to accept a
 * SAF content:// Uri or file descriptor here, so routing downloads through SAF risks silently
 * breaking model loading in a way this change cannot verify without a device. Instead, this picks
 * between the app's own private directories on each storage VOLUME the device actually has
 * (ContextCompat.getExternalFilesDirs returns one per volume: internal/primary, plus a real SD
 * card or USB storage if one is inserted) - still a real folder picker from the user's point of
 * view on any phone with removable storage, and a `java.io.File` on either end, so nothing about
 * how models are loaded needs to change.
 *
 * All downloads/recordings live under "<chosen volume's app-files-dir>/Dizi/<category>/", so the
 * app "creates additional folders" per category under one place the user picked, as asked for.
 */
object StorageLocations {
    const val CAT_MODELS = "models"      // LLM .litertlm files
    const val CAT_ASR = "asr"            // Whisper .tflite + tokenizer.json
    const val CAT_RECORDINGS = "recordings" // kept original audio

    private const val PREF = "storage_prefs"
    private const val KEY_VOLUME = "volume_index"

    data class Volume(val index: Int, val label: String, val root: File, val freeBytes: Long, val totalBytes: Long)

    /** All usable app-private directories this device currently has, in a stable order (index 0 is
     *  always the device's primary/internal storage, so prefs saved as an index stay meaningful
     *  even if an SD card is later removed and index 1+ temporarily disappears from this list). */
    fun volumes(ctx: Context): List<Volume> {
        val dirs = ContextCompat.getExternalFilesDirs(ctx, null)
        val out = ArrayList<Volume>()
        for (i in dirs.indices) {
            val d = dirs[i] ?: continue
            if (i > 0 && Environment.getExternalStorageState(d) != Environment.MEDIA_MOUNTED) continue
            val stat = try { StatFs(d.path) } catch (_: Throwable) { null }
            val free = stat?.let { it.availableBytes } ?: 0L
            val total = stat?.let { it.totalBytes } ?: 0L
            val label = if (i == 0) "Internal storage" else "SD card" + if (dirs.size > 2) " ${i}" else ""
            out.add(Volume(i, label, d, free, total))
        }
        if (out.isEmpty()) out.add(Volume(0, "Internal storage", ctx.filesDir, 0L, 0L))
        return out
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun chosenIndex(ctx: Context): Int = prefs(ctx).getInt(KEY_VOLUME, 0)

    /** Returns "" on success, or an error if that volume isn't currently available (e.g. SD card removed). */
    fun setChosenIndex(ctx: Context, index: Int): String {
        val v = volumes(ctx).firstOrNull { it.index == index } ?: return "not_available"
        if (!v.root.exists() && !v.root.mkdirs()) return "not_available"
        prefs(ctx).edit().putInt(KEY_VOLUME, index).apply()
        DiagLog.i("Storage", "Download/recording folder set to '${v.label}' (${v.root.path})")
        return ""
    }

    /** The real folder for one category under the currently-chosen volume, created if needed. */
    fun dirFor(ctx: Context, category: String): File {
        val vols = volumes(ctx)
        val want = chosenIndex(ctx)
        val v = vols.firstOrNull { it.index == want } ?: vols.first()
        return File(v.root, "Dizi/$category").apply { mkdirs() }
    }

    private fun sizeOf(dir: File): Long {
        if (!dir.isDirectory) return 0L
        var total = 0L
        dir.listFiles()?.forEach { total += if (it.isDirectory) sizeOf(it) else it.length() }
        return total
    }

    /** What the Diagnostics/Storage settings card shows: current volume + choices + size per category. */
    fun infoJson(ctx: Context): String {
        val vols = volumes(ctx)
        val chosen = chosenIndex(ctx)
        val volsArr = JSONArray()
        vols.forEach { v ->
            volsArr.put(JSONObject().put("index", v.index).put("label", v.label)
                .put("free", v.freeBytes).put("total", v.totalBytes).put("current", v.index == chosen))
        }
        val cats = JSONObject()
        for (cat in listOf(CAT_MODELS, CAT_ASR, CAT_RECORDINGS)) {
            cats.put(cat, sizeOf(dirFor(ctx, cat)))
        }
        // Also report anything left behind on OTHER volumes from before a folder change, so
        // nothing "disappears" from the user's point of view after switching.
        var elsewhere = 0L
        vols.filter { it.index != chosen }.forEach { v ->
            for (cat in listOf(CAT_MODELS, CAT_ASR, CAT_RECORDINGS)) elsewhere += sizeOf(File(v.root, "Dizi/$cat"))
        }
        return JSONObject().put("volumes", volsArr).put("categories", cats).put("elsewhere", elsewhere).toString()
    }

    /** Moves every file Dizi has ever written on OTHER volumes into the currently chosen one.
     *  Plain File copy+delete - both ends are always real filesystem paths, never SAF. Returns
     *  the number of files moved. Caller is expected to re-point any in-memory path strings
     *  (ModelStore/AudioRecorder already resolve their directory dynamically from dirFor(), so
     *  they pick this up automatically on the next status()/isReady() check). */
    fun moveEverythingToChosenVolume(ctx: Context): Int {
        val chosen = chosenIndex(ctx)
        var moved = 0
        for (v in volumes(ctx)) {
            if (v.index == chosen) continue
            for (cat in listOf(CAT_MODELS, CAT_ASR, CAT_RECORDINGS)) {
                val src = File(v.root, "Dizi/$cat")
                val files = src.listFiles() ?: continue
                val dst = dirFor(ctx, cat)
                for (f in files) {
                    try {
                        val target = File(dst, f.name)
                        if (target.exists()) target.delete()
                        if (f.copyTo(target, overwrite = true).length() == f.length()) { f.delete(); moved++ }
                    } catch (t: Throwable) {
                        DiagLog.e("Storage", "Could not move ${f.name}", t)
                    }
                }
            }
        }
        DiagLog.i("Storage", "Moved $moved file(s) to the chosen volume")
        return moved
    }

    /** Deletes every downloaded AI model (LLM + Whisper) across all volumes. Recordings are left
     *  alone - this is specifically the "AI models are eating my storage" escape hatch. */
    fun deleteAllModels(ctx: Context, store: ModelStore): Int {
        var count = 0
        for (m in ModelCatalog.ALL) {
            val had = store.file(m).isFile || (store.tokFile(m)?.isFile == true)
            store.remove(m)
            if (had) count++
        }
        // ModelStore.remove() only touches the chosen volume's files() for the spec; also sweep
        // every volume directly in case the chosen volume changed since something was downloaded.
        for (v in volumes(ctx)) {
            for (cat in listOf(CAT_MODELS, CAT_ASR)) {
                File(v.root, "Dizi/$cat").listFiles()?.forEach { it.delete() }
            }
        }
        DiagLog.i("Storage", "Deleted all downloaded AI models ($count tracked)")
        return count
    }
}
