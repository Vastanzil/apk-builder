# Feature status (honest)
Legend: **Logic-tested** = web logic run in a simulated browser (jsdom) with a fake native bridge. **Not device-tested** = written but never compiled or run on a phone.

| Feature | Status |
|---|---|
| UI layout: Habits on Zen Garden, Investment tracker on Finance, Brainy Island under Settings, no settings gear (More is the only entry), Settings card last in More | Logic-tested (simulated browser) |
| Settings > Backup now holds Closed days, Export transactions and Piper export/import (real Piper page exported and re-imported in a simulated browser); Notes header is the toggle; Zen cards spaced | Logic-tested |
| Permissions panel: all 14 permissions once, live states, Grant / Open settings / App info, by-feature view, shared "why" sheet, nothing requested on open | Logic-tested (simulated browser + fake native bridge). Kotlin probes compile-checked; not device-tested |
| Settings panel: 41 settings from one registry, search, Action-required links, dual-write to the central database, authority rules | Logic-tested; native adapters compile-checked; not device-tested |
| Backup v3 + validated restore with safety copy; v2 backups still restore | Logic-tested |
| Registry consistency (manifest <-> registry <-> features, unique ids, defaults) | Run for real against the manifest (7 checks); JUnit versions in `FeatureRegistryTest` |
| Transactions, balance, savings rate, CSV | Logic-tested |
| Planner: Smart calendar (Monday-first, selected-day reminders, complete/reopen/delete, Notify me), tasks, repeat + month-end clamp | Logic-tested |
| Focus timer survives restarts, counts each session once, bonsai stages | Logic-tested |
| Alarms: JS scheduling + one-time/repeat roll-over | Logic-tested |
| Alarms: AlarmManager + foreground-service ringing, snooze, reboot re-arm, health checks (Kotlin) | Not device-tested |
| Notifications, permission prompts (Kotlin) | Not device-tested |
| Voice notes (WebView MediaRecorder, stored in IndexedDB) | Not device-tested; format is WebM/Opus, not AAC |
| Save CSV / JSON / audio to Downloads/Sandpiper | Bridge logic-tested; MediaStore code not device-tested |
| Step counter (daily baseline, counts from first open each day) | Not device-tested |
| Alarm tone choice: 5 built-in original tones, phone alarm tones, your own audio file, preview | Web logic-tested; playback, picker and file copy (Kotlin) not device-tested |
| Zen Garden layout: timer + garden in one card, Fitness card with your full fitness page | Logic-tested in a simulated browser |
| Fitness ports, stars and reports -> Close the day -> day record, bonus points, CSV | Logic-tested end to end (simulated browser) |
| Fitness opens from a button into its own full-screen window; Back/Android back close it | Logic-tested in a simulated browser |
| Fitness native hooks: steps, active minutes, history, permission state, Usage Access minutes, links, workout reminders (Kotlin) | Not device-tested |
| Accessibility service (reel/short/feed counting), warnings, floating counter, status notification, lock overlay over 60% of the screen, screen-off unlock (Kotlin) | Not compiled, not device-tested |
| Display-over-apps, Usage Access and Accessibility permission screens now list Sandpiper (permissions + service declared) | Not device-tested |
| Offline Bricolage Grotesque font (OFL licence included) | Bundled; loads from local file |
| Brainy Island: reel counting by settled swipe (SwipeDetector), web-reel address classification, app/package mapping | Unit tests written (JVM, ported from the working Reel Counter and extended), **not run here** (no Kotlin toolchain available) |
| Brainy Island: BrainyService rewired to the detector + island, settings screen, app picker, diagnostics, reset, tracking pause (Kotlin) | Not compiled, not device-tested (the Reel Counter originals of the detector, island and picker were working on a phone) |
| Brainy Island card in Zen Garden opens the native settings screen | JS syntax-checked; not device-tested |
| Pause Brainy for one app (Settings > Brainy Island): `BrainyService.disableSelf()` from a Bridge call, for banking/wallet apps that refuse to run while Brainy's accessibility switch is on | Written; not compiled, not device-tested (same caveat as the rest of the Brainy stack) |
| Habits, hydration, sleep, investments, backup/restore, calculator, About easter egg | Logic-tested |
| Notes / Piper Pro toggle: sliding switch in the Notes heading; Piper = uploaded Glasspage Pro (rebranded) in an iframe, workspace stored in `sandpiper_central.db` (SQLite, chunked, SHA-256 verified, previous-revision safety copy) | Written; storage adapter tested in Node with a mock bridge, SQL tested on real SQLite; **not run on a device or compiled** |
| Native JS alert/confirm/prompt dialogs (Piper needs them) | Written; not compiled |
| Diagnostics: typed privacy-safe logger, self-test, health, zip export via file picker (Kotlin) + JVM tests incl. canary-leak test | Written; **not compiled, tests not run** |
| Alarms re-armed on every cold start (Android drops them on force-stop) | Written; not compiled, not device-tested |
| Gradle build / APK | **Not built** (no Android SDK available when this was written) |

## Known limits
Brainy detection is heuristic: it recognises Reels/Shorts/TikTok screens by app view IDs and scroll events, which can change when those apps update, so counts are labelled Estimated. Facebook detection is the least reliable. Step and active-minute history comes from a ~15-minute background sampler (WorkManager); force-stopping the app or aggressive battery savers can pause it, and the first day after install is partial. Active minutes are an estimate (brisk-cadence steps / 100). On Android 13+ a sideloaded app may need App info > ⋮ > Allow restricted settings before the Accessibility switch can be turned on.
The planner's own daily plan and skill-tree progress are not saved between launches (same as your original file). No custom alarm music, no XLSX/PDF export, no app lock, no budgets/transfers/multiple accounts, no wake-up sound loop beyond the notification's insistent alarm tone (10 min max).
Voice notes are not included in the JSON backup. Recording may stop if the app is sent to the background.

## v3.5 changes (production pass)
- Cards: single edge. Real 1px border removed; the `::after` gradient ring is the only outline (now has a hairline floor so edges stay uniform). Padding +1px to keep layout identical.
- Brainy Island: `BrainySettingsActivity` reduced to Set up detection / Unlock restricted settings / Reset / Preview / Diagnostics. Tracking, style, look, gap, visibility, browser, tracked apps live only in Settings > Brainy Island. The browser address-bar consent dialog moved to the web toggle (`brainy.browser`).
- Piper Pro: host header bar hidden while Piper is active; a "‹ Notes" button is injected into Piper's own topbar from the host (piper.html untouched).
- Release build: R8 minify + resource shrink, signing key required (no debug-key fallback), `build-release.sh/.bat`. versionCode 3 / 1.2.0.
- Not compiled or device-tested here (no Android SDK): build and smoke-test the release APK before shipping, especially Settings rows (JS bridge under R8) and Piper back button.

## v3.6 (Activity card + Track Record)
- Home: Activity card at the bottom (range 7/30/90d, metrics Focus/Steps/Water/Sleep/Reels/Spend, goal/limit line, streaks). Tap a bar or "Track Record" to open the day sheet.
- Track Record: per-day sheet (date picker, prev/next) built from existing data: Planner closed-day snapshot, habits, focus sessions, steps, water, sleep, money, notes, reels, merged timeline. Empty days read "Nothing recorded", never zero.
- Reels history: BrainyStore keeps `rh` (per-day short/reg/feed/points, 400 days) from this version on; earlier days have no reel data. Steps history retention raised 30 -> 400 days.
- Not yet: hour-by-hour reels, per-app daily split, alarm history, Planner tasks for days that were not closed (planner state is not persisted by design). These need the activity database from the plan.
- Logic smoke-tested in jsdom; Kotlin change not compiled here. versionCode 4 / 1.3.0.

## v3.7 (activity ledger)
- DB v3 (`sandpiper_central.db`): `activity_event` (append-only, deterministic ids, tombstone deletes) + `daily_metric` (derived rollup, rebuilt via `activityRebuild`). Closed metric list in `ActivityCore` (numbers/enums only, no free text). Events older than 400 days are compacted; rollups stay.
- Native writers (work with the app closed): steps + active minutes (StepWorker), alarm fired/snoozed/dismissed, Brainy hourly reel buckets + per-platform reels + regular videos + feed (written when a day rolls over; today's live buckets come from `brainrotToday().hb/ps`). v3.6 `rh` totals are migrated once.
- Web writer: one diff-based sync (`actSync`, called from `save()`, 1.5 s debounce) covers focus, water, sleep, steps, money, habits, notes, closed-day planner/fitness results. Only changed events are sent; removed items become tombstones.
- UI: Activity card and Track Record read the ledger for past days (live app data for today) and fall back to app data. Track Record gains the hour-by-hour reels chart, platform split, alarms section and reels peak in the timeline.
- Backup v4 includes `activity` events; restore merges by id (v2/v3 backups still restore).
- Not done: Diagnostics `ACTIVITY` category/self-test (use `activityStatus()` meanwhile), `day_summary`/`metric_def` tables (closed-day snapshots stay in app data, labels live in JS), voice-note counts, Planner tasks for unclosed days.
- Verified: JS logic in jsdom with a fake ledger. NOT compiled or run on a device: all Kotlin (ActivityCore/Store, CentralDb v3 upgrade, Brainy/Steps/Alarm hooks, Bridge) and `ActivityCoreTest`.
