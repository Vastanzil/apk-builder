package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId

class ActivityCoreTest {
    private val utc = ZoneId.of("UTC")

    @Test fun reduceFollowsTheMetricRule() {
        val rows = listOf(Pair(1L, 10.0), Pair(3L, 30.0), Pair(2L, 20.0))
        assertEquals(60.0, ActivityCore.reduce(Agg.SUM, rows)!!, 0.0)
        assertEquals(30.0, ActivityCore.reduce(Agg.MAX, rows)!!, 0.0)
        assertEquals(30.0, ActivityCore.reduce(Agg.LAST, rows)!!, 0.0)   // latest timestamp wins
        assertNull(ActivityCore.reduce(Agg.SUM, emptyList()))             // no rows = no data, not zero
    }

    @Test fun dayIsTheLocalDate() {
        // 2026-11-04 23:30 in UTC+6 is still the 4th there, but the 4th 17:30 UTC
        val ts = java.time.ZonedDateTime.of(2026, 11, 4, 23, 30, 0, 0, ZoneId.of("Asia/Dhaka")).toInstant().toEpochMilli()
        assertEquals("2026-11-04", ActivityCore.dayOf(ts, ZoneId.of("Asia/Dhaka")))
        assertEquals("2026-11-04", ActivityCore.dayOf(ts, utc))
    }

    @Test fun parseKeepsOnlyKnownMetricsAndSaneValues() {
        val json = """[
          {"id":"focus:1","ts":1762300000000,"metric":"focus.min","value":25},
          {"id":"x:1","metric":"free.text","value":1},
          {"id":"bad id","metric":"water.ml","value":1},
          {"id":"w:1","metric":"water.ml","value":"NaN"},
          {"id":"w:2","metric":"water.ml","value":1e12},
          {"id":"s:1","day":"2026-11-04","metric":"steps.count","value":6400,"source":"weird"}
        ]"""
        val out = ActivityCore.parse(json, 1762300000000L, utc)
        assertEquals(listOf("focus:1", "s:1"), out.map { it.id })
        assertEquals("focus", out[0].module)
        assertEquals("js", out[1].source)
        assertEquals("2026-11-04", out[1].day)
    }

    @Test fun parseAcceptsSmallMetaOnly() {
        val ok = ActivityCore.parse("""[{"id":"a","metric":"reels.platform","value":3,"ts":1,"meta":{"p":"instagram"}}]""", 1L, utc)
        assertEquals("""{"p":"instagram"}""", ok[0].meta)
        val long = "x".repeat(500)
        val big = ActivityCore.parse("""[{"id":"b","metric":"reels.platform","value":3,"ts":1,"meta":{"p":"$long"}}]""", 1L, utc)
        assertNull(big[0].meta)
    }

    @Test fun invalidJsonGivesNoEvents() {
        assertTrue(ActivityCore.parse("not json").isEmpty())
    }
}
