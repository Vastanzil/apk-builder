package com.vastanzil.sandpiper

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

/** How a day's events collapse into one number. */
enum class Agg { SUM, MAX, LAST }

/** One row of the activity ledger. [day] is the LOCAL date fixed when the event is written. */
data class ActEvent(
    val id: String, val ts: Long, val day: String, val module: String, val metric: String,
    val value: Double, val meta: String?, val source: String
)

/**
 * Pure rules of the activity ledger (no Android imports, so plain JUnit can run them).
 * Only metrics in [METRICS] can ever be stored: the ledger holds numbers and enums, never free text.
 */
object ActivityCore {
    val METRICS: Map<String, Agg> = mapOf(
        "focus.min" to Agg.SUM, "focus.sessions" to Agg.SUM,
        "water.ml" to Agg.LAST, "sleep.hours" to Agg.LAST,
        "steps.count" to Agg.MAX, "steps.active_min" to Agg.MAX,
        "spend" to Agg.SUM, "income" to Agg.SUM,
        "habit.done" to Agg.SUM, "notes.created" to Agg.SUM, "voice.count" to Agg.SUM,
        "reels" to Agg.SUM, "reels.platform" to Agg.SUM, "videos.reg" to Agg.SUM, "feed" to Agg.SUM, "usage.min" to Agg.MAX,
        "alarm.fired" to Agg.SUM, "alarm.snoozed" to Agg.SUM, "alarm.dismissed" to Agg.SUM,
        "fit.workouts" to Agg.SUM, "fit.stars" to Agg.SUM,
        "planner.points" to Agg.LAST, "planner.percent" to Agg.LAST
    )

    private val DAY = Regex("^\\d{4}-\\d{2}-\\d{2}$")
    private val ID = Regex("^[A-Za-z0-9._:\\-]{1,80}$")
    const val MAX_BATCH = 5000
    const val KEEP_DAYS = 400

    fun isDay(s: String): Boolean = DAY.matches(s)

    fun dayOf(ts: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        Instant.ofEpochMilli(ts).atZone(zone).toLocalDate().toString()

    /** Collapses (timestamp, value) rows of one day+metric. Null when there are no rows (the day has no data). */
    fun reduce(agg: Agg, rows: List<Pair<Long, Double>>): Double? {
        if (rows.isEmpty()) return null
        return when (agg) {
            Agg.SUM -> rows.sumOf { it.second }
            Agg.MAX -> rows.maxOf { it.second }
            Agg.LAST -> rows.maxByOrNull { it.first }!!.second
        }
    }

    private fun cleanMeta(m: Any?): String? {
        val j: JSONObject = when (m) {
            is JSONObject -> m
            is String -> try { JSONObject(m) } catch (e: Exception) { return null }
            else -> return null
        }
        val s = j.toString()
        return if (s.length <= 400) s else null
    }

    /** Parses a JSON array of events from the web layer or a backup. Invalid items are skipped, never stored. */
    fun parse(json: String, nowMs: Long = System.currentTimeMillis(), zone: ZoneId = ZoneId.systemDefault()): List<ActEvent> {
        val arr = try { JSONArray(json) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<ActEvent>()
        for (i in 0 until minOf(arr.length(), MAX_BATCH)) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val metric = o.optString("metric")
            if (!ID.matches(id) || !METRICS.containsKey(metric)) continue
            val v = o.optDouble("value", Double.NaN)
            if (v.isNaN() || v.isInfinite() || Math.abs(v) > 1e9) continue
            var ts = o.optLong("ts", 0L)
            if (ts <= 0L) ts = nowMs
            val d = o.optString("day")
            val day = if (isDay(d)) d else dayOf(ts, zone)
            val m = o.optString("module")
            val mod = if (ID.matches(m) && m.length <= 24) m else metric.substringBefore('.')
            val sr = o.optString("source")
            val src = if (sr == "native" || sr == "seed" || sr == "import") sr else "js"
            out.add(ActEvent(id, ts, day, mod, metric, v, cleanMeta(o.opt("meta")), src))
        }
        return out
    }
}
