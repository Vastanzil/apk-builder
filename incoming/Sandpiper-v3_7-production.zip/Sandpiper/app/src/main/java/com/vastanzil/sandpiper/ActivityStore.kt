package com.vastanzil.sandpiper

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId

/**
 * The activity ledger in sandpiper_central.db: append-only events (activity_event) plus a derived per-day rollup
 * (daily_metric) that is updated in the same transaction as every write and can always be rebuilt from the events.
 * Written by native code while the app is closed (steps, alarms, Brainy) and by the web layer (everything else).
 */
internal object ActivityStore {
    @Volatile private var ready = false

    fun createTables(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS activity_event(id TEXT PRIMARY KEY, ts INTEGER NOT NULL, day TEXT NOT NULL, " +
                "module TEXT NOT NULL, metric TEXT NOT NULL, value REAL NOT NULL, meta TEXT, source TEXT NOT NULL, " +
                "deleted INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS ev_day ON activity_event(day, module)")
        db.execSQL("CREATE INDEX IF NOT EXISTS ev_metric ON activity_event(metric, day)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS daily_metric(day TEXT NOT NULL, metric TEXT NOT NULL, value REAL NOT NULL, " +
                "n INTEGER NOT NULL, updated_at INTEGER NOT NULL, PRIMARY KEY(day, metric))"
        )
    }

    private fun db(c: Context): SQLiteDatabase = CentralDb.get(c).writableDatabase

    private fun init(c: Context) {
        if (ready) return
        ready = true
        try { migrateBrainyHistory(c); compact(c) } catch (e: Exception) { }
    }

    fun log(c: Context, events: List<ActEvent>): Int { init(c); return write(c, events) }

    /** Convenience for native producers. Never throws. */
    fun add(c: Context, id: String, ts: Long, metric: String, value: Double, meta: String? = null) {
        if (!ActivityCore.METRICS.containsKey(metric)) return
        try { log(c, listOf(ActEvent(id, ts, ActivityCore.dayOf(ts), metric.substringBefore('.'), metric, value, meta, "native"))) } catch (e: Exception) { }
    }

    @Synchronized
    private fun write(c: Context, events: List<ActEvent>): Int {
        if (events.isEmpty()) return 0
        val d = db(c)
        var n = 0
        d.beginTransaction()
        try {
            val touched = LinkedHashSet<Pair<String, String>>()
            for (e in events) {
                d.rawQuery("SELECT day, metric FROM activity_event WHERE id=?", arrayOf(e.id)).use {
                    if (it.moveToFirst()) touched.add(Pair(it.getString(0), it.getString(1)))
                }
                val cv = ContentValues()
                cv.put("id", e.id); cv.put("ts", e.ts); cv.put("day", e.day); cv.put("module", e.module)
                cv.put("metric", e.metric); cv.put("value", e.value); cv.put("meta", e.meta); cv.put("source", e.source)
                cv.put("deleted", 0); cv.put("updated_at", System.currentTimeMillis())
                d.insertWithOnConflict("activity_event", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                touched.add(Pair(e.day, e.metric))
                n++
            }
            for (t in touched) recompute(d, t.first, t.second)
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        return n
    }

    private fun recompute(d: SQLiteDatabase, day: String, metric: String) {
        val agg = ActivityCore.METRICS[metric] ?: return
        val rows = ArrayList<Pair<Long, Double>>()
        d.rawQuery("SELECT ts, value FROM activity_event WHERE day=? AND metric=? AND deleted=0", arrayOf(day, metric)).use {
            while (it.moveToNext()) rows.add(Pair(it.getLong(0), it.getDouble(1)))
        }
        val v = ActivityCore.reduce(agg, rows)
        if (v == null) {
            d.delete("daily_metric", "day=? AND metric=?", arrayOf(day, metric))
        } else {
            val cv = ContentValues()
            cv.put("day", day); cv.put("metric", metric); cv.put("value", v); cv.put("n", rows.size); cv.put("updated_at", System.currentTimeMillis())
            d.insertWithOnConflict("daily_metric", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    /** Tombstone: the event stays for audit but no longer counts. Only that day+metric is recomputed. */
    @Synchronized
    fun delete(c: Context, id: String): Boolean {
        val d = db(c)
        d.beginTransaction()
        try {
            var day: String? = null
            var metric: String? = null
            d.rawQuery("SELECT day, metric FROM activity_event WHERE id=? AND deleted=0", arrayOf(id)).use {
                if (it.moveToFirst()) { day = it.getString(0); metric = it.getString(1) }
            }
            val dy = day
            val mt = metric
            if (dy == null || mt == null) return false
            val cv = ContentValues()
            cv.put("deleted", 1); cv.put("updated_at", System.currentTimeMillis())
            d.update("activity_event", cv, "id=?", arrayOf(id))
            recompute(d, dy, mt)
            d.setTransactionSuccessful()
            return true
        } finally { d.endTransaction() }
    }

    /** Everything recorded for one local date: the rollup per metric plus the events (hourly buckets, platform splits...). */
    fun day(c: Context, day: String): String {
        val out = JSONObject()
        val m = JSONObject()
        val ev = JSONArray()
        out.put("day", day).put("metrics", m).put("events", ev)
        if (!ActivityCore.isDay(day)) return out.toString()
        val d = db(c)
        d.rawQuery("SELECT metric, value FROM daily_metric WHERE day=?", arrayOf(day)).use {
            while (it.moveToNext()) m.put(it.getString(0), it.getDouble(1))
        }
        d.rawQuery("SELECT id, ts, metric, value, meta FROM activity_event WHERE day=? AND deleted=0 ORDER BY ts LIMIT 600", arrayOf(day)).use {
            while (it.moveToNext()) {
                val e = JSONObject().put("i", it.getString(0)).put("t", it.getLong(1)).put("m", it.getString(2)).put("v", it.getDouble(3))
                val ms: String? = it.getString(4)
                if (ms != null) try { e.put("meta", JSONObject(ms)) } catch (x: Exception) { }
                ev.put(e)
            }
        }
        return out.toString()
    }

    /** {day: value} for one metric between two local dates (inclusive). Rollups only, so it stays fast for any history length. */
    fun series(c: Context, metric: String, from: String, to: String): String {
        val o = JSONObject()
        if (!ActivityCore.isDay(from) || !ActivityCore.isDay(to) || !ActivityCore.METRICS.containsKey(metric)) return o.toString()
        db(c).rawQuery("SELECT day, value FROM daily_metric WHERE metric=? AND day>=? AND day<=?", arrayOf(metric, from, to)).use {
            while (it.moveToNext()) o.put(it.getString(0), it.getDouble(1))
        }
        return o.toString()
    }

    @Synchronized
    fun rebuild(c: Context): Int {
        val d = db(c)
        var n = 0
        d.beginTransaction()
        try {
            d.delete("daily_metric", null, null)
            val pairs = ArrayList<Pair<String, String>>()
            d.rawQuery("SELECT DISTINCT day, metric FROM activity_event WHERE deleted=0", null).use {
                while (it.moveToNext()) pairs.add(Pair(it.getString(0), it.getString(1)))
            }
            for (p in pairs) { recompute(d, p.first, p.second); n++ }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        return n
    }

    private fun count(d: SQLiteDatabase, sql: String): Long = d.rawQuery(sql, null).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** Cheap self-test: every live (day, metric) pair has exactly one rollup row. */
    fun verify(c: Context): Boolean {
        val d = db(c)
        return count(d, "SELECT COUNT(*) FROM (SELECT DISTINCT day, metric FROM activity_event WHERE deleted=0)") == count(d, "SELECT COUNT(*) FROM daily_metric")
    }

    fun status(c: Context): String {
        val d = db(c)
        val o = JSONObject()
        o.put("events", count(d, "SELECT COUNT(*) FROM activity_event WHERE deleted=0"))
        o.put("days", count(d, "SELECT COUNT(DISTINCT day) FROM daily_metric"))
        o.put("ok", verify(c))
        return o.toString()
    }

    /** Events older than [ActivityCore.KEEP_DAYS] are dropped; their daily rollups are kept for good. */
    private fun compact(c: Context) {
        val cutoff = LocalDate.now().minusDays(ActivityCore.KEEP_DAYS.toLong()).toString()
        db(c).delete("activity_event", "day<?", arrayOf(cutoff))
    }

    /** For Backup v4. */
    fun export(c: Context): String {
        val cutoff = LocalDate.now().minusDays(ActivityCore.KEEP_DAYS.toLong()).toString()
        val arr = JSONArray()
        db(c).rawQuery("SELECT id, ts, day, module, metric, value, meta, source FROM activity_event WHERE deleted=0 AND day>=? ORDER BY ts", arrayOf(cutoff)).use {
            while (it.moveToNext()) {
                val e = JSONObject().put("id", it.getString(0)).put("ts", it.getLong(1)).put("day", it.getString(2)).put("module", it.getString(3))
                    .put("metric", it.getString(4)).put("value", it.getDouble(5)).put("source", it.getString(7))
                val ms: String? = it.getString(6)
                if (ms != null) try { e.put("meta", JSONObject(ms)) } catch (x: Exception) { }
                arr.put(e)
            }
        }
        return JSONObject().put("v", 1).put("events", arr).toString()
    }

    /** Backup restore: merges by id (same id = same event), so restoring twice never double counts. */
    fun import(c: Context, json: String): Int {
        val events = try { JSONObject(json).optJSONArray("events")?.toString() ?: "[]" } catch (e: Exception) { "[]" }
        val list = ActivityCore.parse(events).map { it.copy(source = "import") }
        var n = 0
        var i = 0
        while (i < list.size) { n += log(c, list.subList(i, minOf(i + 500, list.size))); i += 500 }
        return n
    }

    // ---- Brainy: one finished day becomes hourly reel buckets, per-platform reels, regular videos and feed items ----

    fun emitBrainyDay(c: Context, day: String, o: JSONObject) {
        try {
            val base = LocalDate.parse(day).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val evs = ArrayList<ActEvent>()
            var inBuckets = 0
            val hb = o.optJSONObject("hb")
            if (hb != null) {
                for (k in hb.keys()) {
                    val h = k.toIntOrNull() ?: continue
                    val v = hb.optInt(k)
                    if (v > 0 && h in 0..23) { inBuckets += v; evs.add(ActEvent("reels:$day:$h", base + h * 3_600_000L + 1, day, "brainy", "reels", v.toDouble(), null, "native")) }
                }
            }
            val rest = o.optInt("short") - inBuckets
            if (rest > 0) evs.add(ActEvent("reels:$day:u", base + 1, day, "brainy", "reels", rest.toDouble(), null, "native"))
            val ps = o.optJSONObject("ps")
            if (ps != null) for (k in ps.keys()) {
                val v = ps.optInt(k)
                if (v > 0) evs.add(ActEvent("reels.platform:$day:$k", base + 2, day, "brainy", "reels.platform", v.toDouble(), JSONObject().put("p", k).toString(), "native"))
            }
            if (o.optInt("reg") > 0) evs.add(ActEvent("videos.reg:$day", base + 3, day, "brainy", "videos.reg", o.optInt("reg").toDouble(), null, "native"))
            if (o.optInt("feed") > 0) evs.add(ActEvent("feed:$day", base + 4, day, "brainy", "feed", o.optInt("feed").toDouble(), null, "native"))
            log(c, evs)
        } catch (e: Exception) { }
    }

    /** One time: the per-day reel totals kept by v3.6 (BrainyStore "rh") become ledger events. Reads prefs directly (no BrainyStore.state recursion). */
    private fun migrateBrainyHistory(c: Context) {
        val p = c.getSharedPreferences("sp_act", Context.MODE_PRIVATE)
        if (p.getBoolean("rh_done", false)) return
        val s = c.getSharedPreferences("sp_brainy", Context.MODE_PRIVATE).getString("s", null)
        if (s != null) {
            val rh = try { JSONObject(s).optJSONObject("rh") } catch (e: Exception) { null }
            if (rh != null) {
                val evs = ArrayList<ActEvent>()
                for (day in rh.keys()) {
                    if (!ActivityCore.isDay(day)) continue
                    val r = rh.optJSONObject(day) ?: continue
                    val base = LocalDate.parse(day).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    if (r.optInt("s") > 0) evs.add(ActEvent("reels:$day:u", base + 1, day, "brainy", "reels", r.optInt("s").toDouble(), null, "seed"))
                    if (r.optInt("r") > 0) evs.add(ActEvent("videos.reg:$day", base + 3, day, "brainy", "videos.reg", r.optInt("r").toDouble(), null, "seed"))
                    if (r.optInt("f") > 0) evs.add(ActEvent("feed:$day", base + 4, day, "brainy", "feed", r.optInt("f").toDouble(), null, "seed"))
                }
                write(c, evs)
            }
        }
        p.edit().putBoolean("rh_done", true).apply()
    }
}
