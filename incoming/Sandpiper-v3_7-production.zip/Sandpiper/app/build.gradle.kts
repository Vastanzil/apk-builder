import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// --- Release signing -------------------------------------------------------
// Looks for keystore.properties next to this file (gitignored - never commit it or the .jks/.keystore it points at).
// Required for release builds (assembleRelease / bundleRelease). Run make-keystore.sh / .bat once to create it.
// Debug builds (assembleDebug) never need it.
val keystorePropsFile = rootProject.file("keystore.properties")
val hasRealKeystore = keystorePropsFile.exists()
val keystoreProps = Properties().apply { if (hasRealKeystore) FileInputStream(keystorePropsFile).use { load(it) } }

android {
    namespace = "com.vastanzil.sandpiper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vastanzil.sandpiper"
        minSdk = 29
        targetSdk = 34
        versionCode = 5
        versionName = "1.4.0"
    }

    signingConfigs {
        if (hasRealKeystore) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            // Production: R8 shrinks + obfuscates code, resource shrinking drops unused resources.
            // Keep rules for the JS bridge and persisted enum names are in proguard-rules.pro.
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Signed with YOUR key from keystore.properties. There is deliberately no debug-key fallback:
            // the guard further down stops the build if the file is missing, so a debug-signed APK can never ship by accident.
            if (hasRealKeystore) signingConfig = signingConfigs.getByName("release")
        }
    }
    lint {
        checkReleaseBuilds = true
        abortOnError = false   // report problems (app/build/reports/lint-results-release.html) but do not block the build
    }
    packaging {
        resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1", "META-INF/DEPENDENCIES")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303") // real org.json for JVM unit tests (the Android one is a stub there)
}

// --- Release guard ---------------------------------------------------------
// Fail fast with a clear message instead of producing an unsigned / debug-signed release.
gradle.taskGraph.whenReady {
    val wantsRelease = allTasks.any { it.project == project && (it.name.contains("Release") && (it.name.startsWith("assemble") || it.name.startsWith("bundle") || it.name.startsWith("package"))) }
    if (wantsRelease && !hasRealKeystore) {
        throw GradleException("Release build needs a signing key. Run ./make-keystore.sh (or make-keystore.bat) first, or copy keystore.properties.example to keystore.properties and fill it in.")
    }
}
