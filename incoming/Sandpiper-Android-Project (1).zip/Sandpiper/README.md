# sandpiper.  — a little more breathing room

Offline-first Android app by Tanzil Hasan (@vastanzil). Native Kotlin shell (alarms, notifications,
file saving, step sensor) around a bundled web UI (`app/src/main/assets/index.html`). No INTERNET permission.

## One-click build
**Android Studio (easiest):** File > Open > this folder, wait for Gradle sync, press Run. APK: Build > Build APK(s).
**Command line:** install JDK 17 + Android SDK (platform 34), then run `./build-debug.sh` (Windows: `build-debug.bat`).
Output: `app/build/outputs/apk/debug/app-debug.apk`. Release: `./gradlew assembleRelease` (debug-signed; add your own keystore before publishing).
First build downloads Gradle 8.7 and dependencies, so it needs internet once.

## What works (see FEATURE_STATUS.md for details)
Money tracker with real totals + CSV, your full star-planner (daily plan, skill tree, smart calendar and reminders,
imported whole into the Planner tab), alarms that ring through a foreground service (reboot / time-zone safe), focus timer + bonsai growth, notes + voice notes, habits, hydration, sleep,
investments (manual values), calculator, JSON backup/restore, step counter, 3-tap About easter egg on the logo.

## Edit the UI
Change `app/src/main/assets/index.html`, rebuild. Data lives in WebView localStorage/IndexedDB (app-private).

## Planner
`app/src/main/assets/planner.html` is your Sandpiper planner file, unchanged except for one added line that loads
`planner-bridge.js`. The bridge schedules the planner's reminders with Android so they fire when the app is closed.
Note: as in your original file, the daily plan, points and skill-tree progress are not saved between launches; only reminders are.

## If an alarm does not ring
Open More > Alarm & Clock. The "alarm health" list shows what is blocking alarms (notifications off, full-screen
screen not allowed, battery optimisation) with a Fix button for each. "Test alarm" rings in 10 seconds; lock the phone first
to test the lock-screen path.

## Alarm tones
Each alarm has its own sound: Gentle Morning (default), Classic Tick, Traditional Bell, Digital Beep, Nature / Birds
(all original, generated, in `res/raw`), the phone's default alarm tone, any tone from the phone's picker, or your own audio file
(copied into app-private storage, max 30 MB). Use the ▶ button to preview. If a chosen file is missing, Sandpiper falls back to Gentle Morning.

## Zen Garden, Fitness and Close the day
Zen Garden = one card with the Pomodoro timer (left) and your garden (right), then a **Fitness** button that opens the full fitness page in its own window, then "Closed days".
`fitness.html` is your fitness file, unchanged except one added line that loads `fitness-bridge.js`.
Its two ports (daily report, stars) are connected to the host app's Day Hub, so reports and stars are delivered even if they were queued while the app was closed.
Pressing **Close the day** in the Planner (the planner's own `resolve()` is wrapped by `planner-bridge.js`) now:
1. drains the open Fitness ports,
2. records one day entry with the Planner (tasks, weights, points, streak), Zen (focus sessions and minutes) and Fitness (steps, workouts, stars, latest report),
3. banks bonus points into the planner's points total: 10 points per net Fitness star and 5 per focus session today (constants `FIT_STAR_PTS`, `FOCUS_PTS` in `app.js`). Each day is banked once; closing again updates the record without double-banking.
Entries appear in Zen Garden > Closed days (CSV export) and are part of the JSON backup.

## Brainy (Fitness > Mental tab) permissions
Settings > Accessibility > **Sandpiper Brainy** (counts short videos/feed items in TikTok, Instagram, Facebook, YouTube; reads only the app name, scroll events and view-ID names, never text or messages),
Settings > Apps > Special access > **Display over other apps** (floating counter and focus lock), and **Usage access** (real app time).
If the Accessibility switch is greyed out on Android 13+: App info > ⋮ > *Allow restricted settings*, then try again. The Turn on buttons in the Fitness page open the right screen and show these steps.
Without the overlay permission the lock falls back to an accessibility overlay. The lock clears after 5 minutes of total screen-off time; closing the reel app hides it until you open one again.
Font: Bricolage Grotesque (SIL Open Font License, `assets/bricolage-OFL.txt`).
