/* Sandpiper theme switch: ONE place decides light or dark for every page (and every frame).
   Saved choice (localStorage "sp-theme") wins, otherwise the phone's setting. Frames follow through the storage event. */
(function(){var r=document.documentElement,q=window.matchMedia&&matchMedia('(prefers-color-scheme: dark)');
function mode(){var t;try{t=localStorage.getItem('sp-theme')}catch(e){}return t==='light'||t==='dark'?t:(q&&q.matches?'dark':'light')}
function apply(){var m=mode();r.setAttribute('data-sp',m);r.setAttribute('data-theme',m);r.classList.toggle('gp-sysdark',m==='dark');
 var c=document.querySelector('meta[name=theme-color]');if(c)c.setAttribute('content',m==='dark'?'#0f0f10':'#ffffff')}
apply();document.addEventListener('DOMContentLoaded',apply);addEventListener('storage',function(e){if(e.key==='sp-theme')apply()});
try{q.addEventListener('change',apply)}catch(e){}
window.SpTheme={mode:mode,apply:apply,set:function(m){try{localStorage.setItem('sp-theme',m)}catch(e){}apply()}}})();
