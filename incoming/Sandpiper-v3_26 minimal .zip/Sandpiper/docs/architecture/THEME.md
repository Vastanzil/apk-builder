# Theme (v1.20.0): minimal, flat, light and dark

One layer controls the whole look; the older glass styles still exist underneath but are overridden.

| File | Role |
|---|---|
| `assets/theme.css` | The palette (`--sp-*` tokens, light + dark), flat rules (no blur, shadows, gradients), the font stack. Loaded last by every page. |
| `assets/theme.js` | Decides light or dark for every page and frame: saved choice (`sp-theme`), else the phone setting. `SpTheme.set('light'|'dark')`. Frames follow through the `storage` event. |
| `assets/comic-neue-400.woff2`, `-700.woff2` | The bundled default font (Comic Neue, SIL OFL). |
| `res/values*/colors.xml`, `bools.xml`, `themes.xml` | Native window and status-bar colours follow the phone's day/night setting. |

Rules
- To retheme, edit the tokens at the top of `theme.css`; everything else maps from them. One accent colour only.
- Font: Comic Neue (bundled, SIL OFL) on every device, so the app looks the same on phone and desktop. To use another font, change `--sp-font` in `theme.css`.
- The Planner Pro galaxy (`#c`) keeps its dark space artwork on purpose (it is the planner's star map). Everything around it follows the theme.
- Desktop adds its own layer on top: `assets/desktop/desktop.css` (see `DESKTOP_UI.md`).
