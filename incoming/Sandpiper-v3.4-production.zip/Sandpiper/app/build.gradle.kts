import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// --- Release signing -------------------------------------------------------
// Looks for keystore.properties next to this file (gitignored - never commit it or the .jks/.keystore it points at).
// Not present -> falls back to the debug key, same as before, so a fresh checkout still builds a release APK with
// no setup. Present -> every release build is signed with your own key. Run make-keystore.sh / .bat to create one.
val keystorePropsFile = rootProject.file("keystore.properties")
val hasRealKeystore = keystorePropsFile.exists()
val keystoreProps = Properties().apply { if (hasRealKeystore) FileInputStream(keystorePropsFile).use { load(it) } }

android {
    namespace = "com.vastanzil.sandpiper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vastanzil.sandpiper"
        minSdk = 29
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"
    }

    signingConfigs {
        if (hasRealKeystore) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // keystore.properties present -> your own key (see signingConfigs above).
            // Not present -> the debug key, so the release APK still installs for testing.
            // Replace with your own keystore before distributing this build to anyone else.
            signingConfig = if (hasRealKeystore) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303") // real org.json for JVM unit tests (the Android one is a stub there)
}
