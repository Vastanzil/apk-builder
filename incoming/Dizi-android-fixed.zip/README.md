# Dizi for Android

Offline reader that speaks documents, takes dictation and keeps quick voice notes.
A native Kotlin shell around the bundled web app (`app/src/main/assets/dizi.html`).

## Build

Requirements: Android Studio (current stable), JDK 17+, Android SDK Platform 36.

1. Open this folder in Android Studio and let Gradle sync. If Studio offers to upgrade the
   Android Gradle Plugin, accept it.
2. Run on a device or emulator: **Run > Run 'app'** (debug build, id `app.dizi.reader.debug`).
3. The Gradle wrapper (`gradlew`, `gradle-wrapper.jar`) is included, so no local Gradle install is
   needed. From a terminal:

```
./gradlew assembleDebug        # app/build/outputs/apk/debug/
./gradlew bundleRelease        # app/build/outputs/bundle/release/  (Play Store .aab)
./gradlew assembleRelease      # signed .apk if keystore.properties exists
```

## Release signing

```
keytool -genkeypair -v -keystore dizi-release.jks -alias dizi -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit the values
```

Keep the keystore and `keystore.properties` out of version control (already git-ignored) and back them up.
Without `keystore.properties`, release builds are unsigned.

## What is native

| Feature | Implementation |
|---|---|
| Read aloud with word highlight | Android `TextToSpeech` via `native-shim.js` (offline voices preferred) |
| Dictation and quick note (live guess) | `SpeechRecognizer`, on-device on Android 13+ when available |
| Keeping the original recording | `AudioRecorder.kt` (`MediaRecorder`, AAC/.m4a, app-private storage) - runs in both Dictate modes |
| AI transcript of a full recording | `AsrEngine.kt` (`tensorflow-lite`) running a downloaded Whisper model, decoded by `WhisperTokenizer.kt` |
| Reading with the screen off | Foreground service (media playback) + notification |
| Home-screen widget and launcher shortcut | `QuickNoteWidget`, dynamic shortcut |
| Back button, insets, dark mode | `MainActivity` |
| Library, notes, settings | WebView `localStorage` (app-private) |

## Privacy and security

- `INTERNET` is used only by the system DownloadManager for models you choose. The page is served from assets over `https://appassets.androidplatform.net`,
  navigation to any other host is blocked, and the page has a strict Content-Security-Policy.
- Backups are disabled (`allowBackup=false`).
- The JavaScript bridge validates its inputs and only the bundled page can load.

## Offline AI models

Settings > Offline AI lists models for 4, 6, 8 and 12 GB phones. Tapping Download starts the system
DownloadManager (Wi-Fi only by default, resumes after interruptions, shows a notification) and the file is
stored in app-private storage. Inference runs with LiteRT-LM (`litertlm-android`) in `LlmEngine.kt`.

| Id | Model | File | Size |
|---|---|---|---|
| q35-08 | Qwen3.5 0.8B | litert-community/Qwen3.5-0.8B / Qwen3.5-0.8B_int8.litertlm | 978 MB |
| q35-2 | Qwen3.5 2B | litert-community/Qwen3.5-2B / Qwen3.5-2B_int8.litertlm | 1.97 GB |
| g4-e2b | Gemma 4 E2B | litert-community/gemma-4-E2B-it-litert-lm / gemma-4-E2B-it.litertlm | 2.58 GB |
| g4-e4b | Gemma 4 E4B | litert-community/gemma-4-E4B-it-litert-lm / gemma-4-E4B-it.litertlm | 3.65 GB |
| q35-4-i4 | Qwen3.5 4B INT4 | litert-community/Qwen3.5-4B / Qwen3.5-4B_mixed_int4.litertlm | 2.75 GB |
| q35-4 | Qwen3.5 4B INT8 | litert-community/Qwen3.5-4B / Qwen3.5-4B_int8.litertlm | 4.42 GB |

To change the list, edit `ModelCatalog.kt` (URLs) and `MODELS` in `dizi.html` (UI).

## Dictate: two modes, and a real AI transcript instead of only a live guess

The Dictate tab now has two modes (`recmode` in `dizi.html`, `R.mode`):

- **Live captions** - shows `SpeechRecognizer`'s live, word-by-word guess as you talk, same as
  before. The original audio is *also* recorded in parallel now, so you have something to check
  the guess against.
- **Record, then transcribe** - stays quiet while recording; nothing is sent to the Dictate
  text box until you tap "Transcribe with AI" afterwards.

In both modes, `AudioRecorder.kt` keeps the real microphone audio as an `.m4a` file in app-private
storage (`audioRecStart`/`audioRecStop` in `NativeBridge.kt`, exposed to the page as `DiziRecorder`).
Previously, dictation on Android produced text only and threw the audio away entirely (the old
`if(!NATIVE)` branch in `startRec()` meant `getUserMedia`/`MediaRecorder` never even ran on the
native build) - that gap is what this adds.

"Transcribe with AI" (`aitranscribe` action, `DiziASR.transcribe`) runs the recording through
whichever Whisper model you've picked in **Settings > Speech to text**, via `AsrEngine.kt`
(`tensorflow-lite`, not `litertlm-android` - see the comment on the `tensorflowLite` version in
`libs.versions.toml` for why). That model downloads through the same `ModelStore`/`DownloadManager`
mechanism as the LLM models above, just with an extra small `tokenizer.json` file alongside the
`.tflite` model (`WhisperTokenizer.kt` decodes the model's output token ids back into text with it).

**Whisper ASR: before you rely on this.** Unlike the LLM pipeline above, this part has not been
run against a real `.tflite` file or a real device in this change, and three things specifically
need checking before you trust it:

1. **The `tiny`/`base`/`small` entries in `ModelCatalog.kt` are a starting point, not a verified
   listing.** The repo (`openai/whisper-tiny` etc.) definitely exists and definitely has an
   official `tokenizer.json`, but it's a PyTorch/safetensors repo - it almost certainly does **not**
   host a `.tflite` file. Before shipping, replace `file`/`bytes` on each `asr`-kind `ModelSpec` with
   a real `.tflite` conversion's repo and filename (search `litert-community`, `qualcomm`, or convert
   one yourself), and fix `bytes`/`tokBytes` to the real `Content-Length`. This is the same kind of
   check the Gemma/Qwen entries above already needed, just not yet done for these three.
2. **`AsrEngine.kt` assumes the model is a single-call "audio in, token ids out" graph** (reads
   the expected input length from the model itself, feeds raw 16 kHz float32 PCM, and decodes
   whatever comes out of output tensor 0 as `INT32`/`INT64` token ids). Many community Whisper
   `.tflite` exports are packaged exactly this way, with mel-spectrogram extraction and greedy
   decoding baked into the graph - but if the specific file you pick instead exposes raw per-step
   logits (needing an autoregressive decode loop written against its exact signature), this engine
   deliberately fails with a clear `unsupported_output_...` error rather than guessing. That loop
   would need writing against the real model once you have it.
3. **Native-library packaging**: `tensorflow-lite` is added alongside `litertlm-android`, which may
   bundle its own internal copy of the same runtime. `app/build.gradle.kts` adds a
   `pickFirsts` rule for `libtensorflowlite_jni.so` as a guess at avoiding a packaging conflict -
   confirm the release build actually merges cleanly.

None of this affects the recording/keeping-the-audio part, which doesn't touch Whisper at all and
should work as-is.

**Known limitation, not new:** `R.list` (the Dictate tab's recordings list) is in-memory only, like
the original transcript-only version was - recordings (including the kept audio files) do not
survive the app being killed and restarted. `AudioRecorder.pruneOrphans()` exists for cleaning up
files from past sessions but is not wired up automatically, specifically to avoid deleting a file
still in use while this is unverified; call it from `MainActivity` once you're confident about the
lifecycle you want (e.g. prune on cold start, since nothing from a previous session is reachable
from the UI anyway).

Things to check on the first run:
- `litertlm-android` is pinned to `0.19.1` in `gradle/libs.versions.toml` (it was previously left on
  `latest.release`, which silently picked up a newer build compiled against Kotlin 2.4.x and broke
  `compileDebugKotlin` with a metadata-version mismatch against this project's Kotlin 2.1.21). Kotlin is
  now pinned to `2.4.20` to match. If you deliberately bump `litertlm`, check what Kotlin version the new
  artifact's classes were compiled with (the build error reports it directly as "the binary version of its
  metadata is X.Y.Z") and bump `kotlin` to at least that version in the same change. Qwen3.5 files need
  LiteRT-LM 0.15 or newer.
- The Gemma 4 E4B file name follows the E2B naming and was not opened directly. If a download shows
  "Model file not found online", check the file name in the Hugging Face repo and update `ModelCatalog.kt`.
- Qwen3.5 runs on CPU only here. Gemma tries the GPU first and falls back to CPU.
- Qwen3.5 bundles need a fresh engine per request, so each Qwen request reloads the model (several seconds).
- Android's DownloadManager keeps a notification during downloads. On Android 13+ the app asks for the
  notification permission the first time it reads aloud.

## Not implemented yet

- HD voice packs, Whisper models, MP3/M4A export (shown as unavailable).
- Dictation keeps text only. Audio is not saved.
- Stopping a generation hides its output but the model finishes in the background.

## Notes

- Android's recognizer may play a short sound each time it restarts during long dictation.
- The app uses system fonts. To bundle Atkinson Hyperlegible, add the font files under `assets/` and
  reference them with `@font-face` in `dizi.html`.
- Update `dizi.html` and `native-shim.js` in `app/src/main/assets/` to change the UI.
