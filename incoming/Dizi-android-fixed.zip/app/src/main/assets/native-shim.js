/* Dizi native shim: maps the Web Speech API onto Android TextToSpeech and SpeechRecognizer. */
(function () {
  'use strict';
  var N = window.DiziNative;
  if (!N) return;
  var S = window.DiziShim = {};
  function def(name, val) {
    try { Object.defineProperty(window, name, { value: val, configurable: true, writable: true }); }
    catch (e) { try { window[name] = val; } catch (e2) {} }
  }

  /* ---------- speech synthesis ---------- */
  var voices = [], pending = {}, uid = 0, live = 0, offT = 0, wasOn = false;
  function Voice(o) { this.name = o.name; this.lang = o.lang; this.voiceURI = o.uri; this.localService = true; this.default = false; }
  function Utterance(text) {
    this.text = String(text || ''); this.lang = ''; this.voice = null; this.rate = 1; this.pitch = 1; this.volume = 1;
    this.onstart = null; this.onend = null; this.onerror = null; this.onboundary = null;
  }
  function setPlaying(on) {
    if (on === wasOn) return; wasOn = on;
    try { var t = document.getElementById('docTitle'); N.playing(on, t ? t.textContent : ''); } catch (e) {}
  }
  function idle() { clearTimeout(offT); offT = setTimeout(function () { if (live <= 0) setPlaying(false); }, 900); }
  var synth = {
    speaking: false, pending: false, paused: false, onvoiceschanged: null,
    getVoices: function () { return voices; },
    speak: function (u) {
      var id = 'u' + (++uid), v = u.voice;
      pending[id] = u; live++; clearTimeout(offT); setPlaying(true);
      N.speak(id, u.text, v ? v.voiceURI : '', u.lang || (v && v.lang) || 'en-US', u.rate || 1);
    },
    cancel: function () { pending = {}; live = 0; N.cancel(); idle(); },
    pause: function () {}, resume: function () {},
    addEventListener: function () {}, removeEventListener: function () {}
  };
  S._voices = function (json) {
    try { voices = JSON.parse(json).map(function (o) { return new Voice(o); }); } catch (e) { voices = []; }
    if (typeof synth.onvoiceschanged === 'function') { try { synth.onvoiceschanged(); } catch (e) {} }
  };
  S._ev = function (id, type, n) {
    var u = pending[id]; if (!u) return;
    try {
      if (type === 'start') { synth.speaking = true; if (u.onstart) u.onstart({}); }
      else if (type === 'boundary') { if (u.onboundary) u.onboundary({ name: 'word', charIndex: n }); }
      else {
        delete pending[id]; live = Math.max(0, live - 1);
        if (!live) { synth.speaking = false; idle(); }
        if (type === 'end') { if (u.onend) u.onend({}); }
        else if (u.onerror) u.onerror({ error: 'synthesis-failed' });
      }
    } catch (e) {}
  };
  def('speechSynthesis', synth);
  def('SpeechSynthesisUtterance', Utterance);
  try { S._voices(N.voices()); } catch (e) {}

  /* ---------- speech recognition ---------- */
  var cur = null, curSid = 0;
  function Rec() { this.continuous = false; this.interimResults = false; this.lang = 'en-US'; this.onresult = null; this.onerror = null; this.onend = null; this.onstart = null; }
  Rec.prototype.start = function () { cur = this; try { curSid = N.srStart(this.lang || 'en-US'); } catch (e) {} };
  Rec.prototype.stop = function () { try { N.srStop(); } catch (e) {} };
  Rec.prototype.abort = function () { try { N.srAbort(); } catch (e) {} };
  function ev(final, t) { return { resultIndex: 0, results: [{ isFinal: final, length: 1, 0: { transcript: t, confidence: 1 } }] }; }
  S._sr = function (kind, p, sid) {
    var r = cur; if (!r || sid !== curSid) return;
    try {
      if (kind === 'partial') { if (r.onresult) r.onresult(ev(false, p)); }
      else if (kind === 'final') { if (r.onresult) r.onresult(ev(true, p)); }
      else if (kind === 'error') { if (r.onerror) r.onerror({ error: p }); }
      else if (kind === 'end') { if (r.onend) r.onend({}); }
    } catch (e) {}
  };
  def('SpeechRecognition', Rec);
  def('webkitSpeechRecognition', Rec);

  /* ---------- offline LLM (downloads and inference run natively) ---------- */
  var runs = {}, rid = 0;
  S._llm = function (id, kind, p) {
    var r = runs[id]; if (!r) return;
    if (kind === 'chunk') { r.text += p; if (r.cb) { try { r.cb(r.text); } catch (e) {} } }
    else if (kind === 'done') { delete runs[id]; r.res(r.text); }
    else { delete runs[id]; r.rej(new Error(p)); }
  };
  def('DiziLLM', {
    status: function () { return JSON.parse(N.llmStatus()); },
    start: function (id, wifiOnly) { return N.llmStart(id, !!wifiOnly); },
    remove: function (id) { N.llmRemove(id); },
    run: function (o, cb) {
      return new Promise(function (res, rej) {
        var id = 'r' + (++rid);
        runs[id] = { res: res, rej: rej, cb: cb, text: '' };
        var e = N.llmRun(id, o.model, o.system, o.prompt, !!o.gpu, !!o.idle, !!o.bat);
        if (e) { delete runs[id]; rej(new Error(e)); }
      });
    },
    stop: function () {
      try { N.llmStop(); } catch (e) {}
      Object.keys(runs).forEach(function (k) { var r = runs[k]; delete runs[k]; var er = new Error('stopped'); er.stopped = true; r.rej(er); });
    }
  });

  /* ---------- audio recorder: keeps the real microphone audio for both Dictate modes ---------- */
  var recPending = null;
  S._rec = function (kind, payload) {
    var p = recPending; if (!p) return;
    recPending = null;
    if (kind === 'started') p.res(); else p.rej(new Error(payload || 'error'));
  };
  def('DiziRecorder', {
    start: function () {
      return new Promise(function (res, rej) {
        recPending = { res: res, rej: rej };
        try { N.audioRecStart(); } catch (e) { recPending = null; rej(e); }
      });
    },
    stop: function () {
      try {
        var raw = N.audioRecStop();
        return raw ? JSON.parse(raw) : null; // null: nothing usable was recorded (too short, or never started)
      } catch (e) { return null; }
    }
  });

  /* ---------- offline Whisper transcription: a real pass over a whole recording, not a live guess ---------- */
  var asrRuns = {}, aid = 0;
  S._asr = function (id, kind, payload) {
    var r = asrRuns[id]; if (!r) return;
    delete asrRuns[id];
    if (kind === 'done') r.res(payload); else r.rej(new Error(payload));
  };
  def('DiziASR', {
    status: function () { return JSON.parse(N.asrStatus()); },
    start: function (id, wifiOnly) { return N.asrStart(id, !!wifiOnly); },
    remove: function (id) { N.asrRemove(id); },
    transcribe: function (modelId, audioPath, lang) {
      return new Promise(function (res, rej) {
        var id = 'a' + (++aid);
        asrRuns[id] = { res: res, rej: rej };
        var e = N.asrTranscribe(id, modelId, audioPath, lang || 'en-US');
        if (e) { delete asrRuns[id]; rej(new Error(e)); }
      });
    },
    stop: function () { try { N.asrStop(); } catch (e) {} }
  });
})();
