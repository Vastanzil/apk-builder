package app.dizi.reader

import org.json.JSONObject
import java.io.File

/**
 * Decodes the token-id sequence a Whisper .tflite model outputs back into text, using the
 * model's own tokenizer.json (the standard Hugging Face "fast tokenizer" format: a vocabulary
 * map plus a byte-level BPE scheme, the same one GPT-2 and Whisper both use).
 *
 * This only implements decoding (ids -> text), not encoding, since AsrEngine never needs to
 * tokenize text - only to read back what the model produced.
 */
class WhisperTokenizer private constructor(
    private val idToToken: Map<Int, String>,
    private val byteDecoder: Map<Char, Int>,
) {
    /** Turns a sequence of token ids into text, dropping Whisper's special control tokens
     *  (<|startoftranscript|>, language tags, <|notimestamps|>, timestamp tokens, <|endoftext|>, ...).
     *  These are recognised generically by their "<|...|>" shape rather than by hard-coded ids,
     *  since the exact ids shift between the English-only and multilingual vocabularies. */
    fun decode(ids: IntArray): String {
        val sb = StringBuilder()
        val byteBuf = ArrayList<Int>(64)
        fun flushBytes() {
            if (byteBuf.isEmpty()) return
            val bytes = ByteArray(byteBuf.size) { byteBuf[it].toByte() }
            sb.append(String(bytes, Charsets.UTF_8))
            byteBuf.clear()
        }
        for (id in ids) {
            val tok = idToToken[id] ?: continue
            if (tok.startsWith("<|") && tok.endsWith("|>")) continue // special/control token, not real text
            for (ch in tok) {
                val b = byteDecoder[ch]
                if (b != null) byteBuf.add(b) else { flushBytes(); sb.append(ch) }
            }
        }
        flushBytes()
        return sb.toString().trim()
    }

    companion object {
        /** Returns null if the file is missing or not a recognisable tokenizer.json - callers
         *  should fall back to raw "token_<id>" text rather than crash, and surface that as an
         *  error, since a transcript made of placeholders would look like silent data loss. */
        fun load(file: File): WhisperTokenizer? {
            if (!file.isFile) return null
            return try {
                val root = JSONObject(file.readText(Charsets.UTF_8))
                val model = root.getJSONObject("model")
                val vocab = model.getJSONObject("vocab")
                val idToToken = HashMap<Int, String>(vocab.length())
                val keys = vocab.keys()
                while (keys.hasNext()) {
                    val tok = keys.next()
                    idToToken[vocab.getInt(tok)] = tok
                }
                WhisperTokenizer(idToToken, byteDecoderTable())
            } catch (_: Throwable) {
                null
            }
        }

        /** The standard GPT-2 / Whisper "byte to printable unicode char" map, inverted here to
         *  char -> byte so decode() can undo it. This table is fixed by the tokenizer's own
         *  published scheme, not something a specific model file can override, so it is safe to
         *  hard-code rather than read from tokenizer.json. */
        private fun byteDecoderTable(): Map<Char, Int> {
            val bs = ArrayList<Int>()
            bs.addAll(('!'.code)..('~'.code))
            bs.addAll(('\u00A1'.code)..('\u00AC'.code))
            bs.addAll(('\u00AE'.code)..('\u00FF'.code))
            val cs = ArrayList<Int>(bs)
            var n = 0
            for (b in 0 until 256) {
                if (b !in bs) {
                    bs.add(b)
                    cs.add(256 + n)
                    n++
                }
            }
            val map = HashMap<Char, Int>(bs.size)
            for (i in bs.indices) map[cs[i].toChar()] = bs[i]
            return map
        }
    }
}
