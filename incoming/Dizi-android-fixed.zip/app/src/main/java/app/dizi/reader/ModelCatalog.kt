package app.dizi.reader

/**
 * Models the app can download. Ids match the web UI. LLM files come from
 * huggingface.co/litert-community; ASR (Whisper) files come from the repos named below.
 *
 * kind: "llm" (run by LlmEngine/litertlm-android) or "asr" (run by AsrEngine/tensorflow-lite).
 * tokFile/tokBytes: only set for "asr" specs. Whisper's .tflite graph outputs token ids, not
 * text, so a second small file (a standard Hugging Face tokenizer.json) is downloaded alongside
 * the model and used by WhisperTokenizer to turn ids back into text.
 */
data class ModelSpec(
    val id: String,
    val name: String,
    val repo: String,
    val file: String,
    val bytes: Long,
    val ramGb: Int,
    val gpu: Boolean,
    /** Qwen3.5 bundles need a fresh Engine per conversation (recurrent state is not reset). */
    val freshEngine: Boolean,
    val kind: String = "llm",
    val tokFile: String? = null,
    val tokBytes: Long = 0L,
) {
    val url: String get() = "https://huggingface.co/$repo/resolve/main/$file"
    val tokUrl: String? get() = tokFile?.let { "https://huggingface.co/$repo/resolve/main/$it" }
}

object ModelCatalog {
    val ALL = listOf(
        ModelSpec("q35-08", "Qwen3.5 0.8B", "litert-community/Qwen3.5-0.8B", "Qwen3.5-0.8B_int8.litertlm", 978_000_000L, 4, false, true),
        ModelSpec("q35-2", "Qwen3.5 2B", "litert-community/Qwen3.5-2B", "Qwen3.5-2B_int8.litertlm", 1_970_000_000L, 6, false, true),
        ModelSpec("g4-e2b", "Gemma 4 E2B", "litert-community/gemma-4-E2B-it-litert-lm", "gemma-4-E2B-it.litertlm", 2_580_000_000L, 6, true, false),
        ModelSpec("g4-e4b", "Gemma 4 E4B", "litert-community/gemma-4-E4B-it-litert-lm", "gemma-4-E4B-it.litertlm", 3_650_000_000L, 8, true, false),
        ModelSpec("q35-4-i4", "Qwen3.5 4B (INT4)", "litert-community/Qwen3.5-4B", "Qwen3.5-4B_mixed_int4.litertlm", 2_754_070_624L, 8, false, true),
        ModelSpec("q35-4", "Qwen3.5 4B (INT8)", "litert-community/Qwen3.5-4B", "Qwen3.5-4B_int8.litertlm", 4_418_793_712L, 12, false, true),
        // --- ASR (Whisper, tensorflow-lite): file names below are a best-effort starting point,
        // not verified against a live Hugging Face listing. Before the first real run, open each
        // repo and confirm "file" and "tokFile" actually exist there with these names, and correct
        // "bytes"/"tokBytes" to the real Content-Length (see README). This is the same caveat the
        // Gemma/Qwen entries above already carry, just not yet checked for these three.
        ModelSpec("tiny", "Whisper tiny", "openai/whisper-tiny", "whisper-tiny.tflite", 42_000_000L, 3, false, false, kind = "asr", tokFile = "tokenizer.json", tokBytes = 2_500_000L),
        ModelSpec("base", "Whisper base", "openai/whisper-base", "whisper-base.tflite", 83_000_000L, 3, false, false, kind = "asr", tokFile = "tokenizer.json", tokBytes = 2_500_000L),
        ModelSpec("small", "Whisper small", "openai/whisper-small", "whisper-small.tflite", 262_000_000L, 4, false, false, kind = "asr", tokFile = "tokenizer.json", tokBytes = 2_500_000L),
    )

    fun byId(id: String): ModelSpec? = ALL.firstOrNull { it.id == id }
}
