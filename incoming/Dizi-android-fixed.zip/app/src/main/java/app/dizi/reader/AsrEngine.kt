package app.dizi.reader

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Transcribes a complete recording with an on-device Whisper model (tensorflow-lite), instead of
 * the word-by-word live guess NativeBridge.srStart already gives you from SpeechRecognizer. One
 * request at a time on a worker thread, mirroring LlmEngine's shape so NativeBridge can treat
 * both engines the same way.
 *
 * IMPORTANT - not verified on a real device or against a real model file in this build (see
 * README "Whisper ASR: before you rely on this"). The parts that are solid regardless of which
 * exact Whisper export you point this at: loading the interpreter, decoding the recorded .m4a
 * to 16kHz mono float32 PCM, and windowing it to the model's declared input length. The one
 * part that depends on the specific .tflite file is what the model's output tensor actually is:
 * this engine handles the common "single call, output is the full token-id sequence" shape
 * end-to-end, and fails with a clear message instead of guessing if a given file turns out to
 * need an autoregressive decode loop (raw per-step logits) instead - that would need writing
 * against that file's actual signature, which cannot be done blind.
 */
class AsrEngine(
    private val ctx: Context,
    private val store: ModelStore,
    private val emit: (String, String, String) -> Unit,
) {
    private val exec = Executors.newSingleThreadExecutor()
    private var interpreter: Interpreter? = null
    private var loadedId: String? = null
    private var tokenizer: WhisperTokenizer? = null
    @Volatile private var stopped = false

    /** Returns "" when the request was queued, otherwise an error code (see AsrErr in dizi.html). */
    fun transcribe(reqId: String, modelId: String, audioPath: String, lang: String): String {
        val m = ModelCatalog.byId(modelId) ?: return "unknown_model"
        if (m.kind != "asr") return "unknown_model"
        if (!store.isReady(m)) return "not_downloaded"
        val f = File(audioPath)
        if (!f.isFile || f.length() < 500L) return "no_audio"
        stopped = false
        exec.execute {
            try {
                val text = run(m, f, lang)
                emit(reqId, "done", text)
            } catch (t: Throwable) {
                emit(reqId, "error", t.message ?: t.javaClass.simpleName)
            }
        }
        return ""
    }

    fun stop() { stopped = true }

    fun release() {
        exec.execute { unload() }
        exec.shutdown()
    }

    private fun run(m: ModelSpec, audioFile: File, lang: String): String {
        val interp = ensureLoaded(m)
        val tok = tokenizer ?: throw IllegalStateException("tokenizer_unavailable")
        val pcm = decodeToMonoPcm16k(audioFile)
        if (pcm.isEmpty()) throw IllegalStateException("no_audio")

        val inTensor = interp.getInputTensor(0)
        val windowLen = inTensor.shape().last() // e.g. 480000 for a fixed 30s @ 16kHz window
        val chunks = windowChunks(pcm, windowLen)

        val out = StringBuilder()
        for (chunk in chunks) {
            if (stopped) break
            val piece = runOneWindow(interp, tok, chunk, windowLen)
            if (piece.isNotBlank()) {
                if (out.isNotEmpty()) out.append(' ')
                out.append(piece)
            }
        }
        return out.toString().trim().ifEmpty { throw IllegalStateException("no_speech") }
    }

    private fun runOneWindow(interp: Interpreter, tok: WhisperTokenizer, samples: FloatArray, windowLen: Int): String {
        val input = ByteBuffer.allocateDirect(windowLen * 4).order(ByteOrder.nativeOrder())
        for (i in 0 until windowLen) input.putFloat(if (i < samples.size) samples[i] else 0f)
        input.rewind()

        val outTensor = interp.getOutputTensor(0)
        return when (outTensor.dataType()) {
            DataType.INT32 -> {
                val shape = outTensor.shape()
                val len = shape.last()
                val outBuf = ByteBuffer.allocateDirect(len * 4).order(ByteOrder.nativeOrder())
                interp.run(input, outBuf)
                outBuf.rewind()
                val ids = IntArray(len) { outBuf.int }
                tok.decode(ids)
            }
            DataType.INT64 -> {
                val shape = outTensor.shape()
                val len = shape.last()
                val outBuf = ByteBuffer.allocateDirect(len * 8).order(ByteOrder.nativeOrder())
                interp.run(input, outBuf)
                outBuf.rewind()
                val ids = IntArray(len) { outBuf.long.toInt() }
                tok.decode(ids)
            }
            else -> throw IllegalStateException(
                "unsupported_output_${outTensor.dataType()}_rank${outTensor.shape().size}: " +
                    "this model's output doesn't look like a plain token-id sequence, so it likely " +
                    "needs a per-step decode loop that this build does not implement - see README."
            )
        }
    }

    /** Splits PCM into fixed-length windows (Whisper's own training window, usually 30s). The last
     *  window is zero-padded by runOneWindow if shorter, so no samples are silently dropped. */
    private fun windowChunks(pcm: FloatArray, windowLen: Int): List<FloatArray> {
        if (windowLen <= 0) return listOf(pcm)
        val chunks = ArrayList<FloatArray>()
        var offset = 0
        while (offset < pcm.size) {
            val end = min(pcm.size, offset + windowLen)
            chunks.add(pcm.copyOfRange(offset, end))
            offset = end
        }
        return chunks
    }

    private fun ensureLoaded(m: ModelSpec): Interpreter {
        interpreter?.let { if (loadedId == m.id) return it }
        unload()
        val opts = Interpreter.Options().apply { setNumThreads(max(2, Runtime.getRuntime().availableProcessors() / 2)) }
        val interp = Interpreter(store.file(m), opts)
        val tokFile = store.tokFile(m) ?: throw IllegalStateException("tokenizer_unavailable")
        val tok = WhisperTokenizer.load(tokFile) ?: throw IllegalStateException("tokenizer_unavailable")
        interpreter = interp
        tokenizer = tok
        loadedId = m.id
        return interp
    }

    private fun unload() {
        try { interpreter?.close() } catch (_: Throwable) {}
        interpreter = null
        tokenizer = null
        loadedId = null
    }

    /** Decodes any container MediaExtractor can open (the recorder always writes .m4a/AAC) into
     *  mono float32 PCM at 16 kHz, which is the sample rate every common Whisper export expects. */
    private fun decodeToMonoPcm16k(file: File): FloatArray {
        val extractor = MediaExtractor()
        extractor.setDataSource(file.absolutePath)
        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { trackIndex = i; format = f; break }
        }
        if (trackIndex < 0 || format == null) { extractor.release(); return FloatArray(0) }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val srcRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 16_000
        val srcChannels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1

        val pcm = ArrayList<Short>(srcRate * 30)
        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEos = false
        var sawOutputEos = false
        try {
            while (!sawOutputEos) {
                if (!sawInputEos) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx) ?: continue
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            sawInputEos = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        val shortBuf = outBuf.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val tmp = ShortArray(shortBuf.remaining())
                        shortBuf.get(tmp)
                        for (s in tmp) pcm.add(s)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) sawOutputEos = true
                }
            }
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            try { codec.release() } catch (_: Throwable) {}
            try { extractor.release() } catch (_: Throwable) {}
        }

        val mono = if (srcChannels > 1) downmix(pcm, srcChannels) else pcm.toShortArray()
        val resampled = if (srcRate != TARGET_RATE) resample(mono, srcRate, TARGET_RATE) else mono
        return FloatArray(resampled.size) { resampled[it] / 32768f }
    }

    private fun downmix(interleaved: List<Short>, channels: Int): ShortArray {
        val frames = interleaved.size / channels
        val out = ShortArray(frames)
        for (i in 0 until frames) {
            var sum = 0
            for (c in 0 until channels) sum += interleaved[i * channels + c]
            out[i] = (sum / channels).toShort()
        }
        return out
    }

    /** Simple linear-interpolation resampler. Not as clean as a sinc resampler, but the recorder
     *  already captures at 16 kHz (AudioRecorder.start sets setAudioSamplingRate(16_000)), so in
     *  practice this path only runs if a given device's encoder ignores that hint. */
    private fun resample(src: ShortArray, srcRate: Int, dstRate: Int): ShortArray {
        if (src.isEmpty() || srcRate == dstRate) return src
        val dstLen = (src.size.toLong() * dstRate / srcRate).toInt()
        val out = ShortArray(dstLen)
        val ratio = srcRate.toDouble() / dstRate
        for (i in 0 until dstLen) {
            val pos = i * ratio
            val i0 = pos.toInt()
            val i1 = min(src.size - 1, i0 + 1)
            val frac = pos - i0
            out[i] = (src[i0] * (1 - frac) + src[i1] * frac).roundToInt().toShort()
        }
        return out
    }

    companion object {
        const val TARGET_RATE = 16_000
    }
}
