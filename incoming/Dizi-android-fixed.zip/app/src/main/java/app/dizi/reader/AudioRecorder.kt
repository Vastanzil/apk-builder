package app.dizi.reader

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/**
 * Records the phone's microphone to a real file in app-private storage and keeps it - unlike
 * SpeechRecognizer (NativeBridge.srStart/srStop), which only ever produces text and throws the
 * audio away. Used for both app modes: "record, then transcribe" (this is the only thing
 * running) and "live captions" (this runs alongside SpeechRecognizer, so the live guess and the
 * kept original audio come from the same recording session).
 *
 * One recording at a time. Not thread-safe; call from the main thread, matching how
 * NativeBridge drives everything else through its Handler(Looper.getMainLooper()).
 */
class AudioRecorder(private val ctx: Context) {

    data class Result(val path: String, val durationMs: Long, val bytes: Long)

    private var recorder: MediaRecorder? = null
    private var outFile: File? = null
    private var startedAt: Long = 0L

    private val dir: File by lazy {
        File(ctx.filesDir, "recordings").apply { mkdirs() }
    }

    val isRecording: Boolean get() = recorder != null

    /** Returns "" on success, otherwise an error code the web UI understands (see RecErr in dizi.html). */
    fun start(): String {
        if (recorder != null) return "already_recording"
        val f = File(dir, "rec_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96_000)
            r.setAudioSamplingRate(16_000) // matches what the Whisper models expect; also keeps the file small
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            outFile = f
            startedAt = System.currentTimeMillis()
            ""
        } catch (t: Throwable) {
            try { r.release() } catch (_: Throwable) {}
            recorder = null
            outFile = null
            f.delete()
            when (t) {
                is SecurityException -> "not-allowed"
                is java.io.IOException -> "audio-capture"
                else -> "aborted"
            }
        }
    }

    /** Stops and finalises the file. Returns null if nothing was recording, or the clip was too short/empty. */
    fun stop(): Result? {
        val r = recorder ?: return null
        val f = outFile
        recorder = null
        outFile = null
        val duration = System.currentTimeMillis() - startedAt
        try {
            r.stop()
        } catch (_: Throwable) {
            // stop() throws if start() never produced any data (e.g. mic grabbed by another app mid-recording).
            try { r.reset() } catch (_: Throwable) {}
            f?.delete()
            try { r.release() } catch (_: Throwable) {}
            return null
        }
        try { r.release() } catch (_: Throwable) {}
        if (f == null || !f.isFile || f.length() < 500L || duration < 300L) {
            f?.delete()
            return null
        }
        return Result(f.absolutePath, duration, f.length())
    }

    /** Called when the activity is torn down mid-recording; discards rather than trying to finalise. */
    fun release() {
        val r = recorder ?: return
        recorder = null
        try { r.reset() } catch (_: Throwable) {}
        try { r.release() } catch (_: Throwable) {}
        outFile?.delete()
        outFile = null
    }

    companion object {
        /** Frees space: recordings the web UI no longer lists (deleted, or from a previous app install) pile up otherwise. */
        fun pruneOrphans(ctx: Context, keepPaths: Set<String>) {
            val dir = File(ctx.filesDir, "recordings")
            val files = dir.listFiles() ?: return
            for (f in files) if (f.absolutePath !in keepPaths) f.delete()
        }
    }
}
