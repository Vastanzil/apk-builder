# Settings and Permissions panels (implemented)

Implements `SANDPIPER_SETTINGS_AND_PERMISSIONS_PLAN.md`, phases 0 to 5, in one release.

## One registry
`app/src/main/assets/features.json` is the single source of truth:
- `permissions[]`: id, kind (`runtime` | `special` | `install`), label, what it enables, the manifest permissions it covers.
- `features[]`: which permissions each feature **requires** (action required when missing) or finds **optional** (never shown as an error).
- `settings[]`: id, feature, type (`toggle | number | choice | text | action | info | perm`), default, label, help, `store`, `key`, `authority`, `requires`.

Everything reads it: the Permissions panel, the Settings panel, the status chips, the self-test, `FeatureRegistryTest`.
`FeatureRegistry.validate()` enforces: every manifest permission is listed exactly once, every permission is used by a feature,
setting ids are unique, choice defaults are real options, numbers are inside min/max.

## Permissions (`Permissions.kt`)
One implementation of every probe and request. States: `granted`, `not_granted`, `permanently_denied`, `special`, `na`.
- Never requests anything because a panel opened. A request happens only from a Grant/Fix tap, or at first real use of a feature
  through the shared "why we need this" sheet (`needPerm()` in the page).
- Live probe on panel open and on every app resume (`MainActivity.onResume` -> `onNativePermission`). Nothing is cached.
- "Permanently denied" = asked before and Android no longer shows a rationale; the button then opens App info.
- Special access buttons open the exact Android page; the row re-checks when you return.
- The Fitness page, Planner page, self-test and alarm checks all use the same code (`openPermission`, `requestNotif`, `permState` are thin wrappers).

## Settings
Stores and who owns the live value:

| store | live value | `authority` |
|---|---|---|
| `state` (profile, currency, categories, goals, default alarm sound, backup option) | host localStorage | `central` |
| `notesmode` | `sp_notes_mode` | `central` |
| `app` (snooze length, ring time, rising volume) | `AppSettings` | `central` |
| `island` (Brainy Island) | `IslandStore` | `store` |
| `fit` (Fitness limits, warnings, lock, quiet hours) | Fitness page storage + `setFitSettings` | `store` |

Dual-read, adapted: the central `setting` table mirrors **every** setting. For `central` settings the central value wins and is pushed
into the old store on start (so a restore takes effect); for `store` settings the live store wins (Brainy and Fitness can still be changed from
their own screens, so central must never look newer than what the feature really uses) and central mirrors it. Writes always go to both.
Every write logs `SETTINGS_CHANGED` with the feature only, never the key or value. The Brainy app picker stays a native screen opened from a row.

## Backup v3
`{app, version:3, state, planner_reminders, fitness, settings, piper?, includes}`. Optional Piper workspace (toggle, default on).
Restore validates the whole file first (nothing is touched if it fails), keeps a safety copy in `sp_pre_restore`, then applies data,
Planner reminders, Fitness data, central settings and finally Piper (a Piper failure is reported and the current workspace is left alone).
Version 2 backups still restore. Voice notes are not part of the backup.

## Adding a setting or permission
1. Add it to `features.json` (and `AndroidManifest.xml` for a permission). 2. Run the unit tests (`FeatureRegistryTest`).
3. For a new store kind add one adapter in `LEG` (index.html). No UI code is needed: the panels render from the registry.
