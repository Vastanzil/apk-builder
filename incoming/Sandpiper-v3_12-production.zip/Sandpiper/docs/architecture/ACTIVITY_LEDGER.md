# Activity ledger (history, charts, Track Record)

Lives in `sandpiper_central.db` (CentralDb version 4). Local only: the app has no INTERNET permission and `allowBackup=false`.

## Tables
| Table | Role | Rules |
|---|---|---|
| `activity_event` | Append-only log. One row per fact (a focus session, an hourly reel bucket, one alarm ring...) | Deterministic `id`; writing the same id replaces it, so retries/re-seeds never double count. Deletes set `deleted=1` (tombstone). `day` is the LOCAL date fixed at write time. Events older than 400 days are dropped; rollups stay forever |
| `daily_metric` | Derived: one number per (day, metric) | Updated in the same transaction as every write. Always rebuildable (`activityRebuild`). Self-test checks it and rebuilds on mismatch |
| `day_summary` | Frozen record of a closed day (planner tasks, zen, fitness) | The only table holding user text (task names). Never logged, kept forever, backed up |

## Who writes
- Native (works with the app closed): `Steps.record` (steps, active min), `Notifier`/`AlarmReceiver` (alarm.fired/snoozed/dismissed), `BrainyStore` -> `ActivityStore.emitBrainyDay` when a day rolls over (hourly `reels`, `reels.platform`, `videos.reg`, `feed`). `StepWorker` reads Brainy state every ~15 min so a finished day is always flushed.
- Web (`index.html`): `actSync()` runs from `save()` (1.5 s debounce) and diffs app data into events (only changes are sent). Voice notes log `voice.count` on save/delete; closed days are saved to `day_summary`.

## Read side
`activitySeries(metric, from, to)` (rollups only), `activityDay(day)` (rollups + that day's events), `daySummaryGet(day)`. The Home Activity card and Track Record use the ledger for past days and live app data for today, and fall back to app data if the ledger has nothing.

## Adding a metric (checklist)
1. Add it to `ActivityCore.METRICS` with its rule (SUM / MAX / LAST). Lower-case dotted name; `ActivityCoreTest.everyMetricNameIsWellFormed` enforces the format.
2. Write it: a native `ActivityStore.add(...)` call, or an event in `actEvents()` in `index.html`.
3. Show it: add a chip in `ACTM` + `DBK` (Activity card) and/or a section in `renderTR` (Track Record).
4. Add it to the table above if it needs a new rule. Never rename a metric or an id scheme: old rows would stop matching. Add a new one and migrate.

## Changing the schema
Additive only (`CREATE ... IF NOT EXISTS`, new columns with defaults). Bump `CentralDb.VERSION`, extend `onUpgrade` with `if (oldVersion < N)`, and keep `ActivityStore.createTables` idempotent. Never drop or rewrite existing tables in an upgrade.

## Privacy
Events hold metrics, enums and numbers only: `ActivityCore.parse` drops anything else. `meta` is a tiny JSON (e.g. `{"p":"instagram"}`), max 400 chars. Diagnostics logs enums and counts only (`ACTIVITY` category); a self-test failure rebuilds rollups and logs `ACTIVITY_REBUILT`.

## Backup
Backup format 4 carries `activity: { v:2, events:[...], days:[...] }`. Restore merges by id; a day summary already on the device wins over the backup copy. Older backups without `activity` restore as before.

## Known limits
Planner tasks exist only for days you pressed Close the day (the planner does not persist its plan). Voice-note audio stays in WebView storage and is not backed up; only the counts are. Brainy's per-app time (`usage.min`) is reserved but not written yet. Reel history starts when Brainy first runs this version.

## Auto day submission
`autoCloseCheck()` (index.html) turns each finished day into a Closed days record with `outcome:'auto'`, `auto:true`. It reads Zen/Fitness from app data and reels/feed/active minutes/steps from the ledger (`activityDay`). It never overwrites an existing day, awards no bonus points and records no planner tasks. The ledger sync skips `planner.*` events for auto days, so charts never show a fake 0% day.

## Planner tasks per day
`planner-bridge.js` -> `SpHub.planSnapshot` -> `S.plan.log[date]` (done that day) and `S.plan.open[date]` (pending). `planTasks(date, rec)` merges them with a closed record's own task list; Track Record, auto submission and the `planner.tasks` metric all read it. Names live only in app data / `day_summary`, never in `activity_event`.
