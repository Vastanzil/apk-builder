# Feature status (honest)
Legend: **Logic-tested** = web logic run in a simulated browser (jsdom) with a fake native bridge. **Not device-tested** = written but never compiled or run on a phone.

| Feature | Status |
|---|---|
| Transactions, balance, savings rate, CSV | Logic-tested |
| Planner: Smart calendar (Monday-first, selected-day reminders, complete/reopen/delete, Notify me), tasks, repeat + month-end clamp | Logic-tested |
| Focus timer survives restarts, counts each session once, bonsai stages | Logic-tested |
| Alarms: JS scheduling + one-time/repeat roll-over | Logic-tested |
| Alarms: AlarmManager + foreground-service ringing, snooze, reboot re-arm, health checks (Kotlin) | Not device-tested |
| Notifications, permission prompts (Kotlin) | Not device-tested |
| Voice notes (WebView MediaRecorder, stored in IndexedDB) | Not device-tested; format is WebM/Opus, not AAC |
| Save CSV / JSON / audio to Downloads/Sandpiper | Bridge logic-tested; MediaStore code not device-tested |
| Step counter (daily baseline, counts from first open each day) | Not device-tested |
| Alarm tone choice: 5 built-in original tones, phone alarm tones, your own audio file, preview | Web logic-tested; playback, picker and file copy (Kotlin) not device-tested |
| Zen Garden layout: timer + garden in one card, Fitness card with your full fitness page | Logic-tested in a simulated browser |
| Fitness ports, stars and reports -> Close the day -> day record, bonus points, CSV | Logic-tested end to end (simulated browser) |
| Fitness native hooks: steps, permission state, Usage Access minutes, links, workout reminders (Kotlin) | Not device-tested |
| Habits, hydration, sleep, investments, backup/restore, calculator, About easter egg | Logic-tested |
| Gradle build / APK | **Not built** (no Android SDK available when this was written) |

## Known limits
Fitness / Mental tab: short-video and reel counts need an Accessibility service and the focus-lock overlay needs an overlay service; neither is built, so those counters stay at 0 and the lock is a preview only. Phone-usage minutes and sessions (TikTok, Instagram, Facebook, YouTube) are real once Usage Access is granted. Active minutes are not measured. Step history exists only for days the app was opened. The page's web font does not load offline (system font is used).
The planner's own daily plan and skill-tree progress are not saved between launches (same as your original file). No custom alarm music, no XLSX/PDF export, no app lock, no budgets/transfers/multiple accounts, no wake-up sound loop beyond the notification's insistent alarm tone (10 min max).
Voice notes are not included in the JSON backup. Recording may stop if the app is sent to the background.
