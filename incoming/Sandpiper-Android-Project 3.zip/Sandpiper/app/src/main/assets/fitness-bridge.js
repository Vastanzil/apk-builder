/* Connects Sandpiper Fitness (loaded inside Zen Garden) to the host app and to Android.
   The fitness file itself is not edited: it already looks for window.SandpiperBridge, which this script provides.
   Open ports: submitDailyReport() and awardStars() deliver straight to the host's Day Hub, so the ports are "connected"
   and anything queued while the app was closed is delivered when the page boots. */
(function(){
  var H=null,N=window.SandpiperNative||null;
  try{if(window.parent&&window.parent!==window){H=window.parent.SpHub||null;N=N||window.parent.SandpiperNative||null}}catch(e){}
  function call(f){try{var a=[].slice.call(arguments,1);return N&&N[f]?N[f].apply(N,a):null}catch(e){return null}}
  var B={};
  if(H){
    B.submitDailyReport=function(j){H.receiveReport(j)};
    B.awardStars=function(j){H.receiveStars(j)};
  }
  /* Workout reminders: scheduled with Android so they fire when the app is closed. */
  var IDS='sandpiper.fitness.native_ids';
  B.syncReminders=function(j){
    var L=[],prev=[];try{L=JSON.parse(j)}catch(e){}try{prev=JSON.parse(localStorage.getItem(IDS)||'[]')}catch(e){}
    if(!Array.isArray(L))L=[];var want={};
    L.forEach(function(r){var id='fit_'+r.id;want[id]=1;call('schedule',JSON.stringify({id:id,kind:'reminder',title:'Workout: '+String(r.title||''),at:r.at}))});
    prev.forEach(function(id){if(!want[id])call('cancel',id)});
    try{localStorage.setItem(IDS,JSON.stringify(Object.keys(want)))}catch(e){}
  };
  B.saveSettings=function(){};
  B.openLink=function(u){
    if(!/^https?:\/\//i.test(u))return false;
    if(N&&N.openUrl&&call('openUrl',u))return true;
    try{window.open(u,'_blank','noopener')}catch(e){}return true;
  };
  B.openPermission=function(k){if(!(N&&N.openPermission&&call('openPermission',k)))return false;return true};
  window.SandpiperBridge=B;
})();
