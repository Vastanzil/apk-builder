package com.vastanzil.sandpiper.backup

import android.app.Activity
import android.content.Intent
import androidx.activity.result.IntentSenderRequest
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.vastanzil.sandpiper.MainActivity
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Opt-in encrypted backup to the signed-in user's own Google Drive appDataFolder (scope drive.appdata only: invisible in the normal
 * Drive UI). The backup JSON is encrypted on the phone ([BackupCrypto]) before upload; the passphrase and key never leave it.
 * Plain HTTPS REST through HttpURLConnection. Results go back to the web layer as window.onCloudResult(json).
 */
internal object CloudBackup {
    private const val SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val BIN = "sandpiper-backup.bin"
    private const val MAN = "sandpiper-manifest.json"
    private const val API = "https://www.googleapis.com/drive/v3/files"
    private const val UP = "https://www.googleapis.com/upload/drive/v3/files"
    private val io = Executors.newSingleThreadExecutor()
    private var pending: ((String?) -> Unit)? = null
    @Volatile private var taken: ByteArray? = null

    /** The decrypted backup JSON of the last successful restore (kept in memory until the web layer takes it). */
    fun take(): String { val t = taken; taken = null; return if (t == null) "" else String(t, Charsets.UTF_8) }

    private fun report(a: MainActivity, op: String, ok: Boolean, code: String) =
        a.js("window.onCloudResult&&onCloudResult(" + JSONObject().put("op", op).put("ok", ok).put("code", code).put("at", System.currentTimeMillis()).toString() + ")")

    fun run(a: MainActivity, op: String, pass: String, json: String) {
        if (op != "backup" && op != "restore") return
        if (pass.isEmpty()) { report(a, op, false, "EMPTY_PASSPHRASE"); return }
        authorize(a) { token ->
            if (token == null) { report(a, op, false, "auth"); return@authorize }
            io.execute {
                val chars = pass.toCharArray()
                val code = try {
                    if (op == "backup") upload(token, json.toByteArray(Charsets.UTF_8), chars) else download(token, chars)
                    "ok"
                } catch (e: BackupCryptoException) { e.kind.name }
                catch (e: HttpFail) { e.code }
                catch (e: Exception) { "network" } finally { chars.fill('\u0000') }
                report(a, op, code == "ok", code)
            }
        }
    }

    // ---- Google authorization (access token for drive.appdata only) ----
    private fun authorize(a: MainActivity, cb: (String?) -> Unit) {
        val req = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()
        Identity.getAuthorizationClient(a).authorize(req)
            .addOnSuccessListener { r ->
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) { pending = cb; a.launchAuth(IntentSenderRequest.Builder(pi.intentSender).build()) }
                else cb(r.accessToken)
            }
            .addOnFailureListener { cb(null) }
    }

    fun onAuthResult(a: Activity, data: Intent?) {
        val cb = pending; pending = null
        try { cb?.invoke(Identity.getAuthorizationClient(a).getAuthorizationResultFromIntent(data).accessToken) } catch (e: Exception) { cb?.invoke(null) }
    }

    // ---- backup / restore ----
    private fun upload(token: String, plain: ByteArray, pass: CharArray) {
        val blob = BackupCrypto.encrypt(plain, pass)
        val man = CloudManifest("sandpiper", 1, "1.19.1", 2, blob.salt, blob.kdf, System.currentTimeMillis())
        val old = list(token).map { it.first }
        create(token, BIN, "application/octet-stream", blob.payload)
        create(token, MAN, "application/json", man.toJson().toByteArray(Charsets.UTF_8))
        for (id in old) try { call("DELETE", "$API/$id", token, null, null) } catch (e: Exception) { }
    }

    private fun download(token: String, pass: CharArray) {
        val files = list(token)
        val man = files.firstOrNull { it.second == MAN } ?: throw HttpFail("no_backup")
        val bin = files.firstOrNull { it.second == BIN } ?: throw HttpFail("no_backup")
        val m = CloudManifest.parse(String(call("GET", "$API/${man.first}?alt=media", token, null, null), Charsets.UTF_8))
        val payload = call("GET", "$API/${bin.first}?alt=media", token, null, null)
        taken = BackupCrypto.decrypt(EncryptedBlob(BackupCrypto.VERSION, m.salt, m.kdf, payload), pass)
    }

    /** (id, name) of our files, newest first. */
    private fun list(token: String): List<Pair<String, String>> {
        val q = URLEncoder.encode("name='$BIN' or name='$MAN'", "UTF-8")
        val f = URLEncoder.encode("files(id,name)", "UTF-8")
        val o = JSONObject(String(call("GET", "$API?spaces=appDataFolder&q=$q&fields=$f&orderBy=modifiedTime%20desc&pageSize=20", token, null, null), Charsets.UTF_8))
        val a = o.optJSONArray("files") ?: return emptyList()
        return (0 until a.length()).map { a.getJSONObject(it).let { j -> j.getString("id") to j.getString("name") } }
    }

    private fun create(token: String, name: String, mime: String, data: ByteArray) {
        val b = "sandpiper" + System.nanoTime()
        val meta = JSONObject().put("name", name).put("parents", org.json.JSONArray().put("appDataFolder")).toString()
        val out = ByteArrayOutputStream()
        out.write(("--$b\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$b\r\nContent-Type: $mime\r\n\r\n").toByteArray(Charsets.UTF_8))
        out.write(data)
        out.write("\r\n--$b--".toByteArray(Charsets.UTF_8))
        call("POST", "$UP?uploadType=multipart", token, out.toByteArray(), "multipart/related; boundary=$b")
    }

    class HttpFail(val code: String) : Exception(code)

    private fun call(method: String, url: String, token: String, body: ByteArray?, ctype: String?): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000; c.readTimeout = 60_000
            c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", ctype ?: "application/octet-stream")
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            if (code !in 200..299) throw HttpFail(if (code == 401) "auth" else if (code == 403) "forbidden" else "http_$code")
            return c.inputStream.use { it.readBytes() }
        } finally { c.disconnect() }
    }
}
