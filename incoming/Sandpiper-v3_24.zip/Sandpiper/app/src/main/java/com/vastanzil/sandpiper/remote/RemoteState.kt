package com.vastanzil.sandpiper.remote

import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Pure, in-memory state shared by the Local Sync server and the change bus. No Android, no sockets. */
object RemoteState {
    @Volatile var running = false
    @Volatile var lastTouch = 0L
    @Volatile var dirty = false
    private val ver = AtomicLong(0)
    private val lock = ReentrantLock()
    private val changed = lock.newCondition()

    val version: Long get() = ver.get()

    /** Called by the change bus after every native write. Free when Local Sync is off. Wakes any waiting long-poll at once. */
    fun bump(): Boolean {
        if (!running) return false
        lock.withLock { ver.incrementAndGet(); changed.signalAll() }
        return true
    }

    /** Waits until the version differs from [since], the server stops, or [ms] pass; returns the current version. No polling loop. */
    fun await(since: Long, ms: Long): Long {
        var left = TimeUnit.MILLISECONDS.toNanos(ms)
        lock.withLock { while (running && ver.get() == since && left > 0) left = changed.awaitNanos(left) }
        return ver.get()
    }

    fun touch(now: Long = System.currentTimeMillis()) { lastTouch = now }

    fun reset() { lock.withLock { running = false; dirty = false; lastTouch = 0L; changed.signalAll() } }
}
