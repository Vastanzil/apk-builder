package com.vastanzil.sandpiper.remote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LifeBusRemoteSyncTest {
    @Test fun bumpIsANoOpWhileTheServerIsStopped() {
        RemoteState.reset()
        val v = RemoteState.version
        assertFalse(RemoteState.bump()); assertEquals(v, RemoteState.version)
        RemoteState.running = true
        assertTrue(RemoteState.bump()); assertEquals(v + 1, RemoteState.version)
        RemoteState.reset()
    }

    @Test fun existingSubscribersAreStillCalledInOrder() {
        val s = File("src/main/java/com/vastanzil/sandpiper/LifeBus.kt").readText()
        val w = s.indexOf("Widgets.refreshSoon"); val j = s.indexOf("StorageJobs.schedule"); val r = s.indexOf("RemoteSyncServer.notifyChanged")
        assertTrue(w in 0 until j && j < r)
        assertEquals(1, Regex("Widgets.refreshSoon\\(c\\)").findAll(s).count())
        assertEquals(1, Regex("StorageJobs.schedule\\(c\\)").findAll(s).count())
    }

    @Test fun awaitWakesImmediatelyOnBumpAndTimesOutOtherwise() {
        RemoteState.reset(); RemoteState.running = true
        val v = RemoteState.version
        val t0 = System.currentTimeMillis()
        assertEquals(v, RemoteState.await(v, 150))                       // nothing happened: returns the same version after the timeout
        assertTrue(System.currentTimeMillis() - t0 >= 100)
        val th = Thread { Thread.sleep(80); RemoteState.bump() }
        th.start()
        val t1 = System.currentTimeMillis()
        assertEquals(v + 1, RemoteState.await(v, 5_000))
        assertTrue(System.currentTimeMillis() - t1 < 2_000)
        th.join(); RemoteState.reset()
    }
}
