package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

/**
 * The product promise: Sandpiper cannot reach the internet. The Little brain adds NO network code and NO INTERNET permission:
 * models come from the phone's own AI or from a file the user picks. This scans the real sources so that stays true.
 */
class NoNetworkTest {
    private val forbidden = listOf("java.net.", "HttpURLConnection", "HttpsURLConnection", "okhttp", "android.permission.INTERNET", "ACCESS_NETWORK_STATE", "DownloadManager", "URLConnection")

    @Test fun noNetworkApisOrPermissionsAnywhereInMain() {
        val hits = ArrayList<String>()
        File("src/main").walkTopDown().filter { it.isFile && (it.extension == "kt" || it.extension == "xml") }.forEach { f ->
            val text = f.readText()
            for (w in forbidden) if (text.contains(w)) hits.add(f.path + " -> " + w)
        }
        assertEquals(emptyList<String>(), hits)
    }

    @Test fun gradleAddsNoNetworkLibraries() {
        val g = File("build.gradle.kts").readText().lowercase()
        for (w in listOf("okhttp", "retrofit", "volley", "ktor", "httpclient")) assertEquals(w, false, g.contains(w))
    }
}
