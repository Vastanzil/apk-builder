package com.vastanzil.sandpiper.widget

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WidgetCoreTest {
    private fun type(s: String): String { var cur = ""; for (c in s) cur = Keypad.press(cur, c); return cur }

    @Test fun keypadBuildsAmounts() {
        assertEquals("125.5", type("125.5"))
        assertEquals("0.5", type(".5"))
        assertEquals("5", type("05"))
        assertEquals("12.34", type("12.345"))          // two decimals at most
        assertEquals("12.3", type("12.3."))            // one point only
        assertEquals("12", type("123B"))
        assertEquals("", type("12C"))
        assertEquals("123456789", type("1234567890"))  // length cap
        assertEquals("", type("B"))
    }
    @Test fun keypadValue() {
        assertEquals(125.5, Keypad.value("125.5")!!, 0.0)
        assertEquals(7.0, Keypad.value("7.")!!, 0.0)
        assertNull(Keypad.value("")); assertNull(Keypad.value("0")); assertNull(Keypad.value("0.00")); assertNull(Keypad.value("."))
        assertEquals("BDT 0", Keypad.display("", "BDT")); assertEquals("BDT 12.5", Keypad.display("12.5", "BDT"))
    }
    @Test fun categoriesFromSettingsOrDefaults() {
        assertEquals(listOf("Food", "Rent"), FinanceCore.parseCats(" Food, Rent ,, food\n"))
        assertEquals(FinanceCore.DEFAULT_CATS, FinanceCore.parseCats(null))
        assertEquals(FinanceCore.DEFAULT_CATS, FinanceCore.parseCats(" , ,"))
        assertEquals(FinanceCore.MAX_CATS, FinanceCore.parseCats((1..30).joinToString(",") { "c$it" }).size)
        assertEquals(0, FinanceCore.nextIndex(2, 3)); assertEquals(0, FinanceCore.nextIndex(5, 0))
    }
    @Test fun transactionRecordMatchesTheWebShapeAndLedgerIds() {
        val j = FinanceCore.txJson("wabc", "Food", "Food", 125.5, "expense", 1_700_000_000_000L)
        assertEquals(setOf("id", "name", "cat", "amount", "kind", "ts"), j.keys().asSequence().toSet())
        assertEquals("tx:wabc", FinanceCore.ledgerId("wabc"))
        assertEquals("spend", FinanceCore.ledgerMetric("expense")); assertEquals("income", FinanceCore.ledgerMetric("income"))
        assertEquals("expense", FinanceCore.txJson("w", "x", "x", 1.0, "weird", 0).getString("kind"))
        assertTrue(FinanceCore.newTxId(1L).matches(Regex("^w[a-z0-9]+$")))
    }
    @Test fun pomodoroStateMachine() {
        val t0 = 1_000_000L
        val run = PomState.idle().start(t0, 25)
        assertEquals(25 * 60_000L, run.remaining(t0)); assertFalse(run.isDue(t0 + 1))
        assertTrue(run.isDue(t0 + 25 * 60_000L))
        val paused = run.pause(t0 + 10 * 60_000L)
        assertEquals(PomPhase.PAUSED, paused.phase); assertEquals(15 * 60_000L, paused.remaining(t0 + 99_999_999L))
        val again = paused.resume(t0 + 20 * 60_000L)
        assertEquals(t0 + 35 * 60_000L, again.endAtMs)
        assertEquals(PomPhase.IDLE, again.reset().phase)
        assertEquals(run, run.resume(t0))                 // resume only applies to PAUSED
        assertEquals(PomPhase.IDLE, PomState.idle().pause(t0).phase)
    }
    @Test fun pomodoroEncodeDecodeAndGarbage() {
        val r = PomState.idle().start(5_000L, 50)
        assertEquals(r, PomState.decode(r.encode()))
        val p = r.pause(6_000L); assertEquals(p, PomState.decode(p.encode()))
        assertEquals(PomState.idle(), PomState.decode(null)); assertEquals(PomState.idle(), PomState.decode("RUNNING:abc:25"))
        assertEquals(PomState.idle(), PomState.decode("PAUSED:0:25"))
        assertEquals(25, PomState.decode("RUNNING:9:7").totalMin)        // unknown length falls back to 25
    }
    @Test fun pomodoroWritesTheSameIdsAsTheWebTimer() {
        val ev = PomState.idle().start(0, 25).doneEvents(1_700_000_000_000L)
        assertEquals(Triple("focus:1700000000000", "focus.min", 25.0), ev[0])
        assertEquals(Triple("focus.n:1700000000000", "focus.sessions", 1.0), ev[1])
        assertEquals("25:00", PomState.clock(25 * 60_000L)); assertEquals("00:01", PomState.clock(1)); assertEquals("00:00", PomState.clock(0))
    }
    @Test fun graphScalingNeverDividesByZero() {
        assertEquals(listOf(0f, 0f), GraphCore.heights(listOf(0.0, 0.0)))
        assertEquals(listOf(0.5f, 1f, 0f), GraphCore.heights(listOf(5.0, 10.0, 0.0)))
        assertEquals(emptyList<Float>(), GraphCore.heights(emptyList()))
        assertEquals("steps.count", GraphCore.nextMetric("focus.min")); assertEquals("focus.min", GraphCore.nextMetric("voice.count")); assertEquals("focus.min", GraphCore.nextMetric("unknown"))
        assertEquals("950", GraphCore.compact(950.0)); assertEquals("1.2k", GraphCore.compact(1234.0)); assertEquals("12k", GraphCore.compact(12345.0)); assertEquals("12.5", GraphCore.compact(12.5))
    }
    @Test fun voiceRules() {
        assertTrue(VoiceCore.isId(VoiceCore.newId(5L))); assertFalse(VoiceCore.isId("../x")); assertEquals("vabc.m4a", VoiceCore.fileName("vabc"))
        assertFalse(VoiceCore.worthKeeping(500, 100)); assertFalse(VoiceCore.worthKeeping(5000, 0)); assertTrue(VoiceCore.worthKeeping(5000, 100))
        assertEquals(4, VoiceCore.inboxJson("v1", 2, 3, 4).length())
    }
    @Test fun taskListHeader() {
        assertEquals("No tasks", TaskListCore.progress(0, 0)); assertEquals("2/5 done", TaskListCore.progress(2, 5))
        assertEquals(40, TaskListCore.percent(2, 5)); assertEquals(0, TaskListCore.percent(0, 0))
        assertEquals("weekly", TaskListCore.nextPeriod("daily")); assertEquals("daily", TaskListCore.nextPeriod("monthly"))
    }
}
