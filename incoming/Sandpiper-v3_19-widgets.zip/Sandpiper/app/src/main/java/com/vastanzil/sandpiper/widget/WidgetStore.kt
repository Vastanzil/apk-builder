package com.vastanzil.sandpiper.widget

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Base64
import com.vastanzil.sandpiper.CentralDb
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * widget_inbox (CentralDb v8): records a widget wrote natively that belong to the web layer's own storage (finance list, focus garden,
 * voice recordings). Written the moment the user taps, deleted only after the web layer imported them and said so (ack).
 * Row id = "<kind>:<record id>", so a retried write replaces itself and can never duplicate.
 */
internal object WidgetStore {
    fun createTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS widget_inbox(id TEXT PRIMARY KEY, kind TEXT NOT NULL, json TEXT NOT NULL, ts INTEGER NOT NULL)")
    }

    private fun db(c: Context) = CentralDb.get(c).writableDatabase
    private fun voiceDir(c: Context) = File(c.filesDir, "voice")

    @Synchronized
    fun enqueue(c: Context, kind: String, id: String, json: String, ts: Long): Boolean = try {
        val cv = ContentValues().apply { put("id", "$kind:$id"); put("kind", kind); put("json", json); put("ts", ts) }
        db(c).insertWithOnConflict("widget_inbox", null, cv, SQLiteDatabase.CONFLICT_REPLACE) != -1L
    } catch (e: Exception) { false }

    fun take(c: Context, limit: Int): JSONArray {
        val out = JSONArray()
        try {
            db(c).rawQuery("SELECT id, kind, json, ts FROM widget_inbox ORDER BY ts LIMIT ?", arrayOf(limit.coerceIn(1, 200).toString())).use {
                while (it.moveToNext()) {
                    val data = try { JSONObject(it.getString(2)) } catch (e: Exception) { continue }
                    out.put(JSONObject().put("id", it.getString(0)).put("kind", it.getString(1)).put("ts", it.getLong(3)).put("data", data))
                }
            }
        } catch (e: Exception) { /* empty */ }
        return out
    }

    @Synchronized
    fun ack(c: Context, ids: JSONArray): Int {
        var n = 0
        try {
            val d = db(c)
            for (i in 0 until ids.length()) {
                val id = ids.optString(i, "")
                if (id.isEmpty()) continue
                n += d.delete("widget_inbox", "id=?", arrayOf(id))
                if (id.startsWith(WidgetKinds.VOICE + ":")) {
                    val rid = id.substringAfter(':')
                    if (VoiceCore.isId(rid)) File(voiceDir(c), VoiceCore.fileName(rid)).delete()
                }
            }
        } catch (e: Exception) { /* keep what is left for the next open */ }
        return n
    }

    fun pending(c: Context): Int = try {
        db(c).rawQuery("SELECT COUNT(*) FROM widget_inbox", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (e: Exception) { 0 }

    private fun voiceFile(c: Context, id: String): File? = if (VoiceCore.isId(id)) File(voiceDir(c), VoiceCore.fileName(id)) else null
    fun voiceSize(c: Context, id: String): Long = voiceFile(c, id)?.takeIf { it.exists() }?.length() ?: 0L

    /** One slice of the recording as base64 (the web layer pulls a long recording piece by piece, so any length works). */
    fun voiceChunk(c: Context, id: String, offset: Long, len: Int): String {
        val f = voiceFile(c, id) ?: return ""
        if (!f.exists() || offset < 0 || offset >= f.length()) return ""
        val n = minOf(len.toLong().coerceIn(1L, VoiceCore.CHUNK.toLong()), f.length() - offset).toInt()
        return try {
            java.io.RandomAccessFile(f, "r").use { r -> val buf = ByteArray(n); r.seek(offset); r.readFully(buf); Base64.encodeToString(buf, Base64.NO_WRAP) }
        } catch (e: Exception) { "" }
    }

    /** Voice files with no inbox row (a recording the process died in the middle of) are unplayable: remove them. */
    fun cleanupVoiceOrphans(c: Context) {
        try {
            val known = HashSet<String>()
            db(c).rawQuery("SELECT id FROM widget_inbox WHERE kind=?", arrayOf(WidgetKinds.VOICE)).use { while (it.moveToNext()) known.add(it.getString(0).substringAfter(':')) }
            val now = System.currentTimeMillis()
            voiceDir(c).listFiles()?.forEach { f ->
                val id = f.name.removeSuffix(".m4a")
                if (id !in known && now - f.lastModified() > 120_000L) f.delete()
            }
        } catch (e: Exception) { /* best effort */ }
    }
}
