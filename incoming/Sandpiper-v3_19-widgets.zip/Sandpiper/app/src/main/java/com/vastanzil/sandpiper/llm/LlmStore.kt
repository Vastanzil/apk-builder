package com.vastanzil.sandpiper.llm

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.vastanzil.sandpiper.CentralDb
import org.json.JSONArray
import org.json.JSONObject

data class ModelRow(
    val id: String, val source: String, val name: String, val sizeBytes: Long, val sha256: String?,
    val verified: Boolean, val state: ModelState, val path: String?, val installedAt: Long, val lastUsedAt: Long
)

/**
 * CentralDb version 7 (additive): llm_model and llm_usage.
 *  - llm_model: one row per model file the USER provided (source 'import'; 'catalog' and 'custom' are reserved for a future connected build).
 *    Display names are user text: never logged. Files live in filesDir/models/<id>/ and are never in backups (allowBackup=false).
 *  - llm_usage: counts and durations per day/provider/task. No prompts, no outputs.
 */
internal object LlmStore : UsageSink {
    fun createTables(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS llm_model(id TEXT PRIMARY KEY, source TEXT NOT NULL, name TEXT NOT NULL, host TEXT, " +
                "size_bytes INTEGER NOT NULL DEFAULT 0, sha256 TEXT, verified INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL, " +
                "path TEXT, installed_at INTEGER, last_used_at INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS llm_usage(day TEXT NOT NULL, provider TEXT NOT NULL, task TEXT NOT NULL, " +
                "calls INTEGER NOT NULL DEFAULT 0, ms INTEGER NOT NULL DEFAULT 0, blocked INTEGER NOT NULL DEFAULT 0, " +
                "failed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day, provider, task))"
        )
    }

    @Volatile private var ctxRef: Context? = null
    fun init(c: Context) { ctxRef = c.applicationContext }
    private val appCtx: Context get() = ctxRef ?: throw IllegalStateException("LlmStore not initialised")

    // ---- usage (UsageSink) ----
    override fun callsToday(day: String): Int = try {
        CentralDb.get(appCtx).readableDatabase.rawQuery("SELECT COALESCE(SUM(calls),0) FROM llm_usage WHERE day=?", arrayOf(day)).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    } catch (e: Exception) { 0 }

    /** No UPSERT: Android 10 (minSdk 29) ships SQLite 3.22. Insert-or-ignore, then update. */
    override fun add(day: String, provider: ProviderId, task: LlmTask, calls: Int, ms: Long, blocked: Int, failed: Int) {
        try {
            val db = CentralDb.get(appCtx).writableDatabase
            db.beginTransaction()
            try {
                db.execSQL("INSERT OR IGNORE INTO llm_usage(day,provider,task,calls,ms,blocked,failed) VALUES(?,?,?,0,0,0,0)", arrayOf<Any>(day, provider.name, task.key))
                db.execSQL(
                    "UPDATE llm_usage SET calls=calls+?, ms=ms+?, blocked=blocked+?, failed=failed+? WHERE day=? AND provider=? AND task=?",
                    arrayOf<Any>(calls, ms, blocked, failed, day, provider.name, task.key)
                )
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        } catch (e: Exception) { /* usage is best effort */ }
    }

    fun usageJson(): String {
        val arr = JSONArray()
        try {
            CentralDb.get(appCtx).readableDatabase.rawQuery(
                "SELECT day,provider,task,calls,ms,blocked,failed FROM llm_usage ORDER BY day DESC LIMIT 60", null
            ).use {
                while (it.moveToNext()) arr.put(
                    JSONObject().put("day", it.getString(0)).put("provider", it.getString(1)).put("task", it.getString(2))
                        .put("calls", it.getInt(3)).put("ms", it.getLong(4)).put("blocked", it.getInt(5)).put("failed", it.getInt(6))
                )
            }
        } catch (e: Exception) { /* empty */ }
        return arr.toString()
    }

    // ---- models ----
    private fun row(c: android.database.Cursor) = ModelRow(
        c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getString(4), c.getInt(5) == 1,
        ModelState.values().firstOrNull { s -> s.name == c.getString(6) } ?: ModelState.FAILED,
        c.getString(7), c.getLong(8), c.getLong(9)
    )

    private const val COLS = "id,source,name,size_bytes,sha256,verified,state,path,COALESCE(installed_at,0),COALESCE(last_used_at,0)"

    fun models(): List<ModelRow> = try {
        val out = ArrayList<ModelRow>()
        CentralDb.get(appCtx).readableDatabase.rawQuery("SELECT $COLS FROM llm_model ORDER BY installed_at DESC", null).use { while (it.moveToNext()) out.add(row(it)) }
        out
    } catch (e: Exception) { emptyList() }

    fun readyModel(): ModelRow? = models().firstOrNull { it.state == ModelState.READY && it.path != null }

    fun find(id: String): ModelRow? = models().firstOrNull { it.id == id }

    fun put(m: ModelRow) {
        val cv = ContentValues().apply {
            put("id", m.id); put("source", m.source); put("name", m.name); put("size_bytes", m.sizeBytes)
            put("sha256", m.sha256); put("verified", if (m.verified) 1 else 0); put("state", m.state.name)
            put("path", m.path); put("installed_at", m.installedAt); put("last_used_at", m.lastUsedAt)
        }
        CentralDb.get(appCtx).writableDatabase.insertWithOnConflict("llm_model", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun setState(id: String, s: ModelState) {
        val cv = ContentValues().apply { put("state", s.name) }
        CentralDb.get(appCtx).writableDatabase.update("llm_model", cv, "id=?", arrayOf(id))
    }

    fun touch(id: String, now: Long) {
        val cv = ContentValues().apply { put("last_used_at", now) }
        try { CentralDb.get(appCtx).writableDatabase.update("llm_model", cv, "id=?", arrayOf(id)) } catch (e: Exception) { }
    }

    fun delete(id: String) { CentralDb.get(appCtx).writableDatabase.delete("llm_model", "id=?", arrayOf(id)) }

    fun modelsJson(): String {
        val arr = JSONArray()
        for (m in models()) arr.put(
            JSONObject().put("id", m.id).put("name", m.name).put("sizeBytes", m.sizeBytes).put("state", m.state.name)
                .put("verified", m.verified).put("source", m.source)
        )
        return arr.toString()
    }
}
