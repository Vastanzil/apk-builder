package com.vastanzil.sandpiper.llm

import android.content.Context
import android.net.Uri
import android.os.PowerManager
import com.vastanzil.sandpiper.AppSettings
import com.vastanzil.sandpiper.DCat
import com.vastanzil.sandpiper.DEv
import com.vastanzil.sandpiper.DLvl
import com.vastanzil.sandpiper.DMod
import com.vastanzil.sandpiper.DRes
import com.vastanzil.sandpiper.Diag
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.Executors

/**
 * Android wiring for the Little Brain: one engine, one worker thread, one IO thread for file imports.
 * Everything here is foreground-only: MainActivity tells us when the screen is on, and a thermal listener cancels running calls.
 * Nothing in this package touches the network (NoNetworkTest enforces it).
 */
internal object Brain {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "sp-brain").apply { isDaemon = true } }
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "sp-brain-io").apply { isDaemon = true } }
    @Volatile private var eng: LlmEngine? = null
    @Volatile private var thermalHooked = false

    fun engine(c: Context): LlmEngine = eng ?: synchronized(this) { eng ?: build(c.applicationContext).also { eng = it } }

    private fun build(c: Context): LlmEngine {
        LlmStore.init(c)
        val env = object : EngineEnv {
            override fun nowMs() = System.currentTimeMillis()
            override fun day(nowMs: Long) = LocalDate.ofInstant(Instant.ofEpochMilli(nowMs), ZoneId.systemDefault()).toString()
            override fun mode() = BrainMode.parse(AppSettings.get(c, "brainMode"))
            override fun taskEnabled(t: LlmTask) = AppSettings.get(c, t.setting) == "true"
            override fun mayAsk() = AppSettings.get(c, "brainAsk") != "false"
            override fun budget() = AppSettings.get(c, "brainBudget")?.toIntOrNull() ?: GuardCore.DEFAULT_BUDGET
            override fun snapshot() = LlmGuard.snapshot(c)
            override fun event(ev: BrainEvent, task: LlmTask?, n: Long) {
                val (d, lvl, res) = when (ev) {
                    BrainEvent.PROVIDER_CHOSEN -> Triple(DEv.BRAIN_PROVIDER_CHOSEN, DLvl.D, DRes.OK)
                    BrainEvent.CALL_OK -> Triple(DEv.BRAIN_CALL_OK, DLvl.I, DRes.OK)
                    BrainEvent.CALL_FAILED -> Triple(DEv.BRAIN_CALL_FAILED, DLvl.I, DRes.FAIL)
                    BrainEvent.GUARD_BLOCKED -> Triple(DEv.BRAIN_GUARD_BLOCKED, DLvl.I, DRes.SKIP)
                }
                Diag.log(lvl, DCat.BRAIN, d, DMod.BRAIN, res, n = n)
            }
        }
        val providers = mapOf<ProviderId, LlmProvider>(
            ProviderId.AICORE to SystemAiProvider(),
            ProviderId.LOCAL to LocalModelProvider(c),
            ProviderId.NONE to NullProvider()
        )
        val e = LlmEngine(providers, env, LlmStore, worker)
        hookThermal(c, e)
        return e
    }

    /** A running call is cancelled the moment the phone reaches the guard's thermal level. */
    private fun hookThermal(c: Context, e: LlmEngine) {
        if (thermalHooked) return
        try {
            c.getSystemService(PowerManager::class.java)?.addThermalStatusListener(c.mainExecutor) { s ->
                if (s >= GuardCore.THERMAL_BLOCK_AT) e.cancelAll()
            }
            thermalHooked = true
        } catch (x: Exception) { /* guard still checks before every call */ }
    }

    fun run(c: Context, task: String, input: String, requestId: String, cb: (String, String) -> Unit) =
        engine(c).run(task, input, requestId, cb)

    fun cancel(c: Context, requestId: String): Boolean = engine(c).cancel(requestId)

    fun status(c: Context): String {
        val e = engine(c)
        val day = LocalDate.now().toString()
        return e.statusJson(LlmStore.callsToday(day))
    }

    /** App left the screen: stop work and free model memory. */
    fun onBackground() {
        val e = eng ?: return
        e.cancelAll()
        worker.execute { e.releaseAll() }
    }

    fun importModel(c: Context, uri: Uri, userSha: String?, report: (String) -> Unit) {
        LlmStore.init(c)
        io.execute {
            val code = ModelImporter.import(c, uri, userSha) { pct -> report(JSONObject().put("done", false).put("pct", pct).toString()) }
            report(JSONObject().put("done", true).put("code", code).toString())
        }
    }

    fun remove(c: Context, id: String): Boolean { LlmStore.init(c); engine(c).releaseAll(); return ModelImporter.remove(c, id) }
    fun models(c: Context): String { LlmStore.init(c); return LlmStore.modelsJson() }
    fun usage(c: Context): String { LlmStore.init(c); return LlmStore.usageJson() }

    /** Self-test row: the router resolves and every stored model file is still there with the size we recorded. */
    fun selfTest(c: Context): Pair<Boolean, Long> {
        LlmStore.init(c)
        BrainMode.parse(AppSettings.get(c, "brainMode"))
        var n = 0L
        var ok = true
        for (m in LlmStore.models()) {
            if (m.state != ModelState.READY && m.state != ModelState.STORED) continue
            n++
            val f = m.path?.let { java.io.File(java.io.File(c.filesDir, "models"), it) }
            if (f == null || !f.exists() || f.length() != m.sizeBytes) ok = false
        }
        return ok to n
    }
}
