package com.vastanzil.sandpiper.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.vastanzil.sandpiper.ActivityStore
import com.vastanzil.sandpiper.AppSettings
import com.vastanzil.sandpiper.DCat
import com.vastanzil.sandpiper.DEv
import com.vastanzil.sandpiper.DLvl
import com.vastanzil.sandpiper.DMod
import com.vastanzil.sandpiper.DRes
import com.vastanzil.sandpiper.Diag
import com.vastanzil.sandpiper.Notifier
import com.vastanzil.sandpiper.R
import org.json.JSONObject

/**
 * Pomodoro (25 minutes by default; 15/25/45/50 in Settings). Start, Pause, Resume, Reset all happen on the widget.
 * The countdown is a Chronometer (the system draws it, no wake-ups). An exact alarm fires at the end even if the app is closed:
 * it logs the session (ledger ids focus:<end> and focus.n:<end>, the same the in-app timer uses), queues it for the focus garden,
 * and posts one quiet notification. One timer for the whole phone, however many widgets are placed.
 */
class PomodoroWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)

    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        val now = System.currentTimeMillis()
        when (i.action) {
            ACTION_MAIN -> Widgets.guard {
                val s = state(c)
                val next = when (s.phase) {
                    PomPhase.IDLE -> s.start(now, AppSettings.pomMin(c))
                    PomPhase.RUNNING -> s.pause(now)
                    PomPhase.PAUSED -> s.resume(now)
                }
                save(c, next)
            }
            ACTION_RESET -> Widgets.guard { save(c, PomState.idle()) }
            ACTION_DONE -> Widgets.guard {
                val s = state(c)
                if (s.isDue(now + 1500L)) complete(c, s) else schedule(c, s)     // alarm a hair early: keep running
            }
            else -> { super.onReceive(c0, i); return }
        }
        Widgets.refreshAll(c)
    }

    companion object {
        const val ACTION_MAIN = "com.vastanzil.sandpiper.widget.POM_MAIN"
        const val ACTION_RESET = "com.vastanzil.sandpiper.widget.POM_RESET"
        const val ACTION_DONE = "com.vastanzil.sandpiper.widget.POM_DONE"
        private const val KEY = "pom"
        private const val RC = 7001

        fun state(c: Context): PomState = PomState.decode(Widgets.prefs(c).getString(KEY, null))

        private fun save(c: Context, s: PomState) {
            Widgets.prefs(c).edit().putString(KEY, s.encode()).apply()
            schedule(c, s)
        }

        private fun alarmIntent(c: Context): PendingIntent =
            PendingIntent.getBroadcast(c, RC, Intent(c, PomodoroWidget::class.java).setAction(ACTION_DONE), Widgets.flags())

        /** Exact alarm while running; cancelled otherwise. Falls back to an inexact one if the exact-alarm permission is off. */
        fun schedule(c: Context, s: PomState) {
            val am = c.getSystemService(AlarmManager::class.java) ?: return
            val pi = alarmIntent(c)
            am.cancel(pi)
            if (s.phase != PomPhase.RUNNING) return
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endAtMs, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endAtMs, pi)
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endAtMs, pi)
            }
        }

        /** Idempotent: ids come from the end time, so running this twice writes the same rows. */
        private fun complete(c: Context, s: PomState) {
            for ((id, metric, value) in s.doneEvents(s.endAtMs)) ActivityStore.add(c, id, s.endAtMs, metric, value)
            WidgetStore.enqueue(c, WidgetKinds.FOCUS, "f${s.endAtMs}", JSONObject().put("ts", s.endAtMs).put("min", s.totalMin).toString(), s.endAtMs)
            save(c, PomState.idle())
            Diag.log(DLvl.I, DCat.WIDGET, DEv.POMODORO_DONE, DMod.WIDGETS, DRes.OK, n = s.totalMin.toLong())
            Widgets.wrote(2)
            if (AppSettings.pomNotify(c)) Notifier.show(c, "pomodoro", "reminder", "Focus session complete. ${s.totalMin} minutes logged.")
        }

        fun update(c: Context, m: AppWidgetManager, ids: IntArray) {
            var s = state(c)
            val now = System.currentTimeMillis()
            if (s.isDue(now)) { complete(c, s); s = state(c) }          // the alarm was missed (reboot, battery saver): settle it now
            else if (s.phase == PomPhase.RUNNING) schedule(c, s)       // re-arm after a reboot
            for (id in ids) {
                val v = RemoteViews(c.packageName, R.layout.widget_pomodoro)
                when (s.phase) {
                    PomPhase.RUNNING -> {
                        v.setViewVisibility(R.id.w_chrono, View.VISIBLE); v.setViewVisibility(R.id.w_clock, View.GONE)
                        v.setChronometerCountDown(R.id.w_chrono, true)
                        v.setChronometer(R.id.w_chrono, SystemClock.elapsedRealtime() + s.remaining(now), null, true)
                        v.setTextViewText(R.id.w_status, "Focus"); v.setTextViewText(R.id.w_main, "Pause")
                    }
                    PomPhase.PAUSED -> {
                        v.setViewVisibility(R.id.w_chrono, View.GONE); v.setViewVisibility(R.id.w_clock, View.VISIBLE)
                        v.setTextViewText(R.id.w_clock, PomState.clock(s.remaining(now)))
                        v.setTextViewText(R.id.w_status, "Paused"); v.setTextViewText(R.id.w_main, "Resume")
                    }
                    PomPhase.IDLE -> {
                        v.setViewVisibility(R.id.w_chrono, View.GONE); v.setViewVisibility(R.id.w_clock, View.VISIBLE)
                        v.setTextViewText(R.id.w_clock, PomState.clock(AppSettings.pomMin(c) * 60_000L))
                        v.setTextViewText(R.id.w_status, "Ready"); v.setTextViewText(R.id.w_main, "Start")
                    }
                }
                v.setViewVisibility(R.id.w_reset, if (s.phase == PomPhase.IDLE) View.GONE else View.VISIBLE)
                v.setOnClickPendingIntent(R.id.w_main, Widgets.bcast(c, PomodoroWidget::class.java, ACTION_MAIN, id))
                v.setOnClickPendingIntent(R.id.w_reset, Widgets.bcast(c, PomodoroWidget::class.java, ACTION_RESET, id))
                m.updateAppWidget(id, v)
            }
        }
    }
}
