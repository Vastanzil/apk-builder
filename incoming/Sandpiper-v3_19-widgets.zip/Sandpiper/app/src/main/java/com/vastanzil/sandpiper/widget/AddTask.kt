package com.vastanzil.sandpiper.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import com.vastanzil.sandpiper.PlannerCore
import com.vastanzil.sandpiper.PlannerStore
import com.vastanzil.sandpiper.R

/**
 * Typing a task without opening the app: the widget's "+" posts a silent notification with a text box. What you type is written
 * to PlannerStore by [AddTaskReceiver]; the notification disappears and the widgets refresh. Needs notification permission once.
 */
internal object AddTask {
    const val KEY = "task_text"
    const val ACTION = "com.vastanzil.sandpiper.widget.ADD_TASK_REPLY"
    private const val CH = "sandpiper_widget_input_v1"

    fun prompt(c: Context, period: String) {
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) {
            Toast.makeText(c, "Allow notifications for Sandpiper once, then you can type tasks from the widget.", Toast.LENGTH_LONG).show()
            return
        }
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CH, "Widget quick add", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "A text box that adds a task without opening Sandpiper"
            setSound(null, null); enableVibration(false)          // silent: it only appears because you tapped +
        }
        nm.createNotificationChannel(ch)
        val label = "New " + (TaskListCore.PERIOD_LABEL[period] ?: "daily").lowercase() + " task"
        val ri = RemoteInput.Builder(KEY).setLabel(label).build()
        val reply = Intent(c, AddTaskReceiver::class.java).setAction(ACTION).putExtra("period", period)
        // RemoteInput results are written into the intent, so this PendingIntent must be mutable
        val pi = PendingIntent.getBroadcast(c, period.hashCode(), reply, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        val action = Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat_bird), "Add task", pi).addRemoteInput(ri).build()
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat_bird)
            .setContentTitle(label)
            .setContentText("Type below. Sandpiper stays closed.")
            .addAction(action)
            .setAutoCancel(true)
            .setTimeoutAfter(60_000L)
            .build()
        nm.notify(period.hashCode(), n)
    }
}

class AddTaskReceiver : BroadcastReceiver() {
    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        val period = (i.getStringExtra("period") ?: "daily").let { if (PlannerCore.isPeriod(it)) it else "daily" }
        val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence(AddTask.KEY)?.toString()
        c.getSystemService(NotificationManager::class.java).cancel(period.hashCode())   // also stops the spinner
        if (text.isNullOrBlank()) return
        Widgets.guard {
            if (PlannerStore.add(c, period, text) != null) { Widgets.wrote(0); Widgets.refreshAll(c) }
            else Toast.makeText(c, "Could not add that task.", Toast.LENGTH_SHORT).show()
        }
    }
}
