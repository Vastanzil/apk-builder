package com.vastanzil.sandpiper.llm

import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executor

/*
 * Engine facade. PURE Kotlin: Android pieces (guard readings, database, files) are injected through [EngineEnv] / [UsageSink],
 * so JUnit drives the whole pipeline with a fake provider.
 *
 * Silence rule: a failure never produces UI by itself. The result carries a code; the web layer decides (usually: do nothing).
 * The only time the user is asked anything is NO_PROVIDER with mayAsk=true, and only for an action the user just started.
 */

class CancelToken { @Volatile var canceled = false }

interface LlmProvider {
    val id: ProviderId
    fun availability(): Availability
    /** Blocking, bounded by req.timeoutMs. Must honour [cancel]. */
    fun generate(req: LlmRequest, cancel: CancelToken): LlmResult
    fun release()
    /** Short display name of the active model, or null. Shown in Settings only. */
    fun label(): String? = null
}

/** A local inference runtime (first one planned: LiteRT-LM). This build ships none; see docs/architecture/LITTLE_BRAIN.md. */
interface LlmRuntime {
    fun load(path: String): Boolean
    fun generate(system: String, user: String, maxTokens: Int, timeoutMs: Long, cancel: CancelToken): String?
    fun release()
}

object LlmRuntimes {
    /** Set by the build that bundles a runtime. null = no local runtime in this build. */
    @Volatile var factory: (() -> LlmRuntime)? = null

    /** Format check: can the runtime open the file? Returns null when there is no runtime to ask. */
    fun probe(path: String): Boolean? {
        val f = factory ?: return null
        val rt = try { f() } catch (e: Throwable) { return false }
        return try { rt.load(path) } catch (e: Throwable) { false } finally { try { rt.release() } catch (e: Throwable) { } }
    }
}

/** Seam for Android AICore / ML Kit GenAI. Left unset until the Phase 0 spike has verified the Gradle coordinates on a real phone. */
interface SystemAiBackend {
    fun availability(): Availability
    fun generate(req: LlmRequest, cancel: CancelToken): LlmResult
}

object SystemAi { @Volatile var backend: SystemAiBackend? = null }

class NullProvider : LlmProvider {
    override val id = ProviderId.NONE
    override fun availability() = Availability.UNSUPPORTED
    override fun generate(req: LlmRequest, cancel: CancelToken): LlmResult = LlmResult.Failure(LlmError.NO_PROVIDER)
    override fun release() {}
}

class SystemAiProvider : LlmProvider {
    override val id = ProviderId.AICORE
    override fun availability(): Availability = try { SystemAi.backend?.availability() ?: Availability.UNSUPPORTED } catch (e: Throwable) { Availability.ERROR }
    override fun generate(req: LlmRequest, cancel: CancelToken): LlmResult =
        try { SystemAi.backend?.generate(req, cancel) ?: LlmResult.Failure(LlmError.NO_PROVIDER) } catch (e: Throwable) { LlmResult.Failure(LlmError.ENGINE) }
    override fun release() {}
}

enum class BrainEvent { PROVIDER_CHOSEN, CALL_OK, CALL_FAILED, GUARD_BLOCKED }

interface UsageSink {
    fun callsToday(day: String): Int
    fun add(day: String, provider: ProviderId, task: LlmTask, calls: Int, ms: Long, blocked: Int, failed: Int)
}

interface EngineEnv {
    fun nowMs(): Long
    fun day(nowMs: Long): String
    fun mode(): BrainMode
    fun taskEnabled(t: LlmTask): Boolean
    /** The user's "ask me to provide a model when needed" switch. */
    fun mayAsk(): Boolean
    fun budget(): Int
    fun snapshot(): GuardSnapshot
    /** Diagnostics hook: enum + number only (never text). */
    fun event(ev: BrainEvent, task: LlmTask?, n: Long)
}

class LlmEngine(
    private val providers: Map<ProviderId, LlmProvider>,
    private val env: EngineEnv,
    private val usage: UsageSink,
    private val exec: Executor,
    private val cacheMax: Int = 64
) {
    private val cache = object : LinkedHashMap<String, String>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > cacheMax
    }
    private val tokens = ConcurrentHashMap<String, CancelToken>()
    @Volatile private var lastCallMs = 0L
    @Volatile private var backoffMs = 0L
    @Volatile private var backoffUntilMs = 0L

    private fun avail(p: ProviderId): Availability = try { providers[p]?.availability() ?: Availability.UNSUPPORTED } catch (e: Throwable) { Availability.ERROR }

    /** Non-blocking. [cb] receives (requestId, resultJson) on the engine thread. */
    fun run(taskKey: String, inputJson: String, requestId: String, cb: (String, String) -> Unit) {
        val token = CancelToken()
        tokens[requestId] = token
        exec.execute {
            val out = try { runNow(taskKey, inputJson, requestId, token) } catch (e: Throwable) { fail(LlmError.ENGINE) }
            tokens.remove(requestId)
            try { cb(requestId, out) } catch (e: Throwable) { /* the page may be gone */ }
        }
    }

    fun cancel(requestId: String): Boolean { val t = tokens[requestId] ?: return false; t.canceled = true; return true }
    fun cancelAll() { for (t in tokens.values) t.canceled = true }
    fun releaseAll() { for (p in providers.values) try { p.release() } catch (e: Throwable) { } }

    internal fun runNow(taskKey: String, inputJson: String, requestId: String, token: CancelToken): String {
        val task = LlmTask.fromKey(taskKey) ?: return fail(LlmError.BAD_TASK)
        val spec = LlmTasks.spec(task) ?: return fail(LlmError.DISABLED)
        val mode = env.mode()
        if (mode == BrainMode.OFF || !env.taskEnabled(task)) return fail(LlmError.DISABLED)
        val input = try { JSONObject(inputJson) } catch (e: Exception) { return fail(LlmError.BAD_INPUT) }
        val user = spec.user(input) ?: return fail(LlmError.BAD_INPUT, spec = spec, input = input)

        val key = Hashing.cacheKey(task, inputJson)
        synchronized(cache) { cache[key] }?.let { return okJson(task, ProviderId.NONE, 0L, JSONObject(it), true) }

        val sys = avail(ProviderId.AICORE)
        val loc = avail(ProviderId.LOCAL)
        val pid = RouterCore.choose(mode, sys, loc)
        if (pid == ProviderId.NONE) {
            env.event(BrainEvent.CALL_FAILED, task, LlmError.NO_PROVIDER.ordinal.toLong())
            return fail(LlmError.NO_PROVIDER, mayAsk = env.mayAsk() && RouterCore.userCanFix(mode, loc), spec = spec, input = input)
        }
        env.event(BrainEvent.PROVIDER_CHOSEN, task, pid.ordinal.toLong())

        val now = env.nowMs()
        val day = env.day(now)
        val reason = GuardCore.decide(GuardInput(env.snapshot(), usage.callsToday(day), env.budget(), now, lastCallMs, backoffUntilMs))
        if (reason != null) {
            usage.add(day, pid, task, 0, 0L, 1, 0)
            env.event(BrainEvent.GUARD_BLOCKED, task, reason.ordinal.toLong())
            return fail(LlmError.GUARD_BLOCKED, reason = reason, spec = spec, input = input)
        }
        if (token.canceled) return fail(LlmError.CANCELED)

        val provider = providers[pid] ?: return fail(LlmError.NO_PROVIDER, spec = spec, input = input)
        val req = LlmRequest(requestId, task, spec.system, user, task.maxTokens, 20_000L)
        val t0 = System.nanoTime()
        val res = try { provider.generate(req, token) } catch (e: Throwable) { LlmResult.Failure(LlmError.ENGINE) }
        val ms = (System.nanoTime() - t0) / 1_000_000L
        lastCallMs = env.nowMs()

        if (res is LlmResult.Failure) {
            if (res.code == LlmError.BUSY || res.code == LlmError.QUOTA) {
                backoffMs = GuardCore.nextBackoff(backoffMs)
                backoffUntilMs = lastCallMs + backoffMs
            }
            usage.add(day, pid, task, 1, ms, 0, 1)
            env.event(BrainEvent.CALL_FAILED, task, res.code.ordinal.toLong())
            return fail(res.code, spec = spec, input = input)
        }
        backoffMs = 0L
        if (token.canceled) return fail(LlmError.CANCELED)

        val text = (res as LlmResult.Text).text
        val suggestion = JsonOut.parse(text)?.let { spec.validate(input, it) }
        if (suggestion == null) {
            usage.add(day, pid, task, 1, ms, 0, 1)
            env.event(BrainEvent.CALL_FAILED, task, LlmError.INVALID_OUTPUT.ordinal.toLong())
            return fail(LlmError.INVALID_OUTPUT, spec = spec, input = input)
        }
        synchronized(cache) { cache[key] = suggestion.toString() }
        usage.add(day, pid, task, 1, ms, 0, 0)
        env.event(BrainEvent.CALL_OK, task, ms)
        return okJson(task, pid, ms, suggestion, false)
    }

    private fun okJson(task: LlmTask, pid: ProviderId, ms: Long, s: JSONObject, cached: Boolean): String =
        JSONObject().put("ok", true).put("task", task.key).put("provider", pid.name).put("ms", ms).put("cached", cached).put("suggestion", s).toString()

    private fun fail(
        e: LlmError, reason: GuardReason? = null, mayAsk: Boolean = false, spec: TaskSpec? = null, input: JSONObject? = null
    ): String {
        val o = JSONObject().put("ok", false).put("error", e.name)
        if (reason != null) o.put("reason", reason.name)
        if (e == LlmError.NO_PROVIDER) o.put("mayAsk", mayAsk)
        if (spec != null && input != null) spec.fallback(input)?.let { o.put("fallback", it) }
        return o.toString()
    }

    /** Settings status card. Cheap: no model is loaded. */
    fun statusJson(callsToday: Int): String {
        val mode = env.mode()
        val sys = avail(ProviderId.AICORE)
        val loc = avail(ProviderId.LOCAL)
        val pid = RouterCore.choose(mode, sys, loc)
        val g = GuardCore.decide(GuardInput(env.snapshot(), callsToday, env.budget(), env.nowMs(), lastCallMs, backoffUntilMs))
        return JSONObject()
            .put("mode", mode.name.lowercase()).put("provider", pid.name)
            .put("system", sys.name).put("local", loc.name)
            .put("model", providers[ProviderId.LOCAL]?.label() ?: JSONObject.NULL)
            .put("usageToday", callsToday).put("budget", env.budget())
            .put("mayAsk", env.mayAsk() && RouterCore.userCanFix(mode, loc))
            .put("guard", JSONObject().put("ok", g == null).put("reason", g?.name ?: JSONObject.NULL))
            .toString()
    }
}
