package com.vastanzil.sandpiper.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import com.vastanzil.sandpiper.PlannerCore
import com.vastanzil.sandpiper.PlannerStore
import com.vastanzil.sandpiper.R

/**
 * Planner widget (Daily / Weekly / Monthly, tap the title to switch) and To-do widget (Daily only). Both read and write PlannerStore,
 * the same native tables the app uses, so a tick on the widget is a tick in the app. No Activity is ever started.
 * Adding a task: a quiet notification with a text box (RemoteInput) writes straight to PlannerStore; the app stays closed.
 */
internal object TaskWidgets {
    const val ACTION_TOGGLE = "com.vastanzil.sandpiper.widget.TOGGLE"
    const val ACTION_PERIOD = "com.vastanzil.sandpiper.widget.PERIOD"
    const val ACTION_ADD = "com.vastanzil.sandpiper.widget.ADD"

    fun period(c: Context, id: Int, fixed: String?): String {
        if (fixed != null) return fixed
        val p = Widgets.prefs(c).getString("t_${id}_p", "daily") ?: "daily"
        return if (PlannerCore.isPeriod(p)) p else "daily"
    }

    fun update(c: Context, m: AppWidgetManager, ids: IntArray, cls: Class<*>, fixed: String?) {
        for (id in ids) {
            val p = period(c, id, fixed)
            val tasks = PlannerStore.listTasks(c, p)
            val done = tasks.count { it.done }
            val v = RemoteViews(c.packageName, R.layout.widget_tasks)
            v.setTextViewText(R.id.w_title, (TaskListCore.PERIOD_LABEL[p] ?: "Planner") + if (fixed == null) " \u25BE" else " to-do")
            v.setTextViewText(R.id.w_progress, TaskListCore.progress(done, tasks.size))
            v.setProgressBar(R.id.w_bar, 100, TaskListCore.percent(done, tasks.size), false)
            v.setViewVisibility(R.id.w_empty, if (tasks.isEmpty()) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.w_list, if (tasks.isEmpty()) View.GONE else View.VISIBLE)
            if (fixed == null) v.setOnClickPendingIntent(R.id.w_title, Widgets.bcast(c, cls, ACTION_PERIOD, id))
            v.setOnClickPendingIntent(R.id.w_add, Widgets.bcast(c, cls, ACTION_ADD, id))
            val svc = Intent(c, TaskListService::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra("fixed", fixed ?: "")
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            v.setRemoteAdapter(R.id.w_list, svc)
            // fill-in intents (taskId, done) are merged into this template: it must be mutable
            val tpl = Intent(c, cls).setAction(ACTION_TOGGLE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            v.setPendingIntentTemplate(R.id.w_list, PendingIntent.getBroadcast(c, id, tpl, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE))
            m.updateAppWidget(id, v)
            m.notifyAppWidgetViewDataChanged(id, R.id.w_list)
        }
    }

    /** True when the intent was ours. */
    fun handle(c: Context, i: Intent, fixed: String?): Boolean {
        val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        when (i.action) {
            ACTION_TOGGLE -> {
                val taskId = i.getStringExtra("taskId") ?: return true
                Widgets.guard { PlannerStore.setDone(c, taskId, i.getBooleanExtra("done", false)); Widgets.wrote(0) }
                Widgets.refreshAll(c)
            }
            ACTION_PERIOD -> {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) Widgets.prefs(c).edit().putString("t_${id}_p", TaskListCore.nextPeriod(period(c, id, null))).apply()
                Widgets.refreshAll(c)
            }
            ACTION_ADD -> AddTask.prompt(c, period(c, id, fixed))
            else -> return false
        }
        return true
    }

    fun forget(c: Context, ids: IntArray) {
        val e = Widgets.prefs(c).edit()
        for (id in ids) e.remove("t_${id}_p")
        e.apply()
    }
}

class PlannerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)
    override fun onReceive(c: Context, i: Intent) { if (!TaskWidgets.handle(c.applicationContext, i, null)) super.onReceive(c, i) }
    override fun onDeleted(c: Context, ids: IntArray) = TaskWidgets.forget(c, ids)
    companion object { fun update(c: Context, m: AppWidgetManager, ids: IntArray) = TaskWidgets.update(c, m, ids, PlannerWidget::class.java, null) }
}

class TodoWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)
    override fun onReceive(c: Context, i: Intent) { if (!TaskWidgets.handle(c.applicationContext, i, "daily")) super.onReceive(c, i) }
    companion object { fun update(c: Context, m: AppWidgetManager, ids: IntArray) = TaskWidgets.update(c, m, ids, TodoWidget::class.java, "daily") }
}
