package com.vastanzil.sandpiper.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import android.widget.RemoteViewsService.RemoteViewsFactory
import com.vastanzil.sandpiper.PTask
import com.vastanzil.sandpiper.PlannerStore
import com.vastanzil.sandpiper.R

/** Feeds the task list of the Planner and To-do widgets. Reads PlannerStore each time the widget asks for fresh data. */
class TaskListService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        Factory(applicationContext, intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0), intent.getStringExtra("fixed")?.ifEmpty { null })

    private class Factory(private val c: Context, private val id: Int, private val fixed: String?) : RemoteViewsFactory {
        private var rows: List<PTask> = emptyList()

        override fun onCreate() {}
        override fun onDataSetChanged() {
            rows = try { PlannerStore.listTasks(c, TaskWidgets.period(c, id, fixed)).sortedBy { it.done }.take(40) } catch (e: Exception) { emptyList() }
        }
        override fun onDestroy() { rows = emptyList() }
        override fun getCount(): Int = rows.size
        override fun getViewAt(position: Int): RemoteViews {
            val t = rows.getOrNull(position) ?: return RemoteViews(c.packageName, R.layout.widget_task_item)
            val v = RemoteViews(c.packageName, R.layout.widget_task_item)
            v.setTextViewText(R.id.w_check, if (t.done) "\u2611" else "\u2610")
            v.setTextViewText(R.id.w_text, t.text)
            v.setTextColor(R.id.w_text, if (t.done) 0xFF708F7D.toInt() else 0xFFE9EEE8.toInt())
            v.setTextColor(R.id.w_check, if (t.done) 0xFFB9D9C4.toInt() else 0xFF5B9BFF.toInt())
            v.setOnClickFillInIntent(R.id.w_row, Intent().putExtra("taskId", t.id).putExtra("done", !t.done))
            return v
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 1
        override fun getItemId(position: Int): Long = rows.getOrNull(position)?.id?.hashCode()?.toLong() ?: position.toLong()
        override fun hasStableIds(): Boolean = true
    }
}
