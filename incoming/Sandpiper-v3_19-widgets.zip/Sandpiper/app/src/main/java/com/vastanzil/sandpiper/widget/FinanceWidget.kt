package com.vastanzil.sandpiper.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.vastanzil.sandpiper.ActivityStore
import com.vastanzil.sandpiper.R
import com.vastanzil.sandpiper.SettingsStore

/**
 * Add a transaction without opening the app: amount keypad, Expense/Income switch, category switch, Save.
 * Save writes (1) the inbox row the Finance list imports on next open and (2) the activity-ledger event at once, with the SAME
 * ids the web layer uses (tx:<id>), so the graphs move immediately and nothing is ever counted twice.
 */
class FinanceWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)
    override fun onDeleted(c: Context, ids: IntArray) {
        val e = Widgets.prefs(c).edit()
        for (id in ids) for (k in listOf("amt", "kind", "cat", "msg")) e.remove("f_${id}_$k")
        e.apply()
    }

    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID || i.action !in setOf(ACTION_KEY, ACTION_SAVE, ACTION_KIND, ACTION_CAT)) { super.onReceive(c0, i); return }
        val p = Widgets.prefs(c)
        Widgets.guard {
            when (i.action) {
                ACTION_KEY -> {
                    val k = (i.getStringExtra("tag") ?: "").firstOrNull() ?: return@guard
                    p.edit().putString("f_${id}_amt", Keypad.press(p.getString("f_${id}_amt", "") ?: "", k)).remove("f_${id}_msg").apply()
                }
                ACTION_KIND -> p.edit().putString("f_${id}_kind", if (p.getString("f_${id}_kind", "expense") == "income") "expense" else "income").remove("f_${id}_msg").apply()
                ACTION_CAT -> p.edit().putInt("f_${id}_cat", FinanceCore.nextIndex(p.getInt("f_${id}_cat", 0), categories(c).size)).remove("f_${id}_msg").apply()
                ACTION_SAVE -> save(c, id)
            }
        }
        val m = AppWidgetManager.getInstance(c)
        update(c, m, intArrayOf(id))
    }

    private fun save(c: Context, id: Int) {
        val p = Widgets.prefs(c)
        val amount = Keypad.value(p.getString("f_${id}_amt", "") ?: "")
        if (amount == null) { p.edit().putString("f_${id}_msg", "Enter an amount").apply(); return }
        val cats = categories(c)
        val cat = cats[p.getInt("f_${id}_cat", 0).coerceIn(0, cats.size - 1)]
        val kind = if (p.getString("f_${id}_kind", "expense") == "income") "income" else "expense"
        val now = System.currentTimeMillis()
        val txId = FinanceCore.newTxId(now)
        // 1) the durable record first. If this fails nothing else is written and the user sees it.
        val stored = WidgetStore.enqueue(c, WidgetKinds.TX, txId, FinanceCore.txJson(txId, cat, cat, amount, kind, now).toString(), now)
        if (!stored) { p.edit().putString("f_${id}_msg", "Could not save").apply(); return }
        // 2) the ledger event (graphs and day summary), same id the web layer will use for this transaction
        ActivityStore.add(c, FinanceCore.ledgerId(txId), now, FinanceCore.ledgerMetric(kind), amount)
        p.edit().putString("f_${id}_amt", "").putString("f_${id}_msg", "Saved \u2713 " + currency(c) + " " + Keypad.display(amount.toString().removeSuffix(".0"), "").trim()).apply()
        Widgets.wrote(1)
        Widgets.refreshAll(c)
    }

    companion object {
        const val ACTION_KEY = "com.vastanzil.sandpiper.widget.FIN_KEY"
        const val ACTION_SAVE = "com.vastanzil.sandpiper.widget.FIN_SAVE"
        const val ACTION_KIND = "com.vastanzil.sandpiper.widget.FIN_KIND"
        const val ACTION_CAT = "com.vastanzil.sandpiper.widget.FIN_CAT"

        private val KEYS = listOf(
            R.id.k0 to "0", R.id.k1 to "1", R.id.k2 to "2", R.id.k3 to "3", R.id.k4 to "4", R.id.k5 to "5", R.id.k6 to "6",
            R.id.k7 to "7", R.id.k8 to "8", R.id.k9 to "9", R.id.kdot to ".", R.id.kback to "B", R.id.kclr to "C"
        )

        fun currency(c: Context): String = (SettingsStore.get(c, "finance", "finance.currency") ?: "BDT").ifBlank { "BDT" }.take(5)
        fun categories(c: Context): List<String> = FinanceCore.parseCats(SettingsStore.get(c, "finance", "finance.categories"))

        fun update(c: Context, m: AppWidgetManager, ids: IntArray) {
            for (id in ids) {
                val p = Widgets.prefs(c)
                val cats = categories(c)
                val kind = if (p.getString("f_${id}_kind", "expense") == "income") "income" else "expense"
                val cat = cats[p.getInt("f_${id}_cat", 0).coerceIn(0, cats.size - 1)]
                val amt = p.getString("f_${id}_amt", "") ?: ""
                val msg = p.getString("f_${id}_msg", null)
                val v = RemoteViews(c.packageName, R.layout.widget_finance)
                v.setTextViewText(R.id.w_display, msg ?: Keypad.display(amt, currency(c)))
                v.setTextColor(R.id.w_display, if (msg != null && msg.startsWith("Saved")) 0xFFB9D9C4.toInt() else 0xFFE9EEE8.toInt())
                v.setTextViewText(R.id.w_kind, if (kind == "income") "Income \u25BE" else "Expense \u25BE")
                v.setTextColor(R.id.w_kind, if (kind == "income") 0xFFB9D9C4.toInt() else 0xFFFFB4A8.toInt())
                v.setTextViewText(R.id.w_cat, "$cat \u25BE")
                v.setOnClickPendingIntent(R.id.w_kind, Widgets.bcast(c, FinanceWidget::class.java, ACTION_KIND, id))
                v.setOnClickPendingIntent(R.id.w_cat, Widgets.bcast(c, FinanceWidget::class.java, ACTION_CAT, id))
                v.setOnClickPendingIntent(R.id.w_save, Widgets.bcast(c, FinanceWidget::class.java, ACTION_SAVE, id))
                for ((vid, tag) in KEYS) v.setOnClickPendingIntent(vid, Widgets.bcast(c, FinanceWidget::class.java, ACTION_KEY, id, tag))
                m.updateAppWidget(id, v)
            }
        }
    }
}
