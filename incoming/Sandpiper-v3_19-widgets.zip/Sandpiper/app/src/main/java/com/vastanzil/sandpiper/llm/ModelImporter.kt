package com.vastanzil.sandpiper.llm

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.vastanzil.sandpiper.DCat
import com.vastanzil.sandpiper.DEv
import com.vastanzil.sandpiper.DLvl
import com.vastanzil.sandpiper.DMod
import com.vastanzil.sandpiper.DRes
import com.vastanzil.sandpiper.Diag
import java.io.File
import java.security.MessageDigest

/**
 * Source D (the only source in this build): the user picks a model file that is already on the phone; it is copied into
 * filesDir/models/<id>/. No network. States: COPYING -> VERIFYING -> PROBING -> READY, or STORED when this build has no runtime to probe with.
 * Returns a code for the page: OK_READY, OK_STORED, ALREADY, TOO_BIG, NO_SPACE, HASH_MISMATCH, NOT_A_MODEL, IO.
 */
internal object ModelImporter {
    fun import(c: Context, uri: Uri, userSha: String?, onProgress: (Int) -> Unit): String {
        val models = File(c.filesDir, "models")
        val tmpDir = File(models, "tmp-" + System.currentTimeMillis())
        try {
            var name = "model"
            var size = -1L
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) {
                    it.getString(0)?.let { n -> name = n.take(80) }
                    if (!it.isNull(1)) size = it.getLong(1)
                }
            }
            if (size > ModelFileRules.MAX_BYTES) return "TOO_BIG"
            if (size > 0 && c.filesDir.usableSpace < ModelFileRules.freeSpaceNeeded(size)) return "NO_SPACE"
            tmpDir.mkdirs()
            val part = File(tmpDir, "model.part")
            val md = MessageDigest.getInstance("SHA-256")
            var total = 0L
            var lastPct = -1
            c.contentResolver.openInputStream(uri)?.use { input ->
                part.outputStream().use { out ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                        total += n
                        if (total > ModelFileRules.MAX_BYTES) { tmpDir.deleteRecursively(); return "TOO_BIG" }
                        if (size > 0) {
                            val pct = (total * 100 / size).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                        }
                    }
                }
            } ?: return "IO"
            if (total == 0L) { tmpDir.deleteRecursively(); return "NOT_A_MODEL" }

            val sha = md.digest().joinToString("") { "%02x".format(it) }
            val wanted = userSha?.trim()?.lowercase()
            if (!wanted.isNullOrEmpty() && (!ModelFileRules.isHex64(wanted) || wanted != sha)) { tmpDir.deleteRecursively(); return "HASH_MISMATCH" }

            val id = ModelFileRules.idFor(sha)
            val existing = LlmStore.find(id)
            if (existing != null && existing.path != null && File(models, existing.path).exists()) { tmpDir.deleteRecursively(); return "ALREADY" }

            val rel = id + "/model." + ModelFileRules.safeExt(name)
            val dest = File(models, rel)
            dest.parentFile?.mkdirs()
            if (!part.renameTo(dest)) { tmpDir.deleteRecursively(); return "IO" }
            tmpDir.deleteRecursively()

            LlmStore.put(ModelRow(id, "import", name, total, sha, !wanted.isNullOrEmpty(), ModelState.PROBING, rel, System.currentTimeMillis(), 0L))
            val probe = LlmRuntimes.probe(dest.path)
            return when (probe) {
                null -> { LlmStore.setState(id, ModelState.STORED); log(DEv.BRAIN_MODEL_STORED, DRes.OK, total); "OK_STORED" }
                true -> { LlmStore.setState(id, ModelState.READY); log(DEv.BRAIN_MODEL_STORED, DRes.OK, total); "OK_READY" }
                false -> { remove(c, id); log(DEv.BRAIN_MODEL_FAILED, DRes.FAIL, total); "NOT_A_MODEL" }
            }
        } catch (e: Exception) {
            try { tmpDir.deleteRecursively() } catch (x: Exception) { }
            log(DEv.BRAIN_MODEL_FAILED, DRes.FAIL, 0L)
            return "IO"
        }
    }

    fun remove(c: Context, id: String): Boolean {
        val m = LlmStore.find(id)
        if (m?.path != null) File(File(c.filesDir, "models"), m.path).parentFile?.deleteRecursively()
        File(File(c.filesDir, "models"), id).deleteRecursively()
        LlmStore.delete(id)
        return true
    }

    private fun log(ev: DEv, res: DRes, n: Long) = Diag.log(DLvl.I, DCat.BRAIN, ev, DMod.BRAIN, res, n = n / 1024)
}
