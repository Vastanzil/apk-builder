package com.vastanzil.sandpiper.llm

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager

/** Set by MainActivity.onResume / onPause. The brain runs only while the app is on screen. */
internal object LlmForeground { @Volatile var resumed = false }

/** Reads the phone's state. The decision itself lives in GuardCore (pure, unit tested). */
internal object LlmGuard {
    fun snapshot(c: Context): GuardSnapshot {
        val pm = c.getSystemService(PowerManager::class.java)
        val bm = c.getSystemService(BatteryManager::class.java)
        val thermal = try { pm?.currentThermalStatus ?: 0 } catch (e: Exception) { 0 }
        val saver = try { pm?.isPowerSaveMode ?: false } catch (e: Exception) { false }
        val pctRaw = try { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100 } catch (e: Exception) { 100 }
        val pct = if (pctRaw in 0..100) pctRaw else 100
        val charging = try { bm?.isCharging ?: false } catch (e: Exception) { false }
        return GuardSnapshot(LlmForeground.resumed, thermal, saver, pct, charging)
    }
}
