package com.vastanzil.sandpiper.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.widget.Toast
import androidx.core.app.ServiceCompat
import com.vastanzil.sandpiper.ActivityStore
import com.vastanzil.sandpiper.AppSettings
import com.vastanzil.sandpiper.DCat
import com.vastanzil.sandpiper.DEv
import com.vastanzil.sandpiper.DLvl
import com.vastanzil.sandpiper.DMod
import com.vastanzil.sandpiper.DRes
import com.vastanzil.sandpiper.Diag
import com.vastanzil.sandpiper.R
import java.io.File

/** Microphone foreground service behind the Voice widget. AAC in an .m4a (what the Notes recordings list already plays). */
class VoiceRecordService : Service() {
    companion object {
        const val ACTION_START = "com.vastanzil.sandpiper.widget.VOICE_START"
        const val ACTION_STOP = "com.vastanzil.sandpiper.widget.VOICE_STOP"
        private const val CH = "sandpiper_voice_v1"
        private const val NID = 4107
        @Volatile var running = false
    }

    private var rec: MediaRecorder? = null
    private var id = ""
    private var file: File? = null
    private var startWall = 0L
    private var startElapsed = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_START -> start()
            ACTION_STOP -> stopAndSave()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Voice note recording", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shown while the Voice widget is recording"; setSound(null, null); enableVibration(false)
        })
        val stop = PendingIntent.getService(this, 1, Intent(this, VoiceRecordService::class.java).setAction(ACTION_STOP), Widgets.flags())
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_bird)
            .setContentTitle("Recording voice note")
            .setUsesChronometer(true).setWhen(System.currentTimeMillis())
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_bird), "Stop and save", stop).build())
            .build()
    }

    private fun start() {
        if (running) return
        val now = System.currentTimeMillis()
        id = VoiceCore.newId(now)
        val dir = File(filesDir, "voice").apply { mkdirs() }
        val f = File(dir, VoiceCore.fileName(id))
        file = f
        try {
            ServiceCompat.startForeground(this, NID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { fail("Could not start recording."); return }
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(VoiceCore.SAMPLE_RATE)
            r.setAudioEncodingBitRate(VoiceCore.BITRATE)
            r.setMaxDuration(AppSettings.voiceMaxMin(this) * 60_000)
            r.setOnInfoListener { _, what, _ -> if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) stopAndSave() }
            r.setOutputFile(f.path)
            r.prepare(); r.start()
            rec = r
        } catch (e: Exception) { try { rec?.release() } catch (x: Exception) { }; rec = null; f.delete(); fail("Could not start recording."); return }
        startWall = now
        startElapsed = SystemClock.elapsedRealtime()
        running = true
        Widgets.prefs(this).edit().putLong(VoiceWidget.REC_START, startElapsed).apply()
        Widgets.refreshAll(this)
    }

    private fun fail(msg: String) {
        running = false
        Widgets.prefs(this).edit().putLong(VoiceWidget.REC_START, 0L).putString(VoiceWidget.MSG, msg).apply()
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        Widgets.refreshAll(this)
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    @Synchronized
    private fun stopAndSave() {
        val r = rec ?: run { running = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        rec = null
        var ok = false
        try { r.stop(); ok = true } catch (e: RuntimeException) { /* stopped too soon: nothing was recorded */ }
        try { r.release() } catch (e: Exception) { }
        running = false
        val f = file
        val dur = SystemClock.elapsedRealtime() - startElapsed
        val bytes = f?.length() ?: 0L
        val p = Widgets.prefs(this).edit().putLong(VoiceWidget.REC_START, 0L)
        if (ok && f != null && VoiceCore.worthKeeping(dur, bytes)) {
            // durable record first, then the ledger event (same id the Notes list uses: voice:<id>)
            if (WidgetStore.enqueue(this, WidgetKinds.VOICE, id, VoiceCore.inboxJson(id, startWall, dur, bytes).toString(), startWall)) {
                ActivityStore.add(this, "voice:$id", startWall, "voice.count", 1.0)
                Diag.log(DLvl.I, DCat.WIDGET, DEv.VOICE_SAVED, DMod.WIDGETS, DRes.OK, n = dur / 1000)
                Widgets.wrote(3)
                p.putString(VoiceWidget.MSG, "Saved \u2713")
            } else { f.delete(); p.putString(VoiceWidget.MSG, "Could not save") }
        } else { f?.delete(); p.putString(VoiceWidget.MSG, "Too short, not saved") }
        p.apply()
        Widgets.refreshAll(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (rec != null) stopAndSave()      // the system is stopping us: keep what was recorded
        running = false
        super.onDestroy()
    }
}
