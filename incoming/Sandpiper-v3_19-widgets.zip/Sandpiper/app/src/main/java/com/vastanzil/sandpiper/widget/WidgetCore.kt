package com.vastanzil.sandpiper.widget

import org.json.JSONObject
import java.util.Locale
import java.util.Random

/*
 * Pure logic behind the home-screen widgets (no Android imports, so JUnit covers it).
 *
 * THE RULE OF THE WIDGETS: a tap never opens the app. Each widget writes its record straight into Sandpiper's own storage:
 *   - Planner / To-do      -> PlannerStore (native SQLite)                     visible in the app immediately
 *   - Activity graph       -> reads the ActivityStore rollups                   (read only)
 *   - Pomodoro             -> ActivityStore events focus:<ts> / focus.n:<ts>    + inbox row "focus" for the focus garden
 *   - Finance add          -> ActivityStore event tx:<id> + inbox row "tx"      the web Finance list imports the row on next open
 *   - Voice note           -> file in filesDir/voice + ActivityStore voice:<id> + inbox row "voice"
 * "Inbox" = table widget_inbox. Rows are idempotent (same id as the web would create) and deleted only after the web layer acks.
 */

object WidgetKinds {
    const val TX = "tx"
    const val FOCUS = "focus"
    const val VOICE = "voice"
    const val PLAN = "plan"      // a daily task ticked/unticked on a widget: the app files it in the day history
}

/** The amount keypad of the Finance widget. Keys: 0-9, '.', 'B' (backspace), 'C' (clear). */
object Keypad {
    const val MAX_LEN = 9

    fun press(cur: String, key: Char): String = when {
        key == 'C' -> ""
        key == 'B' -> cur.dropLast(1)
        key == '.' -> if (cur.contains('.') || cur.length >= MAX_LEN - 1) cur else (if (cur.isEmpty()) "0." else "$cur.")
        key in '0'..'9' -> when {
            cur.length >= MAX_LEN -> cur
            cur.contains('.') && cur.substringAfter('.').length >= 2 -> cur       // two decimals at most
            cur == "0" -> key.toString()                                          // no leading zeros
            else -> cur + key
        }
        else -> cur
    }

    /** The amount as a number, or null when empty / not above zero. */
    fun value(cur: String): Double? {
        val t = cur.trimEnd('.')
        if (t.isEmpty()) return null
        val v = t.toDoubleOrNull() ?: return null
        return if (v > 0.0) Math.round(v * 100.0) / 100.0 else null
    }

    fun display(cur: String, currency: String): String = currency + " " + (if (cur.isEmpty()) "0" else cur)
}

/** Records the Finance widget creates. The web layer's own shape is {id,name,cat,amount,kind,ts}. */
object FinanceCore {
    val DEFAULT_CATS = listOf("Food", "Transport", "Bills", "Shopping", "Health", "Other")
    const val MAX_CATS = 12

    /** Categories from the app's Settings text (comma or newline separated), else the defaults. */
    fun parseCats(text: String?): List<String> {
        val out = (text ?: "").split(',', '\n').map { it.trim().take(24) }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }.take(MAX_CATS)
        return if (out.isEmpty()) DEFAULT_CATS else out
    }

    fun nextIndex(i: Int, size: Int): Int = if (size <= 0) 0 else (i + 1) % size

    fun newTxId(now: Long, rnd: Random = Random()): String = "w" + now.toString(36) + Integer.toString(rnd.nextInt(46_656), 36).padStart(3, '0')

    fun txJson(id: String, name: String, cat: String, amount: Double, kind: String, ts: Long): JSONObject =
        JSONObject().put("id", id).put("name", name.take(60)).put("cat", cat).put("amount", amount)
            .put("kind", if (kind == "income") "income" else "expense").put("ts", ts)

    /** Activity-ledger event id the web layer also uses for this transaction (so nothing is counted twice). */
    fun ledgerId(txId: String) = "tx:$txId"
    fun ledgerMetric(kind: String) = if (kind == "income") "income" else "spend"
}

enum class PomPhase { IDLE, RUNNING, PAUSED }

/** Pomodoro state machine. Stored as one string in SharedPreferences: "IDLE", "RUNNING:<endAtMs>:<totalMin>", "PAUSED:<remainingMs>:<totalMin>". */
data class PomState(val phase: PomPhase, val endAtMs: Long = 0L, val remainingMs: Long = 0L, val totalMin: Int = DEFAULT_MIN) {
    companion object {
        const val DEFAULT_MIN = 25
        val CHOICES = listOf(15, 25, 45, 50)
        fun idle() = PomState(PomPhase.IDLE)

        fun clock(ms: Long): String {
            val s = (ms + 999) / 1000
            return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
        }

        fun decode(s: String?): PomState {
            val p = (s ?: "").split(':')
            val total = p.getOrNull(2)?.toIntOrNull()?.takeIf { it in CHOICES } ?: DEFAULT_MIN
            return when (p.getOrNull(0)) {
                "RUNNING" -> p.getOrNull(1)?.toLongOrNull()?.let { PomState(PomPhase.RUNNING, endAtMs = it, totalMin = total) } ?: idle()
                "PAUSED" -> p.getOrNull(1)?.toLongOrNull()?.takeIf { it > 0 }?.let { PomState(PomPhase.PAUSED, remainingMs = it, totalMin = total) } ?: idle()
                else -> idle()
            }
        }
    }

    fun encode(): String = when (phase) {
        PomPhase.IDLE -> "IDLE"
        PomPhase.RUNNING -> "RUNNING:$endAtMs:$totalMin"
        PomPhase.PAUSED -> "PAUSED:$remainingMs:$totalMin"
    }

    fun remaining(now: Long): Long = when (phase) {
        PomPhase.IDLE -> totalMin * 60_000L
        PomPhase.RUNNING -> maxOf(0L, endAtMs - now)
        PomPhase.PAUSED -> remainingMs
    }

    fun start(now: Long, min: Int): PomState = PomState(PomPhase.RUNNING, endAtMs = now + min * 60_000L, totalMin = min)
    fun pause(now: Long): PomState = if (phase == PomPhase.RUNNING) PomState(PomPhase.PAUSED, remainingMs = remaining(now).coerceAtLeast(1000L), totalMin = totalMin) else this
    fun resume(now: Long): PomState = if (phase == PomPhase.PAUSED) PomState(PomPhase.RUNNING, endAtMs = now + remainingMs, totalMin = totalMin) else this
    fun reset(): PomState = idle()
    fun isDue(now: Long): Boolean = phase == PomPhase.RUNNING && now >= endAtMs

    /** What a finished session writes. [startedAt] is the session start, so ids match the web layer's `focus:<ts>`. */
    fun doneEvents(endedAt: Long): List<Triple<String, String, Double>> {
        val ts = endedAt
        return listOf(Triple("focus:$ts", "focus.min", totalMin.toDouble()), Triple("focus.n:$ts", "focus.sessions", 1.0))
    }

}

/** The activity graph: last N local days of one metric, as bar heights 0..1. */
object GraphCore {
    val METRICS = listOf("focus.min" to "Focus (min)", "steps.count" to "Steps", "spend" to "Spent", "water.ml" to "Water (ml)", "voice.count" to "Voice notes")
    const val DAYS = 7

    fun nextMetric(cur: String): String { val i = METRICS.indexOfFirst { it.first == cur }; return METRICS[(i + 1).mod(METRICS.size)].first }
    fun label(metric: String): String = METRICS.firstOrNull { it.first == metric }?.second ?: metric

    /** Heights relative to the largest value; an all-zero series gives zeros (never divides by zero). */
    fun heights(values: List<Double>): List<Float> {
        val max = values.maxOrNull() ?: 0.0
        return values.map { if (max <= 0.0) 0f else (it / max).toFloat().coerceIn(0f, 1f) }
    }

    fun total(values: List<Double>): Double = values.sum()

    fun compact(v: Double): String = when {
        v >= 1_000_000 -> String.format(Locale.US, "%.1fM", v / 1_000_000)
        v >= 10_000 -> String.format(Locale.US, "%.0fk", v / 1_000)
        v >= 1_000 -> String.format(Locale.US, "%.1fk", v / 1_000)
        v == Math.floor(v) -> v.toLong().toString()
        else -> String.format(Locale.US, "%.1f", v)
    }
}

/** Voice-note recording rules. */
object VoiceCore {
    /** No recording time limit. The only stop besides the user is the phone running out of free space (this reserve is kept free). */
    const val SPACE_RESERVE = 64L * 1024 * 1024
    const val MIN_FREE = 8L * 1024 * 1024
    const val CHUNK = 786_432        // multiple of 3, so every chunk is clean base64
    const val BITRATE = 48_000
    const val SAMPLE_RATE = 16_000
    private val ID = Regex("^[A-Za-z0-9]{1,24}$")

    fun newId(now: Long, rnd: Random = Random()): String = "v" + now.toString(36) + Integer.toString(rnd.nextInt(46_656), 36).padStart(3, '0')
    fun isId(s: String) = ID.matches(s)
    fun fileName(id: String) = "$id.m4a"
    fun inboxJson(id: String, ts: Long, durMs: Long, bytes: Long): JSONObject = JSONObject().put("id", id).put("ts", ts).put("dur", durMs).put("bytes", bytes)
    /** A recording this short is a mis-tap, not a note. */
    fun worthKeeping(durMs: Long, bytes: Long) = durMs >= 1_000L && bytes > 0L
}

/** Planner/To-do widget: how many rows fit and what the header says. */
object TaskListCore {
    fun progress(done: Int, total: Int): String = if (total == 0) "No tasks" else "$done/$total done"
    fun percent(done: Int, total: Int): Int = if (total <= 0) 0 else (done * 100 / total).coerceIn(0, 100)
    val PERIOD_LABEL = mapOf("daily" to "Daily", "weekly" to "Weekly", "monthly" to "Monthly")
    fun nextPeriod(p: String): String = when (p) { "daily" -> "weekly"; "weekly" -> "monthly"; else -> "daily" }
}
