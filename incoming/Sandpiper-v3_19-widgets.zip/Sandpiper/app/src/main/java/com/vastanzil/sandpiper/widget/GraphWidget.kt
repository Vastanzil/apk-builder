package com.vastanzil.sandpiper.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.RemoteViews
import com.vastanzil.sandpiper.ActivityStore
import com.vastanzil.sandpiper.R
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

/**
 * Activity record graph: the last 7 days of one metric, drawn from the ActivityStore daily rollups (read only).
 * Tap the title to switch metric (focus, steps, spent, water, voice notes). Refreshes whenever the app or another widget writes.
 */
class GraphWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) = update(c, m, intArrayOf(id))
    override fun onDeleted(c: Context, ids: IntArray) { val e = Widgets.prefs(c).edit(); for (id in ids) e.remove("g_${id}_m"); e.apply() }

    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        if (i.action != ACTION_METRIC) { super.onReceive(c0, i); return }
        val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        val p = Widgets.prefs(c)
        p.edit().putString("g_${id}_m", GraphCore.nextMetric(p.getString("g_${id}_m", "focus.min") ?: "focus.min")).apply()
        Widgets.guard { update(c, AppWidgetManager.getInstance(c), intArrayOf(id)) }
    }

    companion object {
        const val ACTION_METRIC = "com.vastanzil.sandpiper.widget.GRAPH_METRIC"

        fun update(c: Context, m: AppWidgetManager, ids: IntArray) {
            val today = LocalDate.now()
            val from = today.minusDays(GraphCore.DAYS - 1L)
            for (id in ids) {
                val metric = Widgets.prefs(c).getString("g_${id}_m", "focus.min") ?: "focus.min"
                val o = try { JSONObject(ActivityStore.series(c, metric, from.toString(), today.toString())) } catch (e: Exception) { JSONObject() }
                val days = (0 until GraphCore.DAYS).map { from.plusDays(it.toLong()) }
                val values = days.map { o.optDouble(it.toString(), 0.0) }
                val opt = m.getAppWidgetOptions(id)
                val dm = c.resources.displayMetrics
                val wPx = (opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250) * dm.density).toInt().coerceIn(240, 720)
                val hPx = (opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110) * dm.density * 0.7f).toInt().coerceIn(100, 360)
                val v = RemoteViews(c.packageName, R.layout.widget_graph)
                v.setTextViewText(R.id.w_title, GraphCore.label(metric) + " \u25BE")
                v.setTextViewText(R.id.w_progress, "7 days: " + GraphCore.compact(GraphCore.total(values)))
                v.setImageViewBitmap(R.id.w_img, draw(values, days.map { it.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault()) }, wPx, hPx))
                v.setOnClickPendingIntent(R.id.w_title, Widgets.bcast(c, GraphWidget::class.java, ACTION_METRIC, id))
                m.updateAppWidget(id, v)
            }
        }

        private fun draw(values: List<Double>, labels: List<String>, w: Int, h: Int): Bitmap {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            val n = values.size
            val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9FB0C8.toInt(); textSize = h * 0.13f; textAlign = Paint.Align.CENTER }
            val num = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE9EEE8.toInt(); textSize = h * 0.12f; textAlign = Paint.Align.CENTER }
            val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5B9BFF.toInt() }
            val now = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB9D9C4.toInt() }
            val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF; strokeWidth = 2f }
            val slot = w.toFloat() / n
            val baseY = h - label.textSize - 8f
            val top = num.textSize + 10f
            cv.drawLine(0f, baseY, w.toFloat(), baseY, base)
            val hs = GraphCore.heights(values)
            for (i in 0 until n) {
                val cx = slot * i + slot / 2f
                val bw = slot * 0.5f
                val bh = maxOf(if (values[i] > 0.0) 6f else 0f, (baseY - top) * hs[i])
                if (bh > 0f) cv.drawRoundRect(RectF(cx - bw / 2, baseY - bh, cx + bw / 2, baseY), 8f, 8f, if (i == n - 1) now else bar)
                if (values[i] > 0.0 && hs[i] >= 0.999f) cv.drawText(GraphCore.compact(values[i]), cx, baseY - bh - 6f, num)
                cv.drawText(labels[i], cx, h - 6f, label)
            }
            return bmp
        }
    }
}
