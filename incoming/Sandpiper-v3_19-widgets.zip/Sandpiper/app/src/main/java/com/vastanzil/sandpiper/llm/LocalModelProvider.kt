package com.vastanzil.sandpiper.llm

import android.app.ActivityManager
import android.content.Context

/**
 * Runs a model file the user provided, through whatever [LlmRuntimes.factory] this build has (none yet: the provider then
 * reports NO_RUNTIME and the app keeps using plain rules). The model is loaded on first use and released on release()
 * (app goes to background, or idle) so it never sits in memory.
 */
internal class LocalModelProvider(private val c: Context) : LlmProvider {
    override val id = ProviderId.LOCAL
    private var rt: LlmRuntime? = null
    private var loadedId: String? = null

    override fun availability(): Availability {
        if (LlmRuntimes.factory == null) return Availability.NO_RUNTIME
        return if (LlmStore.readyModel() != null) Availability.READY else Availability.NO_MODEL
    }

    override fun label(): String? = LlmStore.models().firstOrNull { it.state == ModelState.READY || it.state == ModelState.STORED }?.name

    @Synchronized
    override fun generate(req: LlmRequest, cancel: CancelToken): LlmResult {
        val m = LlmStore.readyModel() ?: return LlmResult.Failure(LlmError.NO_PROVIDER)
        val factory = LlmRuntimes.factory ?: return LlmResult.Failure(LlmError.NO_PROVIDER)
        return try {
            if (rt == null || loadedId != m.id) {
                releaseNow()
                val mi = ActivityManager.MemoryInfo()
                (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
                if (mi.availMem < m.sizeBytes) return LlmResult.Failure(LlmError.ENGINE)   // not enough free memory: fail closed
                val r = factory()
                if (!r.load(java.io.File(c.filesDir, "models/" + m.path).path)) return LlmResult.Failure(LlmError.ENGINE)
                rt = r; loadedId = m.id
            }
            val t0 = System.nanoTime()
            val text = rt!!.generate(req.system, req.user, req.maxTokens, req.timeoutMs, cancel)
            if (cancel.canceled) return LlmResult.Failure(LlmError.CANCELED)
            LlmStore.touch(m.id, System.currentTimeMillis())
            if (text == null) LlmResult.Failure(LlmError.TIMEOUT) else LlmResult.Text(text, (System.nanoTime() - t0) / 1_000_000L)
        } catch (e: OutOfMemoryError) {
            releaseNow(); LlmResult.Failure(LlmError.ENGINE)
        } catch (e: Exception) {
            LlmResult.Failure(LlmError.ENGINE)
        }
    }

    private fun releaseNow() { try { rt?.release() } catch (e: Throwable) { }; rt = null; loadedId = null }

    @Synchronized override fun release() = releaseNow()
}
