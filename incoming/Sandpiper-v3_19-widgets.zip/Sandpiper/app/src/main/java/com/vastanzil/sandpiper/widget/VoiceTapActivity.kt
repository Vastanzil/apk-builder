package com.vastanzil.sandpiper.widget

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * See-through screen behind the Voice widget's Record button. It shows nothing and closes at once. It exists because Android only lets an
 * app start a microphone service while something of the app is on screen, and because it can ask for the microphone permission itself,
 * so the Sandpiper app never has to be opened. Stopping does not need it (widget Stop button or the recording notification).
 */
class VoiceTapActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        when {
            VoiceRecordService.running -> finish()
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> go()
            else -> requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) go()
        else { Toast.makeText(this, "Microphone not allowed, so nothing was recorded.", Toast.LENGTH_LONG).show(); finish() }
    }

    private fun go() {
        val c = applicationContext
        Widgets.prefs(c).edit().remove(VoiceWidget.MSG).apply()
        try { ContextCompat.startForegroundService(c, Intent(c, VoiceRecordService::class.java).setAction(VoiceRecordService.ACTION_START)) }
        catch (e: Exception) { Toast.makeText(c, "Could not start recording.", Toast.LENGTH_LONG).show() }
        finish()
    }
}
