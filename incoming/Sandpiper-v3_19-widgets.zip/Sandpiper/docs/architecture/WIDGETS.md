# Home-screen widgets (v1.15.0)

**Rule: a widget tap never opens Sandpiper.** Every widget writes its record into Sandpiper's own storage by itself. The app is not started, not brought to the front and not needed.

**Not compiled and not run on a device.** The Kotlin/XML here has been written carefully but there was no Android SDK in the authoring environment. Build, run `./gradlew testDebugUnitTest`, then follow the device checklist below.

## The six widgets
| Widget | Size | Tap does | Writes to | Shows in the app |
|---|---|---|---|---|
| Planner | 4x2 | tick a task; title cycles Daily/Weekly/Monthly; `+` adds a task | `PlannerStore` (native SQLite) | immediately |
| To-do (daily) | 2x3 | same, Daily only | `PlannerStore` | immediately |
| Add transaction | 4x4 | keypad, Expense/Income, category, **Save** | `widget_inbox` row + ledger `tx:<id>` | Finance list on next open; graphs immediately |
| Activity graph | 4x2 | title cycles focus / steps / spent / water / voice notes | read only (`ActivityStore` rollups) | n/a |
| Focus timer | 2x2 | Start / Pause / Resume / Reset (25 min, 15/25/45/50 in Settings) | ledger `focus:<end>` + `focus.n:<end>`, inbox `focus`, one quiet notification | focus garden on next open; graphs immediately |
| Voice note | 2x2 | Record / Stop (max 2/5/10 min) | file in private `voice/`, ledger `voice:<id>`, inbox `voice` | Notes recordings list on next open |

## Why an inbox
Planner and activity data are native, so widgets write them directly. Finance transactions (`S.txs`), the focus garden (`S.sessions`) and voice recordings (IndexedDB) live in the web layer, which cannot run while the app is closed. So the widget writes a durable row in `widget_inbox` (CentralDb v8) at the moment of the tap, and `widgetDrain()` in `index.html` imports and acks it on the next open/resume. Ids are the ones the web layer uses (`tx:<id>`, `focus:<ts>`, `voice:<id>`), so a retry, a crash mid-import or a double drain can never duplicate a record. Rows are deleted only after the ack; a voice file only after its row.

## Typing without opening the app
`RemoteViews` cannot contain a text box. Task text uses a quiet notification with an inline reply box (`RemoteInput`): tap `+`, type in the notification, send. It writes to `PlannerStore` and disappears. Needs notification permission once. Transactions avoid typing: the description is the category.

## Things a widget cannot do alone (one-time, in the app)
- Grant the **microphone** (Voice note) and **notifications** (task quick-add, focus-done alert). The widget says so in a toast when missing.
- Exact alarms for a to-the-second Pomodoro end need the existing exact-alarm permission; without it the end can be a few minutes late (the widget settles it on the next refresh).

## Files
`widget/WidgetCore.kt` (pure: keypad, categories, Pomodoro state machine, graph scaling, voice rules; `WidgetCoreTest`), `WidgetStore.kt` (inbox), `Widgets.kt` (helpers, debounced refresh), `TaskWidgets.kt` + `TaskListService.kt` + `AddTask.kt`, `FinanceWidget.kt`, `GraphWidget.kt`, `PomodoroWidget.kt`, `VoiceWidget.kt` + `VoiceRecordService.kt`. Layouts `res/layout/widget_*.xml`, provider infos `res/xml/*_widget_info.xml`. The app refreshes widgets after planner/activity writes (`Bridge`, debounced 400 ms).

## Device checklist
1. Add each widget; confirm tap targets work and the app never appears.
2. Planner: tick a task on the widget, open the app: same state. Add a task via `+` notification.
3. Finance: type `125.5`, Save; widget shows "Saved"; open the app: transaction is in Finance once; graphs show it; open again: still once.
4. Pomodoro: start, lock the phone, wait for the end (set 15 min for testing); notification appears, session counted once.
5. Voice: record 10 s with the app closed and the screen off (Android 14: confirm the microphone foreground service starts from the widget tap), stop; open Notes: recording plays.
6. Reboot with a running Pomodoro: widget settles or re-arms. Kill the app during a recording: no stuck "Stop" button.
