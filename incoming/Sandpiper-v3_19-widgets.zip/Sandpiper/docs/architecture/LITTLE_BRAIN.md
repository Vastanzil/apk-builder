# Little brain (v1.14.0): what is built, how it connects, how to extend it

Source plan: `LITTLE_BRAIN_PLAN.md` (unchanged copy). This file says what was built from it and where it differs.
**Nothing here has been compiled or run on a device** (no Android SDK or Kotlin compiler in the authoring environment). Pure logic has JUnit tests that have not been executed either; the Settings/Sprout JavaScript was syntax-checked and the `SpBrain` client was exercised with a fake bridge in Node.

## Decisions that differ from the plan
| Plan | Built | Why |
|---|---|---|
| Two flavors, `connected` adds INTERNET, downloader, catalog, custom link, network switch | **Removed.** No INTERNET permission, no network class, no flavors, no catalog URLs | Owner decision: no internet connection. `NoNetworkTest` scans `src/main` for network APIs/permissions and fails the build if any appear |
| Four sources A-D | **A (system AI, seam only) and D (user picks a file already on the phone)** | B and C need the network |
| Brain may nag or toast on failure | **Silent by default.** Failures return a code; the page shows nothing. The only question ever asked is "pick a model file?" | Owner decision: silent unless needed |
| (new) permission to ask | Setting `brain.ask` (default on): when the user taps a brain feature and the only missing piece is a model file, ask once. Off = never ask | Owner decision: "give permission to ask when needed, ask the user to provide" |

## What exists
- `llm/LlmCore.kt` (pure): enums, `GuardCore` (plan 7.2 table), `RouterCore`, strict `JsonOut`, number-subset checks, `TaskSpec` + `SmsExtractSpec`, `CategorizeSpec`, `DaySummarySpec` (+ deterministic fallback), `NoteRewriteSpec`, `ModelFileRules`.
- `llm/LlmEngine.kt` (pure): `LlmEngine` (one call at a time, cache, usage, backoff), `LlmProvider`, `NullProvider`, `SystemAiProvider` + `SystemAiBackend` seam, `LlmRuntime` + `LlmRuntimes.factory` seam.
- Android: `LlmGuard`, `LlmStore` (tables + usage), `ModelImporter` (SAF file copy, SHA-256, probe), `LocalModelProvider`, `Brain` (wiring, thermal listener).
- CentralDb **v7** (additive): `llm_model`, `llm_usage`. Settings: registry feature `brain` (`brain.*`, store `app`, keys in `AppSettings`). Diagnostics: `DCat/DMod.BRAIN`, `BRAIN_*` events, `CHK_BRAIN` self-test (enums and counts only).
- Bridge: `llmStatus, llmRun, llmCancel, llmModels, llmUsage, llmImportPick, llmRemove`; callbacks `window.onLlmResult`, `window.onLlmProgress`. JS client: `window.SpBrain` in `index.html` (embedded pages use `parent.SpBrain`).
- Sprout: "Read with the brain" on could-not-read Review items (`sprout-bridge.js`; one line in `sprout.html`). Only plain credit/debit readings can be approved; Approve is always the user's tap.

## Connection map (existing module -> brain hook)
| Existing piece | Brain connection | State |
|---|---|---|
| `SmsStore` / `sms_inbox` -> Sprout `reviewInbox` | `sms_extract` | **wired** (button, suggestion line, Approve) |
| Sprout ledger rows with `Uncategorized`, `CATEGORIES` | `categorize` (spec + validator done) | spec only; add a chip that calls `SpBrain.run('categorize', {payee, categories})` |
| `ActivityStore.day()` / Day-end flow (`DayEnd`, Planner close) | `day_summary` (spec + fallback done) | spec only; build `facts` from `activityDay()`, call on app open (never at 22:00 in the background) |
| Notes / Piper | `note_rewrite` | spec only |
| `ActivityStore`, `PlannerStore`, `SproutStore` | `ask_data` via a read-only Kotlin tool layer | reserved enum, no spec |
| `FeatureRegistry` / `features.json` / `AppSettings` / `SettingsStore` | brain settings, toggles default off | wired |
| `Diag` / `DiagCore` | enum-only brain events + `CHK_BRAIN` | wired |
| `CentralDb` | v7 tables | wired |
| `MainActivity` lifecycle | foreground flag, cancel + free model memory on pause | wired |
| `Scheduler`, `Notifier`, `AlarmService`, WorkManager | **deliberately not connected**: no background work, no notifications (silent) | n/a |

## Add a task (no engine change)
1. Add a value to `LlmTask` (key, max tokens, setting key). 2. Write a `TaskSpec` (prompt, `user()`, `validate()`, optional `fallback()`), register it in `LlmTasks`. 3. Add the toggle to `features.json` and the key to `AppSettings.BRAIN_TASK_KEYS` (`AppSettingsTest` checks they agree). 4. Call `SpBrain.run(key, input, cb, {ask:true})` from the UI the user is looking at. 5. Add validator tests, including a hallucinated-number and an injection case.

## Still needed before the brain can answer anything
- **Phase 0 spike on the owner's phone.** In this build `SystemAi.backend == null` and `LlmRuntimes.factory == null`, so the router reports `NONE` and the app behaves exactly as before. A model file the user imports is stored (`STORED`) but cannot run yet.
- Verify ML Kit GenAI / AICore and LiteRT-LM Gradle coordinates, then implement `SystemAiBackend` and a `LlmRuntime`, and set them at startup. No dependency was added because none could be verified offline.
- Device checklist from plan section 10 (foreground-only, thermal and battery guards, import of a large file, removal frees space, 10-call heat test).
