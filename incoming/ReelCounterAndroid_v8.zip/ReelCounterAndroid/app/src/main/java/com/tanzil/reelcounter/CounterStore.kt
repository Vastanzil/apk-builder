package com.tanzil.reelcounter

import android.content.Context
import android.content.Intent

enum class IslandStyle(val label: String) {
    AUTO("Automatic"),
    ISLAND("Camera island"),
    STATUS_BAR("Status bar band"),
    FLOAT("Floating pill")
}

enum class IslandLook(val label: String) {
    DARK_GLASS("Liquid Glass – Dark"),
    SKY_GLASS("Liquid Glass – Sky"),
    CLASSIC("Solid Black")
}

internal object CounterStore {
    const val ACTION_COUNT_CHANGED = "com.tanzil.reelcounter.COUNT_CHANGED"
    const val ACTION_STYLE_CHANGED = "com.tanzil.reelcounter.STYLE_CHANGED"
    const val ACTION_APPS_CHANGED = "com.tanzil.reelcounter.APPS_CHANGED"
    const val ACTION_PREVIEW = "com.tanzil.reelcounter.PREVIEW"
    const val ACTION_ENABLED_CHANGED = "com.tanzil.reelcounter.ENABLED_CHANGED"
    private const val PREFS = "reel_counter_store"
    private const val KEY_COUNT = "count"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_STYLE = "style"
    private const val KEY_BROWSER = "browser"
    private const val KEY_GAP = "gap"
    private const val KEY_LOOK = "look"
    private const val KEY_CHOSEN = "chosen_apps"
    private const val KEY_DEBUG = "debug"

    fun count(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0)
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
        notify(context, ACTION_ENABLED_CHANGED)
    }

    fun style(context: Context): IslandStyle =
        runCatching { IslandStyle.valueOf(prefs(context).getString(KEY_STYLE, null) ?: "AUTO") }.getOrDefault(IslandStyle.AUTO)
    fun setStyle(context: Context, style: IslandStyle) {
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()
        notify(context, ACTION_STYLE_CHANGED)
    }

    // --- apps picked from the installed-apps list (null = never chosen -> built-in defaults)
    fun chosenApps(c: Context): Set<String>? =
        prefs(c).getString(KEY_CHOSEN, null)?.split('\n')?.map { it.trim() }?.filter { it.isNotEmpty() }?.toSet()
    fun setChosenApps(c: Context, apps: Set<String>) {
        prefs(c).edit().putString(KEY_CHOSEN, apps.joinToString("\n")).apply()
        notify(c, ACTION_APPS_CHANGED)
    }
    fun monitoredApps(c: Context): Set<String> = chosenApps(c) ?: ReelScrollAccessibilityService.BUILT_IN_APPS

    // --- last camera / layout diagnosis written by the overlay, shown in the app
    fun debug(c: Context): String = prefs(c).getString(KEY_DEBUG, "") ?: ""
    fun setDebug(c: Context, text: String) { prefs(c).edit().putString(KEY_DEBUG, text).apply() }

    fun browserSupport(c: Context): Boolean = prefs(c).getBoolean(KEY_BROWSER, true)
    fun setBrowserSupport(c: Context, on: Boolean) { prefs(c).edit().putBoolean(KEY_BROWSER, on).apply() }

    /** Extra dp of black either side of the camera hole: 0 compact, 1 normal, 2 wide, 3 extra wide. */
    fun gapLevel(c: Context): Int = prefs(c).getInt(KEY_GAP, 2)
    fun gapExtraDp(c: Context): Int = intArrayOf(8, 18, 30, 44)[gapLevel(c).coerceIn(0, 3)]
    fun setGapLevel(c: Context, l: Int) { prefs(c).edit().putInt(KEY_GAP, l).apply(); notify(c, ACTION_STYLE_CHANGED) }

    fun look(c: Context): IslandLook =
        runCatching { IslandLook.valueOf(prefs(c).getString(KEY_LOOK, null) ?: "DARK_GLASS") }.getOrDefault(IslandLook.DARK_GLASS)
    fun setLook(c: Context, l: IslandLook) { prefs(c).edit().putString(KEY_LOOK, l.name).apply(); notify(c, ACTION_STYLE_CHANGED) }
    fun preview(c: Context) = notify(c, ACTION_PREVIEW)

    fun increment(context: Context): Int {
        val next = count(context) + 1
        prefs(context).edit().putInt(KEY_COUNT, next).apply()
        notify(context, ACTION_COUNT_CHANGED)
        return next
    }
    fun reset(context: Context) {
        prefs(context).edit().putInt(KEY_COUNT, 0).apply()
        notify(context, ACTION_COUNT_CHANGED)
    }
    private fun notify(context: Context, action: String) = context.sendBroadcast(Intent(action).setPackage(context.packageName))
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
