package com.tanzil.reelcounter

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView

/** Pick the apps to count from the phone's installed launcher apps (name + icon, no package names). */
class AppPickerActivity : Activity() {
    private class Row(val pkg: String, val label: String, val popular: Boolean)

    private val all = ArrayList<Row>()
    private var shown: List<Row> = emptyList()
    private val chosen = HashSet<String>()
    private val icons = HashMap<String, Drawable?>()
    private lateinit var adapter: BaseAdapter
    private lateinit var summary: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.rgb(9, 10, 18)
        window.statusBarColor = bg; window.navigationBarColor = bg

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16), dp(24), dp(16), dp(12)) }
        root.addView(TextView(this).apply { text = "Tracked apps"; textSize = 22f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(4)) })
        summary = TextView(this).apply { textSize = 13f; setTextColor(0xFFB9B6C9.toInt()); setPadding(0, 0, 0, dp(10)) }
        root.addView(summary)
        val search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(0xFF7F7C93.toInt()); setTextColor(Color.WHITE); isSingleLine = true
            setBackgroundTintList(ColorStateList.valueOf(0xFF5F43A8.toInt()))
        }
        root.addView(search)
        progress = ProgressBar(this).apply { isIndeterminate = true }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(24) })
        val list = ListView(this).apply { divider = null; setSelector(android.R.color.transparent) }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            text = "Done"; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundTintList(ColorStateList.valueOf(0xFF5F43A8.toInt()))
            setOnClickListener { finish() }
        })
        setContentView(root)

        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convertView: View?, parent: ViewGroup): View {
                val row = shown[i]
                val v = (convertView as? LinearLayout) ?: buildRow()
                val icon = v.getChildAt(0) as ImageView
                val texts = v.getChildAt(1) as LinearLayout
                val box = v.getChildAt(2) as CheckBox
                icon.setImageDrawable(icons.getOrPut(row.pkg) { runCatching { packageManager.getApplicationIcon(row.pkg) }.getOrNull() })
                (texts.getChildAt(0) as TextView).text = row.label
                (texts.getChildAt(1) as TextView).apply { text = "Short-video app"; visibility = if (row.popular) View.VISIBLE else View.GONE }
                box.isChecked = row.pkg in chosen
                v.setOnClickListener { toggle(row) }
                return v
            }
        }
        list.adapter = adapter
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filter(s?.toString().orEmpty())
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
        })
        load()
    }

    private fun buildRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10))
        addView(ImageView(context), LinearLayout.LayoutParams(dp(42), dp(42)))
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { textSize = 16f; setTextColor(Color.WHITE); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            addView(TextView(context).apply { textSize = 12f; setTextColor(0xFF9D8CE0.toInt()) })
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14); marginEnd = dp(8) })
        addView(CheckBox(context).apply {
            isClickable = false; isFocusable = false
            buttonTintList = ColorStateList.valueOf(0xFF9D8CE0.toInt())
        })
    }

    private fun load() {
        Thread {
            val pm = packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val rows = pm.queryIntentActivities(launcher, 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .filter { it.first != packageName && it.first !in ReelScrollAccessibilityService.BROWSERS }
                .map { Row(it.first, it.second, it.first in ReelScrollAccessibilityService.BUILT_IN_APPS) }
                .sortedWith(compareByDescending<Row> { it.popular }.thenBy { it.label.lowercase() })
            runOnUiThread {
                all.clear(); all.addAll(rows)
                chosen.clear(); chosen.addAll(CounterStore.chosenApps(this) ?: rows.filter { it.popular }.map { it.pkg }.toSet())
                progress.visibility = View.GONE
                filter(""); updateSummary()
            }
        }.start()
    }

    private fun filter(q: String) {
        val t = q.trim().lowercase()
        shown = if (t.isEmpty()) all.toList() else all.filter { it.label.lowercase().contains(t) }
        adapter.notifyDataSetChanged()
    }

    private fun toggle(row: Row) {
        if (!chosen.add(row.pkg)) chosen.remove(row.pkg)
        CounterStore.setChosenApps(this, chosen.toSet())
        adapter.notifyDataSetChanged(); updateSummary()
    }

    private fun updateSummary() {
        summary.text = "${chosen.size} selected · reels are counted only in these apps. Browsers use “Web reels in browsers”."
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
