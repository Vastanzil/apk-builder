package com.tanzil.reelcounter

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Collects TYPE_VIEW_SCROLLED samples from allow-listed apps (built-in + mods + user's custom list) and,
 * when enabled, from browsers on Instagram / YouTube / Facebook / TikTok web. [SwipeDetector] decides when a
 * swipe has settled into a new reel. In browsers the ONLY thing read is the address-bar text (in memory,
 * never stored) to recognise the site. Events from every other app are dropped immediately.
 */
class ReelScrollAccessibilityService : AccessibilityService() {
    private enum class Web { NO, HOST, REEL }

    private val handler = Handler(Looper.getMainLooper())
    private val detector = SwipeDetector()
    private var lastScrollY = -1
    private var overlay: IslandOverlay? = null
    private var receiverRegistered = false
    private var apps: Set<String> = BUILT_IN_APPS
    private val webState = HashMap<String, Web>()
    private var lastUrlRead = 0L
    private val settle = Runnable {
        if (detector.flush(SystemClock.uptimeMillis())) CounterStore.increment(this@ReelScrollAccessibilityService)
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CounterStore.ACTION_COUNT_CHANGED -> overlay?.render(CounterStore.count(this@ReelScrollAccessibilityService), true)
                CounterStore.ACTION_STYLE_CHANGED -> overlay?.refresh()
                CounterStore.ACTION_ENABLED_CHANGED -> syncOverlay()
                CounterStore.ACTION_APPS_CHANGED -> reloadApps()
                CounterStore.ACTION_PREVIEW -> overlay?.preview()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlay = IslandOverlay(this)
        reloadApps()
        val f = IntentFilter().apply {
            addAction(CounterStore.ACTION_COUNT_CHANGED); addAction(CounterStore.ACTION_STYLE_CHANGED)
            addAction(CounterStore.ACTION_ENABLED_CHANGED); addAction(CounterStore.ACTION_APPS_CHANGED); addAction(CounterStore.ACTION_PREVIEW)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, f)
        receiverRegistered = true
        syncOverlay()
    }

    private fun reloadApps() { apps = CounterStore.monitoredApps(this) - BROWSERS }
    private fun syncOverlay() { if (CounterStore.isEnabled(this)) overlay?.show() else overlay?.hide() }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        val pkg = event.packageName?.toString() ?: return
        val now = SystemClock.uptimeMillis()
        val browser = pkg in BROWSERS && CounterStore.browserSupport(this)

        if (pkg !in apps && !browser) return
        if (!CounterStore.isEnabled(this)) return

        var strict = false
        if (browser && pkg !in apps) {
            when (webMode(pkg, now)) { Web.NO -> return; Web.HOST -> strict = true; Web.REEL -> Unit }
        }

        val dx: Int
        val dy: Int
        if (Build.VERSION.SDK_INT >= 28) {
            dx = event.scrollDeltaX; dy = event.scrollDeltaY
        } else {                                   // API 26-27: derive delta from absolute offset
            val y = event.scrollY
            dy = if (y >= 0 && lastScrollY >= 0) y - lastScrollY else 0
            lastScrollY = y; dx = 0
        }
        val dm = resources.displayMetrics
        detector.onSample(
            SwipeDetector.Sample(
                now, pkg, event.className?.toString().orEmpty(), dx, dy, event.fromIndex, event.itemCount,
                dm.heightPixels, if (browser) (dm.heightPixels / dm.density).toInt() else 0, strict
            )
        )
        handler.removeCallbacks(settle)
        handler.postDelayed(settle, SETTLE_MS)
    }

    // ---- browser: which site is this tab? (address bar text only) ----
    private fun webMode(pkg: String, now: Long): Web {
        if (now - lastUrlRead > 600L) {            // toolbar may be hidden mid-scroll: keep last known answer
            lastUrlRead = now
            readUrl(pkg)?.let { webState[pkg] = classifyUrl(it) }
        }
        return webState[pkg] ?: Web.NO
    }

    @Suppress("DEPRECATION")
    private fun readUrl(pkg: String): String? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != pkg) { if (Build.VERSION.SDK_INT < 33) root.recycle(); return null }
        val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
        var budget = 400
        var found: String? = null
        while (queue.isNotEmpty() && budget-- > 0 && found == null) {
            val n = queue.removeFirst()
            val id = n.viewIdResourceName
            if (id != null && URL_IDS.any { id.endsWith(":id/$it") }) found = n.text?.toString()?.takeIf { it.isNotBlank() }
            if (found == null) for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
            if (Build.VERSION.SDK_INT < 33) n.recycle()
        }
        if (Build.VERSION.SDK_INT < 33) queue.forEach { it.recycle() }
        return found
    }

    private fun classifyUrl(raw: String): Web {
        val u = raw.trim().lowercase().removePrefix("https://").removePrefix("http://")
        if (!u.contains('.') || u.contains(' ')) return Web.NO           // typed search text, not a URL
        val host = u.substringBefore('/').removePrefix("www.").removePrefix("m.").removePrefix("mobile.")
        val path = u.substringAfter('/', "").trimStart('/')
        fun site(reel: Boolean) = if (path.isEmpty()) Web.HOST else if (reel) Web.REEL else Web.NO
        return when {
            host.endsWith("instagram.com") -> site(path.startsWith("reel"))
            host.endsWith("youtube.com") -> site(path.startsWith("shorts"))
            host.endsWith("facebook.com") || host == "fb.watch" -> site(path.startsWith("reel") || path.startsWith("watch"))
            host.endsWith("tiktok.com") -> Web.REEL
            else -> Web.NO
        }
    }

    override fun onInterrupt() { handler.removeCallbacks(settle); detector.reset() }

    override fun onConfigurationChanged(newConfig: Configuration) { super.onConfigurationChanged(newConfig); overlay?.refresh() }

    private fun teardown() {
        handler.removeCallbacks(settle)
        overlay?.hide(false)
        if (receiverRegistered) { try { unregisterReceiver(receiver) } catch (_: Exception) { }; receiverRegistered = false }
    }
    override fun onUnbind(intent: Intent?): Boolean { teardown(); return super.onUnbind(intent) }
    override fun onDestroy() { teardown(); super.onDestroy() }

    companion object {
        private const val SETTLE_MS = 260L

        /** YouTube (+Vanced/ReVanced), Instagram (+Lite/Instander), Facebook (+Lite), TikTok variants. Add others in the app. */
        val BUILT_IN_APPS = setOf(
            "com.google.android.youtube", "com.vanced.android.youtube", "app.revanced.android.youtube", "app.rvx.android.youtube",
            "com.instagram.android", "com.instagram.lite", "com.instander.android",
            "com.facebook.katana", "com.facebook.lite",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go", "com.ss.android.ugc.aweme"
        )
        val BROWSERS = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary", "org.chromium.chrome",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix", "org.mozilla.focus",
            "com.brave.browser", "com.brave.browser_beta", "com.microsoft.emmx", "com.sec.android.app.sbrowser",
            "com.opera.browser", "com.opera.mini.native", "com.opera.gx", "com.duckduckgo.mobile.android",
            "com.vivaldi.browser", "com.kiwibrowser.browser", "com.mi.globalbrowser", "mark.via.gp"
        )
        private val URL_IDS = listOf(
            "url_bar", "url_field", "location_bar_edit_text", "mozac_browser_toolbar_url_view",
            "url_bar_title", "omnibarTextInput", "display_url", "url_edit_text", "url"
        )
    }
}
