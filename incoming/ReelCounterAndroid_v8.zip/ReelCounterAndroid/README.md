# Reel Counter — Android Kotlin starter project

A minimal Android floating Dynamic-Island-style counter. The overlay contains exactly two visual elements: a brain emoji and a number.

## What is implemented

- Always-on-top pill using `TYPE_APPLICATION_OVERLAY`.
- Count persisted locally in `SharedPreferences`.
- Accessibility service listens only for `TYPE_VIEW_SCROLLED` events from Instagram, Facebook, YouTube and TikTok package IDs.
- Scroll events are collected and judged only when the swipe SETTLES (`SwipeDetector`): net vertical travel of 0.5-1.6 screen heights, one reel per gesture, horizontal scrolls ignored, back-and-forth over an already counted reel never recounts. Unit tests: `./gradlew test`.
- Overlay is non-touchable so it does not intercept taps or swipes in the app underneath.
- Foreground service keeps the overlay alive while enabled.
- No screen recording, screenshots, OCR, video capture, or window-content retrieval.

## Important detection limitation

Android does not provide a universal, trustworthy “Reel/Short changed” callback across these apps. This implementation counts vertical scroll accessibility events from the supported apps. Therefore it can also count scrolling in comments, search results, profiles, or ordinary feeds, and some app versions may emit too few or too many events. It is an estimate, not an exact Reel counter. The supported app package IDs can also change by region/version.

## Build

1. Open this folder in Android Studio (JDK 17).
2. Allow Gradle sync to complete.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the phone.
5. Open Reel Counter and grant **Display over other apps**.
6. Open **Enable swipe detection** and enable Reel Counter under Android Accessibility settings.
7. Return to Reel Counter and tap **Start counter**.

To stop the overlay, open the app and tap **Stop counter**. The count is retained until **Reset count** is tapped.

## Integration into an existing app

This is a standalone starter project because the existing Sandpiper Android project ZIP was not attached to this conversation. To merge it into an existing app, copy the Kotlin classes and resource XML, merge the manifest declarations and permissions, and resolve any namespace/package changes. Do not replace the existing app manifest wholesale.

## Android permission disclosure

The accessibility service is used only to receive scroll events from the explicitly allow-listed packages. `canRetrieveWindowContent` is false. The app should clearly explain this to users before directing them to enable the service.


## v2 notes
- **Dynamic island overlay** reads the real `DisplayCutout`: centred punch-hole -> pill wrapped around the camera; wide notch -> black status-bar band (hides system icons under it, switch style in the app if unwanted); no cut-out or landscape -> floating pill. Style can be forced from the app.
- **Mascot:** the brain is `@+id/reel_mascot` in `res/layout/overlay_island.xml`. Replace the TextView with an `ImageView` using the same id; no code change needed.
- Not compiled or run on a device in the authoring environment: build, run `./gradlew test`, and check on a punch-hole and a notch phone.

## v3: permissions and Play Protect
- **Only one special permission is left.** The island is now an `TYPE_ACCESSIBILITY_OVERLAY` window owned by the accessibility service, so `SYSTEM_ALERT_WINDOW`, the foreground service and the notification permission are gone. Accessibility + draw-over-apps is the combination Play Protect scans hardest.
- **Prominent disclosure** dialog appears before the user is sent to Accessibility settings.
- **Android 13+ "restricted settings"**: sideloaded apps get the accessibility switch greyed out. The app has a button to App info; then menu (three dots) > Allow restricted settings. Installing through a store or a session-based installer avoids this.
- **Play Protect "blocked" / "unsafe app" prompt**: tap More details > Install anyway (or choose Don't send). Turning Play Protect off is not required. This cannot be bypassed in code. For a stable result, sign releases with your own release keystore (not the debug key) and publish through Google Play (internal testing is enough).
- The service is not declared as an accessibility tool (`isAccessibilityTool`), because it is not one; do not add that flag to dodge restrictions.

## v5: modded apps, browsers, camera gap
- **Camera gap:** new "Camera gap" button (Compact / Normal / Wide / Extra wide). Default is Wide, so the camera hole sits clear of the brain and the count.
- **Modded apps:** YouTube Vanced / ReVanced / ReVanced Extended, Instagram Lite / Instander, Facebook Lite and TikTok variants are built in. Anything else: Custom apps > Detect (scroll in the app for a few seconds) > Add, or type the package name.
- **Browsers (web reels):** Chrome, Firefox, Brave, Edge, Samsung Internet, Opera, DuckDuckGo, Vivaldi, Kiwi, Mi Browser, Via. The service reads ONLY the address bar to recognise instagram.com / youtube.com / facebook.com / tiktok.com. Chrome shows just the domain, so on those sites it uses a strict near-exact full-page swipe rule; if the full path is visible (/reels, /shorts, /reel) it is precise. Normal scrolling on those sites can occasionally count. Turn browser support off in the app any time.
- This needs `canRetrieveWindowContent=true` (previously false) and no package filter in the service XML, so Android and Play Protect treat it as more sensitive: re-enable the service after updating and expect the same "Install anyway" prompt. Events from non-listed apps are discarded immediately.
- Browser delta units differ between versions (device px vs CSS px); the detector accepts either. Untested on a device: report which browser/site misbehaves.

## v6: liquid glass island + motion
- **Look** (button in the app): Liquid glass dark (default, blends with the camera), Liquid glass sky blue, Classic black. Drawn in a single pass by `LiquidGlassDrawable` (frosted gradient body, top specular gloss, accent inner glow, gradient rim light, moving sheen). No bitmaps and no window blur, so it stays cheap on the overlay window. The notch status-bar band always uses the dark glass.
- **Motion:** spring entrance growing out of the camera, odometer count roll, squash-and-stretch, mascot wiggle, light sweep + rim glow on every reel, bigger celebration (mascot spin) at every 10th and 100th reel, a quiet idle sheen every 9 s (skipped in battery saver). Everything is off when the system animation scale is 0 / animations are removed. "Preview island animation" replays the celebration without changing the count.
- Tune timings in `IslandOverlay` (`bump`, `SPRING`, `IDLE_MS`) and colours in `LiquidGlassDrawable.build`.
- Not compiled/run on a device in the authoring environment; check the look on your phone and tell me what to adjust.

## v7: camera + app picker fixes
- **Why the gap/island style did nothing:** punch-hole cut-outs usually do not touch the screen edge (rect top > 0) and the old code ignored them, so it silently fell back to the floating pill, where the gap setting was unused. Now: any cut-out in the top band is accepted, four sources are queried (insets, window metrics, root insets, display cut-out), the gap also spaces the floating pill, and a forced Island / Status bar style assumes a small centred hole if Android reports none. The app shows a one-line diagnosis ("Camera found: 52x52 px, centred · showing: Dynamic island").
- **Choose apps:** the "custom package names" feature is gone. "Choose apps to count" lists installed apps with icon and name; popular reel apps (YouTube + Vanced/ReVanced, Instagram, Facebook, TikTok variants) are pre-selected. Uses a `<queries>` launcher intent, not QUERY_ALL_PACKAGES. Browsers are excluded from the list and use the Browser support switch.

## v8: interface wording
Settings were renamed for clarity: Display mode (Automatic / Camera island / Status bar band / Floating pill), Appearance (Liquid Glass - Dark / Sky, Solid Black), Cutout spacing (Compact / Standard / Wide / Extra wide), Web reels in browsers, Tracked apps, Start / Pause tracking, Reset counter, Preview animation.
