package com.pipit.reader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale

private val Teal = Color(0xFF0E6B66)
private val Ink = Color(0xFF14202B)
private val Muted = Color(0xFF647482)
private val Surface = Color(0xFFFFFFFF)
private val Page = Color(0xFFF3F6F8)

data class ReaderDoc(val id: String, val title: String, val body: String, val kind: String = "Text")

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        setContent { PipitApp(tts) }
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PipitApp(tts: TextToSpeech?) {
    val context = LocalContext.current
    val store = remember { File(context.filesDir, "library").apply { mkdirs() } }
    var docs by remember { mutableStateOf(loadDocs(store)) }
    var current by remember { mutableStateOf(docs.firstOrNull() ?: ReaderDoc("welcome", "Welcome to Pipit", "Import a text file or paste text to begin reading.\n\nPipit can read documents aloud, transcribe live speech, scan printed text, and keep an offline library.")) }
    var tab by remember { mutableStateOf("Reader") }
    var transcript by remember { mutableStateOf("") }
    var liveText by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    var query by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var speed by remember { mutableFloatStateOf(1f) }
    var language by remember { mutableStateOf("en-US") }
    var webUrl by remember { mutableStateOf("") }
    var webText by remember { mutableStateOf("") }
    var ocrText by remember { mutableStateOf("") }
    var dark by remember { mutableStateOf(false) }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }
    DisposableEffect(speechRecognizer) { onDispose { speechRecognizer?.destroy() } }

    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecognition(speechRecognizer, language,
            onPartial = { liveText = it }, onFinal = { transcript = (transcript + "\n" + it).trim(); liveText = ""; status = "Recognition finished"; listening = false },
            onError = { status = it; listening = false }) else status = "Microphone permission denied"
    }
    val textPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { u -> runCatching { context.contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } }.onSuccess { body ->
            if (!body.isNullOrBlank()) { val d = ReaderDoc(System.currentTimeMillis().toString(), fileName(context, u), body); saveDoc(store, d); docs = loadDocs(store); current = d; tab = "Reader" }
        }.onFailure { status = "Could not open file: ${it.message}" } }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u ->
            status = "Recognising image…"
            runCatching { InputImage.fromFilePath(context, u) }.onSuccess { image ->
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result -> ocrText = result.text; status = "OCR complete. Check the text before saving." }
                    .addOnFailureListener { status = "OCR failed: ${it.localizedMessage}" }
            }.onFailure { status = "Could not read image" }
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF3FD0C4), background = Color(0xFF0F171E), surface = Color(0xFF16212B)) else lightColorScheme(primary = Teal, background = Page, surface = Surface)) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
            TopAppBar(title = { Column { Text("PIPIT", fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold); Text(tab, fontWeight = FontWeight.Bold) } },
                actions = { IconButton(onClick = { dark = !dark }) { Icon(Icons.Default.Contrast, "Toggle theme") } })
        }, bottomBar = {
            NavigationBar {
                listOf("Reader" to Icons.Default.MenuBook, "Library" to Icons.Default.CollectionsBookmark, "Audio" to Icons.Default.Mic, "Scan" to Icons.Default.DocumentScanner, "More" to Icons.Default.MoreHoriz).forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, name) }, label = { Text(name) })
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                when (tab) {
                    "Reader" -> ReaderScreen(current, speed, { speed = it }, onSpeak = { text ->
                        tts?.setSpeechRate(speed); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pipit-read")
                    }, onImport = { textPicker.launch(arrayOf("text/plain", "text/markdown")) }, onSave = { title, body ->
                        val d = ReaderDoc(System.currentTimeMillis().toString(), title.ifBlank { "Untitled document" }, body); saveDoc(store, d); docs = loadDocs(store); current = d
                    }, status = status)
                    "Library" -> LibraryScreen(docs, query, { query = it }, onOpen = { current = it; tab = "Reader" }, onImport = { textPicker.launch(arrayOf("text/plain", "text/markdown")) })
                    "Audio" -> AudioScreen(transcript, liveText, listening, status, language,
                        onLanguage = { language = it }, onStart = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                listening = true; status = "Listening…"; startRecognition(speechRecognizer, language, { liveText = it }, { transcript = (transcript + "\n" + it).trim(); liveText = ""; listening = false; status = "Recognition finished" }, { status = it; listening = false })
                            } else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }, onStop = { speechRecognizer?.stopListening(); listening = false; status = "Stopped" }, onText = { transcript = it },
                        onSave = { if (transcript.isNotBlank()) { val d = ReaderDoc(System.currentTimeMillis().toString(), "Audio transcript · ${System.currentTimeMillis()}", transcript, "Transcript"); saveDoc(store, d); docs = loadDocs(store); current = d; tab = "Library" } },
                        onCopy = { status = "Select and copy transcript text" })
                    "Scan" -> ScanScreen(ocrText, status, onPick = { imagePicker.launch("image/*") }, onText = { ocrText = it }, onSave = {
                        if (ocrText.isNotBlank()) { val d = ReaderDoc(System.currentTimeMillis().toString(), "Scanned document", ocrText, "OCR"); saveDoc(store, d); docs = loadDocs(store); current = d; tab = "Reader" }
                    }, onRead = { tts?.speak(ocrText, TextToSpeech.QUEUE_FLUSH, null, "pipit-ocr") })
                    else -> MoreScreen(note, { note = it }, webUrl, { webUrl = it }, webText, { webText = it }, onOpenWeb = { status = "Web reading is available through the device browser in this starter build." }, onTheme = { dark = it }, dark = dark, onStatus = { status = it })
                }
            }
        }
    }
}

@Composable
fun ReaderScreen(doc: ReaderDoc, speed: Float, onSpeed: (Float) -> Unit, onSpeak: (String) -> Unit, onImport: () -> Unit, onSave: (String, String) -> Unit, status: String) {
    var title by remember(doc.id) { mutableStateOf(doc.title) }
    var body by remember(doc.id) { mutableStateOf(doc.body) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text(doc.kind.uppercase(), color = Muted, fontSize = 11.sp); Text(doc.title, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = onImport) { Icon(Icons.Default.FileOpen, null); Text("Import") }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text(body, fontSize = 18.sp, lineHeight = 29.sp)
            }
        }
        Text("Reading speed · ${"%.1f".format(speed)}×", fontWeight = FontWeight.SemiBold)
        Slider(value = speed, onValueChange = onSpeed, valueRange = 0.5f..2f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onSpeak(body) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlayArrow, null); Text("Read aloud") }
            OutlinedButton(onClick = { title = doc.title; body = doc.body; onSave(title, body) }) { Icon(Icons.Default.BookmarkAdd, null); Text("Save copy") }
        }
        Text(status, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun LibraryScreen(docs: List<ReaderDoc>, query: String, onQuery: (String) -> Unit, onOpen: (ReaderDoc) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), label = { Text("Search library") }, singleLine = true)
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Import TXT / Markdown") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(docs.filter { it.title.contains(query, true) || it.body.contains(query, true) }) { doc ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(doc) }) {
                    Column(Modifier.padding(14.dp)) { Text(doc.title, fontWeight = FontWeight.Bold); Text("${doc.kind} · ${doc.body.length} characters", color = Muted, fontSize = 12.sp); Text(doc.body.take(120).replace('\n', ' '), maxLines = 2, color = Muted) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioScreen(transcript: String, partial: String, listening: Boolean, status: String, language: String, onLanguage: (String) -> Unit, onStart: () -> Unit, onStop: () -> Unit, onText: (String) -> Unit, onSave: () -> Unit, onCopy: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Audio to text", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Transcribe speech from your microphone. Results depend on the speech recognition service installed on this Android device.", color = Muted)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(languageLabel(language), {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text("Recognition language") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                listOf("en-US", "bn-BD", "hi-IN", "ur-PK", "ar-SA", "fr-FR", "es-ES").forEach { code -> DropdownMenuItem(text = { Text(languageLabel(code)) }, onClick = { onLanguage(code); expanded = false }) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onStart, enabled = !listening, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Mic, null); Text("Start recording") }
            OutlinedButton(onClick = onStop, enabled = listening) { Icon(Icons.Default.Stop, null); Text("Stop") }
        }
        Text(status, color = Teal, fontWeight = FontWeight.SemiBold)
        if (partial.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE2F2EF))) { Text("Live: $partial", Modifier.padding(12.dp), color = Ink) }
        OutlinedTextField(transcript, onText, Modifier.fillMaxWidth().heightIn(min = 220.dp), label = { Text("Editable transcript") }, placeholder = { Text("Your recognised speech will appear here…") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onCopy, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ContentCopy, null); Text("Copy") }
            Button(onClick = onSave, enabled = transcript.isNotBlank(), modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Text("Save to library") }
        }
        HorizontalDivider()
        Text("Imported audio files", fontWeight = FontWeight.Bold)
        Text("Not connected in this starter build. True offline transcription of WAV / MP3 files requires a bundled or downloaded ASR model (for example sherpa-onnx) and its native Android runtime. This screen does not falsely route files through the live microphone recognizer.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun ScanScreen(text: String, status: String, onPick: () -> Unit, onText: (String) -> Unit, onSave: () -> Unit, onRead: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Scan & read", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("On-device ML Kit text recognition for Latin-script images. Bengali OCR needs a separate Tesseract ben.traineddata integration.", color = Muted)
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AddPhotoAlternate, null); Text("Choose image") }
        Text(status, color = Teal, fontSize = 13.sp)
        OutlinedTextField(text, onText, Modifier.fillMaxWidth().heightIn(min = 220.dp), label = { Text("Recognised text") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onRead, modifier = Modifier.weight(1f)) { Icon(Icons.Default.VolumeUp, null); Text("Read aloud") }; Button(onClick = onSave, enabled = text.isNotBlank(), modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Text("Save") } }
    }
}

@Composable
fun MoreScreen(note: String, onNote: (String) -> Unit, url: String, onUrl: (String) -> Unit, webText: String, onWebText: (String) -> Unit, onOpenWeb: () -> Unit, onTheme: (Boolean) -> Unit, dark: Boolean, onStatus: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("More tools", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Web reader", fontWeight = FontWeight.Bold); OutlinedTextField(url, onUrl, Modifier.fillMaxWidth(), label = { Text("Page URL") }); Button(onClick = onOpenWeb) { Text("Open page") }; OutlinedTextField(webText, onWebText, Modifier.fillMaxWidth(), label = { Text("Paste article text") }); Button(onClick = { onStatus("Article text is ready to import from the Reader tab.") }) { Text("Prepare text") } } }
        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Quick note", fontWeight = FontWeight.Bold); OutlinedTextField(note, onNote, Modifier.fillMaxWidth(), label = { Text("Write a note") }); Text("Notes are held in this screen during the current session.", color = Muted, fontSize = 12.sp) } }
        Card { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Dark appearance"); Switch(dark, onTheme) } }
        Text("Offline and privacy", fontWeight = FontWeight.Bold)
        Text("Documents are stored in the app's private local storage. Android speech recognition may use an online service unless the installed recognition provider supports offline language packs. Enable offline speech in Android system settings and test airplane mode before relying on it.", color = Muted)
    }
}

private fun startRecognition(recognizer: SpeechRecognizer?, language: String, onPartial: (String) -> Unit, onFinal: (String) -> Unit, onError: (String) -> Unit) {
    if (recognizer == null) { onError("Speech recognition is not available on this device."); return }
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onError(error: Int) { onError("Speech recognition error ($error). Check language support and offline speech pack.") }
        override fun onResults(results: Bundle?) { onFinal(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
        override fun onPartialResults(partialResults: Bundle?) { onPartial(partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
    }
    runCatching { recognizer.startListening(intent) }.onFailure { onError("Could not start microphone: ${it.localizedMessage}") }
}

private fun loadDocs(dir: File): List<ReaderDoc> = dir.listFiles()?.filter { it.extension == "txt" }?.mapNotNull { f ->
    runCatching { val parts = f.readText().split("\n", limit = 2); ReaderDoc(f.nameWithoutExtension, parts.first(), parts.getOrElse(1) { "" }) }.getOrNull()
}?.sortedByDescending { it.id } ?: emptyList()
private fun saveDoc(dir: File, doc: ReaderDoc) { runCatching { File(dir, "${doc.id}.txt").writeText(doc.title.replace("\n", " ") + "\n" + doc.body) } }
private fun fileName(context: android.content.Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, null, null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else "Imported text" } ?: "Imported text"
}.getOrDefault("Imported text")
private fun languageLabel(code: String) = when (code) { "en-US" -> "English"; "bn-BD" -> "বাংলা (Bengali)"; "hi-IN" -> "हिन्दी (Hindi)"; "ur-PK" -> "اردو (Urdu)"; "ar-SA" -> "العربية (Arabic)"; "fr-FR" -> "Français"; else -> "Español" }
