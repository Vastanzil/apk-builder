# Pipit — Android Gradle project

Native Kotlin + Jetpack Compose starter derived from the Pipit HTML prototype.

## Open and build

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. Android Studio → **Open** → select the `PipitAndroid` folder (the folder containing `settings.gradle.kts`).
4. Let Gradle sync. Use JDK 17 (Android Studio's embedded JBR is suitable).
5. Connect an Android device with USB debugging enabled, or create an emulator.
6. Select **app** and press Run. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Included in this starter

- Native Compose app and five bottom destinations: Reader, Library, Audio, Scan, More.
- Android TextToSpeech playback using the system's installed voices and adjustable rate.
- Import `.txt` and `.md` documents through Android's Storage Access Framework.
- Local private app storage for imported documents and saved transcripts.
- Live microphone speech recognition with language selection and partial transcript display.
- Requests offline recognition preference (`EXTRA_PREFER_OFFLINE`); actual offline behavior depends on the speech recognition provider and downloaded language packs.
- Latin-script image OCR using bundled ML Kit text recognition.
- Dark appearance toggle.

## Explicitly not complete yet

This is a native foundation, not a feature-complete production release. The following are not implemented in this build: prerecorded MP3/WAV transcription, offline sherpa-onnx model/runtime, Bengali OCR (`ben.traineddata` + Tesseract), PDF text extraction, word-synchronous TTS highlighting, background Media3 playback, MP3/M4A export, Readability web extraction, Room/FTS search, and an in-app LLM. The HTML prototype's sample/demo behavior has not been represented as real Android functionality.

### Audio transcription caveat

The Audio tab transcribes live microphone speech through Android `SpeechRecognizer`. `EXTRA_PREFER_OFFLINE` is only a preference; it does not guarantee that the device's recognition service works offline. For reliable fully offline transcription—including imported audio files—integrate sherpa-onnx with a tested ASR model and add model download/storage management. Do not market this starter as fully offline until tested in airplane mode on target phones.

### OCR caveat

The included ML Kit Latin recognizer is real. Bengali is not supported by this ML Kit recognizer; Bengali OCR requires a separately integrated Tesseract Bengali model. The current Scan screen clearly states this.

## Project configuration

- Namespace/application ID: `com.pipit.reader`
- Min SDK: 26
- Compile/target SDK: 35
- Java/Kotlin target: 17
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21

## First validation checklist

- [ ] Gradle sync completes in Android Studio.
- [ ] App launches on API 26+ device.
- [ ] Import a UTF-8 English and Bengali TXT file.
- [ ] Verify imported documents persist after force-stop/relaunch.
- [ ] Test TTS with installed English and Bengali voices.
- [ ] Grant microphone permission and test English/Bengali recognition.
- [ ] Test recognition in airplane mode; record which installed provider actually works offline.
- [ ] Scan a clear Latin-script image and check OCR output.
- [ ] Verify app behavior on a low-memory device.

No APK is included because this environment does not have the Android SDK/Gradle build toolchain installed. Build the APK locally using the steps above.
