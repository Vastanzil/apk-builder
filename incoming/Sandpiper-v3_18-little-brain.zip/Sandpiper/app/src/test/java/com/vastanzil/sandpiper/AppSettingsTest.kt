package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Registry option lists must agree with the values native code accepts. */
class AppSettingsTest {
    @Test fun registryOptionsMatchNativeChoices() {
        val reg = org.json.JSONObject(java.io.File("src/main/assets/features.json").readText()).getJSONArray("settings")
        fun options(id: String): List<Int> {
            for (i in 0 until reg.length()) {
                val s = reg.getJSONObject(i)
                if (s.getString("id") == id) { val o = s.getJSONArray("options"); return (0 until o.length()).map { o.getJSONArray(it).getInt(0) } }
            }
            return emptyList()
        }
        assertEquals(AppSettings.SNOOZE_CHOICES.toList(), options("alarms.snoozeMin"))
        assertEquals(AppSettings.RING_CHOICES.toList(), options("alarms.ringMax"))
        assertEquals(AppSettings.DAYEND_CHOICES.toList(), options("planner.dayEndHours"))
        assertTrue(AppSettings.SNOOZE_CHOICES.all { it > 0 })
    }

    @Test fun brainSettingsMatchNativeValues() {
        val reg = org.json.JSONObject(java.io.File("src/main/assets/features.json").readText()).getJSONArray("settings")
        val byKey = HashMap<String, org.json.JSONObject>()
        for (i in 0 until reg.length()) reg.getJSONObject(i).let { if (it.getString("feature") == "brain" && it.getString("store") == "app") byKey[it.getString("key")] = it }
        val mode = byKey.getValue("brainMode").getJSONArray("options")
        assertEquals(AppSettings.BRAIN_MODES, (0 until mode.length()).map { mode.getJSONArray(it).getString(0) })
        assertEquals(AppSettings.BRAIN_TASK_KEYS.toSet(), byKey.keys.filter { it in AppSettings.BRAIN_TASK_KEYS }.toSet())
        val b = byKey.getValue("brainBudget")
        assertEquals(AppSettings.BRAIN_BUDGET_MIN, b.getInt("min")); assertEquals(AppSettings.BRAIN_BUDGET_MAX, b.getInt("max")); assertEquals(AppSettings.BRAIN_BUDGET_DEFAULT, b.getInt("default"))
        for (k in AppSettings.BRAIN_TASK_KEYS) assertEquals(false, byKey.getValue(k).getBoolean("default"))   // every brain feature is opt-in
        // every LlmTask switch is a registered setting
        for (t in com.vastanzil.sandpiper.llm.LlmTask.values()) assertTrue(t.setting, t.setting in byKey)
    }
}
