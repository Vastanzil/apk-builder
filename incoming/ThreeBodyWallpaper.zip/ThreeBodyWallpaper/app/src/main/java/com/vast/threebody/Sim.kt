package com.vast.threebody

import android.graphics.Color
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class Body(
    var m: Double, var x: Double, var y: Double,
    var vx: Double, var vy: Double, val color: Int
) {
    var ax = 0.0
    var ay = 0.0
}

/** Newtonian 3-body gravity, 4th-order Yoshida symplectic integrator. Randomly re-seeded, so it never repeats. */
class Sim {
    companion object {
        const val G = 1.0
        const val EPS = 1e-3      // gravitational softening
        const val TRAIL = 900     // trail length in samples
        const val SPEED = 1.3     // simulated time units per real second
        private val W1 = 1.0 / (2.0 - Math.cbrt(2.0))
        private val W0 = -Math.cbrt(2.0) * W1
        private val C = doubleArrayOf(W1 / 2, (W0 + W1) / 2, (W0 + W1) / 2, W1 / 2)
        private val D = doubleArrayOf(W1, W0, W1)
        private val PALETTE = intArrayOf(
            Color.rgb(120, 180, 255), Color.rgb(255, 190, 90), Color.rgb(255, 100, 110),
            Color.rgb(150, 255, 200), Color.rgb(200, 140, 255)
        )
    }

    var bodies: List<Body> = emptyList()
    private val trail = Array(3) { FloatArray(TRAIL * 2) }
    private var head = 0
    var count = 0
        private set
    var fade = 0.0
    private var age = 0.0

    init { seed() }

    fun seed() {
        val cols = PALETTE.toMutableList().apply { shuffle() }
        val b = List(3) { i ->
            val a = Random.nextDouble() * 2 * Math.PI
            val r = sqrt(Random.nextDouble()) * 1.2 + 0.2
            Body(
                0.7 + Random.nextDouble() * 0.8,
                r * cos(a), r * sin(a),
                Random.nextDouble() - 0.5, Random.nextDouble() - 0.5,
                cols[i]
            )
        }
        var mt = 0.0; var px = 0.0; var py = 0.0; var cx = 0.0; var cy = 0.0
        for (o in b) { mt += o.m; px += o.m * o.vx; py += o.m * o.vy; cx += o.m * o.x; cy += o.m * o.y }
        for (o in b) { o.vx -= px / mt; o.vy -= py / mt; o.x -= cx / mt; o.y -= cy / mt }
        var k = 0.0
        for (o in b) k += 0.5 * o.m * (o.vx * o.vx + o.vy * o.vy)
        var u = 0.0
        for (i in 0 until 3) for (j in i + 1 until 3) {
            val dx = b[i].x - b[j].x; val dy = b[i].y - b[j].y
            u -= G * b[i].m * b[j].m / sqrt(dx * dx + dy * dy + EPS)
        }
        val q = 0.2 + Random.nextDouble() * 0.4   // virial ratio -> bound, lively system
        val f = sqrt(q * abs(u) / (2 * k))
        for (o in b) { o.vx *= f; o.vy *= f }
        bodies = b
        head = 0; count = 0; fade = 0.0; age = 0.0
    }

    private fun acc() {
        val b = bodies
        for (o in b) { o.ax = 0.0; o.ay = 0.0 }
        for (i in 0 until 3) for (j in i + 1 until 3) {
            val dx = b[j].x - b[i].x; val dy = b[j].y - b[i].y
            val d2 = dx * dx + dy * dy + EPS
            val id = G / (d2 * sqrt(d2))
            b[i].ax += b[j].m * dx * id; b[i].ay += b[j].m * dy * id
            b[j].ax -= b[i].m * dx * id; b[j].ay -= b[i].m * dy * id
        }
    }

    private fun step(h: Double) {
        for (s in 0 until 3) {
            for (o in bodies) { o.x += C[s] * h * o.vx; o.y += C[s] * h * o.vy }
            acc()
            for (o in bodies) { o.vx += D[s] * h * o.ax; o.vy += D[s] * h * o.ay }
        }
        for (o in bodies) { o.x += C[3] * h * o.vx; o.y += C[3] * h * o.vy }
    }

    private fun minDist(): Double {
        var m = 1e9
        for (i in 0 until 3) for (j in i + 1 until 3) {
            val dx = bodies[i].x - bodies[j].x; val dy = bodies[i].y - bodies[j].y
            m = min(m, sqrt(dx * dx + dy * dy))
        }
        return m
    }

    private fun escaped(): Boolean {
        var cx = 0.0; var cy = 0.0; var mt = 0.0
        for (o in bodies) { mt += o.m; cx += o.m * o.x; cy += o.m * o.y }
        cx /= mt; cy /= mt
        for (o in bodies) {
            val dx = o.x - cx; val dy = o.y - cy
            val d = sqrt(dx * dx + dy * dy)
            if (d.isNaN() || d.isInfinite()) return true
            val vr = (o.vx * dx + o.vy * dy) / (if (d == 0.0) 1.0 else d)
            if (d > 9 && vr > 0) return true
        }
        return false
    }

    fun advance(realDt: Double) {
        var t = realDt * SPEED
        var guard = 0
        while (t > 0 && guard++ < 3000) {
            var h = min(0.012, max(2e-5, 0.03 * minDist().pow(1.5)))
            if (h > t) h = t
            step(h)
            t -= h
        }
        age += realDt
        for (i in 0 until 3) {
            trail[i][head * 2] = bodies[i].x.toFloat()
            trail[i][head * 2 + 1] = bodies[i].y.toFloat()
        }
        head = (head + 1) % TRAIL
        if (count < TRAIL) count++
        if (escaped() || age > 600) seed()
        fade = min(1.0, fade + realDt * 0.5)
    }

    private fun idx(k: Int) = ((head - count + k) % TRAIL + TRAIL) % TRAIL
    fun tx(body: Int, k: Int) = trail[body][idx(k) * 2]
    fun ty(body: Int, k: Int) = trail[body][idx(k) * 2 + 1]
}
