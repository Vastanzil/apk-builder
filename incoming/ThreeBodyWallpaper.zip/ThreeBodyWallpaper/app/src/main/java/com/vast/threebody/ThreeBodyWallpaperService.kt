package com.vast.threebody

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

class ThreeBodyWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ThreeBodyEngine()

    inner class ThreeBodyEngine : Engine(), Choreographer.FrameCallback {

        private val TARGET_FPS = 60          // lower (e.g. 30) to save battery
        private val minDt = 1.0 / TARGET_FPS - 0.002
        private val SEG = 14

        private val sim = Sim()
        private var w = 0
        private var h = 0
        private var visible = false
        private var lastNs = 0L

        private var camX = 0.0
        private var camY = 0.0
        private var camS = 0.0

        private var stars = FloatArray(0)
        private var vignette: RadialGradient? = null
        private val bgPaint = Paint()
        private val starPaint = Paint().apply { color = Color.argb(150, 255, 255, 255); strokeCap = Paint.Cap.ROUND }
        private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
        private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; xfermode = add
        }
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }
        private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width; h = height
            camS = 0.0
            stars = FloatArray(2 * 220) { i -> if (i % 2 == 0) Random.nextFloat() * w else Random.nextFloat() * h }
            vignette = RadialGradient(
                w / 2f, h / 2f, h * 0.7f,
                Color.argb(115, 20, 25, 60), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            val c = Choreographer.getInstance()
            c.removeFrameCallback(this)
            if (v) { lastNs = 0L; c.postFrameCallback(this) }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            super.onDestroy()
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            if (lastNs == 0L) lastNs = frameTimeNanos
            val dt = (frameTimeNanos - lastNs) / 1e9
            if (dt >= minDt) {
                lastNs = frameTimeNanos
                val d = min(dt, 0.05)
                sim.advance(d)
                updateCamera(d)
                draw()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun updateCamera(dt: Double) {
            if (w == 0 || h == 0) return
            var cx = 0.0; var cy = 0.0; var m = 0.0
            for (b in sim.bodies) { m += b.m; cx += b.m * b.x; cy += b.m * b.y }
            cx /= m; cy /= m
            val aspect = w.toDouble() / h
            var ext = 0.8
            for (b in sim.bodies) ext = max(ext, max(abs(b.x - cx) * 1.25, abs(b.y - cy) * aspect * 1.25))
            val target = w * 0.42 / ext
            if (camS == 0.0) { camS = target; camX = cx; camY = cy; return }
            camS += (target - camS) * min(1.0, dt * 1.2)
            camX += (cx - camX) * min(1.0, dt * 2.0)
            camY += (cy - camY) * min(1.0, dt * 2.0)
        }

        private fun draw() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = try { holder.lockHardwareCanvas() } catch (e: Exception) { holder.lockCanvas() }
                if (c != null) render(c)
            } catch (e: Exception) {
                // surface not ready; skip frame
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
        }

        private fun render(c: Canvas) {
            c.drawColor(Color.rgb(2, 3, 10))
            vignette?.let { bgPaint.shader = it; c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint) }
            starPaint.strokeWidth = max(1.5f, w / 600f)
            c.drawPoints(stars, starPaint)

            val fade = sim.fade
            val n = sim.count
            val s = camS
            val hw = w / 2.0; val hh = h / 2.0
            fun px(x: Float) = (hw + (x - camX) * s).toFloat()
            fun py(y: Float) = (hh + (y - camY) * s).toFloat()
            val dpr = w / 400f

            for ((i, b) in sim.bodies.withIndex()) {
                val r = Color.red(b.color); val g = Color.green(b.color); val bl = Color.blue(b.color)
                var k = 0
                while (k + 1 < n) {
                    val e = min(k + SEG, n - 1)
                    val frac = k.toFloat() / n
                    val a = (frac.toDouble().pow(1.6) * 0.8 * fade * 255).toInt().coerceIn(0, 255)
                    trailPaint.color = Color.argb(a, r, g, bl)
                    trailPaint.strokeWidth = (0.6f + 2.2f * frac) * dpr
                    path.reset()
                    path.moveTo(px(sim.tx(i, k)), py(sim.ty(i, k)))
                    for (q in k + 1..e) path.lineTo(px(sim.tx(i, q)), py(sim.ty(i, q)))
                    c.drawPath(path, trailPaint)
                    k += SEG
                }
                val bx = (hw + (b.x - camX) * s).toFloat()
                val by = (hh + (b.y - camY) * s).toFloat()
                val rad = (7f + 9f * b.m.toFloat()) * dpr
                glowPaint.shader = RadialGradient(
                    bx, by, rad * 4,
                    Color.argb((140 * fade).toInt(), r, g, bl), Color.argb(0, r, g, bl),
                    Shader.TileMode.CLAMP
                )
                c.drawCircle(bx, by, rad * 4, glowPaint)
                corePaint.color = Color.argb((255 * fade).toInt(), 255, 255, 255)
                c.drawCircle(bx, by, rad * 0.35f, corePaint)
            }
        }
    }
}
