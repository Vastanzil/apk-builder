# Three Body Live Wallpaper: build guide

## What you need
- A PC or Mac (Windows, macOS or Linux)
- Android Studio (latest stable): https://developer.android.com/studio
- A USB cable, or any way to copy a file to your phone

## Build the APK (Android Studio)
1. Unzip `ThreeBodyWallpaper.zip`.
2. Android Studio: File > Open > select the `ThreeBodyWallpaper` folder.
3. Wait for "Gradle sync" to finish (first time downloads Gradle and the Android SDK 34; accept the SDK licence prompts if asked).
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. The file is:
   `app/build/outputs/apk/debug/app-debug.apk`

## Install on the OnePlus 13R
1. Copy `app-debug.apk` to the phone (USB, Google Drive, Telegram, etc.).
2. Open it with the Files app. When asked, allow "Install unknown apps" for that app, then install.
   If Play Protect warns, choose "Install anyway" (it is your own unsigned debug build).
3. Open the new "Three Body" app. It jumps straight to the live wallpaper preview.
4. Tap "Set wallpaper" and choose Home screen, Lock screen, or both.

Alternative: install over USB with debugging enabled: `adb install app-debug.apk`

## Command-line build (optional)
Needs JDK 17 and the Android SDK.
```
gradle wrapper --gradle-version 8.7     # once, creates ./gradlew
./gradlew assembleDebug                 # Windows: gradlew.bat assembleDebug
```

## Release (signed) APK, optional
Build > Generate Signed Bundle / APK > APK > create a new keystore (keep it safe) > choose "release" > Finish.
Output: `app/release/app-release.apk`.

## Tweak it
Constants in `Sim.kt`:
- `SPEED` simulation speed (higher is faster)
- `TRAIL` trail length
- `EPS` softening (lower allows tighter, wilder close encounters)
- virial ratio `q` in `seed()` controls how energetic new systems are

In `ThreeBodyWallpaperService.kt`:
- `TARGET_FPS` 60 smooth, 30 saves battery

## Troubleshooting
- Sync error about JDK: File > Settings > Build Tools > Gradle > set Gradle JDK to 17 (the bundled JBR works).
- Wallpaper doesn't appear in the picker: uninstall and reinstall, then open the "Three Body" app.
- Battery: the simulation pauses automatically when the screen is off or the wallpaper isn't visible.
