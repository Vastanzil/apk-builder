# Assist (v1.17.0): what is built and where

Floating bubble on Home (the only place it appears; the dashboard itself is unchanged) opens a full-screen chat. Rules do the understanding and the work; an optional brain only maps a sentence to one intent.

| Piece | File |
|---|---|
| Bubble, chat, rules, actions with Undo / confirm, voice UI | `assets/assist.js` |
| Sleep estimate card (More > Sleep journal), Week / Month reports (Track Record) | `assets/insights.js` |
| Small hooks + `window.SpApp` | `assets/index.html` |
| Intent mapper for the brain (strict validation, numbers must appear in the sentence) | `llm/LlmCore.kt` `AssistIntentSpec` (task `ask_data`, setting `brainChat`) |
| Screen-off night estimate (pure) | `SleepCore.kt` |
| `sleepEstimate`, `assistListen/Stop/Speak`, `savePdf` | `Bridge.kt`, `AssistVoice.kt` |
| Settings > Assist | `features.json` feature `assist` (state keys `assistTrust`, `assistLang`, `assistSpeak`, `sleepAuto`, `weeklyPrep`) |

Rules: money always asks (every trust level); safe actions run with Undo; reads never write. Sleep estimates are never written to the journal until the user confirms; a manual entry always wins; corrections shift future estimates (median of the last 7, max 60 min). No network code was added; speech uses the phone's own recogniser/TTS (offline preferred).

Not built: cloud model key and custom model URL (need INTERNET, outside the current no-network rule), Bangla sentence understanding beyond digits and a few words (voice language only changes recognition/TTS).

Verified here: JS in headless Chromium with a fake native bridge. NOT compiled or run on a device: all Kotlin (`SleepCore`, `AssistVoice`, Bridge additions, `AssistIntentSpec`) and their JUnit tests.
