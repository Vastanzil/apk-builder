# Life OS: how the widgets must work (parallel, one truth)

## Principle
Sandpiper is one system with **one source of truth per domain**. The app screen, the home-screen widgets, the SMS reader, the scheduler and the future Brain are **parallel clients** of the same data. No client keeps its own copy, its own timer or its own rules. A change made by any client is visible to all of them.

```
      clients (parallel)                      core (one truth each)                     fan-out
  app screens (web UI) ─┐                 Planner tasks   -> PlannerStore (native)  ─┐
  home-screen widgets  ─┼── write via ──> Activity ledger -> ActivityStore (native)  ─┼─> LifeBus.changed()
  SMS / scheduler      ─┤  the same API   Focus timer     -> FocusTimer   (native)   │     -> all widgets refresh
  Little brain         ─┘                 Finance / voice -> FinanceStore / VoiceStore (native)
```

## Domain table: where each thing lives and who may write it
| Domain | Single source | App | Widget | Same ids? |
|---|---|---|---|---|
| Daily/Weekly/Monthly tasks | PlannerStore | via bridge | Planner + To-do widgets write it directly | task id |
| Activity ledger (graphs, summaries) | ActivityStore | via bridge | widgets add events directly | `tx:`/`focus:`/`voice:` ids shared with the app |
| **Focus timer** | **FocusTimer (native)** | Zen screen is a view of it | Focus widget is a view of it | one state; sessions `focus:<end>` |
| Finance transactions | **FinanceStore (native `fin_tx`)** | via bridge (`S.txs` is a cache) | writes it directly + ledger event | tx id |
| Voice recordings | **VoiceStore (native `voice_note` + `Sandpiper/recordings`)** | upload/list/play via bridge | writes file + row directly + ledger event | voice id |
| Settings (categories, currency, timer length) | central settings | edits | widgets read | n/a |

## What was wrong before (found in the audit)
1. **Two focus timers.** The app's Zen screen had its own JS timer; the widget had another. They could run together and double-count sessions. Now one native timer; both are views of it. Mode (focus / short break / long break every 4th) lives there too.
2. **Widgets refreshed only when the web layer called a few bridge methods.** A change made by the SMS reader, a widget or the scheduler never refreshed other widgets. Now every native store calls `LifeBus.changed()` after a successful write.
3. **The app kept showing a stale task list** after the user came back from a widget. Now `onAppResume` reloads lists and drains the widget inbox.
4. **Nothing showed whether a tap reached Sandpiper.** Now every widget tap is logged (Diagnostics > Widgets) and Settings > Home-screen widgets > Test widgets checks receivers, storage, the inbox, the timer and the recorder.
5. **Voice start depended on background rules and unusual encoder settings.** Now it starts from an invisible screen that waits until recording really runs, asks for the microphone itself, and records AAC 44.1 kHz / 64 kbps (accepted everywhere). No time limit.

## The former gap is closed (v1.16.0)
Finance transactions and voice notes now live in native storage (`fin_tx`, `voice_note` + files in `Sandpiper/recordings`). The widgets write them directly, the app reads the same rows, so there is no queue and nothing waits for the app to open. See `STORAGE.md`.

## If a widget tap still does nothing
Run Settings > Home-screen widgets > **Test widgets**, then open Diagnostics and look for "Widget action" lines right after you tap.
- Test shows FAIL: send me that line, it names the broken part.
- Test passes but **no "Widget action" line appears after a tap**: the phone blocked the tap before Sandpiper ran. This is the usual behaviour of Xiaomi/Redmi/POCO (MIUI/HyperOS), Oppo/Realme/OnePlus, Vivo/iQOO, Infinix/Tecno: allow **Autostart**, set battery to **No restrictions**, and lock Sandpiper in Recents. The `+` (planner) and Record (voice) taps use screens instead of broadcasts, so they are the first to work on such phones.
