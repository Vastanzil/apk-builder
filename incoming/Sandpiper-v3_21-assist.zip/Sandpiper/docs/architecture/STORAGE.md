# Sandpiper folder and native storage (v1.16.0)

Everything you own lives in **Internal storage/Sandpiper/** (visible in the Files app):

```
Sandpiper/
  db/          sandpiper.db            the database (tasks, finance, voice list, activity, settings, Piper, Sprout ...)
  recordings/  <id>.m4a / .webm        voice notes (app recorder and Voice widget)
  planner/     planner.json            readable copy of tasks and history (rewritten after changes)
  finance/     transactions.json       readable copy of transactions (rewritten after changes)
  backup/      sandpiper-backup-*.json manual backups; backup/auto/sandpiper-YYYY-MM-DD.db = automatic daily database copy, last 7 kept
  import/      drop a backup .json here, then Settings > Sandpiper folder > Restore
  export/      CSV exports, voice notes copied out, other files
  README.txt
```

## Permission
Android only lets an app use this folder with **All files access** (Android 11+) or storage permission (Android 10). Settings > Sandpiper folder shows a "Needs Files access · Fix" chip. Without it Sandpiper works exactly the same but keeps the same folder tree in private app storage.

## Native storage for finance and voice
- **Finance**: table `fin_tx` (CentralDb v9). The Finance screen, the Finance widget and Sprout read the same rows; `S.txs` in the web layer is only a cache. First run after the upgrade moves what the app already had into native storage; restoring a backup replaces the table.
- **Voice notes**: audio file in `recordings/` + table `voice_note`. The app recorder uploads to it in 768 KB pieces; the Voice widget writes the file directly. Recordings kept earlier in the browser store (IndexedDB) and earlier widget recordings are moved over automatically. Playback loads the file in pieces, so any length works.

## How the database is moved (safety rules)
1. Only with Files access. The old private database is never deleted.
2. The copy is made after folding in the old write-ahead log, and is adopted only if `PRAGMA quick_check` says `ok`.
3. Which copy is the truth is remembered (`db_live`), not guessed from file dates. If the private one was live (access had been off) it replaces the shared one, and the replaced file is kept in `backup/`.
4. The shared database uses the rollback journal (not WAL: its shared-memory file is unreliable on shared storage).
5. While the shared database is live, a **shadow copy** is refreshed in private storage (15 s after any change and whenever the app leaves the screen). Losing Files access, or deleting the Sandpiper folder, restores from the shadow or the newest daily copy.
6. A damaged database is set aside in `backup/` and replaced from the shadow or the newest daily copy.
After granting Files access, **restart Sandpiper** once: the database moves at the next start (Settings shows "restart Sandpiper to move the database there"). Files (recordings, exports) move immediately.

## Not moved
Custom alarm tones (private copies of sounds you picked) and the diagnostics log stay in private app storage.

## Not verified
Not compiled and not run on a device here. Test on the phone: grant Files access, restart, check Sandpiper/db/sandpiper.db appears, add a task/transaction, record a voice note, tap Settings > Home-screen widgets > Test widgets, then clear nothing and reboot. Also try: revoke Files access, reopen (data must still be there), grant again.
