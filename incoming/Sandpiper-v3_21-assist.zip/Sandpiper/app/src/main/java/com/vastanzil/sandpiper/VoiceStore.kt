package com.vastanzil.sandpiper

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Base64
import com.vastanzil.sandpiper.widget.VoiceCore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile

/**
 * Voice notes in native storage: the audio is a file in Sandpiper/recordings/, the list is the table voice_note. The app's recorder and
 * the Voice widget both register notes here. Files are never deleted unless the user deletes that note.
 */
internal object VoiceStore {
    fun createTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS voice_note(id TEXT PRIMARY KEY, title TEXT NOT NULL, created INTEGER NOT NULL, dur INTEGER NOT NULL, file TEXT NOT NULL, bytes INTEGER NOT NULL, mime TEXT NOT NULL)")
    }

    private fun db(c: Context) = CentralDb.get(c).writableDatabase
    private fun dir(c: Context) = StorageRoot.dir(c, "recordings")

    fun extFor(mime: String): String = when {
        mime.contains("mp4") || mime.contains("aac") || mime.contains("m4a") -> "m4a"
        mime.contains("webm") -> "webm"
        mime.contains("ogg") -> "ogg"
        mime.contains("wav") -> "wav"
        else -> "bin"
    }

    fun mimeFor(ext: String): String = when (ext) { "m4a" -> "audio/mp4"; "webm" -> "audio/webm"; "ogg" -> "audio/ogg"; "wav" -> "audio/wav"; else -> "application/octet-stream" }

    /** Temp name used while a recording is in progress; only these are ever cleaned up automatically. */
    fun tempFile(c: Context, id: String): File = File(dir(c), "$id.m4a.rec")
    fun finalFile(c: Context, id: String, ext: String = "m4a"): File = File(dir(c), "$id.$ext")

    /** The widget finished a recording: [f] is already in recordings/. */
    fun register(c: Context, id: String, f: File, mime: String, title: String, created: Long, dur: Long): Boolean {
        if (!VoiceCore.isId(id) || !f.isFile || f.length() <= 0L) return false
        return try {
            val cv = ContentValues().apply { put("id", id); put("title", title.take(80)); put("created", created); put("dur", dur); put("file", f.name); put("bytes", f.length()); put("mime", mime) }
            val ok = db(c).insertWithOnConflict("voice_note", null, cv, SQLiteDatabase.CONFLICT_REPLACE) != -1L
            if (ok) LifeBus.changed(c)
            ok
        } catch (e: Exception) { false }
    }

    // ---- upload from the web recorder, piece by piece ----
    fun put(c: Context, id: String, index: Int, b64: String): Boolean {
        if (!VoiceCore.isId(id)) return false
        return try {
            val part = File(dir(c), "$id.part")
            if (index == 0 && part.exists()) part.delete()
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            part.appendBytes(bytes)
            true
        } catch (e: Exception) { false }
    }

    fun done(c: Context, id: String, mime: String, title: String, created: Long, dur: Long): Boolean {
        if (!VoiceCore.isId(id)) return false
        return try {
            val part = File(dir(c), "$id.part")
            if (!part.isFile || part.length() <= 0L) return false
            val dst = finalFile(c, id, extFor(mime))
            if (dst.exists()) dst.delete()
            if (!part.renameTo(dst)) return false
            register(c, id, dst, mime, title, created, dur)
        } catch (e: Exception) { false }
    }

    private fun fileOf(c: Context, id: String): File? {
        if (!VoiceCore.isId(id)) return null
        val name: String = (try { db(c).rawQuery("SELECT file FROM voice_note WHERE id=?", arrayOf(id)).use { if (it.moveToFirst()) it.getString(0) else null } } catch (e: Exception) { null }) ?: return null
        return StorageRoot.find(c, "recordings", name)
    }

    fun list(c: Context): JSONArray {
        val out = JSONArray()
        try {
            db(c).rawQuery("SELECT id,title,created,dur,bytes,mime FROM voice_note ORDER BY created DESC", null).use {
                while (it.moveToNext()) out.put(JSONObject().put("id", it.getString(0)).put("title", it.getString(1)).put("created", it.getLong(2))
                    .put("dur", it.getLong(3)).put("bytes", it.getLong(4)).put("mime", it.getString(5)))
            }
        } catch (e: Exception) { }
        return out
    }

    fun count(c: Context): Int = try { db(c).rawQuery("SELECT COUNT(*) FROM voice_note", null).use { if (it.moveToFirst()) it.getInt(0) else 0 } } catch (e: Exception) { 0 }

    fun size(c: Context, id: String): Long = fileOf(c, id)?.length() ?: 0L

    fun chunk(c: Context, id: String, offset: Long, len: Int): String {
        val f = fileOf(c, id) ?: return ""
        if (offset < 0 || offset >= f.length()) return ""
        val n = minOf(len.toLong().coerceIn(1L, VoiceCore.CHUNK.toLong()), f.length() - offset).toInt()
        return try { RandomAccessFile(f, "r").use { r -> val b = ByteArray(n); r.seek(offset); r.readFully(b); Base64.encodeToString(b, Base64.NO_WRAP) } } catch (e: Exception) { "" }
    }

    fun delete(c: Context, id: String): Boolean {
        val f = fileOf(c, id)
        return try {
            val n = db(c).delete("voice_note", "id=?", arrayOf(id))
            f?.delete()
            if (n > 0) LifeBus.changed(c)
            n > 0
        } catch (e: Exception) { false }
    }

    /** Copies a note into Sandpiper/export/ and returns the file name ("" on failure). */
    fun exportCopy(c: Context, id: String): String {
        val f = fileOf(c, id) ?: return ""
        return try {
            var to = File(StorageRoot.dir(c, "export"), "sandpiper-voice-" + f.name)
            if (to.exists()) to = File(StorageRoot.dir(c, "export"), "sandpiper-voice-" + System.currentTimeMillis() + "-" + f.name)
            f.copyTo(to, overwrite = false); to.name
        } catch (e: Exception) { "" }
    }

    /** Recordings made while a recording process died leave *.rec files: remove those older than 10 minutes (never any other file). */
    fun cleanupTemp(c: Context) {
        try { dir(c).listFiles { f -> f.name.endsWith(".rec") || f.name.endsWith(".part") }?.forEach { if (System.currentTimeMillis() - it.lastModified() > 600_000L) it.delete() } } catch (e: Exception) { }
    }
}
