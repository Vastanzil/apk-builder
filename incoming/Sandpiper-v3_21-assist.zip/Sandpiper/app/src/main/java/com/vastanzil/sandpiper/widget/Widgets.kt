package com.vastanzil.sandpiper.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.vastanzil.sandpiper.DCat
import com.vastanzil.sandpiper.DEv
import com.vastanzil.sandpiper.DLvl
import com.vastanzil.sandpiper.DMod
import com.vastanzil.sandpiper.DRes
import com.vastanzil.sandpiper.Diag

/** Shared helpers for every widget. Nothing here ever starts an Activity: that is the point of the widgets. */
internal object Widgets {
    private const val PREFS = "sp_widgets"
    fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun flags() = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Explicit broadcast to a widget provider. The data URI keeps every button's PendingIntent distinct (extras alone would not). */
    fun bcast(c: Context, cls: Class<*>, action: String, widgetId: Int, tag: String = ""): PendingIntent {
        val i = Intent(c, cls).setAction(action).setData(Uri.parse("spw://$widgetId/$action/$tag"))
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId).putExtra("tag", tag)
        return PendingIntent.getBroadcast(c, 0, i, flags())
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var pending: Runnable? = null

    /** Debounced: many app writes in a row refresh the widgets once. */
    fun refreshSoon(c: Context) {
        val app = c.applicationContext
        pending?.let { main.removeCallbacks(it) }
        val r = Runnable { refreshAll(app) }
        pending = r
        main.postDelayed(r, 400L)
    }

    fun refreshAll(c0: Context) {
        val c = c0.applicationContext
        val m = AppWidgetManager.getInstance(c)
        fun ids(cls: Class<*>) = m.getAppWidgetIds(ComponentName(c, cls))
        guard { PlannerWidget.update(c, m, ids(PlannerWidget::class.java)) }
        guard { TodoWidget.update(c, m, ids(TodoWidget::class.java)) }
        guard { FinanceWidget.update(c, m, ids(FinanceWidget::class.java)) }
        guard { GraphWidget.update(c, m, ids(GraphWidget::class.java)) }
        guard { PomodoroWidget.update(c, m, ids(PomodoroWidget::class.java)) }
        guard { VoiceWidget.update(c, m, ids(VoiceWidget::class.java)) }
    }

    /** A broken widget must never take the app (or the other widgets) down. */
    inline fun guard(body: () -> Unit) {
        try { body() } catch (e: Exception) {
            Diag.log(DLvl.W, DCat.WIDGET, DEv.WIDGET_FAIL, DMod.WIDGETS, DRes.FAIL, code = Diag.codeOf(e))
        }
    }

    /** Every widget tap that reaches the app is logged (code only). If a tap shows nothing here, the phone blocked it before Sandpiper ran. */
    fun acted(code: Int) = Diag.log(DLvl.I, DCat.WIDGET, DEv.WIDGET_ACTION, DMod.WIDGETS, DRes.OK, n = code.toLong())

    fun wrote(kindOrdinal: Int) = Diag.log(DLvl.I, DCat.WIDGET, DEv.WIDGET_WRITE, DMod.WIDGETS, DRes.OK, n = kindOrdinal.toLong())
}
