package com.vastanzil.sandpiper.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.app.PendingIntent
import android.net.Uri
import com.vastanzil.sandpiper.R

/**
 * Voice note without opening Sandpiper: one tap starts recording (no time limit) (a microphone foreground service with a Stop button in its
 * notification), one tap stops and saves. The file goes to private storage, the ledger gets voice:<id>, and the Notes recordings
 * list imports it on next open. The microphone permission is granted once in the app; after that the widget never needs the app.
 */
class VoiceWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)

    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        if (i.action != ACTION_STOP) { super.onReceive(c0, i); return }
        Widgets.acted(51)
        Widgets.guard {
            if (VoiceRecordService.running) c.startService(Intent(c, VoiceRecordService::class.java).setAction(VoiceRecordService.ACTION_STOP))
            else { Widgets.prefs(c).edit().putLong(REC_START, 0L).apply(); Widgets.refreshAll(c) }
        }
    }

    companion object {
        const val ACTION_STOP = "com.vastanzil.sandpiper.widget.VOICE_STOP_TAP"
        const val MSG = "voice_msg"
        const val REC_START = "voice_rec_start"       // SystemClock.elapsedRealtime() at start; 0 = not recording

        fun update(c: Context, m: AppWidgetManager, ids: IntArray) {
            val p = Widgets.prefs(c)
            var start = p.getLong(REC_START, 0L)
            if (start > 0L && !VoiceRecordService.running) { p.edit().putLong(REC_START, 0L).apply(); start = 0L }   // the process died mid-recording
            if (start == 0L) com.vastanzil.sandpiper.VoiceStore.cleanupTemp(c)
            for (id in ids) {
                val v = RemoteViews(c.packageName, R.layout.widget_voice)
                if (start > 0L) {
                    v.setViewVisibility(R.id.w_chrono, View.VISIBLE); v.setViewVisibility(R.id.w_clock, View.GONE)
                    v.setChronometerCountDown(R.id.w_chrono, false)
                    v.setChronometer(R.id.w_chrono, start, null, true)
                    v.setTextViewText(R.id.w_status, "Recording"); v.setTextViewText(R.id.w_main, "\u25A0  Stop")
                    v.setInt(R.id.w_main, "setBackgroundResource", R.drawable.widget_key_danger)
                } else {
                    v.setViewVisibility(R.id.w_chrono, View.GONE); v.setViewVisibility(R.id.w_clock, View.VISIBLE)
                    v.setTextViewText(R.id.w_clock, p.getString(MSG, null) ?: "Tap to record")
                    v.setTextViewText(R.id.w_status, "Voice note"); v.setTextViewText(R.id.w_main, "\u25CF  Record")
                    v.setInt(R.id.w_main, "setBackgroundResource", R.drawable.widget_key_accent)
                }
                v.setOnClickPendingIntent(R.id.w_main,
                    if (start > 0L) Widgets.bcast(c, VoiceWidget::class.java, ACTION_STOP, id)
                    else PendingIntent.getActivity(c, 200 + id, Intent(c, VoiceTapActivity::class.java).setData(Uri.parse("spw://$id/voice")), Widgets.flags()))
                m.updateAppWidget(id, v)
            }
        }
    }
}
