package com.vastanzil.sandpiper

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject

/**
 * Finance transactions in native storage (CentralDb table fin_tx, inside Sandpiper/db/). The app's Finance screen and the Finance widget
 * are both clients of this table. Shape = the web layer's own {id,name,cat,amount,kind,ts}. Writes are idempotent by id.
 */
internal object FinanceStore {
    private val ID = Regex("^[A-Za-z0-9._:\\-]{1,64}$")
    const val MAX_AMOUNT = 1e12

    fun createTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS fin_tx(id TEXT PRIMARY KEY, name TEXT NOT NULL, cat TEXT NOT NULL, amount REAL NOT NULL, kind TEXT NOT NULL, ts INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS fin_tx_ts ON fin_tx(ts)")
    }

    private fun db(c: Context) = CentralDb.get(c).writableDatabase

    /** Null when the record is not acceptable (never stored). */
    fun clean(o: JSONObject): ContentValues? {
        val id = o.optString("id")
        val amount = o.optDouble("amount", Double.NaN)
        val kind = o.optString("kind")
        val ts = o.optLong("ts", 0L)
        if (!ID.matches(id) || amount.isNaN() || amount.isInfinite() || amount <= 0.0 || amount > MAX_AMOUNT) return null
        if (kind != "income" && kind != "expense") return null
        if (ts <= 0L) return null
        val name = o.optString("name").trim().take(60).ifEmpty { o.optString("cat").trim().take(60) }
        if (name.isEmpty()) return null
        return ContentValues().apply {
            put("id", id); put("name", name); put("cat", o.optString("cat").trim().take(30).ifEmpty { "Other" })
            put("amount", Math.round(amount * 100.0) / 100.0); put("kind", kind); put("ts", ts); put("updated_at", System.currentTimeMillis())
        }
    }

    fun add(c: Context, o: JSONObject): Boolean {
        val cv = clean(o) ?: return false
        return try {
            val ok = db(c).insertWithOnConflict("fin_tx", null, cv, SQLiteDatabase.CONFLICT_REPLACE) != -1L
            if (ok) LifeBus.changed(c)
            ok
        } catch (e: Exception) { false }
    }

    fun delete(c: Context, id: String): Boolean = try {
        val n = db(c).delete("fin_tx", "id=?", arrayOf(id))
        if (n > 0) LifeBus.changed(c)
        n > 0
    } catch (e: Exception) { false }

    fun list(c: Context): JSONArray {
        val out = JSONArray()
        try {
            db(c).rawQuery("SELECT id,name,cat,amount,kind,ts FROM fin_tx ORDER BY ts DESC LIMIT 200000", null).use {
                while (it.moveToNext()) out.put(JSONObject().put("id", it.getString(0)).put("name", it.getString(1)).put("cat", it.getString(2))
                    .put("amount", it.getDouble(3)).put("kind", it.getString(4)).put("ts", it.getLong(5)))
            }
        } catch (e: Exception) { /* empty */ }
        return out
    }

    fun count(c: Context): Int = try { db(c).rawQuery("SELECT COUNT(*) FROM fin_tx", null).use { if (it.moveToFirst()) it.getInt(0) else 0 } } catch (e: Exception) { 0 }

    /** Replaces the whole table (restore / first-run migration) in one transaction; invalid rows are skipped. Returns rows stored, -1 on failure. */
    fun replaceAll(c: Context, arr: JSONArray): Int {
        val d = db(c)
        var n = 0
        d.beginTransaction()
        try {
            d.delete("fin_tx", null, null)
            for (i in 0 until arr.length()) {
                val cv = clean(arr.optJSONObject(i) ?: continue) ?: continue
                d.insertWithOnConflict("fin_tx", null, cv, SQLiteDatabase.CONFLICT_REPLACE); n++
            }
            d.setTransactionSuccessful()
        } catch (e: Exception) { return -1 } finally { d.endTransaction() }
        LifeBus.changed(c)
        return n
    }
}
