package com.vastanzil.sandpiper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Where Sandpiper keeps everything you own: Internal storage/Sandpiper/
 *   db/          the database (sandpiper.db)
 *   recordings/  voice notes
 *   planner/     planner.json, a readable copy of your tasks
 *   finance/     transactions.json, a readable copy of your transactions
 *   backup/      backups (manual, plus an automatic daily database copy in backup/auto)
 *   import/      drop a backup file here and restore it from Settings
 *   export/      CSV and other exports
 * This needs "All files access" (Android 11+) or storage permission (Android 10). Without it everything still works and lives in
 * the app's private storage (same sub-folders); granting it later moves the files over (promote) and the database after a restart.
 */
internal object StorageRoot {
    const val NAME = "Sandpiper"
    val SUBS = listOf("db", "recordings", "planner", "finance", "backup", "import", "export")

    fun hasAccess(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(c, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun sharedRoot(): File = File(Environment.getExternalStorageDirectory(), NAME)
    fun privateRoot(c: Context): File = File(c.applicationContext.filesDir, NAME)

    fun usingShared(c: Context): Boolean = hasAccess(c) && try {
        val r = sharedRoot(); r.mkdirs(); r.isDirectory && r.canWrite()
    } catch (e: Exception) { false }

    fun root(c: Context): File = (if (usingShared(c)) sharedRoot() else privateRoot(c)).also { it.mkdirs() }
    fun dir(c: Context, sub: String): File = File(root(c), sub).also { it.mkdirs() }

    /** A file may still sit in the private fallback if access was granted after it was written: look in both. */
    fun find(c: Context, sub: String, name: String): File? {
        if (name.contains('/') || name.contains('\\') || name.startsWith(".")) return null
        val a = File(dir(c, sub), name)
        if (a.isFile) return a
        val b = File(File(privateRoot(c), sub), name)
        return if (b.isFile) b else null
    }

    fun ensureTree(c: Context) {
        for (s in SUBS) dir(c, s)
        File(dir(c, "backup"), "auto").mkdirs()
        val readme = File(root(c), "README.txt")
        if (!readme.exists()) try {
            readme.writeText("Sandpiper folder\n\ndb/          database (sandpiper.db)\nrecordings/  voice notes\nplanner/     planner.json (readable copy of your tasks)\nfinance/     transactions.json (readable copy of your transactions)\nbackup/      backups; backup/auto has a daily database copy (last 7 kept)\nimport/      put a backup file here, then Settings > Sandpiper folder > Restore\nexport/      CSV and other exports\n\nDo not edit files in db/ while Sandpiper is open.\n")
        } catch (e: Exception) { }
    }

    /** Moves what accumulated in the private fallback folder into the shared one (never overwrites, verifies sizes). */
    fun promote(c: Context) {
        if (!usingShared(c)) return
        for (s in SUBS) {
            if (s == "db") continue
            val from = File(privateRoot(c), s)
            val files = from.listFiles() ?: continue
            for (f in files) {
                if (!f.isFile) continue
                try {
                    var to = File(dir(c, s), f.name)
                    if (to.exists() && to.length() == f.length()) { f.delete(); continue }
                    if (to.exists()) to = File(dir(c, s), f.nameWithoutExtension + "-private-" + System.currentTimeMillis() + (if (f.extension.isEmpty()) "" else "." + f.extension))
                    f.copyTo(to, overwrite = false)
                    if (to.length() == f.length()) f.delete() else to.delete()
                } catch (e: Exception) { /* leave it where it is; tried again next start */ }
            }
        }
    }

    fun label(c: Context): String = if (usingShared(c)) "Internal storage/" + NAME else "App-private storage"
}
