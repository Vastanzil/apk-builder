package com.vastanzil.sandpiper

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import java.util.Locale

/**
 * Assist voice: push-to-talk recognition and read-aloud, both through the phone's own speech services.
 * Sandpiper itself has no network code; it only asks the system recogniser (offline preferred). Main thread only.
 */
class AssistVoice(private val a: MainActivity) {
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    private fun push(text: String, fin: Boolean, err: String = "") =
        a.js("window.onAssistHeard&&onAssistHeard(" + JSONObject.quote(text) + "," + fin + "," + JSONObject.quote(err) + ")")

    private fun locale(lang: String): Locale = when (lang) {
        "bn" -> Locale.forLanguageTag("bn-BD")
        "en" -> Locale.US
        else -> Locale.getDefault()
    }

    fun listen(lang: String) = a.runOnUiThread {
        runCatching {
            if (!SpeechRecognizer.isRecognitionAvailable(a)) { push("", true, "unavailable"); return@runOnUiThread }
            stopNow()
            val r = SpeechRecognizer.createSpeechRecognizer(a)
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    push(t, true, if (t.isEmpty()) "empty" else "")
                }
                override fun onPartialResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    push(t, false)
                }
                override fun onError(e: Int) = push("", true, if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "empty" else "error")
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr = r
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            if (lang != "auto") i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale(lang).toLanguageTag())
            r.startListening(i)
        }.onFailure { push("", true, "error") }
    }

    /** Ends the recording; the final text still arrives through onAssistHeard. */
    fun stop() = a.runOnUiThread { runCatching { sr?.stopListening() } }

    private fun stopNow() { runCatching { sr?.cancel(); sr?.destroy() }; sr = null }

    fun speak(text: String, lang: String) = a.runOnUiThread {
        runCatching {
            val say = { val t = tts; if (t != null) { t.language = locale(lang); t.speak(text.take(600), TextToSpeech.QUEUE_FLUSH, null, "assist") } }
            if (tts != null && ttsOk) say()
            else tts = TextToSpeech(a) { st -> ttsOk = st == TextToSpeech.SUCCESS; if (ttsOk) say() }
        }
    }

    fun shutdown() = a.runOnUiThread {
        stopNow()
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null; ttsOk = false
    }
}
