package com.vastanzil.sandpiper.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.vastanzil.sandpiper.ActivityStore
import com.vastanzil.sandpiper.AppSettings
import com.vastanzil.sandpiper.DCat
import com.vastanzil.sandpiper.DEv
import com.vastanzil.sandpiper.DLvl
import com.vastanzil.sandpiper.DMod
import com.vastanzil.sandpiper.DRes
import com.vastanzil.sandpiper.Diag
import com.vastanzil.sandpiper.LifeBus
import com.vastanzil.sandpiper.Notifier
import org.json.JSONObject

/**
 * THE focus timer. One state for the whole phone; the app's Zen screen and the Focus widget are two views of it.
 * Start/pause/reset from either side changes the same record; the end of a session (exact alarm, works with the app closed) writes
 * the ledger events (focus:<end>, focus.n:<end>), queues the session for the focus garden, advances Focus -> Break -> Focus
 * (every 4th session earns the long break) and posts one notification. Completion is idempotent: ids come from the end time.
 */
internal object FocusTimer {
    const val ACTION_ALARM = "com.vastanzil.sandpiper.widget.FOCUS_ALARM"
    private const val KEY = "pom"
    private const val COUNT = "focus_count"
    private const val RC = 7001

    fun state(c: Context): PomState {
        val s = PomState.decode(Widgets.prefs(c).getString(KEY, null))
        return if (s.phase == PomPhase.IDLE) PomState.idle(s.mode, FocusCore.minutes(s.mode, AppSettings.pomMin(c))) else s
    }

    private fun put(c: Context, s: PomState) {
        Widgets.prefs(c).edit().putString(KEY, s.encode()).apply()
        arm(c, s)
        LifeBus.changed(c)
    }

    /** Settles a session that has ended (alarm missed after a reboot, or the alarm itself). True when something was completed. */
    fun settle(c: Context, slackMs: Long = 0L): Boolean {
        val s = state(c)
        if (s.phase != PomPhase.RUNNING) return false
        if (System.currentTimeMillis() + slackMs < s.endAtMs) { arm(c, s); return false }
        complete(c, s)
        return true
    }

    fun start(c: Context, mode: String?): PomState {
        val now = System.currentTimeMillis()
        val st = state(c)
        if (st.phase == PomPhase.RUNNING) return st
        if (st.phase == PomPhase.PAUSED && (mode.isNullOrEmpty() || mode == st.mode)) { put(c, st.resume(now)); return state(c) }
        val m = if (mode != null && FocusCore.isMode(mode)) mode else st.mode
        val n = st.start(now, FocusCore.minutes(m, AppSettings.pomMin(c)), m)
        put(c, n)
        return n
    }

    fun pause(c: Context): PomState { val s = state(c).pause(System.currentTimeMillis()); put(c, s); return s }

    fun toggle(c: Context): PomState = if (state(c).phase == PomPhase.RUNNING) pause(c) else start(c, null)

    /** Back to the start of [mode] (or the current mode). */
    fun reset(c: Context, mode: String?): PomState {
        val m = if (mode != null && FocusCore.isMode(mode)) mode else state(c).mode
        val s = PomState.idle(m, FocusCore.minutes(m, AppSettings.pomMin(c)))
        put(c, s)
        return s
    }

    /** The app tells us how many sessions it already has, once, so the every-4th long break stays in step. */
    fun seed(c: Context, sessions: Int) {
        val p = Widgets.prefs(c)
        if (!p.contains(COUNT) && sessions >= 0) p.edit().putInt(COUNT, sessions).apply()
    }

    fun json(c: Context): String {
        settle(c)
        val s = state(c)
        return JSONObject().put("mode", s.mode).put("running", s.phase == PomPhase.RUNNING).put("paused", s.phase == PomPhase.PAUSED)
            .put("remain", (s.remaining(System.currentTimeMillis()) + 999) / 1000).put("total", s.totalMin * 60)
            .put("count", Widgets.prefs(c).getInt(COUNT, 0)).toString()
    }

    private fun complete(c: Context, s: PomState) {
        val p = Widgets.prefs(c)
        var count = p.getInt(COUNT, 0)
        if (s.mode == "focus") {
            for ((id, metric, value) in s.doneEvents(s.endAtMs)) ActivityStore.add(c, id, s.endAtMs, metric, value)
            WidgetStore.enqueue(c, WidgetKinds.FOCUS, "f${s.endAtMs}", JSONObject().put("ts", s.endAtMs).put("min", s.totalMin).toString(), s.endAtMs)
            count += 1
            p.edit().putInt(COUNT, count).apply()
            Diag.log(DLvl.I, DCat.WIDGET, DEv.POMODORO_DONE, DMod.WIDGETS, DRes.OK, n = s.totalMin.toLong())
            Widgets.wrote(2)
        }
        val next = FocusCore.nextMode(s.mode, count)
        put(c, PomState.idle(next, FocusCore.minutes(next, AppSettings.pomMin(c))))
        if (AppSettings.pomNotify(c))
            Notifier.show(c, "focus-end", "reminder", if (s.mode == "focus") "Focus session complete. Your tree grew." else "Break is over. Ready to focus?")
    }

    private fun alarmIntent(c: Context): PendingIntent =
        PendingIntent.getBroadcast(c, RC, Intent(c, FocusAlarmReceiver::class.java).setAction(ACTION_ALARM), Widgets.flags())

    /** Exact alarm while running (falls back to an inexact one when the exact-alarm permission is off). */
    private fun arm(c: Context, s: PomState) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        val pi = alarmIntent(c)
        am.cancel(pi)
        if (s.phase != PomPhase.RUNNING) return
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endAtMs, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endAtMs, pi)
        } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endAtMs, pi) }
    }
}

class FocusAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        Widgets.guard { FocusTimer.settle(c, slackMs = 1500L) }
        Widgets.refreshAll(c)
    }
}
