package com.vastanzil.sandpiper.widget

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.vastanzil.sandpiper.PlannerCore
import com.vastanzil.sandpiper.PlannerStore

/**
 * The widget's "+" opens this small floating box over the home screen (not the Sandpiper app): type, press Add, done.
 * It writes to PlannerStore, the same table the app's Daily/Weekly/Monthly lists read, then refreshes the widgets and closes.
 * It runs in its own task and is not kept in Recents.
 */
class QuickAddActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val period = (intent.getStringExtra("period") ?: "daily").let { if (PlannerCore.isPeriod(it)) it else "daily" }
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        val box = EditText(this).apply {
            hint = "New " + (TaskListCore.PERIOD_LABEL[period] ?: "daily").lowercase() + " task"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
        }
        val add = Button(this).apply { text = "Add" }
        val cancel = Button(this).apply { text = "Cancel" }
        fun submit() {
            val t = box.text.toString()
            if (t.isBlank()) { finish(); return }
            Widgets.acted(12)
            Widgets.guard {
                if (PlannerStore.add(applicationContext, period, t) != null) { Widgets.wrote(0); Widgets.refreshAll(applicationContext) }
                else Toast.makeText(applicationContext, "Could not add that task.", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
        add.setOnClickListener { submit() }
        cancel.setOnClickListener { finish() }
        box.setOnEditorActionListener { _, _, _ -> submit(); true }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; addView(cancel); addView(add) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(8))
            addView(TextView(this@QuickAddActivity).apply { text = "Add to planner"; textSize = 16f })
            addView(box, LinearLayout.LayoutParams(px(280), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(row)
        }
        setContentView(col)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setFinishOnTouchOutside(true)
        box.requestFocus()
    }
}
