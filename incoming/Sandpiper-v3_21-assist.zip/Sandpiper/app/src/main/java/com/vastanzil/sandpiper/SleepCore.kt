package com.vastanzil.sandpiper

import org.json.JSONArray
import org.json.JSONObject

/**
 * Estimates last night's sleep from how long the screen stayed off. Pure Kotlin (no Android imports) so plain JUnit covers it.
 * Input: screen-off intervals as [startMs, endMs]. Brief screen-on checks (up to [MERGE_GAP_MS]) do not split the night; they are reported as gaps.
 * This is an estimate from phone idle time, not a medical measurement, and the user's own entry always wins.
 */
object SleepCore {
    const val MERGE_GAP_MS = 20L * 60_000
    const val MIN_NIGHT_MS = 3L * 3_600_000

    data class Est(val bed: Long, val wake: Long, val checks: List<Long>, val confidence: Int) {
        val mins: Long get() = (wake - bed) / 60_000
        fun json(): JSONObject = JSONObject().put("ok", true).put("bed", bed).put("wake", wake).put("mins", mins)
            .put("conf", confidence).put("checks", JSONArray(checks))
    }

    fun estimate(off: List<LongArray>, winStart: Long, winEnd: Long): Est? {
        val clipped = off.mapNotNull { v ->
            val s = maxOf(v[0], winStart); val e = minOf(v[1], winEnd)
            if (e > s) longArrayOf(s, e) else null
        }.sortedBy { it[0] }
        if (clipped.isEmpty()) return null
        val merged = ArrayList<LongArray>()
        val gapsOf = ArrayList<MutableList<Long>>()
        for (v in clipped) {
            val last = merged.lastOrNull()
            if (last != null && v[0] - last[1] <= MERGE_GAP_MS) {
                gapsOf.last().add(last[1])
                last[1] = maxOf(last[1], v[1])
            } else { merged.add(longArrayOf(v[0], v[1])); gapsOf.add(ArrayList()) }
        }
        var best = 0
        for (i in merged.indices) if (merged[i][1] - merged[i][0] > merged[best][1] - merged[best][0]) best = i
        val b = merged[best]
        val len = b[1] - b[0]
        if (len < MIN_NIGHT_MS) return null
        val checks = gapsOf[best]
        val hours = len / 3_600_000.0
        val conf = (50 + minOf(30.0, (hours - 3) * 6) - 6 * minOf(checks.size, 4)).toInt().coerceIn(30, 95)
        return Est(b[0], b[1], checks, conf)
    }
}
