package com.vastanzil.sandpiper.widget

import android.Manifest
import android.app.AlarmManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.vastanzil.sandpiper.PlannerStore
import org.json.JSONArray
import org.json.JSONObject

/**
 * "Test widgets" (Settings > Home-screen widgets) and the diagnostics row CHK_WIDGETS. Non-destructive: it writes nothing into the
 * planner or the ledger (the inbox probe row is removed again). Each line is {name, ok, note}. ok=false means a real fault inside
 * Sandpiper; permissions the user simply has not granted yet are ok=true with a note saying what is needed.
 */
internal object WidgetSelfTest {
    fun run(c: Context): JSONArray {
        val out = JSONArray()
        fun line(name: String, ok: Boolean, note: String) { out.put(JSONObject().put("name", name).put("ok", ok).put("note", note)) }

        val m = AppWidgetManager.getInstance(c)
        val classes = listOf("Planner" to PlannerWidget::class.java, "To-do" to TodoWidget::class.java, "Finance" to FinanceWidget::class.java,
            "Graph" to GraphWidget::class.java, "Focus" to PomodoroWidget::class.java, "Voice" to VoiceWidget::class.java)
        val placed = classes.joinToString(", ") { (n, cls) -> n + " " + m.getAppWidgetIds(ComponentName(c, cls)).size }
        line("Widgets on your home screen", true, placed)

        val missing = ArrayList<String>()
        for ((n, cls) in classes) try { c.packageManager.getReceiverInfo(ComponentName(c, cls), 0) } catch (e: Exception) { missing.add(n) }
        line("Widget receivers registered", missing.isEmpty(), if (missing.isEmpty()) "all six" else "missing: " + missing.joinToString())

        run {
            val sh = com.vastanzil.sandpiper.StorageRoot.usingShared(c)
            line("Sandpiper folder", true, com.vastanzil.sandpiper.StorageRoot.label(c) + if (sh && !com.vastanzil.sandpiper.DbLocation.shared) " (restart Sandpiper to move the database there)" else "")
        }
        try { val f = com.vastanzil.sandpiper.FinanceStore.count(c); val v = com.vastanzil.sandpiper.VoiceStore.count(c); line("Finance and voice storage", true, "$f transactions, $v voice notes") }
        catch (e: Exception) { line("Finance and voice storage", false, e.javaClass.simpleName) }
        try { PlannerStore.listTasks(c, "daily"); line("Planner storage readable", true, "same tables the app uses") }
        catch (e: Exception) { line("Planner storage readable", false, e.javaClass.simpleName) }

        try {
            val id = "selftest" + System.currentTimeMillis().toString(36)
            val wrote = WidgetStore.enqueue(c, "selftest", id, "{\"x\":1}", System.currentTimeMillis())
            val seen = (0 until WidgetStore.take(c, 200).length()).any { WidgetStore.take(c, 200).optJSONObject(it)?.optString("id") == "selftest:$id" }
            val gone = WidgetStore.ack(c, JSONArray().put("selftest:$id")) == 1
            line("Widget inbox write/read/remove", wrote && seen && gone, "pending for the app: " + WidgetStore.pending(c))
        } catch (e: Exception) { line("Widget inbox write/read/remove", false, e.javaClass.simpleName) }

        try { val s = FocusTimer.state(c); line("Focus timer state", true, s.mode + " " + s.phase.name.lowercase()) }
        catch (e: Exception) { line("Focus timer state", false, e.javaClass.simpleName) }

        try { MediaRecorder().release(); line("Recorder available", true, "this phone can record audio") }
        catch (e: Throwable) { line("Recorder available", false, e.javaClass.simpleName) }

        val mic = ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        line("Microphone", true, if (mic) "allowed" else "not allowed yet: the Record button will ask on first use")
        line("Notifications", true, if (NotificationManagerCompat.from(c).areNotificationsEnabled()) "allowed" else "off: the focus-done alert will not show")
        val exact = Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java)?.canScheduleExactAlarms() == true
        line("Exact alarms", true, if (exact) "allowed" else "off: the focus timer may end a few minutes late")
        return out
    }

    /** (all required checks passed, number of checks). */
    fun summary(c: Context): Pair<Boolean, Long> {
        val a = run(c)
        var ok = true
        for (i in 0 until a.length()) if (!a.getJSONObject(i).getBoolean("ok")) ok = false
        return ok to a.length().toLong()
    }
}
