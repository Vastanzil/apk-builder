package com.vastanzil.sandpiper.widget

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Base64
import com.vastanzil.sandpiper.CentralDb
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * widget_inbox (CentralDb v8): records a widget wrote natively that belong to the web layer's own storage (finance list, focus garden,
 * voice recordings). Written the moment the user taps, deleted only after the web layer imported them and said so (ack).
 * Row id = "<kind>:<record id>", so a retried write replaces itself and can never duplicate.
 */
internal object WidgetStore {
    fun createTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS widget_inbox(id TEXT PRIMARY KEY, kind TEXT NOT NULL, json TEXT NOT NULL, ts INTEGER NOT NULL)")
    }

    private fun db(c: Context) = CentralDb.get(c).writableDatabase

    @Synchronized
    fun enqueue(c: Context, kind: String, id: String, json: String, ts: Long): Boolean = try {
        val cv = ContentValues().apply { put("id", "$kind:$id"); put("kind", kind); put("json", json); put("ts", ts) }
        db(c).insertWithOnConflict("widget_inbox", null, cv, SQLiteDatabase.CONFLICT_REPLACE) != -1L
    } catch (e: Exception) { false }

    fun take(c: Context, limit: Int): JSONArray {
        val out = JSONArray()
        try {
            db(c).rawQuery("SELECT id, kind, json, ts FROM widget_inbox ORDER BY ts LIMIT ?", arrayOf(limit.coerceIn(1, 200).toString())).use {
                while (it.moveToNext()) {
                    val data = try { JSONObject(it.getString(2)) } catch (e: Exception) { continue }
                    out.put(JSONObject().put("id", it.getString(0)).put("kind", it.getString(1)).put("ts", it.getLong(3)).put("data", data))
                }
            }
        } catch (e: Exception) { /* empty */ }
        return out
    }

    @Synchronized
    fun ack(c: Context, ids: JSONArray): Int {
        var n = 0
        try {
            val d = db(c)
            for (i in 0 until ids.length()) {
                val id = ids.optString(i, "")
                if (id.isEmpty()) continue
                n += d.delete("widget_inbox", "id=?", arrayOf(id))
            }
        } catch (e: Exception) { /* keep what is left for the next open */ }
        return n
    }

    fun pending(c: Context): Int = try {
        db(c).rawQuery("SELECT COUNT(*) FROM widget_inbox", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (e: Exception) { 0 }

}
