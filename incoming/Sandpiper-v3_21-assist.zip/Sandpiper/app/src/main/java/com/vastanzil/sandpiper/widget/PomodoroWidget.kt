package com.vastanzil.sandpiper.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.vastanzil.sandpiper.R

/**
 * Focus widget: a second view of the ONE focus timer (FocusTimer), the same one the app's Zen screen shows. Start from the widget and
 * the app shows it running; pause in the app and the widget shows paused. The countdown is a Chronometer (drawn by the system).
 */
class PomodoroWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = update(c, m, ids)

    override fun onReceive(c0: Context, i: Intent) {
        val c = c0.applicationContext
        when (i.action) {
            ACTION_MAIN -> Widgets.guard { Widgets.acted(40); FocusTimer.toggle(c) }
            ACTION_RESET -> Widgets.guard { Widgets.acted(41); FocusTimer.reset(c, null) }
            else -> { super.onReceive(c0, i); return }
        }
        Widgets.refreshAll(c)
    }

    companion object {
        const val ACTION_MAIN = "com.vastanzil.sandpiper.widget.POM_MAIN"
        const val ACTION_RESET = "com.vastanzil.sandpiper.widget.POM_RESET"

        fun update(c: Context, m: AppWidgetManager, ids: IntArray) {
            FocusTimer.settle(c)                                   // a session that ended while nothing was running
            val s = FocusTimer.state(c)
            val now = System.currentTimeMillis()
            val label = FocusCore.label(s.mode)
            for (id in ids) {
                val v = RemoteViews(c.packageName, R.layout.widget_pomodoro)
                when (s.phase) {
                    PomPhase.RUNNING -> {
                        v.setViewVisibility(R.id.w_chrono, View.VISIBLE); v.setViewVisibility(R.id.w_clock, View.GONE)
                        v.setChronometerCountDown(R.id.w_chrono, true)
                        v.setChronometer(R.id.w_chrono, SystemClock.elapsedRealtime() + s.remaining(now), null, true)
                        v.setTextViewText(R.id.w_status, label); v.setTextViewText(R.id.w_main, "Pause")
                    }
                    PomPhase.PAUSED -> {
                        v.setViewVisibility(R.id.w_chrono, View.GONE); v.setViewVisibility(R.id.w_clock, View.VISIBLE)
                        v.setTextViewText(R.id.w_clock, PomState.clock(s.remaining(now)))
                        v.setTextViewText(R.id.w_status, "$label paused"); v.setTextViewText(R.id.w_main, "Resume")
                    }
                    PomPhase.IDLE -> {
                        v.setViewVisibility(R.id.w_chrono, View.GONE); v.setViewVisibility(R.id.w_clock, View.VISIBLE)
                        v.setTextViewText(R.id.w_clock, PomState.clock(s.remaining(now)))
                        v.setTextViewText(R.id.w_status, if (s.mode == "focus") "Ready" else "Break ready")
                        v.setTextViewText(R.id.w_main, if (s.mode == "focus") "Start" else "Start break")
                    }
                }
                v.setViewVisibility(R.id.w_reset, if (s.phase == PomPhase.IDLE) View.GONE else View.VISIBLE)
                v.setOnClickPendingIntent(R.id.w_main, Widgets.bcast(c, PomodoroWidget::class.java, ACTION_MAIN, id))
                v.setOnClickPendingIntent(R.id.w_reset, Widgets.bcast(c, PomodoroWidget::class.java, ACTION_RESET, id))
                m.updateAppWidget(id, v)
            }
        }
    }
}
