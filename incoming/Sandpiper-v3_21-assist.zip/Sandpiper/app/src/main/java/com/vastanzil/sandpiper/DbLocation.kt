package com.vastanzil.sandpiper

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File

/**
 * Decides where the database file lives and moves it there safely.
 *  - With Files access: Sandpiper/db/sandpiper.db (rollback-journal mode, not WAL: WAL's shared-memory file is unreliable on shared storage).
 *  - Without: the usual private location (WAL).
 * The old file is never deleted. It becomes the shadow: while the shared copy is live, StorageJobs keeps the private file refreshed,
 * so losing Files access (or deleting the folder) never loses data. Which one is truth is remembered in "db_live", not guessed from dates.
 * A copy is only adopted after PRAGMA quick_check passes on it.
 */
internal object DbLocation {
    private const val PREF = "sp_storage"
    private const val LIVE = "db_live"
    @Volatile var shared = false
        private set

    fun privateFile(c: Context): File = c.applicationContext.getDatabasePath(CentralDb.NAME)
    fun sharedFile(c: Context): File = File(StorageRoot.dir(c, "db"), "sandpiper.db")

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun path(c0: Context): String {
        val c = c0.applicationContext
        val priv = privateFile(c)
        shared = false
        if (!StorageRoot.usingShared(c)) { prefs(c).edit().putString(LIVE, "private").apply(); return priv.path }
        return try {
            StorageRoot.ensureTree(c)
            val target = sharedFile(c)
            val live = prefs(c).getString(LIVE, null)
            when {
                !target.exists() -> {
                    val src = when { priv.exists() -> priv; else -> newestAuto(c) }
                    if (src != null && !copyVerified(src, target)) throw IllegalStateException("copy")
                }
                live != "shared" && priv.exists() -> {          // the private file was the live one (e.g. access had been off): adopt it
                    aside(c, target, "replaced-shared")
                    if (!copyVerified(priv, target)) throw IllegalStateException("adopt")
                }
                !integrityOk(target) -> {                        // damaged or edited from outside
                    aside(c, target, "damaged")
                    val src = if (priv.exists() && integrityOk(priv)) priv else newestAuto(c)
                    if (src != null && !copyVerified(src, target)) throw IllegalStateException("restore")
                }
            }
            shared = true
            prefs(c).edit().putString(LIVE, "shared").apply()
            target.path
        } catch (e: Exception) {
            shared = false
            prefs(c).edit().putString(LIVE, "private").apply()
            priv.path
        }
    }

    fun newestAuto(c: Context): File? =
        File(StorageRoot.dir(c, "backup"), "auto").listFiles { f -> f.isFile && f.name.endsWith(".db") }
            ?.sortedByDescending { it.lastModified() }?.firstOrNull { integrityOk(it) }

    /** Keeps a file we are about to replace in backup/ so nothing is ever lost silently. */
    private fun aside(c: Context, f: File, tag: String) {
        try { if (f.exists()) f.copyTo(File(StorageRoot.dir(c, "backup"), "sandpiper-$tag-" + System.currentTimeMillis() + ".db"), overwrite = false) } catch (e: Exception) { }
    }

    fun integrityOk(f: File): Boolean = try {
        SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY).use { d ->
            d.rawQuery("PRAGMA quick_check", null).use { it.moveToFirst() && it.getString(0) == "ok" }
        }
    } catch (e: Exception) { false }

    /** Copies a database that is NOT open, folding its WAL in first, and only keeps the copy if it passes the integrity check. */
    private fun copyVerified(src: File, dst: File): Boolean {
        return try {
            try {
                SQLiteDatabase.openDatabase(src.path, null, SQLiteDatabase.OPEN_READWRITE).use { d -> d.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() } }
            } catch (e: Exception) { /* read-only source: copy as it is */ }
            dst.parentFile?.mkdirs()
            val tmp = File(dst.parentFile, dst.name + ".tmp")
            src.copyTo(tmp, overwrite = true)
            if (!integrityOk(tmp)) { tmp.delete(); return false }
            if (dst.exists()) dst.delete()
            tmp.renameTo(dst)
        } catch (e: Exception) { false }
    }

    /** Copies the LIVE database (open) to [dest] while holding a read lock so the file cannot change mid-copy. */
    fun snapshotLive(c: Context, dest: File): Boolean {
        return try {
            val db = CentralDb.get(c).writableDatabase
            try { db.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() } } catch (e: Exception) { }
            val tmp = File(dest.parentFile, dest.name + ".tmp")
            dest.parentFile?.mkdirs()
            db.beginTransactionNonExclusive()
            try {
                db.rawQuery("SELECT count(*) FROM sqlite_master", null).use { it.moveToFirst() }     // takes the read lock
                File(db.path).copyTo(tmp, overwrite = true)
            } finally { db.endTransaction() }
            if (dest.exists()) dest.delete()
            tmp.renameTo(dest)
        } catch (e: Exception) { false }
    }
}
