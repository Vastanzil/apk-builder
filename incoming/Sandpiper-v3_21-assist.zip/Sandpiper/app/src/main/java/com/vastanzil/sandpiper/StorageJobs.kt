package com.vastanzil.sandpiper

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.time.LocalDate
import java.util.concurrent.Executors

/**
 * Background housekeeping for the Sandpiper folder. Runs off the main thread, never throws.
 *  - shadow: while the database lives in Sandpiper/db, a copy is kept in the private location (so losing Files access loses nothing)
 *  - daily database copy in backup/auto (last 7 kept)
 *  - readable mirrors: planner/planner.json and finance/transactions.json
 *  - startup: promote files from the private fallback, move older widget voice files into recordings/
 * Triggered by LifeBus (debounced 15 s after any change) and when the app leaves the screen.
 */
internal object StorageJobs {
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "sp-storage").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var pending: Runnable? = null

    fun startup(c0: Context) {
        val c = c0.applicationContext
        io.execute {
            try {
                StorageRoot.ensureTree(c)
                StorageRoot.promote(c)
                VoiceStore.cleanupTemp(c)
                migrateLegacyWidgetVoice(c)
                snapshotNow(c)
            } catch (e: Throwable) { }
        }
    }

    fun schedule(c0: Context) {
        val c = c0.applicationContext
        pending?.let { main.removeCallbacks(it) }
        val r = Runnable { io.execute { try { snapshotNow(c) } catch (e: Throwable) { } } }
        pending = r
        main.postDelayed(r, 15_000L)
    }

    fun flushNow(c0: Context) { val c = c0.applicationContext; io.execute { try { snapshotNow(c) } catch (e: Throwable) { } } }

    private fun snapshotNow(c: Context) {
        if (DbLocation.shared) {
            DbLocation.snapshotLive(c, DbLocation.privateFile(c))                 // shadow
            val auto = File(StorageRoot.dir(c, "backup"), "auto").apply { mkdirs() }
            val today = File(auto, "sandpiper-" + LocalDate.now() + ".db")
            if (!today.exists()) DbLocation.snapshotLive(c, today)
            auto.listFiles { f -> f.name.startsWith("sandpiper-") && f.name.endsWith(".db") }?.sortedByDescending { it.name }?.drop(7)?.forEach { it.delete() }
        }
        write(File(StorageRoot.dir(c, "planner"), "planner.json"), PlannerStore.exportAll(c).toString(2))
        write(File(StorageRoot.dir(c, "finance"), "transactions.json"), FinanceStore.list(c).toString(2))
    }

    private fun write(f: File, text: String) {
        try { val t = File(f.parentFile, f.name + ".tmp"); t.writeText(text); if (f.exists()) f.delete(); t.renameTo(f) } catch (e: Exception) { }
    }

    /** Voice notes recorded by earlier widget versions sit in filesDir/voice with an inbox row: register them in the new store. */
    private fun migrateLegacyWidgetVoice(c: Context) {
        try {
            val rows = com.vastanzil.sandpiper.widget.WidgetStore.take(c, 200)
            val acked = org.json.JSONArray()
            for (i in 0 until rows.length()) {
                val r = rows.getJSONObject(i)
                if (r.getString("kind") != "voice") continue
                val d = r.getJSONObject("data")
                val id = d.optString("id")
                val old = File(File(c.filesDir, "voice"), "$id.m4a")
                if (com.vastanzil.sandpiper.widget.VoiceCore.isId(id) && old.isFile) {
                    val dst = VoiceStore.finalFile(c, id)
                    if (!dst.exists()) old.copyTo(dst)
                    if (VoiceStore.register(c, id, dst, "audio/mp4", "Voice note " + java.util.Date(d.optLong("ts")).toString(), d.optLong("ts"), d.optLong("dur"))) { old.delete(); acked.put(r.getString("id")) }
                } else acked.put(r.getString("id"))
            }
            if (acked.length() > 0) com.vastanzil.sandpiper.widget.WidgetStore.ack(c, acked)
        } catch (e: Exception) { }
    }
}
