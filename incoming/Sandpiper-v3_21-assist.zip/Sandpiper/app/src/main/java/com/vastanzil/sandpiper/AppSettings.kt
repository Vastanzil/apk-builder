package com.vastanzil.sandpiper

import android.content.Context

/**
 * App-level native settings that change behaviour of native code (alarm snooze length, ring time, rising volume).
 * Edited only from the Settings panel (assets/features.json, store "app"); read by [Notifier] and [AlarmService].
 */
internal object AppSettings {
    private const val PREFS = "sp_app_settings"
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val SNOOZE_CHOICES = intArrayOf(5, 10, 15)
    val RING_CHOICES = intArrayOf(1, 5, 10, 15)
    val DAYEND_CHOICES = intArrayOf(1, 2, 3)   // hours before midnight

    fun snoozeMin(c: Context): Int = prefs(c).getInt("snoozeMin", 10).let { if (it in SNOOZE_CHOICES) it else 10 }
    fun ringMaxMin(c: Context): Int = prefs(c).getInt("ringMax", 10).let { if (it in RING_CHOICES) it else 10 }
    fun ramp(c: Context): Boolean = prefs(c).getBoolean("ramp", true)
    fun dayEnd(c: Context): Boolean = prefs(c).getBoolean("dayEnd", true)
    fun dayEndHours(c: Context): Int = prefs(c).getInt("dayEndHrs", 2).let { if (it in DAYEND_CHOICES) it else 2 }
    /** yyyy-MM-dd of the day the Planner was last closed (set by the web layer), or "". */
    fun dayClosed(c: Context): String = prefs(c).getString("dayClosed", "") ?: ""

    // ---- Little brain (on-device LLM). Every feature is opt-in (default off); the brain never touches the network. ----
    val BRAIN_MODES = listOf("auto", "system", "local", "off")
    val BRAIN_TASK_KEYS = listOf("brainSms", "brainCat", "brainSummary", "brainRewrite", "brainChat")
    const val BRAIN_BUDGET_MIN = 5
    const val BRAIN_BUDGET_MAX = 200
    const val BRAIN_BUDGET_DEFAULT = 40
    fun brainMode(c: Context): String { val v = prefs(c).getString("brainMode", "auto") ?: "auto"; return if (v in BRAIN_MODES) v else "auto" }
    fun brainAsk(c: Context): Boolean = prefs(c).getBoolean("brainAsk", true)
    fun brainBudget(c: Context): Int = prefs(c).getInt("brainBudget", BRAIN_BUDGET_DEFAULT).coerceIn(BRAIN_BUDGET_MIN, BRAIN_BUDGET_MAX)

    // ---- Home-screen widgets ----
    fun pomMin(c: Context): Int = prefs(c).getInt("pomMin", com.vastanzil.sandpiper.widget.PomState.DEFAULT_MIN).let { if (it in com.vastanzil.sandpiper.widget.PomState.CHOICES) it else com.vastanzil.sandpiper.widget.PomState.DEFAULT_MIN }
    fun pomNotify(c: Context): Boolean = prefs(c).getBoolean("pomNotify", true)

    fun snoozeMs(c: Context) = snoozeMin(c) * 60_000L
    fun ringMaxMs(c: Context) = ringMaxMin(c) * 60_000L

    fun get(c: Context, key: String): String? = when (key) {
        "snoozeMin" -> snoozeMin(c).toString()
        "ringMax" -> ringMaxMin(c).toString()
        "ramp" -> ramp(c).toString()
        "dayEnd" -> dayEnd(c).toString()
        "dayEndHrs" -> dayEndHours(c).toString()
        "dayClosed" -> dayClosed(c)
        "pomMin" -> pomMin(c).toString()
        "pomNotify" -> pomNotify(c).toString()
        "brainMode" -> brainMode(c)
        "brainAsk" -> brainAsk(c).toString()
        "brainBudget" -> brainBudget(c).toString()
        in BRAIN_TASK_KEYS -> prefs(c).getBoolean(key, false).toString()
        else -> null
    }

    /** Validates and stores one value (strings from the web layer). Returns false for an unknown key or invalid value. */
    fun set(c: Context, key: String, value: String): Boolean {
        val e = prefs(c).edit()
        when (key) {
            "snoozeMin" -> { val v = value.toIntOrNull() ?: return false; if (v !in SNOOZE_CHOICES) return false; e.putInt(key, v) }
            "ringMax" -> { val v = value.toIntOrNull() ?: return false; if (v !in RING_CHOICES) return false; e.putInt(key, v) }
            "ramp" -> e.putBoolean(key, value == "true")
            "dayEnd" -> e.putBoolean(key, value == "true")
            "dayEndHrs" -> { val v = value.toIntOrNull() ?: return false; if (v !in DAYEND_CHOICES) return false; e.putInt(key, v) }
            "dayClosed" -> { if (!Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(value)) return false; e.putString(key, value) }
            "pomMin" -> { val v = value.toIntOrNull() ?: return false; if (v !in com.vastanzil.sandpiper.widget.PomState.CHOICES) return false; e.putInt(key, v) }
            "pomNotify" -> e.putBoolean(key, value == "true")
            "brainMode" -> { if (value !in BRAIN_MODES) return false; e.putString(key, value) }
            "brainAsk" -> e.putBoolean(key, value == "true")
            "brainBudget" -> { val v = value.toIntOrNull() ?: return false; if (v !in BRAIN_BUDGET_MIN..BRAIN_BUDGET_MAX) return false; e.putInt(key, v) }
            in BRAIN_TASK_KEYS -> e.putBoolean(key, value == "true")
            else -> return false
        }
        e.apply()
        if (key == "dayEnd" || key == "dayEndHrs") DayEnd.sync(c)   // keep the daily reminder in step with the setting
        return true
    }
}
