package com.vastanzil.sandpiper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import org.json.JSONObject

object Notifier {
    const val CH_ALARM = "sandpiper_alarm_v1"
    const val CH_RING = "sandpiper_ring_v1"
    const val CH_REMIND = "sandpiper_reminder_v1"
    const val ACTION_SNOOZE = "com.vastanzil.sandpiper.SNOOZE"
    const val ACTION_DISMISS = "com.vastanzil.sandpiper.DISMISS"

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val tone: Uri = RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val alarm = NotificationChannel(CH_ALARM, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Rings when an alarm is due"
            setSound(tone, attrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 700, 400, 700)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val remind = NotificationChannel(CH_REMIND, "Reminders and focus timer", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Reminders, task alerts and focus-session timers"
        }
        val ring = NotificationChannel(CH_RING, "Ringing alarm", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Shown while an alarm is ringing (sound is played by the app)"
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(ring)
        nm.createNotificationChannel(alarm)
        nm.createNotificationChannel(remind)
    }

    private fun flags() = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun show(c: Context, id: String, kind: String, title: String, tone: String = Tones.DEFAULT) {
        channels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val nid = id.hashCode()
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), flags())
        val icon = Icon.createWithResource(c, R.drawable.ic_stat_bird)

        if (kind == "alarm") {
            val ring = Intent(c, AlarmActivity::class.java)
                .putExtra("id", id).putExtra("title", title).putExtra("tone", tone)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val full = PendingIntent.getActivity(c, nid, ring, flags())
            val snooze = action(c, ACTION_SNOOZE, id, title, nid + 1, tone)
            val dismiss = action(c, ACTION_DISMISS, id, title, nid + 2, tone)
            val n = Notification.Builder(c, CH_ALARM)
                .setSmallIcon(R.drawable.ic_stat_bird)
                .setContentTitle(title)
                .setContentText("Alarm")
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .setTimeoutAfter(AppSettings.ringMaxMs(c))
                .addAction(Notification.Action.Builder(icon, "Snooze ${AppSettings.snoozeMin(c)} min", snooze).build())
                .addAction(Notification.Action.Builder(icon, "Dismiss", dismiss).build())
                .build()
            n.flags = n.flags or Notification.FLAG_INSISTENT // keep sounding until dismissed or timed out
            nm.notify(nid, n)
        } else {
            val n = Notification.Builder(c, CH_REMIND)
                .setSmallIcon(R.drawable.ic_stat_bird)
                .setContentTitle("Sandpiper")
                .setContentText(title)
                .setStyle(Notification.BigTextStyle().bigText(title))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(nid, n)
        }
    }

    /** Notification for the ringing foreground service (silent channel; the service plays the sound). */
    fun ringNotification(c: Context, id: String, title: String, tone: String): Notification {
        val nid = id.hashCode()
        val icon = Icon.createWithResource(c, R.drawable.ic_stat_bird)
        val ring = Intent(c, AlarmActivity::class.java)
            .putExtra("id", id).putExtra("title", title).putExtra("tone", tone)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(c, nid, ring, flags())
        return Notification.Builder(c, CH_RING)
            .setSmallIcon(R.drawable.ic_stat_bird)
            .setContentTitle(title)
            .setContentText("Alarm ringing")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(Notification.Action.Builder(icon, "Snooze ${AppSettings.snoozeMin(c)} min", action(c, ACTION_SNOOZE, id, title, nid + 1, tone)).build())
            .addAction(Notification.Action.Builder(icon, "Dismiss", action(c, ACTION_DISMISS, id, title, nid + 2, tone)).build())
            .build()
    }

    private fun action(c: Context, act: String, id: String, title: String, req: Int, tone: String): PendingIntent {
        val i = Intent(c, ActionReceiver::class.java).setAction(act)
            .setData(Uri.parse("sandpiper://action/" + Uri.encode(id) + "/" + act.substringAfterLast('.')))
            .putExtra("id", id).putExtra("title", title).putExtra("tone", tone)
        return PendingIntent.getBroadcast(c, req, i, flags())
    }

    fun dismiss(c: Context, id: String) {
        c.stopService(Intent(c, AlarmService::class.java))
        c.getSystemService(NotificationManager::class.java).cancel(id.hashCode())
    }

    fun snooze(c: Context, id: String, title: String, tone: String = Tones.DEFAULT) {
        dismiss(c, id)
        val sid = if (id.startsWith("snooze_")) id else "snooze_$id"
        Scheduler.put(
            c, JSONObject().put("id", sid).put("kind", "alarm").put("title", title).put("tone", tone)
                .put("at", System.currentTimeMillis() + AppSettings.snoozeMs(c))
        )
    }
}
