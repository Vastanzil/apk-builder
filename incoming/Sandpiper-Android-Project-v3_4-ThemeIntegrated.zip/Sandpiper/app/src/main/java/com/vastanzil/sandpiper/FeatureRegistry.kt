package com.vastanzil.sandpiper

import android.content.Context
import org.json.JSONObject

/**
 * The single source of truth for permissions, features and settings: assets/features.json.
 * The Permissions panel, the Settings panel, the status chips, the self-test mapping and the unit tests all read it,
 * so a permission or setting cannot exist on one screen and be missing on another.
 */
internal object FeatureRegistry {
    @Volatile private var cache: String? = null

    fun json(c: Context): String =
        cache ?: c.applicationContext.assets.open("features.json").bufferedReader().use { it.readText() }.also { cache = it }

    fun parsed(c: Context): JSONObject = JSONObject(json(c))

    /**
     * Consistency rules (checked by FeatureRegistryTest and at runtime by the self-test):
     *  1. every registry permission is declared in the manifest (and, when strict, every manifest permission is in the registry exactly once)
     *  2. every permission is used by at least one feature; features only reference known permissions
     *  3. setting ids are unique, belong to a known feature, and only require known permissions
     *  4. choice settings have options and a default that is one of them; number settings have min <= default <= max
     * Returns human-readable problems (empty = consistent).
     */
    fun validate(reg: JSONObject, manifestPermissions: Set<String>, strict: Boolean = true): List<String> {
        val errors = ArrayList<String>()
        val perms = reg.getJSONArray("permissions")
        val permIds = HashSet<String>()
        val manifestSeen = HashMap<String, String>()
        for (i in 0 until perms.length()) {
            val p = perms.getJSONObject(i)
            val id = p.getString("id")
            if (!permIds.add(id)) errors.add("duplicate permission id $id")
            val m = p.getJSONArray("manifest")
            for (j in 0 until m.length()) {
                val name = m.getString(j)
                val prev = manifestSeen.put(name, id)
                if (prev != null) errors.add("$name listed under both $prev and $id")
                if (name !in manifestPermissions) errors.add("$name ($id) is not in the manifest")
            }
        }
        // strict = the source manifest (unit test). At runtime the merged manifest also contains permissions that libraries add, so only the registry -> manifest direction is checked.
        if (strict) for (name in manifestPermissions) if (name !in manifestSeen) errors.add("$name is in the manifest but not in the registry")

        val feats = reg.getJSONArray("features")
        val featIds = HashSet<String>()
        val usedPerms = HashSet<String>()
        for (i in 0 until feats.length()) {
            val f = feats.getJSONObject(i)
            val id = f.getString("id")
            if (!featIds.add(id)) errors.add("duplicate feature id $id")
            for (key in listOf("requires", "optional")) {
                val a = f.getJSONArray(key)
                for (j in 0 until a.length()) {
                    val pid = a.getString(j)
                    usedPerms.add(pid)
                    if (pid !in permIds) errors.add("feature $id references unknown permission $pid")
                }
            }
        }
        for (id in permIds) if (id !in usedPerms) errors.add("permission $id is not used by any feature")

        val sets = reg.getJSONArray("settings")
        val setIds = HashSet<String>()
        for (i in 0 until sets.length()) {
            val s = sets.getJSONObject(i)
            val id = s.getString("id")
            if (!setIds.add(id)) errors.add("duplicate setting id $id")
            if (s.getString("feature") !in featIds) errors.add("setting $id has unknown feature")
            s.optJSONArray("requires")?.let { r -> for (j in 0 until r.length()) if (r.getString(j) !in permIds) errors.add("setting $id requires unknown permission ${r.getString(j)}") }
            when (s.getString("type")) {
                "choice" -> {
                    val opts = s.optJSONArray("options")
                    if (opts == null || opts.length() == 0) errors.add("choice $id has no options")
                    else {
                        val values = (0 until opts.length()).map { opts.getJSONArray(it).get(0).toString() }
                        if (s.opt("default")?.toString() !in values) errors.add("choice $id default is not an option")
                    }
                }
                "number" -> {
                    val d = s.optDouble("default", Double.NaN)
                    if (d.isNaN() || d < s.optDouble("min", Double.NEGATIVE_INFINITY) || d > s.optDouble("max", Double.POSITIVE_INFINITY)) errors.add("number $id default is outside min/max")
                }
                "perm" -> if (s.getString("key") !in permIds) errors.add("perm row $id points to unknown permission")
            }
        }
        return errors
    }
}
