package com.vastanzil.sandpiper

import android.content.Context

/**
 * App-level native settings that change behaviour of native code (alarm snooze length, ring time, rising volume).
 * Edited only from the Settings panel (assets/features.json, store "app"); read by [Notifier] and [AlarmService].
 */
internal object AppSettings {
    private const val PREFS = "sp_app_settings"
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val SNOOZE_CHOICES = intArrayOf(5, 10, 15)
    val RING_CHOICES = intArrayOf(1, 5, 10, 15)

    fun snoozeMin(c: Context): Int = prefs(c).getInt("snoozeMin", 10).let { if (it in SNOOZE_CHOICES) it else 10 }
    fun ringMaxMin(c: Context): Int = prefs(c).getInt("ringMax", 10).let { if (it in RING_CHOICES) it else 10 }
    fun ramp(c: Context): Boolean = prefs(c).getBoolean("ramp", true)

    fun snoozeMs(c: Context) = snoozeMin(c) * 60_000L
    fun ringMaxMs(c: Context) = ringMaxMin(c) * 60_000L

    fun get(c: Context, key: String): String? = when (key) {
        "snoozeMin" -> snoozeMin(c).toString()
        "ringMax" -> ringMaxMin(c).toString()
        "ramp" -> ramp(c).toString()
        else -> null
    }

    /** Validates and stores one value (strings from the web layer). Returns false for an unknown key or invalid value. */
    fun set(c: Context, key: String, value: String): Boolean {
        val e = prefs(c).edit()
        when (key) {
            "snoozeMin" -> { val v = value.toIntOrNull() ?: return false; if (v !in SNOOZE_CHOICES) return false; e.putInt(key, v) }
            "ringMax" -> { val v = value.toIntOrNull() ?: return false; if (v !in RING_CHOICES) return false; e.putInt(key, v) }
            "ramp" -> e.putBoolean(key, value == "true")
            else -> return false
        }
        e.apply()
        return true
    }
}
