package com.vastanzil.sandpiper

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.media.MediaPlayer
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File

/** JavaScript bridge exposed to the bundled page as `window.SandpiperNative`. */
class Bridge(private val a: MainActivity) {
    private val ctx: Context = a.applicationContext
    private val main = Handler(Looper.getMainLooper())

    /** Returns the next trigger time (epoch ms), or 0 if nothing could be scheduled. */
    @JavascriptInterface fun schedule(json: String): Long = try {
        val o = JSONObject(json)
        Scheduler.put(ctx, o)
        val next = Scheduler.nextTime(o, System.currentTimeMillis()) ?: 0L
        Diag.log(DLvl.I, DCat.BRIDGE, DEv.BRIDGE_SCHEDULE, DMod.ALARMS, if (next > 0L) DRes.OK else DRes.SKIP)
        next
    } catch (e: Exception) {
        Diag.log(DLvl.W, DCat.BRIDGE, DEv.BRIDGE_SCHEDULE, DMod.ALARMS, DRes.FAIL, code = Diag.codeOf(e))
        0L
    }

    /** Schedules a real alarm 10 seconds from now through the same path as normal alarms. */
    @JavascriptInterface fun testAlarm(tone: String): Long = schedule(
        JSONObject().put("id", "test_alarm").put("kind", "alarm").put("title", "Test alarm")
            .put("tone", tone.ifBlank { Tones.DEFAULT })
            .put("at", System.currentTimeMillis() + 10_000L).toString()
    )

    /** kind = "system" (ringtone picker) or "file" (any audio file). Result arrives in window.onToneChosen(). */
    @JavascriptInterface fun pickTone(kind: String) { a.pickTone(kind) }

    /** Deletes a copied custom tone file (only inside the app's own tones folder). */
    @JavascriptInterface fun deleteTone(tone: String) {
        if (!tone.startsWith("file:")) return
        runCatching {
            val f = File(tone.removePrefix("file:")).canonicalFile
            if (f.path.startsWith(File(ctx.filesDir, "tones").canonicalPath)) f.delete()
        }
    }

    private var preview: MediaPlayer? = null
    private val stopper = Runnable { stopPreviewNow() }
    private fun stopPreviewNow() {
        main.removeCallbacks(stopper)
        runCatching { preview?.stop() }
        runCatching { preview?.release() }
        preview = null
    }

    @JavascriptInterface fun previewTone(tone: String) {
        main.post {
            stopPreviewNow()
            val mp = Tones.player(ctx, tone) ?: return@post
            mp.setVolume(0.8f, 0.8f)
            mp.start()
            preview = mp
            main.postDelayed(stopper, 8000)
        }
    }

    @JavascriptInterface fun stopPreview() { main.post { stopPreviewNow() } }

    @JavascriptInterface fun cancel(id: String) { Scheduler.remove(ctx, id) }

    @JavascriptInterface fun notifEnabled(): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    /** Used by the Planner and Fitness pages: same shared request path as the Permissions panel. */
    @JavascriptInterface fun requestNotif() {
        if (Permissions.act(ctx, a, "notifications") == "granted") a.js("window.onNativePermission&&onNativePermission()")
    }

    /** Saves a file (base64) into Downloads/Sandpiper via MediaStore; no storage permission needed. */
    @JavascriptInterface fun saveFile(name: String, mime: String, b64: String): Boolean = try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safe)
            put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sandpiper")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(uri)!!.use { it.write(bytes) }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        r.update(uri, v, null, null)
        Diag.log(DLvl.I, DCat.BRIDGE, DEv.BRIDGE_SAVE_FILE, DMod.OTHER, DRes.OK, n = bytes.size.toLong())
        true
    } catch (e: Exception) {
        Diag.log(DLvl.W, DCat.BRIDGE, DEv.BRIDGE_SAVE_FILE, DMod.OTHER, DRes.FAIL, code = Diag.codeOf(e))
        false
    }

    @JavascriptInterface fun requestActivity() { Permissions.act(ctx, a, "activity") }

    /** Reads the step sensor, stores the sample and pushes {ok, steps, activeMin, history} to window.onSteps(). */
    @JavascriptInterface fun readSteps() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            push(JSONObject().put("ok", false).put("reason", "permission")); return
        }
        if (ctx.getSystemService(SensorManager::class.java).getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) {
            push(JSONObject().put("ok", false).put("reason", "sensor")); return
        }
        Thread {
            val total = Steps.readTotal(ctx)
            if (total != null) Steps.record(ctx, total)
            val sum = Steps.summary(ctx)
            push(sum.put("ok", true).put("reason", ""))
        }.start()
    }

    private fun push(o: JSONObject) { a.js("window.onSteps&&onSteps(" + JSONObject.quote(o.toString()) + ")") }

    // ---------- Fitness support ----------
    @JavascriptInterface fun openUrl(url: String): Boolean {
        if (!Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(url)) return false
        return try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
    }

    /** Permission flags in the shape the fitness page expects. Accessibility detection is not implemented, so it is always false. */
    @JavascriptInterface fun permState(): String = JSONObject()
        .put("usage", Permissions.ok(ctx, "usage"))
        .put("overlay", Permissions.ok(ctx, "overlay"))
        .put("a11y", Permissions.ok(ctx, "accessibility"))
        .put("notif", Permissions.ok(ctx, "notifications"))
        .put("act", Permissions.ok(ctx, "activity"))
        .toString()

    @JavascriptInterface fun openAppInfo() {
        runCatching {
            a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Today's Brainy counts plus real app usage time (needs Usage Access) in the shape setBrainrot() expects. */
    @JavascriptInterface fun brainrotToday(): String {
        val o = BrainyStore.snapshot(ctx)
        runCatching {
            val u = JSONObject(usageToday())
            if (u.optBoolean("ok")) o.put("usageMin", u.optLong("usageMin")).put("sessions", u.optInt("sessions"))
        }
        return o.toString()
    }

    /** Fitness-page settings (floating counter, blocker, budgets, quiet hours...) used by the accessibility service. */
    @JavascriptInterface fun setFitSettings(json: String) { BrainyStore.setSettings(ctx, json) }

    /** Opens the native Brainy Island settings screen (reel detection, tracked apps, island look, diagnostics). */
    @JavascriptInterface fun openBrainySettings() {
        a.runOnUiThread { runCatching { a.startActivity(Intent(a, BrainySettingsActivity::class.java)) } }
    }

    /** Piper Pro workspace in Sandpiper's central database. Returns "" when nothing is stored yet. */
    @JavascriptInterface fun piperLoad(): String = PiperStore.load(ctx) ?: ""

    /** Stores the whole Piper workspace (validated JSON object with a pages array) in one transaction. */
    @JavascriptInterface fun piperSave(json: String): Boolean = PiperStore.save(ctx, json)

    /** {"ok":true,"has":true,"pages":12,"bytes":123456,"updatedAt":...}; ok=false means the database is unavailable. */
    @JavascriptInterface fun piperStatus(): String = PiperStore.status(ctx)

    /** Opens the native Diagnostics screen (self-test, module health, export of the privacy-safe diagnostic log). */
    @JavascriptInterface fun openDiagnostics() {
        a.runOnUiThread { runCatching { a.startActivity(Intent(a, DiagnosticsActivity::class.java)) } }
    }

    /** Fitness-page ids (a11y, usage, overlay, notif, act) mapped onto the shared Permissions actions. */
    @JavascriptInterface fun openPermission(which: String): Boolean {
        val id = when (which) { "a11y" -> "accessibility"; "notif" -> "notifications"; "act" -> "activity"; "usage", "overlay" -> which; else -> return false }
        return Permissions.act(ctx, a, id) != "na"
    }

    /** Today's foreground time and session count for TikTok, Instagram, Facebook and YouTube (needs Usage Access). */
    @JavascriptInterface fun usageToday(): String {
        if (!Permissions.usageOn(ctx)) return JSONObject().put("ok", false).toString()
        val pk = IslandStore.monitoredApps(ctx)   // the apps chosen in Brainy Island (built-in list until changed)
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        val now = System.currentTimeMillis()
        val um = ctx.getSystemService(android.app.usage.UsageStatsManager::class.java)
        val ev = um.queryEvents(cal.timeInMillis, now)
        val e = android.app.usage.UsageEvents.Event()
        val start = HashMap<String, Long>()
        var total = 0L
        var sessions = 0
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.packageName !in pk) continue
            when (e.eventType) {
                android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED -> start[e.packageName] = e.timeStamp
                android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED -> start.remove(e.packageName)?.let { t0 ->
                    val d = e.timeStamp - t0
                    if (d >= 5000) { total += d; sessions++ }
                }
            }
        }
        start.values.forEach { total += now - it } // still open right now
        return JSONObject().put("ok", true).put("usageMin", total / 60000).put("sessions", sessions).toString()
    }

    // ---------- Settings and Permissions panels ----------
    /** assets/features.json: permissions, features and every setting definition. */
    @JavascriptInterface fun registry(): String = try { FeatureRegistry.json(ctx) } catch (e: Exception) { "" }

    /** Live state of every permission: [{"id":..,"state":"granted|not_granted|permanently_denied|special|na"}]. */
    @JavascriptInterface fun permissions(log: Boolean): String = try { Permissions.statesJson(ctx, a, log) } catch (e: Exception) { "[]" }

    /** Grant / Fix button: requested | opened | appinfo | granted | na. */
    @JavascriptInterface fun permissionAction(id: String): String = try { Permissions.act(ctx, a, id) } catch (e: Exception) { "na" }

    @JavascriptInterface fun settingGet(feature: String, key: String): String? = SettingsStore.get(ctx, feature, key)
    @JavascriptInterface fun settingSet(feature: String, key: String, value: String): Boolean = SettingsStore.set(ctx, feature, key, value)
    @JavascriptInterface fun settingsAll(): String = SettingsStore.all(ctx).toString()
    @JavascriptInterface fun settingsReplace(json: String): Boolean = try { SettingsStore.replaceAll(ctx, JSONObject(json)) } catch (e: Exception) { false }

    /** Brainy Island settings as strings (tracking, always, browser = true/false; style, look = enum name; gap = 0..3). */
    @JavascriptInterface fun islandGet(key: String): String? = when (key) {
        "tracking" -> IslandStore.tracking(ctx).toString()
        "always" -> IslandStore.islandAlways(ctx).toString()
        "browser" -> IslandStore.browserSupport(ctx).toString()
        "style" -> IslandStore.style(ctx).name
        "look" -> IslandStore.look(ctx).name
        "gap" -> IslandStore.gapLevel(ctx).toString()
        else -> null
    }

    @JavascriptInterface fun islandSet(key: String, value: String): Boolean {
        return try {
            when (key) {
                "tracking" -> IslandStore.setTracking(ctx, value == "true")
                "always" -> IslandStore.setIslandAlways(ctx, value == "true")
                "browser" -> IslandStore.setBrowserSupport(ctx, value == "true")
                "style" -> IslandStore.setStyle(ctx, IslandStyle.valueOf(value))
                "look" -> IslandStore.setLook(ctx, IslandLook.valueOf(value))
                "gap" -> IslandStore.setGapLevel(ctx, value.toInt())
                else -> return false
            }
            true
        } catch (e: Exception) { false }
    }

    @JavascriptInterface fun appGet(key: String): String? = AppSettings.get(ctx, key)
    @JavascriptInterface fun appSet(key: String, value: String): Boolean = AppSettings.set(ctx, key, value)

    @JavascriptInterface fun trackedAppsCount(): Int = IslandStore.monitoredApps(ctx).size
    @JavascriptInterface fun openAppPicker() { a.runOnUiThread { runCatching { a.startActivity(Intent(a, BrainyAppPickerActivity::class.java)) } } }

    @JavascriptInterface fun appVersion(): String = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    /** Records that a setting of [feature] changed. Only the feature enum is logged, never the key or value. */
    @JavascriptInterface fun logSettingChange(feature: String) {
        val mod = when (feature) {
            "brainy" -> DMod.BRAINY; "alarms" -> DMod.ALARMS; "finance" -> DMod.FINANCE; "notes" -> DMod.NOTES; "planner" -> DMod.PLANNER
            "steps" -> DMod.STEPS; "habits" -> DMod.HABITS; "general", "backup", "diagnostics", "about" -> DMod.APP; else -> DMod.OTHER
        }
        Diag.log(DLvl.I, DCat.SETTINGS, DEv.SETTINGS_CHANGED, mod, DRes.OK)
    }

    @JavascriptInterface fun logBackup(restore: Boolean, ok: Boolean) {
        Diag.log(if (ok) DLvl.I else DLvl.W, if (restore) DCat.RESTORE else DCat.BACKUP, if (restore) DEv.BACKUP_RESTORED else DEv.BACKUP_EXPORTED, DMod.APP, if (ok) DRes.OK else DRes.FAIL)
    }

    @JavascriptInterface fun logSeeded(count: Int) { Diag.log(DLvl.I, DCat.SETTINGS, DEv.SETTINGS_SEEDED, DMod.APP, DRes.OK, n = count.toLong()) }
}
