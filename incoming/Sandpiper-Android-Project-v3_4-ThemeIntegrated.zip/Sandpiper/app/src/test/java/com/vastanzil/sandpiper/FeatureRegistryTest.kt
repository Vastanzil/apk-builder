package com.vastanzil.sandpiper

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Reads the real assets/features.json and the real AndroidManifest.xml (Gradle runs unit tests from the app/ folder). */
class FeatureRegistryTest {
    private fun registry() = JSONObject(File("src/main/assets/features.json").readText())
    private fun manifestPermissions(): Set<String> =
        Regex("<uses-permission[^>]*android:name=\"([^\"]+)\"").findAll(File("src/main/AndroidManifest.xml").readText()).map { it.groupValues[1] }.toSet()

    @Test fun registryMatchesManifestAndIsConsistent() {
        assertEquals(emptyList<String>(), FeatureRegistry.validate(registry(), manifestPermissions()))
    }

    @Test fun everyManifestPermissionAppearsExactlyOnce() {
        val perms = registry().getJSONArray("permissions")
        val seen = ArrayList<String>()
        for (i in 0 until perms.length()) { val m = perms.getJSONObject(i).getJSONArray("manifest"); for (j in 0 until m.length()) seen.add(m.getString(j)) }
        assertEquals(manifestPermissions(), seen.toSet())
        assertEquals(seen.size, seen.toSet().size)
    }

    @Test fun settingIdsAreUnique() {
        val s = registry().getJSONArray("settings")
        val ids = (0 until s.length()).map { s.getJSONObject(it).getString("id") }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun diagnosticsCoverEveryRuntimeAndSpecialPermission() {
        val perms = registry().getJSONArray("permissions")
        val covered = Permissions.DIAG_ROWS.map { it.id }.toSet()
        for (i in 0 until perms.length()) {
            val p = perms.getJSONObject(i)
            if (p.getString("kind") != "install") assertTrue("self-test is missing ${p.getString("id")}", p.getString("id") in covered)
        }
    }

    @Test fun validatorCatchesProblems() {
        val bad = registry()
        bad.getJSONArray("settings").put(JSONObject(bad.getJSONArray("settings").getJSONObject(0).toString())) // duplicate id
        assertTrue(FeatureRegistry.validate(bad, manifestPermissions()).any { it.contains("duplicate setting id") })

        val unknownPerm = registry()
        unknownPerm.getJSONArray("features").getJSONObject(0).getJSONArray("optional").put("teleport")
        assertTrue(FeatureRegistry.validate(unknownPerm, manifestPermissions()).any { it.contains("unknown permission teleport") })

        val extra = manifestPermissions() + "android.permission.CAMERA"
        assertTrue(FeatureRegistry.validate(registry(), extra).any { it.contains("CAMERA") })

        val badDefault = registry()
        val s = badDefault.getJSONArray("settings")
        for (i in 0 until s.length()) if (s.getJSONObject(i).getString("id") == "alarms.snoozeMin") s.getJSONObject(i).put("default", 7)
        assertTrue(FeatureRegistry.validate(badDefault, manifestPermissions()).any { it.contains("default is not an option") })
    }
}
