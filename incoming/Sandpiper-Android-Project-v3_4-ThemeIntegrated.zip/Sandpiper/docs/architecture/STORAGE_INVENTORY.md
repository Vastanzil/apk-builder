# Storage inventory (plan stage S1)

Developer-only. Lives in `docs/`, outside `app/`, so Gradle never packages it into the APK.
Derived from the code in this repository. "Owner" = the layer that writes it.

## Native (Kotlin) stores
| Store | Type | Owner | Readers | Contents | Bound |
|---|---|---|---|---|---|
| `sp_items` | SharedPreferences | `Scheduler` | `AlarmReceiver`, `BootReceiver`, self-test | one JSON per alarm/reminder, key = item id | one per alarm/reminder |
| `sp_brainy` | SharedPreferences | `BrainyStore` | `BrainyService`, `Bridge`, `Steps`, `IslandStore` | key `s` = today's counts + 30-day `hist`; key `set` = Fitness-page Brainy settings | reels array capped at 400; hist 30 days |
| `sp_brainy_island` | SharedPreferences | `IslandStore` | `BrainyService`, `IslandOverlay`, settings screens | tracking, island look/style/gap, browser opt-in, chosen apps, last layout note | small |
| `sp_steps2` | SharedPreferences | `Steps` | `Bridge`, self-test | key `d` = last sensor total + per-day steps / active minutes | 45 days |
| `sandpiper_central.db` | SQLite (platform, WAL) | `CentralDb` / `PiperStore` | `Bridge.piper*`, self-test | `module_doc` + `module_doc_chunk` (Piper workspace as one versioned, SHA-256-verified JSON, current + previous revision); `piper_page` (page/folder index); `piper_setting`; **`setting(feature, k, v, updated_at)`** = one row per app setting (schema v2; mirrors every setting so one backup restores them all) | 32 MB per document; 2 revisions |
| `sp_app_settings` | SharedPreferences | `AppSettings` | `Notifier`, `AlarmService`, `Bridge.app*` | alarm snooze length, ring time, rising volume | tiny |
| `sp_perm_asked` | SharedPreferences | `Permissions` | Permissions panel | which runtime permissions were already requested (needed to detect "permanently denied") | tiny |
| `sp_pre_restore` | localStorage | host page | restore | safety copy of the previous data, taken just before a restore replaces it (overwritten by the next restore) | one copy |
| `files/tones/` | files | `MainActivity.onToneResult` | `Tones` | user-chosen alarm audio (max 30 MB each) | per chosen tone |
| `files/diag/diag.jsonl` | file | `Diag` | export only | typed diagnostic events (enums + numbers) | 2 MB, 14 days |
| `res/raw/tone_*.wav` | APK resources | build | `Tones` | 5 built-in tones | read-only |

## Web (WebView) stores - not readable from Kotlin
| Key | Kind | Owner | Contents |
|---|---|---|---|
| `sandpiper_state_v2` | localStorage | `index.html` | finance, notes, habits, water, sleep, investments, alarms list, profile, day records |
| `sandpiper_reminders` | localStorage | planner + `planner-bridge.js` | planner reminders |
| `sandpiper.fitness.v1` | localStorage | `fitness.html` | fitness data blob |
| `sandpiper.fitness.native_ids` / `sp_native_ids` | localStorage | bridge scripts | ids of reminders handed to Android |
| `sp_ci` | localStorage | `index.html` | small UI flag |
| IndexedDB `piper-db` / store `snapshots` | IndexedDB | `piper.html` | Piper's local snapshot history (max 5 full copies). Not in the central DB. |
| `piper-backup` (legacy read: `glasspage-pro-backup`) | localStorage | `piper.html` | fallback copy only used if a central-DB save fails; a newer fallback wins on next load and is pushed back |
| IndexedDB `sandpiper` / store `rec` | IndexedDB | `index.html` | voice-note audio (NOT in the JSON backup) |

## Manifest permissions -> feature
| Permission | Feature | Verdict |
|---|---|---|
| POST_NOTIFICATIONS | reminders, warnings | used |
| RECEIVE_BOOT_COMPLETED | re-arm alarms | used |
| VIBRATE | alarm, warnings | used |
| WAKE_LOCK | `MediaPlayer.setWakeMode` in `AlarmService` | used |
| FOREGROUND_SERVICE / ..._MEDIA_PLAYBACK | ringing alarm service | used |
| USE_FULL_SCREEN_INTENT | lock-screen alarm | used |
| SCHEDULE_EXACT_ALARM | precise reminders | used |
| RECORD_AUDIO, MODIFY_AUDIO_SETTINGS | voice notes (WebView capture) | used; MODIFY_AUDIO_SETTINGS kept because WebView audio capture is documented to need it |
| ACTIVITY_RECOGNITION | step counter | used |
| SYSTEM_ALERT_WINDOW | focus-lock overlay | used (optional) |
| PACKAGE_USAGE_STATS | real app time | used (optional) |
| (accessibility service) | Brainy counting + island | used |
| INTERNET | - | deliberately absent |

No permission was removed: none could be proven unused without a device run.
