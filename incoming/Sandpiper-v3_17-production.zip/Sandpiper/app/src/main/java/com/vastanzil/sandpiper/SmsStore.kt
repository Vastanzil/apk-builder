package com.vastanzil.sandpiper

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Pure rules for capturing bank / wallet SMS (no Android imports, so plain JUnit covers them).
 * Only messages from providers the user selected are ever kept, OTP messages are dropped before anything is stored,
 * and a message must look like a transaction (credited, debited, cash out, balance...). Everything else is ignored.
 */
object SmsFilter {
    private val OTP = Regex("\\b(?:otp|one[- ]time password|verification code|passcode|security code)\\b", RegexOption.IGNORE_CASE)
    private val TX = Regex(
        "\\b(?:credited|debited|received|sent|paid|payment|withdraw\\w*|deposit\\w*|cash[- ]?(?:in|out)|transfer\\w*|purchase\\w*|" +
            "spent|charged|refund\\w*|add\\s*money|top[- ]?up|balance|bal|trxid|txn|atm)\\b", RegexOption.IGNORE_CASE
    )

    /** Letters and digits only, lower case: "City Bank", "CITYBANK" and "city-bank" all become "citybank". */
    fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    fun isOtp(body: String): Boolean = OTP.containsMatchIn(body)
    fun looksTransactional(body: String): Boolean = TX.containsMatchIn(body)

    /** Sender id (e.g. "bKash", "CityBank Alert", "16216") against the selected provider names. Names under 3 characters never match. */
    fun senderMatches(sender: String, providers: List<String>): Boolean {
        val s = norm(sender)
        if (s.length < 3) return false
        return providers.any { val p = norm(it); p.length >= 3 && (s.contains(p) || (s.length >= 4 && p.contains(s))) }
    }

    fun accept(sender: String, body: String, providers: List<String>): Boolean =
        body.isNotBlank() && senderMatches(sender, providers) && !isOtp(body) && looksTransactional(body)

    /** Stable id: the same message read twice (receiver, then an inbox scan) is stored once. */
    fun id(sender: String, ts: Long, body: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest("${norm(sender)}|$ts|${body.trim()}".toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }.take(32)
    }

    /** A message thread (one sender) found in the inbox: how many messages, how many look like transactions, the newest of those. */
    data class SmsThread(val sender: String, val total: Int, val tx: Int, val last: Long, val preview: String)

    /** Personal numbers ("+88017...", long digit strings) are never offered: only bank / wallet style senders (names or short codes). */
    fun isPersonalNumber(sender: String): Boolean {
        val t = sender.trim()
        val digits = t.count { it.isDigit() }
        return t.startsWith("+") || (digits >= 10 && digits >= t.length - 1)
    }

    /** Groups inbox messages by sender for the "choose which threads to add" list. Keeps counts and ONE short preview, nothing else. */
    class ThreadCollector {
        private class Acc(var sender: String) { var total = 0; var tx = 0; var last = 0L; var preview = "" }
        private val map = LinkedHashMap<String, Acc>()

        fun add(sender: String, body: String, ts: Long) {
            if (sender.isBlank() || isPersonalNumber(sender)) return
            val k = norm(sender)
            if (k.length < 3) return
            val a = map.getOrPut(k) { Acc(sender) }
            a.total++
            if (!isOtp(body) && looksTransactional(body)) {
                a.tx++
                if (ts >= a.last) { a.last = ts; a.preview = body.trim().replace(Regex("\\s+"), " ").take(90); a.sender = sender }
            }
        }

        /** Only senders with at least one transaction-looking message, busiest first. */
        fun result(limit: Int): List<SmsThread> =
            map.values.filter { it.tx > 0 }.sortedWith(compareByDescending<Acc> { it.tx }.thenByDescending { it.last })
                .take(limit).map { SmsThread(it.sender, it.total, it.tx, it.last, it.preview) }
    }

    /** Provider names from the JSON array the web layer stores: ["bKash","Nagad","City Bank"]. */
    fun parseProviders(json: String): List<String> = try {
        val a = JSONArray(json)
        (0 until a.length()).map { a.optString(it).trim() }.filter { it.length in 3..40 }.distinct().take(60)
    } catch (e: Exception) { emptyList() }
}

/**
 * Captured SMS waiting for Sprout (sms_inbox in sandpiper_central.db). The web layer takes them, Sprout turns them into ledger rows,
 * then they are acknowledged. Acknowledged rows keep only their id (sender and text are erased) so a later inbox scan cannot
 * import the same message twice, and nothing readable is retained.
 */
internal object SmsStore {
    private const val PREFS = "sp_sms"
    private val READ_PERMS = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)

    fun createTables(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS sms_inbox(id TEXT PRIMARY KEY, sender TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL, state INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS sms_state ON sms_inbox(state, ts)")
    }

    private fun db(c: Context): SQLiteDatabase = CentralDb.get(c).writableDatabase
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun granted(c: Context): Boolean = READ_PERMS.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

    fun setProviders(c: Context, json: String): Int {
        val list = SmsFilter.parseProviders(json)
        prefs(c).edit().putString("providers", JSONArray(list).toString()).apply()
        return list.size
    }

    fun providers(c: Context): List<String> = SmsFilter.parseProviders(prefs(c).getString("providers", "[]") ?: "[]")

    /** Keeps the message when it passes the filter. Returns true when it was stored (new). */
    @Synchronized
    fun accept(c: Context, sender: String, body: String, ts: Long): Boolean {
        if (!SmsFilter.accept(sender, body, providers(c))) return false
        return try {
            val cv = ContentValues()
            cv.put("id", SmsFilter.id(sender, ts, body)); cv.put("sender", sender.take(40)); cv.put("body", body.take(1000)); cv.put("ts", ts); cv.put("state", 0)
            val rowId = db(c).insertWithOnConflict("sms_inbox", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            if (rowId != -1L) Diag.log(DLvl.I, DCat.DB, DEv.SMS_ACCEPTED, DMod.SPROUT, DRes.OK, n = 1L)
            rowId != -1L
        } catch (e: Exception) { false }
    }

    fun pending(c: Context): Int = try {
        db(c).rawQuery("SELECT COUNT(*) FROM sms_inbox WHERE state=0", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (e: Exception) { 0 }

    /** Oldest first, so a debit and its matching credit reach Sprout in the order they arrived. */
    fun take(c: Context, limit: Int): String {
        val out = JSONArray()
        try {
            db(c).rawQuery("SELECT id, sender, body, ts FROM sms_inbox WHERE state=0 ORDER BY ts LIMIT ?", arrayOf(limit.coerceIn(1, 200).toString())).use {
                while (it.moveToNext()) out.put(JSONObject().put("id", it.getString(0)).put("sender", it.getString(1)).put("body", it.getString(2)).put("ts", it.getLong(3)))
            }
        } catch (e: Exception) { }
        return out.toString()
    }

    /** Sprout has them: erase sender and text, keep the id. Returns how many were acknowledged. */
    @Synchronized
    fun ack(c: Context, idsJson: String): Int {
        val ids = try { JSONArray(idsJson) } catch (e: Exception) { return 0 }
        val d = db(c)
        var n = 0
        d.beginTransaction()
        try {
            val cv = ContentValues(); cv.put("state", 1); cv.put("sender", ""); cv.put("body", "")
            for (i in 0 until ids.length()) n += d.update("sms_inbox", cv, "id=? AND state=0", arrayOf(ids.optString(i)))
            // ids older than a year are not needed any more: an inbox scan only looks back far less than that
            d.delete("sms_inbox", "state=1 AND ts<?", arrayOf((System.currentTimeMillis() - 365L * 86_400_000L).toString()))
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        if (n > 0) Diag.log(DLvl.I, DCat.DB, DEv.SMS_DELIVERED, DMod.SPROUT, DRes.OK, n = n.toLong())
        return n
    }

    /** Reads the inbox for messages from the selected providers in the last [days] days. Returns how many NEW messages were kept, or -1 without permission. */
    fun scan(c: Context, days: Int): Int {
        if (!granted(c)) return -1
        val list = providers(c)
        if (list.isEmpty()) return 0
        val since = System.currentTimeMillis() - days.coerceIn(1, 365) * 86_400_000L
        var n = 0
        try {
            c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), "date>=?", arrayOf(since.toString()), "date ASC")?.use {
                var rows = 0
                while (it.moveToNext() && rows < 20_000) {
                    rows++
                    val sender = it.getString(0) ?: continue
                    if (!SmsFilter.senderMatches(sender, list)) continue       // other people's messages are never even copied
                    if (accept(c, sender, it.getString(1) ?: "", it.getLong(2))) n++
                }
            }
        } catch (e: SecurityException) { return -1 } catch (e: Exception) { }
        Diag.log(DLvl.I, DCat.DB, DEv.SMS_SCAN, DMod.SPROUT, DRes.OK, n = n.toLong())
        return n
    }

    /**
     * Lists the senders in the inbox that look like banks or wallets (last [days] days) so the USER chooses which threads Sprout may use.
     * Nothing is stored here: only counts and one short preview per sender are returned. Null without permission.
     */
    fun discover(c: Context, days: Int): String? {
        if (!granted(c)) return null
        val since = System.currentTimeMillis() - days.coerceIn(1, 365) * 86_400_000L
        val col = SmsFilter.ThreadCollector()
        try {
            c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), "date>=?", arrayOf(since.toString()), "date ASC")?.use {
                var rows = 0
                while (it.moveToNext() && rows < 20_000) {
                    rows++
                    col.add(it.getString(0) ?: continue, it.getString(1) ?: "", it.getLong(2))
                }
            }
        } catch (e: SecurityException) { return null } catch (e: Exception) { }
        val arr = JSONArray()
        for (t in col.result(80)) arr.put(JSONObject().put("sender", t.sender).put("total", t.total).put("tx", t.tx).put("last", t.last).put("preview", t.preview))
        Diag.log(DLvl.I, DCat.DB, DEv.SMS_SCAN, DMod.SPROUT, DRes.OK, n = arr.length().toLong())
        return JSONObject().put("ok", true).put("threads", arr).toString()
    }

    fun status(c: Context): String =
        JSONObject().put("granted", granted(c)).put("providers", providers(c).size).put("pending", pending(c)).toString()
}
