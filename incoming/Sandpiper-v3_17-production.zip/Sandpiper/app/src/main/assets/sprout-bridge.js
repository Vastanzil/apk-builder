/* Sprout <-> Sandpiper bridge. sprout.html is the Sprout app as delivered, with two edits only: the Content-Security-Policy allows this
   bundled script, and this file is loaded in <head>. Everything below wires Sprout into Sandpiper without touching its code:
   1. its whole state lives in the central database (not localStorage),
   2. its settings and permission are owned by Sandpiper's Settings / Permissions (its own Settings tab is hidden),
   3. simple Finance transactions are mirrored into it automatically (one account, never duplicated),
   4. the leaf icon returns to Finance, and file saves go through Sandpiper's Downloads/Sandpiper folder. */
(function(){
  'use strict';
  var N=null;try{N=window.SandpiperNative||null}catch(e){}
  var hub=null;try{hub=window.parent&&window.parent!==window?window.parent.SpHub:null}catch(e){}
  var KEY='sprout:v1',disabled=false;

  /* ---- 1. central database storage: seed Sprout's own loader before its script runs, keep no second copy ---- */
  var origSet=Storage.prototype.setItem,origRemove=Storage.prototype.removeItem;
  if(N&&N.sproutLoad&&N.sproutSave){
    try{var stored=N.sproutLoad();if(stored)origSet.call(window.localStorage,KEY,stored);else origRemove.call(window.localStorage,KEY)}catch(e){}
    Storage.prototype.setItem=function(k,v){
      if(this===window.localStorage&&k===KEY){
        if(disabled)return;
        var ok=false;try{ok=N.sproutSave(String(v))}catch(e){}
        if(!ok)throw new Error('central database unavailable');      // Sprout then shows its own "changes are not being saved" warning
        return;
      }
      return origSet.apply(this,arguments);
    };
    document.addEventListener('DOMContentLoaded',function(){try{origRemove.call(window.localStorage,KEY)}catch(e){}});   // Sprout has loaded: drop the transient copy
  }
  window.__spDisable=function(){disabled=true};                          // used before an erase so a late save cannot bring the data back

  /* ---- everything else needs Sprout's own script to have run ---- */
  document.addEventListener('DOMContentLoaded',function(){
    /* 2. Sandpiper owns the settings: hide Sprout's Settings tab (region, currency, language, navigation, add button, providers, demo, SMS, erase) */
    var st=document.createElement('style');
    st.textContent='.seg[data-m="settings"],#more-settings{display:none!important}.brand .logo{cursor:pointer}';
    document.head.appendChild(st);
    try{if(document.querySelector('.seg.active[data-m="settings"]'))setMoreTab('reports')}catch(e){}

    /* 4a. the leaf icon returns to Finance */
    var logo=document.querySelector('.brand .logo');
    if(logo&&hub&&typeof hub.leaveSprout==='function'){
      logo.setAttribute('role','button');logo.setAttribute('tabindex','0');logo.setAttribute('aria-label','Back to Finance');
      var back=function(){try{hub.leaveSprout()}catch(e){}};
      logo.addEventListener('click',back);
      logo.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();back()}});
    }

    /* 4b. downloads (CSV export, backup JSON) go to Downloads/Sandpiper through the app, because a WebView cannot save blob links */
    var plainDownload=window.download;
    window.download=function(name,text,type){
      try{
        if(N&&N.saveFile){
          N.saveFile(String(name),String(type||'application/octet-stream'),btoa(unescape(encodeURIComponent(String(text)))));
          if(hub&&typeof hub.hint==='function')hub.hint('Saved to Downloads/Sandpiper/'+name);
          return;
        }
      }catch(e){}
      if(typeof plainDownload==='function')plainDownload(name,text,type);
    };

    /* tell the host Sprout is ready: it answers with __spApply(settings, transactions) */
    setTimeout(function(){try{if(hub&&typeof hub.sproutReady==='function')hub.sproutReady()}catch(e){}},0);
  });

  /* ---- 2/3. host -> Sprout: apply Sandpiper's settings and mirror the simple Finance transactions. Idempotent. ---- */
  function provString(){return customProviders.map(function(c){return c.name+(c.accountLabel&&c.accountLabel!==c.name?':'+c.accountLabel:'')}).join(', ')}
  function parseProviders(text){
    var out=[],seen={};
    String(text||'').split(',').forEach(function(part){
      var p=part.trim();if(!p)return;
      var i=p.indexOf(':'),name=(i<0?p:p.slice(0,i)).trim(),label=(i<0?'':p.slice(i+1)).trim();
      if(!name||seen[name.toLowerCase()])return;seen[name.toLowerCase()]=1;
      if(BUILTIN.some(function(b){return b.name.toLowerCase()===name.toLowerCase()}))return;   // bKash, Nagad, Rocket, City Bank already have exact patterns
      var old=customProviders.find(function(c){return c.name===name});     // keep the provider type (bank / mobile wallet) already known
      out.push({name:name,accountLabel:label||name,type:old&&old.type?old.type:'bank'});
    });
    return out;
  }
  function mapCat(cat,name){
    var m=CATEGORIES.find(function(c){return c.toLowerCase()===String(cat||'').toLowerCase()});
    return m||autoCat('Uncategorized',String(name||''));
  }
  function applySettings(s){
    if(!s)return;
    if(s.country&&typeof COUNTRIES!=='undefined'&&COUNTRIES[s.country]&&s.country!==country)setCountry(s.country);
    if(s.currency&&/^[A-Z]{3}$/.test(s.currency)&&s.currency!==currency)setCurrency(s.currency);
    if(s.lang&&s.lang!==lang)setLang(s.lang);
    setNavPos(s.navPos||'bottom');setFabSide(s.fab||'right');setNavHide(!!s.navHide);
    if(demoMode!==!!s.demo){demoMode=!!s.demo;render()}
    var want=s.sms?'granted':'not_requested';
    if(smsPermission!==want){smsPermission=want;if(want==='granted')reloadSprout(false);else render()}
    if(typeof s.providers==='string'){
      var list=parseProviders(s.providers);
      if(list.map(function(c){return c.name+(c.accountLabel!==c.name?':'+c.accountLabel:'')}).join(', ')!==provString()){customProviders=list;render()}
    }
  }
  function syncBasic(list){
    var acc=ensureAccount('Sandpiper','cash','sandpiper'),present={},seen={},ch=false;
    ledger.forEach(function(l){if(l.source==='sandpiper'&&l.refId)present[l.refId]=l});
    list.forEach(function(t){
      var ref='sp:'+t.id;seen[ref]=1;
      if(present[ref])return;                                              // already here (or voided inside Sprout: respected)
      var amt=Number(t.amount);if(!(amt>0))return;
      var dir=t.kind==='income'?'credit':'debit';
      eff(acc,dir,amt);acc.source=acc.source==='stated'?acc.source:'computed';
      ledger.push({id:nextTxId++,accountId:acc.id,amount:amt,dir:dir,ts:Number(t.ts)||Date.now(),cat:mapCat(t.cat,t.name),note:String(t.name||'').slice(0,120),
        incomeType:dir==='credit'?'other':null,source:'sandpiper',refId:ref,possibleDuplicate:false,void:false});
      ch=true;
    });
    ledger.slice().forEach(function(l){                                    // deleted on the simple Finance page: void here (reverses the balance)
      if(l.source==='sandpiper'&&l.refId&&!seen[l.refId]&&!l.void){voidTx(l.id);ch=true}
    });
    if(ch)render();
  }
  window.__spApply=function(settings,txs){
    try{applySettings(settings)}catch(e){}
    try{if(Array.isArray(txs))syncBasic(txs)}catch(e){}
  };
})();

/* ===== Real SMS: OTPs dropped, credited/debited read, transfers paired, ATM / cash out / cash in go to Cash in hand ===== */
(function(){
  'use strict';
  var hub=null;try{hub=window.parent&&window.parent!==window?window.parent.SpHub:null}catch(e){}
  var XFER_RE=/\b(?:transfer(?:red)?|fund\s*transfer|add\s*money|top[- ]?up|NPSB|BEFTN|RTGS|IBFT|send\s*money)\b/i;
  var ATM_RE=/\bATM\b/i,WD_RE=/\b(?:withdraw(?:n|al)?|cash\s*withdrawal)\b/i,POS_RE=/\b(?:purchase|POS|merchant|shop)\b/i;
  var COUT_RE=/\bcash[- ]?out\b/i,CIN_RE=/\bcash[- ]?in\b|\bcash\s*deposit\b|\bCDM\b/i;
  var FEE_RE=/\bfee\b[:\s]*(?:Tk|TK|BDT|Rs)?\.?\s?([\d,]+(?:\.\d+)?)/i;
  function reEsc(t){return String(t).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
  function norm(t){return String(t).toLowerCase().replace(/[^a-z0-9]/g,'')}
  function asProv(b,c){return b?{name:b.name,type:b.type||'mfs',key:b.name}:{name:c.accountLabel||c.name,type:c.type||'bank',key:c.name}}
  /* WHO sent it decides the provider: "Tk 1,000 debited ... transfer to bKash" from City Bank is a City Bank message even though it mentions bKash */
  function providerFor(sender,body){
    var ns=norm(sender),b=BUILTIN.find(function(p){return p.re.test(sender)||(ns.length>=3&&ns.indexOf(norm(p.name))>=0)});
    if(b)return asProv(b);
    var c=customProviders.find(function(c){var n=norm(c.name);return n.length>=3&&ns.indexOf(n)>=0});
    if(c)return asProv(null,c);
    var hay=sender+' '+body;                                       // pasted text has no sender: fall back to the text itself
    b=BUILTIN.find(function(p){return p.re.test(hay)});if(b)return asProv(b);
    c=customProviders.find(function(c){return new RegExp('\\b'+reEsc(c.name)+'\\b','i').test(hay)});
    return c?asProv(null,c):null;
  }
  /* other providers' names in the text would confuse Sprout's own reader (it takes the first provider it sees), so they are masked for it */
  function maskOthers(body,ownKey){
    var names=BUILTIN.map(function(p){return p.name}).concat(customProviders.map(function(c){return c.name}));
    names.forEach(function(n){if(n.toLowerCase()!==String(ownKey).toLowerCase())body=body.replace(new RegExp('\\b'+reEsc(n)+'\\b','gi'),'another provider')});
    return body;
  }
  window.__spProviderFor=providerFor;                           // used by Sprout's review inbox (Approve)
  function otherProviderMentioned(body,own){
    var names=BUILTIN.map(function(p){return p.name}).concat(customProviders.map(function(c){return c.name}));
    return names.some(function(n){return n.toLowerCase()!==String(own).toLowerCase()&&new RegExp('\\b'+reEsc(n)+'\\b','i').test(body)});
  }
  function kindOf(body){
    if(ATM_RE.test(body)&&(WD_RE.test(body)||(/\bdebited\b/i.test(body)&&!POS_RE.test(body))))return'atm';
    if(COUT_RE.test(body))return'cashout';
    if(CIN_RE.test(body))return'cashin';
    return null;
  }
  /* a cash movement is a transfer between an account and Cash in hand, never income or expense */
  function cashMove(prov,kind,body,ts){
    var g=genericMatch('credited '+body);                  // reuse Sprout's amount / reference / balance reader; direction comes from the kind
    if(!g||!(g.amount>0))return false;
    var acc=ensureAccount(prov.name,prov.type||'mfs','stated'),cash=ensureAccount('Cash','cash','manual');
    if(g.trxId?ledger.some(function(l){return l.accountId===acc.id&&l.refId===g.trxId}):
       ledger.some(function(l){return l.accountId===acc.id&&l.cat==='Transfer'&&l.amount===g.amount&&Math.abs(l.ts-ts)<120000})){blockedDuplicateCount++;return true}
    var fm=body.match(FEE_RE),fee=kind!=='cashin'&&fm?num(fm[1]):0,n0=ledger.length;
    if(kind==='cashin')doTransferInternal(cash,acc,g.amount,0,ts,g.trxId);
    else doTransferInternal(acc,cash,g.amount,fee,ts,g.trxId);
    var rows=ledger.slice(n0);
    var label={atm:['ATM withdrawal','Cash from ATM ('+acc.name+')'],cashout:['Cash out at agent','Cash from '+acc.name],cashin:['Cash in to '+acc.name,'Cash handed in to '+acc.name]}[kind];
    if(rows[0])rows[0].note=label[0];if(rows[1])rows[1].note=label[1];
    rows.forEach(function(r){r.source='sms-transfer'});
    if(g.balance!=null)setAccountBalance(acc,g.balance,ts,'stated');   // the SMS states the real balance: it wins over the computed one
    return true;
  }
  /* bank debit + wallet credit of the same amount within 10 minutes (one of them worded like a transfer) = ONE transfer, not an expense plus income */
  function pairTransfer(row,body,accName){
    row.xw=row.xw||XFER_RE.test(body);
    var best=null;
    ledger.forEach(function(o){
      if(o===row||o.source!=='sms'||o.void||o.transferGroupId||o.accountId===row.accountId||o.dir===row.dir)return;
      if(Math.abs(o.amount-row.amount)>=0.005||Math.abs(o.ts-row.ts)>10*60000||!(row.xw||o.xw))return;
      if(!best||Math.abs(o.ts-row.ts)<Math.abs(best.ts-row.ts))best=o;
    });
    if(!best)return;
    var debit=row.dir==='debit'?row:best,credit=row.dir==='credit'?row:best;
    var a=accounts.find(function(x){return x.id===debit.accountId}),b=accounts.find(function(x){return x.id===credit.accountId});
    var gid='trp'+debit.id+'_'+credit.id;
    [debit,credit].forEach(function(r){r.cat='Transfer';r.incomeType=null;r.source='sms-pair';r.transferGroupId=gid;r.possibleDuplicate=false});
    debit.note='Transfer to '+(b?b.name:'');credit.note='Transfer from '+(a?a.name:'');
  }
  function smartIngest(sender,body,ts){
    sender=String(sender||'');body=String(body||'');
    if(OTP_RE.test(body))return;                                  // OTP: never stored, never reviewed
    var prov=providerFor(sender,body);
    if(!prov)return plainIngest(sender,body,ts);                  // not a known provider: Sprout's own rules (discard)
    var kind=kindOf(body);
    if(kind&&cashMove(prov,kind,body,ts))return;
    var n0=ledger.length,mentions=otherProviderMentioned(body,prov.key);
    plainIngest(sender,maskOthers(body,prov.key),ts);             // credited / debited / balance etc. through Sprout's own pipeline
    if(ledger.length>n0){var row=ledger[ledger.length-1];if(row&&row.source==='sms'){row.xw=mentions||XFER_RE.test(body);pairTransfer(row,body,prov.name)}}
  }
  var plainIngest=null;

  /* ===== comments: a Comment button on every ledger row; the text is the transaction's note (shown, exported, backed up) ===== */
  function decorate(){
    document.querySelectorAll('button[onclick^="voidTx("]').forEach(function(v){
      if(v.previousElementSibling&&v.previousElementSibling.dataset&&v.previousElementSibling.dataset.cmt)return;
      var id=Number(String(v.getAttribute('onclick')).replace(/\D+/g,''));if(!id)return;
      var b=document.createElement('button');b.className='sm ghost';b.type='button';b.dataset.cmt=String(id);b.textContent='Comment';
      v.parentNode.insertBefore(b,v);
    });
  }
  function onComment(e){
    var b=e.target.closest&&e.target.closest('button[data-cmt]');if(!b)return;
    var l=ledger.find(function(x){return x.id===Number(b.dataset.cmt)});if(!l)return;
    var t=window.prompt('Comment for this transaction',l.note||'');if(t===null)return;
    l.note=String(t).trim().slice(0,200);render();
  }

  /* ===== host -> Sprout: captured SMS, oldest first. Acknowledged to the host only after Sprout has saved them. ===== */
  window.__spIngest=function(list){
    try{
      if(!Array.isArray(list)||!list.length||smsPermission!=='granted')return false;   // not granted: leave them pending
      var ids=[];
      list.forEach(function(m){if(m&&m.id){ids.push(m.id);pendingSmsQueue.push([String(m.sender||''),String(m.body||''),Number(m.ts)||Date.now()])}});
      reloadSprout(false);
      setTimeout(function(){try{if(hub&&typeof hub.smsDone==='function')hub.smsDone(ids)}catch(e){}},700);
      return true;
    }catch(e){try{if(hub&&typeof hub.smsDone==='function')hub.smsDone([])}catch(x){}return false}
  };

  document.addEventListener('DOMContentLoaded',function(){
    plainIngest=window.ingest;window.ingest=smartIngest;
    document.addEventListener('click',onComment);
    var raf=0;new MutationObserver(function(){if(!raf)raf=requestAnimationFrame(function(){raf=0;decorate()})}).observe(document.body,{childList:true,subtree:true});
    decorate();
  });
})();

