package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmsFilterTest {
    private val providers = listOf("bKash", "Nagad", "City Bank")

    @Test fun senderNamesMatchLoosely() {
        assertTrue(SmsFilter.senderMatches("bKash", providers))
        assertTrue(SmsFilter.senderMatches("CITYBANK", providers))
        assertTrue(SmsFilter.senderMatches("CityBank Alert", providers))
        assertTrue(SmsFilter.senderMatches("NAGAD", providers))
    }

    @Test fun otherSendersAreNeverKept() {
        assertFalse(SmsFilter.senderMatches("Grameenphone", providers))
        assertFalse(SmsFilter.senderMatches("+8801712345678", providers))   // a person
        assertFalse(SmsFilter.senderMatches("AB", providers))
        assertFalse(SmsFilter.senderMatches("bKash", emptyList()))            // nothing selected = nothing read
        assertFalse(SmsFilter.senderMatches("bKash", listOf("bk")))           // names under 3 characters never match
    }

    @Test fun otpIsDroppedBeforeAnythingIsStored() {
        assertTrue(SmsFilter.isOtp("Your OTP for bKash transaction is 583921. Do not share this code."))
        assertTrue(SmsFilter.isOtp("Use verification code 4421 to confirm payment of Tk 500"))
        assertFalse(SmsFilter.accept("bKash", "Your OTP for bKash transaction is 583921.", providers))
    }

    @Test fun onlyTransactionsPass() {
        assertTrue(SmsFilter.accept("bKash", "You have received Tk 2,500.00 from 017XXXXXXXX. TrxID 8N7K2P1. Balance Tk 14,840.00", providers))
        assertTrue(SmsFilter.accept("CityBank Alert", "Tk 10,000.00 debited from your card. Trans ID: BK3302955. Avail Bal: BDT 69,690.00", providers))
        assertTrue(SmsFilter.accept("bKash", "Cash Out Tk 2,000.00 from agent. TrxID 1K9P7T2. Balance Tk 67,690.00", providers))
        assertTrue(SmsFilter.accept("CITYBANK", "ATM withdrawal of BDT 5,000 at Gulshan. Avail Bal BDT 21,000", providers))
        assertFalse(SmsFilter.accept("bKash", "Get 10% cashback on your next recharge! Visit our app.", providers))
        assertFalse(SmsFilter.accept("Grameenphone", "You have received Tk 50 from a friend. Balance Tk 10", providers))
        assertFalse(SmsFilter.accept("bKash", "   ", providers))
    }

    @Test fun sameMessageGetsTheSameIdOnce() {
        val a = SmsFilter.id("bKash", 1_762_000_000_000L, "You have received Tk 100. TrxID A1")
        assertEquals(a, SmsFilter.id("BKASH", 1_762_000_000_000L, " You have received Tk 100. TrxID A1 "))
        assertNotEquals(a, SmsFilter.id("bKash", 1_762_000_000_001L, "You have received Tk 100. TrxID A1"))
        assertEquals(32, a.length)
    }

    @Test fun providerListParsing() {
        assertEquals(listOf("bKash", "City Bank"), SmsFilter.parseProviders("""["bKash"," City Bank ","bk","bKash"]"""))
        assertTrue(SmsFilter.parseProviders("not json").isEmpty())
    }
}

class SmsThreadsTest {
    @Test fun personalNumbersAreNeverOffered() {
        assertTrue(SmsFilter.isPersonalNumber("+8801712345678"))
        assertTrue(SmsFilter.isPersonalNumber("01712345678"))
        assertFalse(SmsFilter.isPersonalNumber("bKash"))
        assertFalse(SmsFilter.isPersonalNumber("16216"))        // a short code is a service, not a person
        assertFalse(SmsFilter.isPersonalNumber("CityBank"))
    }

    @Test fun threadsAreGroupedBySenderAndOnlyTransactionSendersListed() {
        val c = SmsFilter.ThreadCollector()
        c.add("bKash", "You have received Tk 500.00. TrxID A1. Balance Tk 900", 1_000L)
        c.add("BKASH", "Cash Out Tk 200.00. TrxID A2. Balance Tk 700", 2_000L)
        c.add("bKash", "Your OTP for bKash is 123456", 3_000L)                    // counted as a message, not as a transaction
        c.add("CityBank", "Tk 1,000.00 debited. Trans ID: X9. Avail Bal: BDT 5,000", 1_500L)
        c.add("PromoShop", "Big sale this weekend! Visit us today", 1_600L)       // no transaction wording: not offered
        c.add("+8801712345678", "I sent you Tk 500 received?", 1_700L)            // a person: not offered
        val r = c.result(10)
        assertEquals(listOf("BKASH", "CityBank"), r.map { it.sender })
        assertEquals(3, r[0].total)
        assertEquals(2, r[0].tx)
        assertEquals(2_000L, r[0].last)
        assertTrue(r[0].preview.startsWith("Cash Out"))
        assertTrue(r.none { it.sender == "PromoShop" })
    }
}
