package com.tanzil.reelcounter

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SwipeDetectorTest {
    private val page = 2000

    private fun sample(t: Long, dy: Int, dx: Int = 0, idx: Int = -1, view: String = "pager") =
        SwipeDetector.Sample(t, "ig", view, dx, dy, idx, if (idx >= 0) 50 else -1, page)

    /** Emits [n] scroll events travelling [pages] screen heights; returns the time after the last one. */
    private fun SwipeDetector.swipe(start: Long, pages: Float, n: Int = 12): Long {
        var t = start
        val per = (page * pages / n).toInt()
        repeat(n) { onSample(sample(t, per)); t += 16 }
        return t
    }

    @Test fun oneSwipeWithManyEventsCountsOnce() {
        val d = SwipeDetector()
        val t = d.swipe(0, 1f)
        assertTrue(d.flush(t + 260))
        assertFalse(d.flush(t + 600))
    }

    @Test fun snapAnimationResidueDoesNotRecount() {
        val d = SwipeDetector()
        var t = d.swipe(0, 1f)
        assertTrue(d.flush(t + 260))
        t += 300
        repeat(6) { d.onSample(sample(t, 25)); t += 16 }
        assertFalse(d.flush(t + 260))
    }

    @Test fun tapsAndSmallDragsNeverCount() {
        val d = SwipeDetector()
        val t = d.swipe(0, 0.12f, 4)
        assertFalse(d.flush(t + 260))
    }

    @Test fun slowDragWithPauseCountsOnce() {
        val d = SwipeDetector()
        var t = d.swipe(0, 0.3f, 4)
        assertFalse(d.flush(t + 260))
        t = d.swipe(t + 500, 0.7f, 6)
        assertTrue(d.flush(t + 260))
    }

    @Test fun backThenForwardOverSameReelCountsOnce() {
        val d = SwipeDetector()
        var t = d.swipe(0, 1f); assertTrue(d.flush(t + 260))
        t = d.swipe(t + 500, -1f); assertFalse(d.flush(t + 260))
        t = d.swipe(t + 500, 1f); assertFalse(d.flush(t + 260))   // same reel again
        t = d.swipe(t + 500, 1f); assertTrue(d.flush(t + 260))    // genuinely new reel
    }

    @Test fun horizontalCarouselIgnored() {
        val d = SwipeDetector()
        repeat(8) { d.onSample(sample(it * 16L, 0, dx = 400)) }
        assertFalse(d.flush(500))
    }

    @Test fun flingedFeedRejected() {
        val d = SwipeDetector()
        val t = d.swipe(0, 2.5f)
        assertFalse(d.flush(t + 260))
    }

    @Test fun indexOnlyAppsStillCount() {
        val d = SwipeDetector()
        d.onSample(sample(0, 0, idx = 5)); assertFalse(d.flush(300))
        d.onSample(sample(500, 0, idx = 6)); d.onSample(sample(516, 0, idx = 6))
        assertTrue(d.flush(800))
    }

    @Test fun strictModeRejectsLooseTravel() {
        val d = SwipeDetector(); var t = 0L
        repeat(10) { d.onSample(SwipeDetector.Sample(t, "ch", "web", 0, 120, -1, -1, page, 0, true)); t += 16 }
        assertFalse(d.flush(t + 260))                 // 0.6 page is fine for apps, too loose for ambiguous web pages
    }

    @Test fun browserDeltasInCssPixelsStillCount() {
        val d = SwipeDetector(); var t = 0L
        repeat(10) { d.onSample(SwipeDetector.Sample(t, "ch", "web", 0, 75, -1, -1, page, 750, false)); t += 16 }
        assertTrue(d.flush(t + 260))                  // 750 "dp" == one page when the browser reports CSS px
    }
}
