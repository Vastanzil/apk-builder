package com.tanzil.reelcounter

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.DecelerateInterpolator
import kotlin.math.max

/**
 * Liquid-glass pill, drawn in one pass (no bitmaps, no blur => cheap on the overlay window):
 * smoked/frosted gradient body, top specular gloss, accent inner glow, gradient rim light,
 * plus an animated sheen sweep and rim-glow pulse that [IslandOverlay] triggers.
 */
internal class LiquidGlassDrawable(private val density: Float) : Drawable() {
    var look: IslandLook = IslandLook.DARK_GLASS
        set(v) { if (field != v) { field = v; cacheKey = ""; invalidateSelf() } }
    /** Notch status-bar band: flat top, rounded bottom corners. */
    var band = false
        set(v) { if (field != v) { field = v; cacheKey = ""; invalidateSelf() } }

    private var sheen = -1f
    private var glow = 0f
    private var glowAmount = 1f
    private var sheenAnim: ValueAnimator? = null
    private var glowAnim: ValueAnimator? = null

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val sheenPath = Path()
    private val rect = RectF()
    private var cacheKey = ""
    private var bandW = 0f
    private var skew = 0f
    private var effects = true
    private var accent = 0xFF67C5ED.toInt()

    private fun dp(v: Float) = v * density

    private fun build(key: String) {
        cacheKey = key
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        val eff = if (band && look == IslandLook.SKY_GLASS) IslandLook.DARK_GLASS else look
        effects = eff != IslandLook.CLASSIC
        accent = if (eff == IslandLook.SKY_GLASS) 0xFF1D9BE0.toInt() else 0xFF67C5ED.toInt()
        rect.set(0f, 0f, w, h); rect.inset(dp(0.6f), dp(0.6f))
        path.reset()
        if (band) {
            val r = minOf(dp(16f), h / 2f)
            path.addRoundRect(rect, floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r), Path.Direction.CW)
        } else path.addRoundRect(rect, rect.height() / 2f, rect.height() / 2f, Path.Direction.CW)

        val top: Int; val bot: Int
        when (eff) {
            IslandLook.DARK_GLASS -> { top = 0xEE222E3A.toInt(); bot = 0xF4060A0E.toInt() }
            IslandLook.SKY_GLASS -> { top = 0xEAEAF7FF.toInt(); bot = 0xEA8FD4FA.toInt() }
            IslandLook.CLASSIC -> { top = Color.BLACK; bot = Color.BLACK }
        }
        body.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, top, bot, Shader.TileMode.CLAMP)
        val glossA = if (eff == IslandLook.SKY_GLASS) 150 else 80
        gloss.shader = LinearGradient(0f, rect.top, 0f, rect.top + h * 0.55f,
            Color.argb(glossA, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        inner.shader = LinearGradient(0f, rect.bottom, 0f, rect.bottom - h * 0.65f,
            Color.argb(80, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.argb(0, Color.red(accent), Color.green(accent), Color.blue(accent)), Shader.TileMode.CLAMP)
        rim.shader = if (!effects) null else if (eff == IslandLook.SKY_GLASS)
            LinearGradient(rect.left, rect.top, rect.right, rect.bottom, intArrayOf(0xFFFFFFFF.toInt(), 0x66FFFFFF, 0xCCFFFFFF.toInt()), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        else
            LinearGradient(rect.left, rect.top, rect.right, rect.bottom, intArrayOf(0xCCFFFFFF.toInt(), 0x1AFFFFFF, 0x66FFFFFF), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        rim.color = 0x26FFFFFF

        bandW = max(h * 1.6f, dp(36f)); skew = h * 0.5f
        sheenPath.reset()
        sheenPath.moveTo(0f, 0f); sheenPath.lineTo(bandW, 0f); sheenPath.lineTo(bandW - skew, h); sheenPath.lineTo(-skew, h); sheenPath.close()
        sheenPaint.shader = LinearGradient(0f, 0f, bandW, 0f, intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
    }

    override fun draw(c: Canvas) {
        if (bounds.isEmpty) return
        val key = "$look|${bounds.width()}|${bounds.height()}|$band"
        if (key != cacheKey) build(key)
        c.drawPath(path, body)
        if (effects) {
            c.save(); c.clipPath(path)
            c.drawRect(rect, gloss)
            inner.alpha = (255 * (0.7f + 0.3f * glow)).toInt().coerceIn(0, 255)
            c.drawRect(rect, inner)
            if (sheen in 0f..1f) {
                val x = -bandW + sheen * (bounds.width() + bandW + skew)
                c.translate(x, 0f); c.drawPath(sheenPath, sheenPaint)
            }
            c.restore()
        }
        rim.strokeWidth = dp(1f) + dp(0.6f) * glow
        c.drawPath(path, rim)
        if (glow > 0.01f && effects) {
            glowRim.strokeWidth = dp(1.4f)
            glowRim.color = Color.argb((glow * glowAmount * 235).toInt().coerceIn(0, 255), Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawPath(path, glowRim)
        }
    }

    /** One diagonal light sweep across the glass. */
    fun sweep(ms: Long) {
        if (!ValueAnimator.areAnimatorsEnabled()) return
        sheenAnim?.cancel()
        sheenAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms; interpolator = DecelerateInterpolator(1.3f)
            addUpdateListener { sheen = it.animatedValue as Float; invalidateSelf() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { sheen = -1f; invalidateSelf() }
            })
            start()
        }
    }

    /** Rim lights up in the accent colour and fades. */
    fun pulseGlow(ms: Long, amount: Float) {
        if (!ValueAnimator.areAnimatorsEnabled()) return
        glowAnim?.cancel(); glowAmount = amount
        glowAnim = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = ms
            addUpdateListener { glow = it.animatedValue as Float; invalidateSelf() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { glow = 0f; invalidateSelf() }
            })
            start()
        }
    }

    fun cancel() { sheenAnim?.cancel(); glowAnim?.cancel() }

    override fun setAlpha(alpha: Int) = Unit
    override fun setColorFilter(colorFilter: ColorFilter?) = Unit
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
}
