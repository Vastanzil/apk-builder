package com.tanzil.reelcounter

import android.content.Context
import android.content.Intent

enum class IslandStyle(val label: String) {
    AUTO("Auto (detect cutout)"),
    ISLAND("Dynamic island (punch-hole)"),
    STATUS_BAR("Black status bar (notch)"),
    FLOAT("Floating pill")
}

enum class IslandLook(val label: String) {
    DARK_GLASS("Liquid glass · dark"),
    SKY_GLASS("Liquid glass · sky blue"),
    CLASSIC("Classic black")
}

internal object CounterStore {
    const val ACTION_COUNT_CHANGED = "com.tanzil.reelcounter.COUNT_CHANGED"
    const val ACTION_STYLE_CHANGED = "com.tanzil.reelcounter.STYLE_CHANGED"
    const val ACTION_APPS_CHANGED = "com.tanzil.reelcounter.APPS_CHANGED"
    const val ACTION_PREVIEW = "com.tanzil.reelcounter.PREVIEW"
    const val ACTION_ENABLED_CHANGED = "com.tanzil.reelcounter.ENABLED_CHANGED"
    private const val PREFS = "reel_counter_store"
    private const val KEY_COUNT = "count"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_STYLE = "style"
    private const val KEY_APPS = "custom_apps"
    private const val KEY_BROWSER = "browser"
    private const val KEY_GAP = "gap"
    private const val KEY_LOOK = "look"
    private const val KEY_CAPTURE_UNTIL = "capture_until"
    private const val KEY_CAPTURED = "captured"

    fun count(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0)
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
        notify(context, ACTION_ENABLED_CHANGED)
    }

    fun style(context: Context): IslandStyle =
        runCatching { IslandStyle.valueOf(prefs(context).getString(KEY_STYLE, null) ?: "AUTO") }.getOrDefault(IslandStyle.AUTO)
    fun setStyle(context: Context, style: IslandStyle) {
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()
        notify(context, ACTION_STYLE_CHANGED)
    }

    // --- custom (modded / cloned) apps, one package name per entry
    fun customApps(c: Context): Set<String> =
        (prefs(c).getString(KEY_APPS, "") ?: "").split('\n', ',', ' ').map { it.trim() }.filter { it.contains('.') }.toSet()
    fun setCustomApps(c: Context, raw: String) {
        prefs(c).edit().putString(KEY_APPS, raw.split('\n', ',', ' ').map { it.trim() }.filter { it.contains('.') }.joinToString("\n")).apply()
        notify(c, ACTION_APPS_CHANGED)
    }
    fun addCustomApp(c: Context, pkg: String) = setCustomApps(c, (customApps(c) + pkg).joinToString("\n"))

    // --- "Detect app": for 30 s the service remembers the last app that scrolled
    fun startCapture(c: Context) { prefs(c).edit().putLong(KEY_CAPTURE_UNTIL, System.currentTimeMillis() + 30_000).putString(KEY_CAPTURED, "").apply() }
    fun captureUntil(c: Context): Long = prefs(c).getLong(KEY_CAPTURE_UNTIL, 0L).let { if (System.currentTimeMillis() < it) android.os.SystemClock.uptimeMillis() + (it - System.currentTimeMillis()) else 0L }
    fun setCaptured(c: Context, pkg: String) { prefs(c).edit().putString(KEY_CAPTURED, pkg).apply() }
    fun takeCaptured(c: Context): String? {
        val v = prefs(c).getString(KEY_CAPTURED, "").orEmpty()
        if (v.isEmpty()) return null
        prefs(c).edit().putString(KEY_CAPTURED, "").putLong(KEY_CAPTURE_UNTIL, 0L).apply(); return v
    }

    fun browserSupport(c: Context): Boolean = prefs(c).getBoolean(KEY_BROWSER, true)
    fun setBrowserSupport(c: Context, on: Boolean) { prefs(c).edit().putBoolean(KEY_BROWSER, on).apply() }

    /** Extra dp of black either side of the camera hole: 0 compact, 1 normal, 2 wide, 3 extra wide. */
    fun gapLevel(c: Context): Int = prefs(c).getInt(KEY_GAP, 2)
    fun gapExtraDp(c: Context): Int = intArrayOf(8, 18, 30, 44)[gapLevel(c).coerceIn(0, 3)]
    fun setGapLevel(c: Context, l: Int) { prefs(c).edit().putInt(KEY_GAP, l).apply(); notify(c, ACTION_STYLE_CHANGED) }

    fun look(c: Context): IslandLook =
        runCatching { IslandLook.valueOf(prefs(c).getString(KEY_LOOK, null) ?: "DARK_GLASS") }.getOrDefault(IslandLook.DARK_GLASS)
    fun setLook(c: Context, l: IslandLook) { prefs(c).edit().putString(KEY_LOOK, l.name).apply(); notify(c, ACTION_STYLE_CHANGED) }
    fun preview(c: Context) = notify(c, ACTION_PREVIEW)

    fun increment(context: Context): Int {
        val next = count(context) + 1
        prefs(context).edit().putInt(KEY_COUNT, next).apply()
        notify(context, ACTION_COUNT_CHANGED)
        return next
    }
    fun reset(context: Context) {
        prefs(context).edit().putInt(KEY_COUNT, 0).apply()
        notify(context, ACTION_COUNT_CHANGED)
    }
    private fun notify(context: Context, action: String) = context.sendBroadcast(Intent(action).setPackage(context.packageName))
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
