package com.tanzil.reelcounter

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var countLabel: TextView
    private lateinit var statusLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 10, 18)
        window.navigationBarColor = Color.rgb(9, 10, 18)
        buildUi()
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        if (::countLabel.isInitialized) refreshUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(Color.rgb(9, 10, 18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "🧠  Reel Counter"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        val subtitle = TextView(this).apply {
            text = "A tiny reminder to scroll intentionally."
            textSize = 14f
            setTextColor(0xFFB9B6C9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        countLabel = TextView(this).apply {
            textSize = 44f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        statusLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFB9B6C9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(countLabel)
        content.addView(statusLabel)
        content.addView(actionButton("1. Allow floating overlay") { openOverlayPermission() })
        content.addView(actionButton("2. Enable swipe detection") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        content.addView(actionButton("Start counter") { startCounter() })
        content.addView(actionButton("Stop counter") { stopCounter() })
        content.addView(actionButton("Reset count") { CounterStore.reset(this); refreshUi() })

        val note = TextView(this).apply {
            text = "Swipe counting uses Android scroll events from Instagram, Facebook, YouTube and TikTok. Android does not expose a reliable signal for every individual Reel/Short, so other vertical scrolling inside those apps may also count."
            textSize = 12f
            setTextColor(0xFF9693A8.toInt())
            setPadding(0, dp(20), 0, dp(12))
        }
        content.addView(note)
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        refreshUi()
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF5F43A8.toInt()))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(10) }
    }

    private fun openOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun startCounter() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission()
            statusLabel.text = "Grant overlay permission, then tap Start counter again."
            return
        }
        if (!isAccessibilityServiceEnabled()) {
            statusLabel.text = "Enable Reel Counter in Accessibility settings, then tap Start counter again."
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        CounterStore.setEnabled(this, true)
        val intent = Intent(this, CounterOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        refreshUi()
    }

    private fun stopCounter() {
        CounterStore.setEnabled(this, false)
        stopService(Intent(this, CounterOverlayService::class.java))
        refreshUi()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = ComponentName(this, ReelScrollAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshUi() {
        countLabel.text = "🧠  ${CounterStore.count(this)}"
        statusLabel.text = if (CounterStore.isEnabled(this)) "Counter enabled · overlay should be visible" else "Counter stopped"
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
