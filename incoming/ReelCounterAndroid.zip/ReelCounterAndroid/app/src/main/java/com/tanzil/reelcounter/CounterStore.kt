package com.tanzil.reelcounter

import android.content.Context

internal object CounterStore {
    private const val PREFS = "reel_counter_store"
    private const val KEY_COUNT = "count"
    private const val KEY_ENABLED = "enabled"

    fun count(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0)
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }
    fun increment(context: Context): Int {
        val next = count(context) + 1
        prefs(context).edit().putInt(KEY_COUNT, next).apply()
        context.sendBroadcast(android.content.Intent(CounterOverlayService.ACTION_COUNT_CHANGED).setPackage(context.packageName))
        return next
    }
    fun reset(context: Context) {
        prefs(context).edit().putInt(KEY_COUNT, 0).apply()
        context.sendBroadcast(android.content.Intent(CounterOverlayService.ACTION_COUNT_CHANGED).setPackage(context.packageName))
    }
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
