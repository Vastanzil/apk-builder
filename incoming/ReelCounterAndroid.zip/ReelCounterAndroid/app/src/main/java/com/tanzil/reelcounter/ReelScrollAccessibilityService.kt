package com.tanzil.reelcounter

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.os.SystemClock

/**
 * Receives only TYPE_VIEW_SCROLLED events from the allow-listed apps.
 * Window content retrieval is disabled: this service does not inspect text,
 * screenshots, video frames, messages, or user-entered content.
 */
class ReelScrollAccessibilityService : AccessibilityService() {
    private var lastAcceptedScrollAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        if (!CounterStore.isEnabled(this)) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg !in SUPPORTED_PACKAGES) return

        // A single gesture can generate several accessibility scroll events.
        // Debounce those events to approximate one count per swipe.
        val now = event.eventTime.takeIf { it > 0L } ?: SystemClock.uptimeMillis()
        if (now - lastAcceptedScrollAt < SWIPE_DEBOUNCE_MS) return
        lastAcceptedScrollAt = now
        CounterStore.increment(this)
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val SWIPE_DEBOUNCE_MS = 500L
        private val SUPPORTED_PACKAGES = setOf(
            "com.instagram.android",
            "com.facebook.katana",
            "com.facebook.lite",
            "com.google.android.youtube",
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.zhiliaoapp.musically.go"
        )
    }
}
