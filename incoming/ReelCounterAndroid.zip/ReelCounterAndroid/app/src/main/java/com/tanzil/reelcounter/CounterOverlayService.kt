package com.tanzil.reelcounter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.widget.LinearLayout
import android.widget.TextView

class CounterOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var pill: LinearLayout? = null
    private var countView: TextView? = null
    private var receiverRegistered = false

    private val countReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_COUNT_CHANGED) renderCount(CounterStore.count(this@CounterOverlayService), animate = true)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        registerCountReceiver()
        showPill()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun showPill() {
        if (pill != null || !android.provider.Settings.canDrawOverlays(this)) return

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(5), dp(15), dp(5))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(30).toFloat()
                setColor(0xF20B0C16.toInt())
                setStroke(dp(1), 0xFF9670FF.toInt())
            }
            elevation = dp(10).toFloat()
        }

        val brain = TextView(this).apply {
            text = "🧠"
            textSize = 19f
            includeFontPadding = false
        }
        val number = TextView(this).apply {
            text = CounterStore.count(this@CounterOverlayService).toString()
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            includeFontPadding = false
            setPadding(dp(8), 0, 0, 0)
        }
        container.addView(brain, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        container.addView(number, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            dp(40),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(5)
        }

        try {
            windowManager.addView(container, params)
            pill = container
            countView = number
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun renderCount(value: Int, animate: Boolean) {
        val view = countView ?: return
        view.text = value.toString()
        if (animate) {
            val pulse = ScaleAnimation(
                0.78f, 1f, 0.78f, 1f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 180
                interpolator = AccelerateDecelerateInterpolator()
            }
            view.startAnimation(pulse)
        }
    }

    @Suppress("DEPRECATION")
    private fun registerCountReceiver() {
        val filter = IntentFilter(ACTION_COUNT_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(countReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(countReceiver, filter)
        }
        receiverRegistered = true
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Reel Counter overlay", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the floating reel counter active"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Reel Counter is active")
                .setContentText("🧠 ${CounterStore.count(this)}")
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Reel Counter is active")
                .setContentText("Floating counter is running")
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (receiverRegistered) unregisterReceiver(countReceiver)
        pill?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        pill = null
        countView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_COUNT_CHANGED = "com.tanzil.reelcounter.COUNT_CHANGED"
        private const val CHANNEL_ID = "reel_counter_overlay"
        private const val NOTIFICATION_ID = 4107
    }
}
