# Reel Counter — Android Kotlin starter project

A minimal Android floating Dynamic-Island-style counter. The overlay contains exactly two visual elements: a brain emoji and a number.

## What is implemented

- Always-on-top pill using `TYPE_APPLICATION_OVERLAY`.
- Count persisted locally in `SharedPreferences`.
- Accessibility service listens only for `TYPE_VIEW_SCROLLED` events from Instagram, Facebook, YouTube and TikTok package IDs.
- A 500 ms debounce attempts to collapse multiple accessibility events from one swipe into one increment.
- Overlay is non-touchable so it does not intercept taps or swipes in the app underneath.
- Foreground service keeps the overlay alive while enabled.
- No screen recording, screenshots, OCR, video capture, or window-content retrieval.

## Important detection limitation

Android does not provide a universal, trustworthy “Reel/Short changed” callback across these apps. This implementation counts vertical scroll accessibility events from the supported apps. Therefore it can also count scrolling in comments, search results, profiles, or ordinary feeds, and some app versions may emit too few or too many events. It is an estimate, not an exact Reel counter. The supported app package IDs can also change by region/version.

## Build

1. Open this folder in Android Studio (JDK 17).
2. Allow Gradle sync to complete.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the phone.
5. Open Reel Counter and grant **Display over other apps**.
6. Open **Enable swipe detection** and enable Reel Counter under Android Accessibility settings.
7. Return to Reel Counter and tap **Start counter**.

To stop the overlay, open the app and tap **Stop counter**. The count is retained until **Reset count** is tapped.

## Integration into an existing app

This is a standalone starter project because the existing Sandpiper Android project ZIP was not attached to this conversation. To merge it into an existing app, copy the Kotlin classes and resource XML, merge the manifest declarations and permissions, and resolve any namespace/package changes. Do not replace the existing app manifest wholesale.

## Android permission disclosure

The accessibility service is used only to receive scroll events from the explicitly allow-listed packages. `canRetrieveWindowContent` is false. The app should clearly explain this to users before directing them to enable the service.
