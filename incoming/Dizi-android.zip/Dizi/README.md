# Dizi for Android

Offline reader that speaks documents, takes dictation (system or Whisper), summarises with on-device AI models, exports audio and keeps quick voice notes.
A native Kotlin shell around the bundled web app (`app/src/main/assets/dizi.html`).

## Build

Requirements: Android Studio (current stable), JDK 17+, Android SDK Platform 35.

1. Open this folder in Android Studio and let Gradle sync. Pinned to AGP 8.8.2 + Gradle 8.10.2 (AGP 8.8 needs exactly Gradle >= 8.10.2). If Studio offers to upgrade the
   Android Gradle Plugin, accept it.
2. Run on a device or emulator: **Run > Run 'app'** (debug build, id `app.dizi.reader.debug`).
3. No wrapper jar is included. From a terminal, run `gradle wrapper --gradle-version 8.10.2`
   once (needs a local Gradle), then:

```
./gradlew assembleDebug        # app/build/outputs/apk/debug/
./gradlew bundleRelease        # app/build/outputs/bundle/release/  (Play Store .aab)
./gradlew assembleRelease      # signed .apk if keystore.properties exists
```

## Release signing

```
keytool -genkeypair -v -keystore dizi-release.jks -alias dizi -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit the values
```

Keep the keystore and `keystore.properties` out of version control (already git-ignored) and back them up.
Without `keystore.properties`, release builds are unsigned.

## What is native

| Feature | Implementation |
|---|---|
| Read aloud with word highlight | Android `TextToSpeech` via `native-shim.js` (offline voices preferred) |
| Dictation, quick note | `SpeechRecognizer` (on-device on Android 13+), or **Whisper** (whisper.cpp, tiny/base/small q5_1) when a model is downloaded and selected |
| Offline AI (summary, key points, simplify, clean, ask a question) | **LiteRT-LM** `litertlm-android` runs Gemma 4 E2B/E4B and Qwen3.5 0.8B/2B/4B/9B `.litertlm` files from `litert-community` on Hugging Face. Long documents are split into chunks (map-reduce). Without a model the rule-based tools are used. |
| Model downloads | `Downloader.kt`: resumable (HTTP Range), app-private storage, foreground service so it survives the screen going off. Only URLs listed in `ModelCatalog.kt` can be fetched. |
| Save as audio (MP3, M4A) | `AudioExporter.kt`: TextToSpeech renders chunks, they are resampled and encoded to MP3 (shine, native) or AAC (MediaCodec), then saved to Music/Dizi (MediaStore). |
| HD voices | The phone's speech engine downloads them: the button opens the system voice data screen, installed voices show up in the voice picker. |
| Reading with the screen off | Foreground service (media playback) + notification |
| Home-screen widget and launcher shortcut | `QuickNoteWidget`, dynamic shortcut |
| Library, notes, settings | WebView `localStorage` (app-private) |

## Build notes

- Toolchain: Gradle 8.10.2, AGP 8.8.2, Kotlin 2.3.0 (needed to read LiteRT-LM's Kotlin metadata), JDK 17, compileSdk/targetSdk 35.
- Native code (whisper.cpp v1.7.5 and the shine MP3 encoder) is fetched from GitHub by CMake during the build, so the build machine needs network access, git, and the Android NDK + CMake 3.22.1 (Android Studio and GitHub runners have them; Gradle installs them if the SDK licences are accepted).
- To build without native code: `-Pdizi.native=false`. Whisper and MP3 then report "not available"; M4A export and everything else still work.
- ABI: arm64-v8a only (nearly all current phones). Add `x86_64` to `abiFilters` for emulators.
- Size: LiteRT-LM adds roughly 20-30 MB to the APK. Models are not bundled.

## Privacy and security

- `INTERNET` is used only by the native model downloader. The page cannot make requests (CSP `connect-src 'none'`), navigation to other hosts is blocked, and the downloader accepts only `https://huggingface.co/...` URLs chosen from the built-in catalog.
- Backups are disabled (`allowBackup=false`). Models and the library stay on the phone.
- The JavaScript bridge validates its inputs and only the bundled page can load.

## Things to check on a real phone (not testable in the build environment)

This version was written without the ability to compile or run it on a device. The web UI was exercised in a headless browser against a mocked bridge, but the Kotlin and C++ have not been compiled here. Expect to fix small things on the first build, and check:

- **Model file names and sizes** in `ModelCatalog.kt` against the Hugging Face repos (the 4B and 9B Qwen3.5 files and the Gemma 4 files in particular). A wrong name shows "File not found on the server".
- **Qwen3.5 + Gemma 4 need LiteRT-LM 0.15 or newer** (0.18.0 is pinned). The 9B model needs a 12 GB phone. CPU is the default backend; GPU is experimental and falls back to CPU.
- **Whisper quality**: tiny and base are weak outside English. Use small for Bengali or Hindi. Dictation arrives in segments after each pause, not word by word.
- **MP3** uses the shine encoder with MPEG-2 (22.05 kHz) or MPEG-1 (44.1 kHz) mono at 48, 64 or 96 kbps.
- **Gemma and Qwen files are large** (1-5 GB). Downloads ask for a second tap on mobile data.

## Notes

- Android's recognizer may play a short sound each time it restarts during long dictation.
- The app uses system fonts. To bundle Atkinson Hyperlegible, add the font files under `assets/` and reference them with `@font-face` in `dizi.html`.
- Update `dizi.html` and `native-shim.js` in `app/src/main/assets/` to change the UI.
