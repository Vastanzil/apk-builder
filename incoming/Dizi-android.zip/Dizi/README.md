# Dizi for Android

Offline reader that speaks documents, takes dictation and keeps quick voice notes.
A native Kotlin shell around the bundled web app (`app/src/main/assets/dizi.html`).

## Build

Requirements: Android Studio (current stable), JDK 17+, Android SDK Platform 36.

1. Open this folder in Android Studio and let Gradle sync. If Studio offers to upgrade the
   Android Gradle Plugin, accept it.
2. Run on a device or emulator: **Run > Run 'app'** (debug build, id `app.dizi.reader.debug`).
3. No wrapper jar is included. From a terminal, run `gradle wrapper --gradle-version 8.13`
   once (needs a local Gradle), then:

```
./gradlew assembleDebug        # app/build/outputs/apk/debug/
./gradlew bundleRelease        # app/build/outputs/bundle/release/  (Play Store .aab)
./gradlew assembleRelease      # signed .apk if keystore.properties exists
```

## Release signing

```
keytool -genkeypair -v -keystore dizi-release.jks -alias dizi -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit the values
```

Keep the keystore and `keystore.properties` out of version control (already git-ignored) and back them up.
Without `keystore.properties`, release builds are unsigned.

## What is native

| Feature | Implementation |
|---|---|
| Read aloud with word highlight | Android `TextToSpeech` via `native-shim.js` (offline voices preferred) |
| Dictation and quick note | `SpeechRecognizer`, on-device on Android 13+ when available |
| Reading with the screen off | Foreground service (media playback) + notification |
| Home-screen widget and launcher shortcut | `QuickNoteWidget`, dynamic shortcut |
| Back button, insets, dark mode | `MainActivity` |
| Library, notes, settings | WebView `localStorage` (app-private) |

## Privacy and security

- `INTERNET` is used only by the system DownloadManager for models you choose. The page is served from assets over `https://appassets.androidplatform.net`,
  navigation to any other host is blocked, and the page has a strict Content-Security-Policy.
- Backups are disabled (`allowBackup=false`).
- The JavaScript bridge validates its inputs and only the bundled page can load.

## Offline AI models

Settings > Offline AI lists models for 4, 6, 8 and 12 GB phones. Tapping Download starts the system
DownloadManager (Wi-Fi only by default, resumes after interruptions, shows a notification) and the file is
stored in app-private storage. Inference runs with LiteRT-LM (`litertlm-android`) in `LlmEngine.kt`.

| Id | Model | File | Size |
|---|---|---|---|
| q35-08 | Qwen3.5 0.8B | litert-community/Qwen3.5-0.8B / Qwen3.5-0.8B_int8.litertlm | 978 MB |
| q35-2 | Qwen3.5 2B | litert-community/Qwen3.5-2B / Qwen3.5-2B_int8.litertlm | 1.97 GB |
| g4-e2b | Gemma 4 E2B | litert-community/gemma-4-E2B-it-litert-lm / gemma-4-E2B-it.litertlm | 2.58 GB |
| g4-e4b | Gemma 4 E4B | litert-community/gemma-4-E4B-it-litert-lm / gemma-4-E4B-it.litertlm | 3.65 GB |
| q35-4-i4 | Qwen3.5 4B INT4 | litert-community/Qwen3.5-4B / Qwen3.5-4B_mixed_int4.litertlm | 2.75 GB |
| q35-4 | Qwen3.5 4B INT8 | litert-community/Qwen3.5-4B / Qwen3.5-4B_int8.litertlm | 4.42 GB |

To change the list, edit `ModelCatalog.kt` (URLs) and `MODELS` in `dizi.html` (UI).

Things to check on the first run:
- `litertlm-android` is set to `latest.release`. After a successful build, pin the resolved version in
  `gradle/libs.versions.toml`. Qwen3.5 files need LiteRT-LM 0.15 or newer.
- The Gemma 4 E4B file name follows the E2B naming and was not opened directly. If a download shows
  "Model file not found online", check the file name in the Hugging Face repo and update `ModelCatalog.kt`.
- Qwen3.5 runs on CPU only here. Gemma tries the GPU first and falls back to CPU.
- Qwen3.5 bundles need a fresh engine per request, so each Qwen request reloads the model (several seconds).
- Android's DownloadManager keeps a notification during downloads. On Android 13+ the app asks for the
  notification permission the first time it reads aloud.

## Not implemented yet

- HD voice packs, Whisper models, MP3/M4A export (shown as unavailable).
- Dictation keeps text only. Audio is not saved.
- Stopping a generation hides its output but the model finishes in the background.

## Notes

- Android's recognizer may play a short sound each time it restarts during long dictation.
- The app uses system fonts. To bundle Atkinson Hyperlegible, add the font files under `assets/` and
  reference them with `@font-face` in `dizi.html`.
- Update `dizi.html` and `native-shim.js` in `app/src/main/assets/` to change the UI.
