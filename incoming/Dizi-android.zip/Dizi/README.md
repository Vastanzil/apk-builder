# Dizi for Android

Offline reader that speaks documents, takes dictation and keeps quick voice notes.
A native Kotlin shell around the bundled web app (`app/src/main/assets/dizi.html`).

## Build

Requirements: Android Studio (current stable), JDK 17+, Android SDK Platform 36.

1. Open this folder in Android Studio and let Gradle sync. If Studio offers to upgrade the
   Android Gradle Plugin, accept it.
2. Run on a device or emulator: **Run > Run 'app'** (debug build, id `app.dizi.reader.debug`).
3. No wrapper jar is included. From a terminal, run `gradle wrapper --gradle-version 8.13`
   once (needs a local Gradle), then:

```
./gradlew assembleDebug        # app/build/outputs/apk/debug/
./gradlew bundleRelease        # app/build/outputs/bundle/release/  (Play Store .aab)
./gradlew assembleRelease      # signed .apk if keystore.properties exists
```

## Release signing

```
keytool -genkeypair -v -keystore dizi-release.jks -alias dizi -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit the values
```

Keep the keystore and `keystore.properties` out of version control (already git-ignored) and back them up.
Without `keystore.properties`, release builds are unsigned.

## What is native

| Feature | Implementation |
|---|---|
| Read aloud with word highlight | Android `TextToSpeech` via `native-shim.js` (offline voices preferred) |
| Dictation and quick note | `SpeechRecognizer`, on-device on Android 13+ when available |
| Reading with the screen off | Foreground service (media playback) + notification |
| Home-screen widget and launcher shortcut | `QuickNoteWidget`, dynamic shortcut |
| Back button, insets, dark mode | `MainActivity` |
| Library, notes, settings | WebView `localStorage` (app-private) |

## Privacy and security

- No `INTERNET` permission. The page is served from assets over `https://appassets.androidplatform.net`,
  navigation to any other host is blocked, and the page has a strict Content-Security-Policy.
- Backups are disabled (`allowBackup=false`).
- The JavaScript bridge validates its inputs and only the bundled page can load.

## Not implemented yet (shown as "not available" in the app)

- Downloading offline AI models (Qwen3.5, Gemma 4) and running them. The catalog and settings are in
  the UI. Inference needs a runtime such as LiteRT-LM or llama.cpp, plus the `INTERNET` permission
  for downloads.
- HD voice packs, Whisper models, MP3/M4A export.
- Dictation keeps text only. Audio is not saved.

## Notes

- Android's recognizer may play a short sound each time it restarts during long dictation.
- The app uses system fonts. To bundle Atkinson Hyperlegible, add the font files under `assets/` and
  reference them with `@font-face` in `dizi.html`.
- Update `dizi.html` and `native-shim.js` in `app/src/main/assets/` to change the UI.
