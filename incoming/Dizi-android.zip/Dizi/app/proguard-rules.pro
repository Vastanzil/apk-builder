-keepattributes JavascriptInterface
-keepclassmembers class app.dizi.reader.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# LiteRT-LM uses JNI and reflection
-keep class com.google.ai.edge.litertlm.** { *; }
-dontwarn com.google.ai.edge.litertlm.**
