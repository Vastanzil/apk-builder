-keepattributes JavascriptInterface
-keepclassmembers class app.dizi.reader.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
