-keepattributes JavascriptInterface
-keepclassmembers class app.dizi.reader.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# LiteRT-LM and JNI
-keep class com.google.ai.edge.litertlm.** { *; }
-dontwarn com.google.ai.edge.litertlm.**
-keep class app.dizi.reader.WhisperJni { *; }
-keep class app.dizi.reader.Mp3Jni { *; }
