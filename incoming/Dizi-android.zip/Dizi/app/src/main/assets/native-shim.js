/* Dizi native shim: maps the Web Speech API onto Android TextToSpeech and SpeechRecognizer. */
(function () {
  'use strict';
  var N = window.DiziNative;
  if (!N) return;
  var S = window.DiziShim = {};
  function def(name, val) {
    try { Object.defineProperty(window, name, { value: val, configurable: true, writable: true }); }
    catch (e) { try { window[name] = val; } catch (e2) {} }
  }

  /* ---------- events from the native side (downloads, language model, audio export) ---------- */
  var handlers = {};
  S.on = function (name, fn) { (handlers[name] = handlers[name] || []).push(fn); };
  function fire(name, args) { (handlers[name] || []).forEach(function (f) { try { f.apply(null, args); } catch (e) {} }); }
  S._dl = function (kind, id, done, total, status) { fire('dl', [kind, id, done, total, status]); };
  S._llm = function (rid, type, text) { fire('llm', [rid, type, text]); };
  S._exp = function (jid, type, value) { fire('exp', [jid, type, value]); };
  S.state = function () { try { return JSON.parse(N.state()); } catch (e) { return null; } };

  /* ---------- speech synthesis ---------- */
  var voices = [], pending = {}, uid = 0, live = 0, offT = 0, wasOn = false;
  function Voice(o) { this.name = o.name; this.lang = o.lang; this.voiceURI = o.uri; this.localService = true; this.default = false; }
  function Utterance(text) {
    this.text = String(text || ''); this.lang = ''; this.voice = null; this.rate = 1; this.pitch = 1; this.volume = 1;
    this.onstart = null; this.onend = null; this.onerror = null; this.onboundary = null;
  }
  function setPlaying(on) {
    if (on === wasOn) return; wasOn = on;
    try { var t = document.getElementById('docTitle'); N.playing(on, t ? t.textContent : ''); } catch (e) {}
  }
  function idle() { clearTimeout(offT); offT = setTimeout(function () { if (live <= 0) setPlaying(false); }, 900); }
  var synth = {
    speaking: false, pending: false, paused: false, onvoiceschanged: null,
    getVoices: function () { return voices; },
    speak: function (u) {
      var id = 'u' + (++uid), v = u.voice;
      pending[id] = u; live++; clearTimeout(offT); setPlaying(true);
      N.speak(id, u.text, v ? v.voiceURI : '', u.lang || (v && v.lang) || 'en-US', u.rate || 1);
    },
    cancel: function () { pending = {}; live = 0; N.cancel(); idle(); },
    pause: function () {}, resume: function () {},
    addEventListener: function () {}, removeEventListener: function () {}
  };
  S._voices = function (json) {
    try { voices = JSON.parse(json).map(function (o) { return new Voice(o); }); } catch (e) { voices = []; }
    if (typeof synth.onvoiceschanged === 'function') { try { synth.onvoiceschanged(); } catch (e) {} }
  };
  S._ev = function (id, type, n) {
    var u = pending[id]; if (!u) return;
    try {
      if (type === 'start') { synth.speaking = true; if (u.onstart) u.onstart({}); }
      else if (type === 'boundary') { if (u.onboundary) u.onboundary({ name: 'word', charIndex: n }); }
      else {
        delete pending[id]; live = Math.max(0, live - 1);
        if (!live) { synth.speaking = false; idle(); }
        if (type === 'end') { if (u.onend) u.onend({}); }
        else if (u.onerror) u.onerror({ error: 'synthesis-failed' });
      }
    } catch (e) {}
  };
  def('speechSynthesis', synth);
  def('SpeechSynthesisUtterance', Utterance);
  try { S._voices(N.voices()); } catch (e) {}

  /* ---------- speech recognition ---------- */
  var cur = null, curSid = 0;
  function Rec() { this.continuous = false; this.interimResults = false; this.lang = 'en-US'; this.onresult = null; this.onerror = null; this.onend = null; this.onstart = null; }
  Rec.prototype.start = function () { cur = this; try { curSid = N.srStart(this.lang || 'en-US'); } catch (e) {} };
  Rec.prototype.stop = function () { try { N.srStop(); } catch (e) {} };
  Rec.prototype.abort = function () { try { N.srAbort(); } catch (e) {} };
  function ev(final, t) { return { resultIndex: 0, results: [{ isFinal: final, length: 1, 0: { transcript: t, confidence: 1 } }] }; }
  S._sr = function (kind, p, sid) {
    var r = cur; if (!r || sid !== curSid) return;
    try {
      if (kind === 'partial') { if (r.onresult) r.onresult(ev(false, p)); }
      else if (kind === 'final') { if (r.onresult) r.onresult(ev(true, p)); }
      else if (kind === 'error') { if (r.onerror) r.onerror({ error: p }); }
      else if (kind === 'end') { if (r.onend) r.onend({}); }
    } catch (e) {}
  };
  def('SpeechRecognition', Rec);
  def('webkitSpeechRecognition', Rec);
})();
