// JNI bridge to the shine MP3 encoder (mono, CBR). Kotlin side: app.dizi.reader.Mp3Jni
#include <jni.h>
#include <cstdint>
#include <cstring>
#include <vector>

extern "C" {
#include "layer3.h"
}

namespace {
struct Enc {
    shine_t s = nullptr;
    int spp = 0;  // samples per pass (mono)
    std::vector<int16_t> pending;
};

void drain(Enc *e, std::vector<uint8_t> &out, bool all) {
    while (static_cast<int>(e->pending.size()) >= e->spp) {
        int written = 0;
        unsigned char *d = shine_encode_buffer_interleaved(e->s, e->pending.data(), &written);
        if (d != nullptr && written > 0) out.insert(out.end(), d, d + written);
        e->pending.erase(e->pending.begin(), e->pending.begin() + e->spp);
    }
    (void) all;
}

jbyteArray toArray(JNIEnv *env, const std::vector<uint8_t> &v) {
    jbyteArray a = env->NewByteArray(static_cast<jsize>(v.size()));
    if (!v.empty()) env->SetByteArrayRegion(a, 0, static_cast<jsize>(v.size()), reinterpret_cast<const jbyte *>(v.data()));
    return a;
}
}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_app_dizi_reader_Mp3Jni_open(JNIEnv *, jobject, jint sampleRate, jint kbps) {
    if (shine_check_config(sampleRate, kbps) < 0) return 0;
    shine_config_t cfg;
    memset(&cfg, 0, sizeof(cfg));
    shine_set_config_mpeg_defaults(&cfg.mpeg);
    cfg.wave.channels = static_cast<decltype(cfg.wave.channels)>(1);   // mono
    cfg.wave.samplerate = sampleRate;
    cfg.mpeg.mode = static_cast<decltype(cfg.mpeg.mode)>(3);           // MONO
    cfg.mpeg.bitr = kbps;
    shine_t s = shine_initialise(&cfg);
    if (s == nullptr) return 0;
    Enc *e = new Enc();
    e->s = s;
    e->spp = shine_samples_per_pass(s);
    return reinterpret_cast<jlong>(e);
}

JNIEXPORT jbyteArray JNICALL
Java_app_dizi_reader_Mp3Jni_encode(JNIEnv *env, jobject, jlong handle, jshortArray pcm, jint len) {
    auto *e = reinterpret_cast<Enc *>(handle);
    std::vector<uint8_t> out;
    if (e != nullptr && len > 0) {
        const size_t old = e->pending.size();
        e->pending.resize(old + static_cast<size_t>(len));
        env->GetShortArrayRegion(pcm, 0, len, reinterpret_cast<jshort *>(e->pending.data() + old));
        drain(e, out, false);
    }
    return toArray(env, out);
}

JNIEXPORT jbyteArray JNICALL
Java_app_dizi_reader_Mp3Jni_finish(JNIEnv *env, jobject, jlong handle) {
    auto *e = reinterpret_cast<Enc *>(handle);
    std::vector<uint8_t> out;
    if (e != nullptr) {
        if (!e->pending.empty()) {
            e->pending.resize(static_cast<size_t>(e->spp), 0);
            drain(e, out, true);
        }
        int written = 0;
        unsigned char *d = shine_flush(e->s, &written);
        if (d != nullptr && written > 0) out.insert(out.end(), d, d + written);
    }
    return toArray(env, out);
}

JNIEXPORT void JNICALL
Java_app_dizi_reader_Mp3Jni_close(JNIEnv *, jobject, jlong handle) {
    auto *e = reinterpret_cast<Enc *>(handle);
    if (e != nullptr) {
        shine_close(e->s);
        delete e;
    }
}

}  // extern "C"
