package app.dizi.reader

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private lateinit var bridge: NativeBridge
    private var pageReady = false
    private var pendingQuick = false
    private var micCallback: ((Boolean) -> Unit)? = null

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            micCallback?.invoke(granted)
            micCallback = null
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        // Edge-to-edge is enforced on newer Android: keep the web UI clear of bars, cutouts and the keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true // localStorage keeps the library, notes and settings
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = 100
            mediaPlaybackRequiresUserGesture = true
        }

        bridge = NativeBridge(this, web)
        web.addJavascriptInterface(bridge, "DiziNative")

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // Only the bundled app may load. Everything else is blocked.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != ASSET_HOST

            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
                if (pendingQuick) {
                    pendingQuick = false
                    fireQuickNote()
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.Dizi&&Dizi.back&&Dizi.back())||false") { r ->
                    if (r != "true") finish()
                }
            }
        })

        web.loadUrl(START_URL)
        publishShortcut()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == ACTION_QUICK_NOTE) {
            i.action = Intent.ACTION_MAIN
            if (pageReady) fireQuickNote() else pendingQuick = true
        }
    }

    private fun fireQuickNote() {
        web.evaluateJavascript("window.Dizi&&window.Dizi.quick()", null)
    }

    private fun publishShortcut() {
        try {
            val intent = Intent(this, MainActivity::class.java).setAction(ACTION_QUICK_NOTE)
            val shortcut = ShortcutInfoCompat.Builder(this, "quick_note")
                .setShortLabel(getString(R.string.shortcut_quick_note))
                .setIcon(IconCompat.createWithResource(this, R.drawable.ic_shortcut_quick_note))
                .setIntent(intent)
                .build()
            ShortcutManagerCompat.setDynamicShortcuts(this, listOf(shortcut))
        } catch (_: Exception) {
        }
    }

    /** Runs [cb] with true when the microphone permission is (or becomes) granted. */
    fun withMic(cb: (Boolean) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
        } else {
            micCallback = cb
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun startPlayback(title: String) {
        askNotificationsOnce()
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, PlaybackService::class.java).putExtra(PlaybackService.EXTRA_TITLE, title)
            )
        } catch (_: Exception) {
        }
    }

    fun stopPlayback() {
        stopService(Intent(this, PlaybackService::class.java))
    }

    fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        val prefs = getSharedPreferences("dizi", MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::bridge.isInitialized) bridge.onResume()
    }

    override fun onDestroy() {
        bridge.release()
        stopPlayback()
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val ACTION_QUICK_NOTE = "app.dizi.reader.QUICK_NOTE"
        private const val ASSET_HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$ASSET_HOST/assets/dizi.html"
    }
}
