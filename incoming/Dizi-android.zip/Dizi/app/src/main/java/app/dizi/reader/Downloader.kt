package app.dizi.reader

import android.content.Context
import android.os.StatFs
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Resumable model downloader. Files go to filesDir/models/<kind>/ (app-private). A "<file>.part" file is
 * kept between attempts and continued with an HTTP Range request. A "<file>.ok" marker is written only
 * after the whole file arrived, so a half-finished file is never treated as installed.
 */
class Downloader(
    private val ctx: Context,
    /** kind, id, bytesDone, bytesTotal, status: "progress" | "done" | "cancelled" | "error:<reason>" */
    private val onEvent: (String, String, Long, Long, String) -> Unit
) {
    private val exec = Executors.newFixedThreadPool(2)
    private val flags = ConcurrentHashMap<String, AtomicBoolean>()
    val progress = ConcurrentHashMap<String, LongArray>()

    fun file(i: ModelCatalog.Item) = File(ctx.filesDir, "models/${i.dir}/${i.file}")
    private fun marker(i: ModelCatalog.Item) = File(file(i).path + ".ok")
    private fun part(i: ModelCatalog.Item) = File(file(i).path + ".part")
    private fun key(i: ModelCatalog.Item) = "${i.kind}:${i.id}"

    fun installed(i: ModelCatalog.Item) = file(i).isFile && marker(i).isFile

    /** Returns true when a new download was started. */
    fun start(i: ModelCatalog.Item): Boolean {
        val k = key(i)
        if (installed(i) || flags.containsKey(k)) return false
        val flag = AtomicBoolean(false)
        flags[k] = flag
        exec.execute { run(i, flag) }
        return true
    }

    fun cancel(i: ModelCatalog.Item) {
        flags[key(i)]?.set(true)
    }

    fun remove(i: ModelCatalog.Item) {
        cancel(i)
        file(i).delete(); marker(i).delete(); part(i).delete()
    }

    fun isRunning(i: ModelCatalog.Item) = flags.containsKey(key(i))

    fun shutdown() {
        flags.values.forEach { it.set(true) }
        exec.shutdown()
    }

    private fun open(first: URL, resumeFrom: Long): Pair<HttpURLConnection, Int> {
        var url = first
        var hops = 0
        while (true) {
            val c = url.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "Dizi-Android")
            c.setRequestProperty("Accept-Encoding", "identity")
            if (resumeFrom > 0) c.setRequestProperty("Range", "bytes=$resumeFrom-")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("bad redirect")
                c.disconnect()
                url = URL(url, loc)
                if (url.protocol != "https") throw IOException("insecure redirect")
                if (++hops > 6) throw IOException("too many redirects")
                continue
            }
            return c to code
        }
    }

    private fun run(i: ModelCatalog.Item, flag: AtomicBoolean) {
        val k = key(i)
        val dst = file(i)
        val tmp = part(i)
        var conn: HttpURLConnection? = null
        try {
            dst.parentFile?.mkdirs()
            val first = URL(i.url)
            if (first.protocol != "https" || first.host != "huggingface.co") throw IOException("blocked host")

            var resume = if (tmp.isFile) tmp.length() else 0L
            var (c, code) = open(first, resume)
            conn = c
            if (code == 416) {          // our partial file is not valid for the server's file: start over
                c.disconnect(); tmp.delete(); resume = 0
                val r = open(first, 0); c = r.first; code = r.second; conn = c
            }
            if (code != 200 && code != 206) throw IOException("HTTP $code")
            if (code == 200) resume = 0  // server ignored Range

            val len = c.contentLengthLong
            val total = if (len > 0) resume + len else 0L
            val need = (if (total > 0) total else i.approxBytes) - resume
            val free = StatFs(ctx.filesDir.path).availableBytes
            if (free < need + 150_000_000L) throw IOException("storage")

            progress[k] = longArrayOf(resume, total)
            var done = resume
            var lastEmit = 0L
            onEvent(i.kind, i.id, done, total, "progress")

            RandomAccessFile(tmp, "rw").use { raf ->
                raf.setLength(resume)
                raf.seek(resume)
                c.inputStream.use { ins ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        if (flag.get()) break
                        val n = ins.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastEmit > 300) {
                            lastEmit = now
                            progress[k] = longArrayOf(done, total)
                            onEvent(i.kind, i.id, done, total, "progress")
                        }
                    }
                }
            }

            if (flag.get()) {
                onEvent(i.kind, i.id, done, total, "cancelled")
                return
            }
            if (total > 0 && tmp.length() != total) throw IOException("incomplete")
            if (tmp.length() < i.approxBytes / 2) throw IOException("unexpected size")
            dst.delete()
            if (!tmp.renameTo(dst)) throw IOException("rename failed")
            marker(i).writeText(dst.length().toString())
            onEvent(i.kind, i.id, dst.length(), dst.length(), "done")
        } catch (e: Exception) {
            onEvent(i.kind, i.id, 0, 0, "error:" + (e.message ?: "failed").take(60))
        } finally {
            conn?.disconnect()
            progress.remove(k)
            flags.remove(k)
        }
    }
}
