package app.dizi.reader

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/** JNI wrapper around whisper.cpp (see src/main/cpp/whisper_jni.cpp). */
class WhisperJni {
    external fun init(path: String): Long
    external fun free(handle: Long)
    external fun transcribe(handle: Long, pcm: FloatArray, lang: String, threads: Int): String

    companion object {
        val available: Boolean = try {
            System.loadLibrary("dizi_native"); true
        } catch (_: Throwable) {
            false
        }
    }
}

/** JNI wrapper around the shine MP3 encoder (src/main/cpp/mp3_jni.cpp). */
class Mp3Jni {
    external fun open(sampleRate: Int, kbps: Int): Long
    external fun encode(handle: Long, pcm: ShortArray, len: Int): ByteArray
    external fun finish(handle: Long): ByteArray
    external fun close(handle: Long)
}

/**
 * Offline dictation with Whisper. Records 16 kHz audio, cuts it into segments at pauses (or after 25 s),
 * transcribes each segment on a worker thread and reports it as a final result. Events match the
 * SpeechRecognizer path in NativeBridge: "partial", "final", "error", "end".
 */
class WhisperRecognizer(private val emit: (String, String, Int) -> Unit) {

    private val jni = WhisperJni()
    private var handle = 0L
    private var loadedPath = ""
    private val worker = Executors.newSingleThreadExecutor()
    private val stop = AtomicBoolean(false)
    @Volatile private var running = false

    fun isRunning() = running

    fun start(sid: Int, modelPath: String, lang: String) {
        if (running) return
        running = true
        stop.set(false)
        Thread({ loop(sid, modelPath, whisperLang(lang)) }, "dizi-whisper-rec").start()
    }

    fun stop() {
        stop.set(true)
    }

    fun release() {
        stop.set(true)
        worker.execute {
            if (handle != 0L) jni.free(handle)
            handle = 0
        }
        worker.shutdown()
    }

    @SuppressLint("MissingPermission") // RECORD_AUDIO is checked by MainActivity.withMic before start()
    private fun loop(sid: Int, modelPath: String, lang: String) {
        var rec: AudioRecord? = null
        try {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) throw IllegalStateException("audio")
            rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, RATE * 2)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("audio")

            // Load the model on the worker (can take a few seconds) while the microphone already records.
            worker.execute {
                if (handle == 0L || loadedPath != modelPath) {
                    if (handle != 0L) jni.free(handle)
                    handle = jni.init(modelPath)
                    loadedPath = if (handle != 0L) modelPath else ""
                }
            }

            rec.startRecording()
            val frame = ShortArray(RATE / 10) // 100 ms
            val seg = ArrayList<ShortArray>()
            val pre = ArrayDeque<ShortArray>()
            var inSpeech = false
            var silent = 0
            var segFrames = 0
            var floor = 200.0

            fun flush() {
                if (seg.isEmpty()) return
                val total = seg.sumOf { it.size }
                val pcm = FloatArray(total)
                var o = 0
                for (f in seg) for (s in f) pcm[o++] = s / 32768f
                seg.clear(); segFrames = 0; inSpeech = false; silent = 0
                if (total < RATE / 2) return // under half a second: noise
                emit("partial", "…", sid)
                worker.execute {
                    if (handle == 0L) { emit("error", "language-not-supported", sid); return@execute }
                    val raw = jni.transcribe(handle, pcm, lang, minOf(4, Runtime.getRuntime().availableProcessors()))
                    val t = clean(raw)
                    emit("partial", "", sid)
                    if (t.isNotEmpty()) emit("final", t, sid)
                }
            }

            while (!stop.get()) {
                val n = rec.read(frame, 0, frame.size)
                if (n <= 0) continue
                val f = if (n == frame.size) frame.copyOf() else frame.copyOf(n)
                var sum = 0.0
                for (s in f) sum += s.toDouble() * s
                val rms = sqrt(sum / f.size)
                val speech = rms > floor * 2.5 + 150
                if (!speech && !inSpeech) floor = floor * 0.95 + rms * 0.05

                if (speech) {
                    if (!inSpeech) { inSpeech = true; seg.addAll(pre); pre.clear() }
                    silent = 0
                    seg.add(f); segFrames++
                } else if (inSpeech) {
                    seg.add(f); segFrames++; silent++
                    if (silent >= 8) flush() // 0.8 s pause ends the segment
                } else {
                    pre.addLast(f)
                    if (pre.size > 3) pre.removeFirst()
                }
                if (segFrames >= 250) flush() // 25 s cap (Whisper window is 30 s)
            }
            rec.stop()
            flush()
        } catch (e: Throwable) {
            emit("error", if (e is IllegalStateException) "audio-capture" else "aborted", sid)
        } finally {
            try { rec?.release() } catch (_: Exception) {}
            // Wait for queued transcriptions, then signal the end.
            worker.execute {
                running = false
                emit("end", "", sid)
            }
        }
    }

    private fun clean(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return ""
        if (Regex("^[\\[(].*[\\])]$").matches(t)) return "" // [BLANK_AUDIO], (music) ...
        return t
    }

    private fun whisperLang(tag: String): String {
        val l = tag.lowercase().replace('_', '-')
        return when {
            l.startsWith("zh-hk") || l.startsWith("yue") -> "yue"
            l.startsWith("fil") -> "tl"
            l.startsWith("nb") || l.startsWith("nn") -> "no"
            l.isBlank() -> "auto"
            else -> l.substringBefore('-')
        }
    }

    private companion object {
        const val RATE = 16000
    }
}
