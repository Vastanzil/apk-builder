package app.dizi.reader

/** Models the app can download. Ids match the web UI. Files come from huggingface.co/litert-community. */
data class ModelSpec(
    val id: String,
    val name: String,
    val repo: String,
    val file: String,
    val bytes: Long,
    val ramGb: Int,
    val gpu: Boolean,
    /** Qwen3.5 bundles need a fresh Engine per conversation (recurrent state is not reset). */
    val freshEngine: Boolean,
) {
    val url: String get() = "https://huggingface.co/$repo/resolve/main/$file"
}

object ModelCatalog {
    val ALL = listOf(
        ModelSpec("q35-08", "Qwen3.5 0.8B", "litert-community/Qwen3.5-0.8B", "Qwen3.5-0.8B_int8.litertlm", 978_000_000L, 4, false, true),
        ModelSpec("q35-2", "Qwen3.5 2B", "litert-community/Qwen3.5-2B", "Qwen3.5-2B_int8.litertlm", 1_970_000_000L, 6, false, true),
        ModelSpec("g4-e2b", "Gemma 4 E2B", "litert-community/gemma-4-E2B-it-litert-lm", "gemma-4-E2B-it.litertlm", 2_580_000_000L, 6, true, false),
        ModelSpec("g4-e4b", "Gemma 4 E4B", "litert-community/gemma-4-E4B-it-litert-lm", "gemma-4-E4B-it.litertlm", 3_650_000_000L, 8, true, false),
        ModelSpec("q35-4-i4", "Qwen3.5 4B (INT4)", "litert-community/Qwen3.5-4B", "Qwen3.5-4B_mixed_int4.litertlm", 2_754_070_624L, 8, false, true),
        ModelSpec("q35-4", "Qwen3.5 4B (INT8)", "litert-community/Qwen3.5-4B", "Qwen3.5-4B_int8.litertlm", 4_418_793_712L, 12, false, true),
    )

    fun byId(id: String): ModelSpec? = ALL.firstOrNull { it.id == id }
}
