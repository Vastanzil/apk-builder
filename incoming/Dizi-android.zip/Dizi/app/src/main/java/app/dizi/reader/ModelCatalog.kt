package app.dizi.reader

/**
 * Downloadable models. The page only ever sends an id, so the app can only fetch the URLs listed here.
 * File names follow the Hugging Face repos; if a repo renames a file the download reports an error.
 */
object ModelCatalog {

    data class Item(
        val id: String,
        val kind: String,          // "llm" or "stt"
        val repo: String,
        val file: String,
        val approxBytes: Long,
        val qwen: Boolean = false  // Qwen3.5 needs a fresh engine per request (recurrent state is not reset)
    ) {
        val url: String get() = "https://huggingface.co/$repo/resolve/main/$file"
        val dir: String get() = if (kind == "llm") "llm" else "stt"
    }

    val llm = listOf(
        Item("q35-08", "llm", "litert-community/Qwen3.5-0.8B", "Qwen3.5-0.8B_int8.litertlm", 978_000_000L, qwen = true),
        Item("q35-2", "llm", "litert-community/Qwen3.5-2B", "Qwen3.5-2B_int8.litertlm", 2_119_744_416L, qwen = true),
        Item("g4-e2b", "llm", "litert-community/gemma-4-E2B-it-litert-lm", "gemma-4-E2B-it.litertlm", 2_600_000_000L),
        Item("q35-4", "llm", "litert-community/Qwen3.5-4B", "Qwen3.5-4B_int8.litertlm", 4_100_000_000L, qwen = true),
        Item("g4-e4b", "llm", "litert-community/gemma-4-E4B-it-litert-lm", "gemma-4-E4B-it.litertlm", 3_700_000_000L),
        Item("q35-9", "llm", "litert-community/Qwen3.5-9B", "Qwen3.5-9B_mixed_int4.litertlm", 5_200_000_000L, qwen = true)
    )

    val stt = listOf(
        Item("tiny", "stt", "ggerganov/whisper.cpp", "ggml-tiny-q5_1.bin", 32_000_000L),
        Item("base", "stt", "ggerganov/whisper.cpp", "ggml-base-q5_1.bin", 60_000_000L),
        Item("small", "stt", "ggerganov/whisper.cpp", "ggml-small-q5_1.bin", 190_000_000L)
    )

    fun find(kind: String, id: String): Item? =
        when (kind) {
            "llm" -> llm.firstOrNull { it.id == id }
            "stt" -> stt.firstOrNull { it.id == id }
            else -> null
        }
}
