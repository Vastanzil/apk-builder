package app.dizi.reader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import org.json.JSONObject
import java.io.File

/** Downloads model files with the system DownloadManager (retries, resume, notification) into app-private storage. */
class ModelStore(private val ctx: Context) {

    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val prefs = ctx.getSharedPreferences("models", Context.MODE_PRIVATE)
    private val dir: File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "models").apply { mkdirs() }

    fun file(m: ModelSpec) = File(dir, m.file)

    /** A finished download is at least 90% of the expected size (DownloadManager already checks Content-Length). */
    fun isReady(m: ModelSpec): Boolean = file(m).let { it.isFile && it.length() >= m.bytes * 0.9 } && !isDownloading(m)

    private fun isDownloading(m: ModelSpec): Boolean {
        val s = query(m)?.first
        return s == DownloadManager.STATUS_PENDING || s == DownloadManager.STATUS_RUNNING || s == DownloadManager.STATUS_PAUSED
    }

    /** Returns "" when started, otherwise an error code the web UI understands. */
    fun start(m: ModelSpec, wifiOnly: Boolean): String {
        if (isReady(m) || isDownloading(m)) return ""
        val free = try { StatFs(dir.path).availableBytes } catch (_: Exception) { Long.MAX_VALUE }
        if (free < m.bytes + 300_000_000L) return "no_space"
        file(m).delete()
        val req = DownloadManager.Request(Uri.parse(m.url))
            .setTitle(m.name)
            .setDescription("Dizi offline AI model")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setAllowedOverMetered(!wifiOnly)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(ctx, null, "models/${m.file}")
        prefs.edit().putLong(m.id, dm.enqueue(req)).apply()
        return ""
    }

    fun remove(m: ModelSpec) {
        val id = prefs.getLong(m.id, -1L)
        if (id != -1L) dm.remove(id)
        prefs.edit().remove(m.id).apply()
        file(m).delete()
    }

    private fun query(m: ModelSpec): Triple<Int, Pair<Long, Long>, Int>? {
        val id = prefs.getLong(m.id, -1L)
        if (id == -1L) return null
        dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (c.moveToFirst()) {
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                return Triple(status, got to total, reason)
            }
        }
        prefs.edit().remove(m.id).apply() // removed from the system UI
        return null
    }

    fun status(m: ModelSpec): JSONObject {
        var state = "none"
        var reason = ""
        var bytes = 0L
        var total = m.bytes
        val q = query(m)
        if (q != null) {
            bytes = q.second.first
            if (q.second.second > 0) total = q.second.second
            when (q.first) {
                DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING -> state = "downloading"
                DownloadManager.STATUS_PAUSED -> {
                    state = "paused"
                    reason = when (q.third) {
                        DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "wifi"
                        DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "network"
                        else -> "retry"
                    }
                }
                DownloadManager.STATUS_FAILED -> {
                    state = "failed"
                    reason = when (q.third) {
                        DownloadManager.ERROR_INSUFFICIENT_SPACE, DownloadManager.ERROR_DEVICE_NOT_FOUND -> "no_space"
                        401, 403 -> "denied"
                        404 -> "not_found"
                        else -> "network"
                    }
                }
                DownloadManager.STATUS_SUCCESSFUL -> {
                    if (file(m).let { it.isFile && it.length() >= m.bytes * 0.9 }) state = "ready"
                    else { state = "failed"; reason = "incomplete"; file(m).delete() }
                }
            }
        }
        if (state == "none" && file(m).let { it.isFile && it.length() >= m.bytes * 0.9 }) state = "ready"
        return JSONObject().put("state", state).put("reason", reason).put("bytes", bytes).put("total", total)
    }

    fun statusAll(): String {
        val o = JSONObject()
        for (m in ModelCatalog.ALL) o.put(m.id, status(m))
        return o.toString()
    }
}
