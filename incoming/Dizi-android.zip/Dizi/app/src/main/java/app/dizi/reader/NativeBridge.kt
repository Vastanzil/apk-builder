package app.dizi.reader

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Exposed to the page as `DiziNative`. native-shim.js maps the Web Speech API onto it, so the web app
 * keeps using speechSynthesis and SpeechRecognition unchanged.
 */
class NativeBridge(private val activity: MainActivity, private val web: WebView) : TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(activity.applicationContext, this)
    private var ttsReady = false

    private var recognizer: SpeechRecognizer? = null
    private val store = ModelStore(activity.applicationContext)
    private val llm = LlmEngine(activity.applicationContext, store) { id, kind, payload ->
        call("_llm", "'$id','$kind',${JSONObject.quote(payload)}")
    }
    private val seq = AtomicInteger()
    @Volatile private var activeSid = 0

    private fun call(fn: String, args: String) {
        main.post { web.evaluateJavascript("window.DiziShim&&DiziShim.$fn($args)", null) }
    }

    /* ------------------------------------------------------------------ text to speech */

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = call("_ev", "'$utteranceId','start',0")
            override fun onDone(utteranceId: String?) = call("_ev", "'$utteranceId','end',0")

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = call("_ev", "'$utteranceId','error',0")
            override fun onError(utteranceId: String?, errorCode: Int) = call("_ev", "'$utteranceId','error',0")

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) =
                call("_ev", "'$utteranceId','boundary',$start")
        })
        call("_voices", JSONObject.quote(voicesJson()))
    }

    private fun voicesJson(): String {
        val all = tts?.voices.orEmpty()
        val offline = all.filter {
            !it.isNetworkConnectionRequired && !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
        val arr = JSONArray()
        for (v in offline.ifEmpty { all }.sortedBy { it.locale.toLanguageTag() }) {
            val label = v.locale.getDisplayName(v.locale).ifBlank { v.locale.toLanguageTag() }
            arr.put(
                JSONObject()
                    .put("name", "$label · ${v.name.substringAfterLast("-x-", v.name)}")
                    .put("lang", v.locale.toLanguageTag())
                    .put("uri", v.name)
            )
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun voices(): String = if (ttsReady) voicesJson() else "[]"

    @JavascriptInterface
    fun speak(id: String, text: String, voiceUri: String, lang: String, rate: Float) {
        if (!ID_RE.matches(id)) return
        main.post {
            val t = tts
            if (t == null || !ttsReady || text.length > TextToSpeech.getMaxSpeechInputLength()) {
                call("_ev", "'$id','error',0")
                return@post
            }
            val v = t.voices?.firstOrNull { it.name == voiceUri }
            if (v != null) t.voice = v else t.language = Locale.forLanguageTag(lang)
            t.setSpeechRate(rate.coerceIn(0.5f, 3f))
            if (t.speak(text, TextToSpeech.QUEUE_ADD, null, id) != TextToSpeech.SUCCESS) {
                call("_ev", "'$id','error',0")
            }
        }
    }

    @JavascriptInterface
    fun cancel() {
        main.post { tts?.stop() }
    }

    @JavascriptInterface
    fun playing(on: Boolean, title: String) {
        main.post { if (on) activity.startPlayback(title.take(80)) else activity.stopPlayback() }
    }

    /* ------------------------------------------------------------------ speech recognition */

    @JavascriptInterface
    fun srStart(lang: String): Int {
        val sid = seq.incrementAndGet()
        activeSid = sid
        main.post {
            activity.withMic { granted ->
                if (sid != activeSid) return@withMic
                if (granted) {
                    beginRecognition(sid, lang)
                } else {
                    emitSr("error", "not-allowed", sid)
                    emitSr("end", "", sid)
                }
            }
        }
        return sid
    }

    @JavascriptInterface
    fun srStop() {
        main.post { recognizer?.stopListening() }
    }

    @JavascriptInterface
    fun srAbort() {
        main.post { destroyRecognizer() }
    }

    private fun emitSr(kind: String, payload: String, sid: Int) =
        call("_sr", "'$kind',${JSONObject.quote(payload)},$sid")

    private fun beginRecognition(sid: Int, lang: String) {
        destroyRecognizer()
        val ctx = activity
        val rec = when {
            Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx) ->
                SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
            SpeechRecognizer.isRecognitionAvailable(ctx) -> SpeechRecognizer.createSpeechRecognizer(ctx)
            else -> null
        }
        if (rec == null) {
            emitSr("error", "service-not-allowed", sid)
            emitSr("end", "", sid)
            return
        }
        recognizer = rec
        rec.setRecognitionListener(listener(sid))
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        rec.startListening(intent)
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()

    private fun listener(sid: Int) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = firstResult(partialResults)
            if (t.isNotEmpty()) emitSr("partial", t, sid)
        }

        override fun onResults(results: Bundle?) {
            val t = firstResult(results)
            if (t.isNotEmpty()) emitSr("final", t, sid)
            emitSr("end", "", sid)
        }

        override fun onError(error: Int) {
            val code = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> null
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> "network"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                12, 13 -> "language-not-supported" // ERROR_LANGUAGE_NOT_SUPPORTED, ERROR_LANGUAGE_UNAVAILABLE (API 31)
                else -> "aborted"
            }
            if (code != null) emitSr("error", code, sid)
            emitSr("end", "", sid)
        }
    }

    private fun destroyRecognizer() {
        recognizer?.let {
            try { it.cancel() } catch (_: Exception) {}
            it.destroy()
        }
        recognizer = null
    }

    /* ------------------------------------------------------------------ offline models */

    @JavascriptInterface
    fun llmStatus(): String = store.statusAll()

    @JavascriptInterface
    fun llmStart(id: String, wifiOnly: Boolean): String =
        ModelCatalog.byId(id)?.let { store.start(it, wifiOnly) } ?: "unknown_model"

    @JavascriptInterface
    fun llmRemove(id: String) {
        ModelCatalog.byId(id)?.let { llm.unloadModel(it.id); store.remove(it) }
    }

    @JavascriptInterface
    fun llmRun(reqId: String, modelId: String, system: String, prompt: String, gpu: Boolean, idle: Boolean, battery: Boolean): String {
        if (!ID_RE.matches(reqId)) return "bad_request"
        if (prompt.length > 60_000 || system.length > 4_000) return "too_long"
        return llm.run(reqId, modelId, system, prompt, gpu, idle, battery)
    }

    @JavascriptInterface
    fun llmStop() = llm.stop()

    fun release() {
        llm.release()
        activeSid = 0
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private companion object {
        val ID_RE = Regex("^[A-Za-z0-9_-]{1,32}$")
    }
}
