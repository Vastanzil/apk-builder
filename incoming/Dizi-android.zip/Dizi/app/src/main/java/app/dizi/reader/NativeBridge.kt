package app.dizi.reader

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Exposed to the page as `DiziNative`. native-shim.js maps the Web Speech API onto it, so the web app
 * keeps using speechSynthesis and SpeechRecognition unchanged.
 */
class NativeBridge(private val activity: MainActivity, private val web: WebView) : TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(activity.applicationContext, this)
    private var ttsReady = false

    private var recognizer: SpeechRecognizer? = null
    private val seq = AtomicInteger()
    @Volatile private var activeSid = 0

    private val appCtx = activity.applicationContext
    private val prefs = activity.getSharedPreferences("dizi", Context.MODE_PRIVATE)
    private var hdPending = false

    private fun q(s: String) = JSONObject.quote(s)

    private val downloader = Downloader(appCtx) { kind, id, done, total, status ->
        call("_dl", "${q(kind)},${q(id)},$done,$total,${q(status)}")
        if (status != "progress") TransferService.end(appCtx)
    }
    private val llm = LlmEngine(appCtx) { rid, type, text -> call("_llm", "${q(rid)},${q(type)},${q(text)}") }
    private val whisper = WhisperRecognizer { kind, payload, sid -> emitSr(kind, payload, sid) }
    private val exporter = AudioExporter(appCtx) { jid, type, value ->
        call("_exp", "${q(jid)},${q(type)},${q(value)}")
        if (type != "progress") TransferService.end(appCtx)
    }

    private fun call(fn: String, args: String) {
        main.post { web.evaluateJavascript("window.DiziShim&&DiziShim.$fn($args)", null) }
    }

    /* ------------------------------------------------------------------ text to speech */

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = call("_ev", "'$utteranceId','start',0")
            override fun onDone(utteranceId: String?) = call("_ev", "'$utteranceId','end',0")

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = call("_ev", "'$utteranceId','error',0")
            override fun onError(utteranceId: String?, errorCode: Int) = call("_ev", "'$utteranceId','error',0")

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) =
                call("_ev", "'$utteranceId','boundary',$start")
        })
        call("_voices", JSONObject.quote(voicesJson()))
    }

    private fun voicesJson(): String {
        val all = tts?.voices.orEmpty()
        val offline = all.filter {
            !it.isNetworkConnectionRequired && !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
        val arr = JSONArray()
        for (v in offline.ifEmpty { all }.sortedBy { it.locale.toLanguageTag() }) {
            val label = v.locale.getDisplayName(v.locale).ifBlank { v.locale.toLanguageTag() }
            arr.put(
                JSONObject()
                    .put("name", "$label · ${v.name.substringAfterLast("-x-", v.name)}")
                    .put("lang", v.locale.toLanguageTag())
                    .put("uri", v.name)
            )
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun voices(): String = if (ttsReady) voicesJson() else "[]"

    @JavascriptInterface
    fun speak(id: String, text: String, voiceUri: String, lang: String, rate: Float) {
        if (!ID_RE.matches(id)) return
        main.post {
            val t = tts
            if (t == null || !ttsReady || text.length > TextToSpeech.getMaxSpeechInputLength()) {
                call("_ev", "'$id','error',0")
                return@post
            }
            val v = t.voices?.firstOrNull { it.name == voiceUri }
            if (v != null) t.voice = v else t.language = Locale.forLanguageTag(lang)
            t.setSpeechRate(rate.coerceIn(0.5f, 3f))
            if (t.speak(text, TextToSpeech.QUEUE_ADD, null, id) != TextToSpeech.SUCCESS) {
                call("_ev", "'$id','error',0")
            }
        }
    }

    @JavascriptInterface
    fun cancel() {
        main.post { tts?.stop() }
    }

    @JavascriptInterface
    fun playing(on: Boolean, title: String) {
        main.post { if (on) activity.startPlayback(title.take(80)) else activity.stopPlayback() }
    }

    /* ------------------------------------------------------------------ speech recognition */

    @JavascriptInterface
    fun srStart(lang: String): Int {
        val sid = seq.incrementAndGet()
        activeSid = sid
        main.post {
            activity.withMic { granted ->
                if (sid != activeSid) return@withMic
                if (granted) {
                    val m = whisperModel()
                    if (m != null) {
                        destroyRecognizer()
                        whisper.start(sid, downloader.file(m).path, lang)
                    } else {
                        beginRecognition(sid, lang)
                    }
                } else {
                    emitSr("error", "not-allowed", sid)
                    emitSr("end", "", sid)
                }
            }
        }
        return sid
    }

    @JavascriptInterface
    fun srStop() {
        main.post {
            recognizer?.stopListening()
            if (whisper.isRunning()) whisper.stop()
        }
    }

    @JavascriptInterface
    fun srAbort() {
        main.post {
            destroyRecognizer()
            if (whisper.isRunning()) whisper.stop()
        }
    }

    /** The Whisper model to use for dictation, or null to use the phone's own recognizer. */
    private fun whisperModel(): ModelCatalog.Item? {
        if (!WhisperJni.available) return null
        val id = prefs.getString("stt", "system") ?: "system"
        val m = ModelCatalog.find("stt", id) ?: return null
        return if (downloader.installed(m)) m else null
    }

    private fun emitSr(kind: String, payload: String, sid: Int) =
        call("_sr", "'$kind',${JSONObject.quote(payload)},$sid")

    private fun beginRecognition(sid: Int, lang: String) {
        destroyRecognizer()
        val ctx = activity
        val rec = when {
            Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx) ->
                SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
            SpeechRecognizer.isRecognitionAvailable(ctx) -> SpeechRecognizer.createSpeechRecognizer(ctx)
            else -> null
        }
        if (rec == null) {
            emitSr("error", "service-not-allowed", sid)
            emitSr("end", "", sid)
            return
        }
        recognizer = rec
        rec.setRecognitionListener(listener(sid))
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        rec.startListening(intent)
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()

    private fun listener(sid: Int) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = firstResult(partialResults)
            if (t.isNotEmpty()) emitSr("partial", t, sid)
        }

        override fun onResults(results: Bundle?) {
            val t = firstResult(results)
            if (t.isNotEmpty()) emitSr("final", t, sid)
            emitSr("end", "", sid)
        }

        override fun onError(error: Int) {
            val code = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> null
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> "network"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                12, 13 -> "language-not-supported" // ERROR_LANGUAGE_NOT_SUPPORTED, ERROR_LANGUAGE_UNAVAILABLE (API 31)
                else -> "aborted"
            }
            if (code != null) emitSr("error", code, sid)
            emitSr("end", "", sid)
        }
    }

    private fun destroyRecognizer() {
        recognizer?.let {
            try { it.cancel() } catch (_: Exception) {}
            it.destroy()
        }
        recognizer = null
    }

    /* ------------------------------------------------------------------ downloads, state */

    private val idRe = Regex("^[a-z0-9-]{1,12}$")

    private fun item(kind: String, id: String): ModelCatalog.Item? =
        if (idRe.matches(id)) ModelCatalog.find(kind, id) else null

    @JavascriptInterface
    fun state(): String {
        val o = JSONObject()
        val l = JSONObject(); val st = JSONObject(); val dl = JSONObject()
        for (m in ModelCatalog.llm) {
            if (downloader.installed(m)) l.put(m.id, downloader.file(m).length())
            downloader.progress["llm:${m.id}"]?.let { dl.put("llm:${m.id}", JSONArray().put(it[0]).put(it[1])) }
        }
        for (m in ModelCatalog.stt) {
            if (downloader.installed(m)) st.put(m.id, downloader.file(m).length())
            downloader.progress["stt:${m.id}"]?.let { dl.put("stt:${m.id}", JSONArray().put(it[0]).put(it[1])) }
        }
        val mi = ActivityManager.MemoryInfo()
        (appCtx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        o.put("llm", l).put("stt", st).put("dl", dl)
            .put("whisper", WhisperJni.available)
            .put("mp3", WhisperJni.available)
            .put("ramGb", Math.round(mi.totalMem / 1073741824.0).toInt())
            .put("sttActive", prefs.getString("stt", "system"))
        return o.toString()
    }

    @JavascriptInterface
    fun metered(): Boolean =
        (appCtx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered

    @JavascriptInterface
    fun dlStart(kind: String, id: String): Boolean {
        val m = item(kind, id) ?: return false
        main.post { activity.askNotificationsOnce() }
        if (!downloader.start(m)) return false
        TransferService.begin(appCtx, appCtx.getString(R.string.notif_downloading))
        return true
    }

    @JavascriptInterface
    fun dlCancel(kind: String, id: String) {
        item(kind, id)?.let { downloader.cancel(it) }
    }

    @JavascriptInterface
    fun dlRemove(kind: String, id: String) {
        val m = item(kind, id) ?: return
        if (kind == "llm") llm.unload()
        downloader.remove(m)
    }

    @JavascriptInterface
    fun setStt(id: String) {
        if (id == "system" || (idRe.matches(id) && ModelCatalog.find("stt", id) != null)) {
            prefs.edit().putString("stt", id).apply()
        }
    }

    /* ------------------------------------------------------------------ offline language model */

    @JavascriptInterface
    fun llmRun(rid: String, modelId: String, optsJson: String, stepsJson: String) {
        if (!ID_RE.matches(rid)) return
        val m = item("llm", modelId)
        if (m == null || !downloader.installed(m)) { call("_llm", "${q(rid)},'error','not-installed'"); return }
        if (stepsJson.length > 400_000) { call("_llm", "${q(rid)},'error','too-long'"); return }
        try {
            val o = JSONObject(optsJson)
            if (o.optBoolean("bat", true) &&
                (appCtx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isPowerSaveMode
            ) {
                call("_llm", "${q(rid)},'error','power-save'")
                return
            }
            val arr = JSONArray(stepsJson)
            val steps = (0 until minOf(arr.length(), 40)).map {
                val s = arr.getJSONObject(it)
                LlmEngine.Step(s.getString("p"), s.optBoolean("s", false))
            }
            if (steps.isEmpty()) return
            llm.run(rid, m, downloader.file(m).path, o.optBoolean("gpu", false), if (o.optBoolean("idle", true)) 120 else 0, steps)
        } catch (e: Exception) {
            call("_llm", "${q(rid)},'error','bad-request'")
        }
    }

    @JavascriptInterface
    fun llmCancel() = llm.cancel()

    @JavascriptInterface
    fun llmUnload() = llm.unload()

    /* ------------------------------------------------------------------ audio export */

    @JavascriptInterface
    fun exportStart(jid: String, text: String, lang: String, voiceUri: String, rate: Float, fmt: String, kbps: Int, title: String) {
        if (!ID_RE.matches(jid) || text.isBlank() || text.length > 3_000_000) { call("_exp", "${q(jid)},'error','bad-request'"); return }
        val f = if (fmt == "m4a") "m4a" else "mp3"
        if (f == "mp3" && !WhisperJni.available) { call("_exp", "${q(jid)},'error','mp3-unavailable'"); return }
        val br = if (kbps in intArrayOf(48, 64, 96)) kbps else 64
        main.post { activity.askNotificationsOnce() }
        TransferService.begin(appCtx, appCtx.getString(R.string.notif_exporting))
        exporter.start(jid, text, lang.take(16), voiceUri.take(200), rate, f, br, title.take(80))
    }

    @JavascriptInterface
    fun exportCancel() = exporter.cancel()

    /* ------------------------------------------------------------------ HD voices (system voice data) */

    @JavascriptInterface
    fun hdStatus(lang: String): String {
        val l2 = lang.take(2).lowercase()
        val vs = tts?.voices.orEmpty().filter {
            it.locale.language == l2 && it.quality >= Voice.QUALITY_HIGH &&
                !it.isNetworkConnectionRequired && !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
        return JSONObject().put("count", vs.size).put("names", JSONArray(vs.map { it.name.substringAfterLast("-x-", it.name) })).toString()
    }

    @JavascriptInterface
    fun hdInstall() {
        main.post {
            hdPending = true
            try {
                activity.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                try {
                    activity.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                    hdPending = false
                }
            }
        }
    }

    /** Called when the app returns to the front: pick up voices installed in the system settings. */
    fun onResume() {
        if (!hdPending) return
        hdPending = false
        ttsReady = false
        tts?.shutdown()
        tts = TextToSpeech(activity.applicationContext, this)
    }

    fun release() {
        downloader.shutdown()
        llm.release()
        whisper.release()
        exporter.cancel()
        activeSid = 0
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private companion object {
        val ID_RE = Regex("^[A-Za-z0-9_-]{1,32}$")
    }
}
