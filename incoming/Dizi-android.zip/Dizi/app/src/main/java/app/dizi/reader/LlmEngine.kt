package app.dizi.reader

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

/**
 * Runs the offline language models (Gemma 4 and Qwen3.5 as .litertlm files) with LiteRT-LM.
 * One single-thread executor owns the Engine and every Conversation, as the LiteRT-LM docs require.
 */
class LlmEngine(
    private val ctx: Context,
    /** requestId, type ("status" | "token" | "done" | "cancelled" | "error"), text */
    private val emit: (String, String, String) -> Unit
) {
    class Step(val prompt: String, val stream: Boolean)

    private val executor = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())

    private var engine: Engine? = null
    private var loadedKey = ""
    private var conversation: com.google.ai.edge.litertlm.Conversation? = null
    private var idleJob: Job? = null
    @Volatile private var cancelled = false

    fun run(
        rid: String,
        item: ModelCatalog.Item,
        path: String,
        useGpu: Boolean,
        idleSeconds: Int,
        steps: List<Step>
    ) {
        cancelled = false
        scope.launch {
            idleJob?.cancel()
            try {
                emit(rid, "status", "loading")
                ensureEngine(path, useGpu)
                emit(rid, "status", "running")

                val hidden = ArrayList<String>()
                val shown = ArrayList<String>()
                for ((idx, step) in steps.withIndex()) {
                    if (cancelled) break
                    val prompt = step.prompt.replace("{{prev}}", hidden.joinToString("\n\n"))
                    val conv = checkNotNull(engine).createConversation(ConversationConfig())
                    conversation = conv
                    val sb = StringBuilder()
                    try {
                        if (step.stream && shown.isNotEmpty()) emit(rid, "token", "\n\n")
                        conv.sendMessageAsync(prompt).collect { m ->
                            val t = m.toString()
                            sb.append(t)
                            if (step.stream) emit(rid, "token", t)
                        }
                    } finally {
                        conversation = null
                        try { conv.close() } catch (_: Exception) {}
                    }
                    val out = sb.toString().trim()
                    if (step.stream) shown.add(out) else hidden.add(out)
                    if (!step.stream) emit(rid, "status", "step ${idx + 1}/${steps.size}")
                }
                emit(rid, if (cancelled) "cancelled" else "done", shown.joinToString("\n\n"))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                closeEngine()
                emit(rid, "error", (e.message ?: e.javaClass.simpleName).take(160))
            } finally {
                if (item.qwen) closeEngine() else scheduleIdle(idleSeconds)
            }
        }
    }

    fun cancel() {
        cancelled = true
        scope.launch {
            try { conversation?.cancelProcess() } catch (_: Exception) {}
        }
    }

    fun unload() {
        scope.launch { closeEngine() }
    }

    fun release() {
        cancelled = true
        scope.launch {
            closeEngine()
            executor.shutdown()
        }
    }

    private fun ensureEngine(path: String, useGpu: Boolean) {
        val key = "$path|$useGpu"
        if (engine != null && loadedKey == key) return
        closeEngine()
        val cache = ctx.cacheDir.path
        var e: Engine? = null
        if (useGpu) {
            val g = Engine(EngineConfig(modelPath = path, backend = Backend.GPU(), cacheDir = cache))
            try { g.initialize(); e = g } catch (_: Throwable) { /* fall back to CPU below; do not close a failed engine */ }
        }
        if (e == null) {
            val c = Engine(EngineConfig(modelPath = path, backend = Backend.CPU(), cacheDir = cache))
            c.initialize()
            e = c
        }
        engine = e
        loadedKey = key
    }

    private fun closeEngine() {
        val e = engine
        engine = null
        loadedKey = ""
        if (e != null) try { e.close() } catch (_: Exception) {}
    }

    private fun scheduleIdle(seconds: Int) {
        idleJob?.cancel()
        if (seconds <= 0) return
        idleJob = scope.launch {
            delay(seconds * 1000L)
            closeEngine()
        }
    }
}
