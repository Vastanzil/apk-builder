package app.dizi.reader

import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Runs a downloaded .litertlm model with LiteRT-LM. One request at a time on a worker thread.
 * [emit] is called with (requestId, "chunk" | "done" | "error", payload).
 */
class LlmEngine(
    private val ctx: Context,
    private val store: ModelStore,
    private val emit: (String, String, String) -> Unit,
) {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var engine: Engine? = null
    private var loadedKey: String? = null
    @Volatile private var stopped = false
    private val idleTask = Runnable { exec.execute { unload() } }

    /** Returns "" when the request was queued, otherwise an error code. */
    fun run(reqId: String, modelId: String, system: String, prompt: String, useGpu: Boolean, idleUnload: Boolean, batteryPause: Boolean): String {
        val m = ModelCatalog.byId(modelId) ?: return "unknown_model"
        if (!store.isReady(m)) return "not_downloaded"
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (batteryPause && pm.isPowerSaveMode) return "battery_saver"
        val info = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
        if (info.totalMem < (m.ramGb * 0.8 * GIB).toLong()) return "low_memory"

        main.removeCallbacks(idleTask)
        stopped = false
        exec.execute {
            try {
                generate(reqId, m, system, prompt, useGpu && m.gpu)
            } catch (t: Throwable) {
                unload()
                emit(reqId, "error", t.message ?: t.javaClass.simpleName)
            }
            if (idleUnload) main.postDelayed(idleTask, IDLE_MS)
        }
        return ""
    }

    /** The current generation finishes on its own, but its output is dropped. */
    fun stop() { stopped = true }

    fun unloadModel(id: String) { exec.execute { if (loadedKey?.startsWith(id + ":") == true) unload() } }

    fun release() {
        main.removeCallbacks(idleTask)
        exec.execute { unload() }
        exec.shutdown()
    }

    private fun generate(reqId: String, m: ModelSpec, system: String, prompt: String, gpu: Boolean) {
        if (m.freshEngine) unload()
        val eng = ensureEngine(m, gpu)
        val conv = eng.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(system),
                samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.3),
                maxOutputToken = 1024,
            )
        )
        val latch = CountDownLatch(1)
        var failure: Throwable? = null
        try {
            conv.sendMessageAsync(prompt, object : MessageCallback {
                override fun onMessage(message: Message) {
                    if (!stopped) emit(reqId, "chunk", message.toString())
                }
                override fun onDone() { latch.countDown() }
                override fun onError(throwable: Throwable) { failure = throwable; latch.countDown() }
            })
            if (!latch.await(10, TimeUnit.MINUTES)) throw IllegalStateException("timeout")
        } finally {
            conv.close()
        }
        val f = failure
        if (f != null) throw f
        emit(reqId, "done", "")
        if (m.freshEngine) unload()
    }

    private fun ensureEngine(m: ModelSpec, gpu: Boolean): Engine {
        val key = m.id + ":" + gpu
        engine?.let { if (loadedKey == key) return it }
        unload()
        val cache = File(ctx.cacheDir, "litert").apply { mkdirs() }
        trimCache(cache)
        fun build(backend: Backend): Engine {
            val e = Engine(EngineConfig(modelPath = store.file(m).path, backend = backend, cacheDir = cache.path))
            try { e.initialize() } catch (t: Throwable) { try { e.close() } catch (_: Throwable) {}; throw t }
            return e
        }
        val e = if (gpu) {
            try { build(Backend.GPU()) } catch (_: Throwable) { build(Backend.CPU()) }
        } else {
            build(Backend.CPU())
        }
        engine = e
        loadedKey = key
        return e
    }

    private fun unload() {
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
        loadedKey = null
    }

    /** The GPU program cache grows with every engine creation, so clear it when it gets large. */
    private fun trimCache(dir: File) {
        val size = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        if (size > 600L * 1024 * 1024) dir.listFiles()?.forEach { it.deleteRecursively() }
    }

    private companion object {
        const val GIB = 1024.0 * 1024.0 * 1024.0
        const val IDLE_MS = 2 * 60 * 1000L
    }
}
