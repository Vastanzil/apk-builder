package app.dizi.reader

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reads a document aloud into an audio file: Android TextToSpeech renders WAV chunks, which are
 * resampled and encoded to MP3 (shine, native) or M4A/AAC (MediaCodec), then saved to Music/Dizi.
 */
class AudioExporter(
    private val ctx: Context,
    /** jobId, type ("progress" | "done" | "error" | "cancelled"), value */
    private val emit: (String, String, String) -> Unit
) {
    private val cancel = AtomicBoolean(false)
    @Volatile private var busy = false

    fun cancel() { cancel.set(true) }

    fun start(jid: String, text: String, lang: String, voiceUri: String, rate: Float, fmt: String, kbps: Int, title: String) {
        if (busy) { emit(jid, "error", "busy"); return }
        busy = true
        cancel.set(false)
        Thread({
            try {
                val result = export(jid, text, lang, voiceUri, rate.coerceIn(0.5f, 2.5f), fmt, kbps, title)
                if (cancel.get()) emit(jid, "cancelled", "") else emit(jid, "done", result)
            } catch (e: Throwable) {
                emit(jid, "error", (e.message ?: e.javaClass.simpleName).take(120))
            } finally {
                busy = false
            }
        }, "dizi-export").start()
    }

    private fun export(jid: String, text: String, lang: String, voiceUri: String, rate: Float, fmt: String, kbps: Int, title: String): String {
        val tmpDir = File(ctx.cacheDir, "export").apply { mkdirs() }
        tmpDir.listFiles()?.forEach { it.delete() }

        // 1. text to speech engine
        val ready = CountDownLatch(1)
        var ok = false
        val engine = TextToSpeech(ctx.applicationContext) { status -> ok = status == TextToSpeech.SUCCESS; ready.countDown() }
        if (!ready.await(15, TimeUnit.SECONDS) || !ok) { engine.shutdown(); throw IllegalStateException("no speech engine") }
        try {
            val v = engine.voices?.firstOrNull { it.name == voiceUri }
            if (v != null) engine.voice = v else engine.language = Locale.forLanguageTag(lang)
            engine.setSpeechRate(rate)

            val limit = minOf(TextToSpeech.getMaxSpeechInputLength() - 100, 1200).coerceAtLeast(200)
            val chunks = split(text, limit)
            if (chunks.isEmpty()) throw IllegalStateException("empty text")

            var latch = CountDownLatch(1)
            var failed = false
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { latch.countDown() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { failed = true; latch.countDown() }
                override fun onError(utteranceId: String?, errorCode: Int) { failed = true; latch.countDown() }
            })

            // 2. render, resample, encode chunk by chunk
            var sink: Sink? = null
            val out = File(tmpDir, "out." + if (fmt == "m4a") "m4a" else "mp3")
            var resampler: Resampler? = null
            try {
                for ((i, chunk) in chunks.withIndex()) {
                    if (cancel.get()) return ""
                    val wav = File(tmpDir, "c$i.wav")
                    latch = CountDownLatch(1); failed = false
                    val r = engine.synthesizeToFile(chunk, Bundle(), wav, "x$i")
                    if (r != TextToSpeech.SUCCESS) throw IllegalStateException("speech failed")
                    if (!latch.await(180, TimeUnit.SECONDS) || failed) throw IllegalStateException("speech failed")
                    val w = readWav(wav)
                    wav.delete()
                    if (sink == null) {
                        val target = if (w.rate <= 24000) 22050 else 44100
                        resampler = Resampler(w.rate, target)
                        sink = if (fmt == "m4a") AacSink(out, target, kbps * 1000) else Mp3Sink(out, target, kbps)
                    }
                    val pcm = resampler!!.process(w.pcm)
                    sink.write(pcm)
                    sink.write(ShortArray(resampler.dstRate / 8)) // 125 ms pause between chunks
                    emit(jid, "progress", (((i + 1) * 100) / chunks.size).toString())
                }
                sink?.finish()
                sink = null
            } finally {
                try { sink?.abort() } catch (_: Exception) {}
            }
            if (cancel.get()) return ""

            // 3. publish
            return publish(out, fmt, title)
        } finally {
            try { engine.stop() } catch (_: Exception) {}
            engine.shutdown()
            tmpDir.listFiles()?.forEach { it.delete() }
        }
    }

    private fun split(text: String, limit: Int): List<String> {
        val parts = text.replace("\r", "").split(Regex("(?<=[.!?।؟。！？])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() { if (sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0) } }
        for (p0 in parts) {
            var p = p0
            while (p.length > limit) {            // very long sentence: cut at a space
                var cut = p.lastIndexOf(' ', limit)
                if (cut < limit / 2) cut = limit
                if (sb.isNotEmpty()) flush()
                out.add(p.substring(0, cut).trim())
                p = p.substring(cut).trim()
            }
            if (sb.length + p.length + 1 > limit) flush()
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(p)
        }
        flush()
        return out.filter { it.isNotBlank() }
    }

    private class Wav(val rate: Int, val pcm: ShortArray)

    private fun readWav(f: File): Wav {
        RandomAccessFile(f, "r").use { raf ->
            val head = ByteArray(12)
            raf.readFully(head)
            var rate = 22050; var ch = 1; var bits = 16
            var dataLen = 0L
            while (raf.filePointer + 8 <= raf.length()) {
                val id = ByteArray(4); raf.readFully(id)
                val szb = ByteArray(4); raf.readFully(szb)
                val sz = ByteBuffer.wrap(szb).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                val name = String(id, Charsets.US_ASCII)
                if (name == "fmt ") {
                    val b = ByteArray(sz.toInt()); raf.readFully(b)
                    val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                    ch = bb.getShort(2).toInt(); rate = bb.getInt(4); bits = bb.getShort(14).toInt()
                } else if (name == "data") {
                    dataLen = if (sz == 0L || raf.filePointer + sz > raf.length()) raf.length() - raf.filePointer else sz
                    break
                } else {
                    raf.seek(raf.filePointer + sz + (sz and 1L))
                }
            }
            if (bits != 16 || ch < 1 || dataLen <= 0) throw IllegalStateException("unsupported audio")
            val bytes = ByteArray(dataLen.toInt()); raf.readFully(bytes)
            val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val frames = sb.remaining() / ch
            val pcm = ShortArray(frames)
            if (ch == 1) sb.get(pcm) else {
                val tmp = ShortArray(frames * ch); sb.get(tmp)
                for (i in 0 until frames) { var s = 0; for (c in 0 until ch) s += tmp[i * ch + c]; pcm[i] = (s / ch).toShort() }
            }
            return Wav(rate, pcm)
        }
    }

    /** Linear resampler that keeps its position between chunks. */
    private class Resampler(val srcRate: Int, val dstRate: Int) {
        private var pos = 0.0
        private var last: Short = 0
        private val step = srcRate.toDouble() / dstRate

        fun process(inp: ShortArray): ShortArray {
            if (srcRate == dstRate) return inp
            val n = inp.size
            if (n == 0) return inp
            val out = ShortArray(((n - pos) / step).toInt() + 2)
            var o = 0
            while (pos < n - 1) {
                val i = Math.floor(pos).toInt()
                val frac = pos - i
                val a = if (i < 0) last.toInt() else inp[i].toInt()
                val b = inp[i + 1].toInt()
                if (o < out.size) out[o++] = (a + (b - a) * frac).toInt().toShort()
                pos += step
            }
            pos -= n
            last = inp[n - 1]
            return out.copyOf(o)
        }
    }

    private interface Sink {
        fun write(pcm: ShortArray)
        fun finish()
        fun abort()
    }

    private class Mp3Sink(private val file: File, rate: Int, kbps: Int) : Sink {
        private val jni = Mp3Jni()
        private val handle: Long
        private val os: OutputStream
        private var closed = false
        init {
            if (!WhisperJni.available) throw IllegalStateException("MP3 encoder is not in this build")
            handle = jni.open(rate, kbps)
            if (handle == 0L) throw IllegalStateException("MP3 settings not supported")
            os = file.outputStream().buffered()
        }
        override fun write(pcm: ShortArray) { if (pcm.isNotEmpty()) os.write(jni.encode(handle, pcm, pcm.size)) }
        override fun finish() { os.write(jni.finish(handle)); os.close(); jni.close(handle); closed = true }
        override fun abort() { if (!closed) { closed = true; try { os.close() } catch (_: Exception) {}; jni.close(handle) } }
    }

    private class AacSink(private val file: File, private val rate: Int, bitrate: Int) : Sink {
        private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        private val muxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        private val info = MediaCodec.BufferInfo()
        private var track = -1
        private var started = false
        private var samples = 0L
        private var closed = false

        init {
            val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
        }

        override fun write(pcm: ShortArray) {
            val bytes = ByteArray(pcm.size * 2)
            ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm)
            var off = 0
            while (off < bytes.size) {
                val idx = codec.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val buf = codec.getInputBuffer(idx)!!
                    buf.clear()
                    val n = minOf(buf.capacity(), bytes.size - off)
                    buf.put(bytes, off, n)
                    codec.queueInputBuffer(idx, 0, n, samples * 1_000_000L / rate, 0)
                    samples += n / 2
                    off += n
                }
                drain(false)
            }
        }

        override fun finish() {
            var queued = false
            while (!queued) {
                val idx = codec.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    codec.queueInputBuffer(idx, 0, 0, samples * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    queued = true
                }
                drain(false)
            }
            drain(true)
            closed = true
            codec.stop(); codec.release()
            if (started) muxer.stop()
            muxer.release()
        }

        override fun abort() {
            if (closed) return
            closed = true
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { if (started) muxer.stop() } catch (_: Exception) {}
            try { muxer.release() } catch (_: Exception) {}
        }

        private fun drain(untilEnd: Boolean) {
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (untilEnd) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!untilEnd) return
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat); muxer.start(); started = true
                    }
                    i >= 0 -> {
                        val buf = codec.getOutputBuffer(i)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && started) {
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            muxer.writeSampleData(track, buf, info)
                        }
                        codec.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }
    }

    private fun publish(src: File, fmt: String, title: String): String {
        val ext = if (fmt == "m4a") "m4a" else "mp3"
        val mime = if (fmt == "m4a") "audio/mp4" else "audio/mpeg"
        var base = title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().replace(Regex("\\s+"), "-")
        if (base.isEmpty()) base = "Dizi-audio"
        val name = "$base.$ext"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Dizi")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("cannot save")
            try {
                r.openOutputStream(uri)!!.use { o -> FileInputStream(src).use { it.copyTo(o) } }
                val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                r.update(uri, done, null, null)
            } catch (e: Exception) {
                r.delete(uri, null, null)
                throw e
            }
            return "Music/Dizi/$name"
        }
        // Android 8 and 9: app-specific folder (no storage permission needed).
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Dizi").apply { mkdirs() }
        val dst = File(dir, name)
        src.copyTo(dst, overwrite = true)
        return "Android/data/${ctx.packageName}/files/Music/Dizi/$name"
    }
}
