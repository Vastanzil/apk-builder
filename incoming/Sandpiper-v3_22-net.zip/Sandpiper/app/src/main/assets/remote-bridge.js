/* Sandpiper Local Sync: runs in a DESKTOP browser only (the phone serves it to a paired browser; the phone's own WebView never loads it).
   It gives the web UI the same window.SandpiperNative surface as the phone, relayed to the real Bridge over the Bridge v2 envelope
   {v,id,m,p} -> {v,id,ok,d|e}. Calls are synchronous XHRs to the phone (same origin), because the UI reads return values directly. */
(function(){'use strict';
if(window.SandpiperNative)return;
const KEYS=['sandpiper_state_v2','sandpiper_reminders','sandpiper.fitness.v1'];
let id=0,own=0;
function xhr(method,url,body){const x=new XMLHttpRequest();x.open(method,url,false);if(body!=null)x.setRequestHeader('Content-Type','text/plain');x.send(body==null?null:body);return x}
function toLogin(){if(location.pathname!=='/pair')location.href='/pair'}

/* 1. boot from the phone's data once per tab (iframes share sessionStorage, so they do not re-apply it) */
let booted=false;try{booted=sessionStorage.getItem('sp_remote_boot')==='1'}catch(e){}
if(!booted){try{const r=xhr('GET','/snapshot');if(r.status===401){toLogin();return}
 if(r.status===200){const o=JSON.parse(r.responseText);KEYS.forEach(k=>{if(o[k]!=null)localStorage.setItem(k,o[k]);else localStorage.removeItem(k)});sessionStorage.setItem('sp_remote_boot','1')}}catch(e){}}

/* 2. send changes of the mirrored keys back to the phone (debounced, last write wins) */
const queue={};let tm=0;
function flush(){tm=0;Object.keys(queue).forEach(k=>{const v=queue[k];delete queue[k];
 try{const r=xhr('POST','/ls',JSON.stringify({k,v}));if(r.status===401)toLogin()}catch(e){}})}
const set=Storage.prototype.setItem;
Storage.prototype.setItem=function(k,v){set.call(this,k,v);if(this===localStorage&&KEYS.indexOf(k)>=0){queue[k]=String(v);if(!tm)tm=setTimeout(flush,400)}};
window.addEventListener('pagehide',()=>{if(tm){clearTimeout(tm);flush()}});

/* 3. the bridge */
const HIDE=new Set(['assistListen','assistStop','assistSpeak','savePdf','llmRun','pickTone','pickModel','previewTone','stopPreview','requestNotif','requestActivity','openPermission','openAppInfo','sleepEstimate','remoteStart','remoteStop','remoteStatus','remotePairCode','cloudRun','cloudTake']);
const LOCAL={
 saveFile:(name,mime,b64)=>{try{const bin=atob(b64),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);
  const u=URL.createObjectURL(new Blob([a],{type:mime||'application/octet-stream'})),l=document.createElement('a');l.href=u;l.download=name;document.body.appendChild(l);l.click();l.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);return true}catch(e){return false}},
 openUrl:u=>{try{window.open(u,'_blank','noopener');return true}catch(e){return false}},
 notifEnabled:()=>false};
function call(m,a){let x;try{x=xhr('POST','/rpc',JSON.stringify({v:1,id:++id,m,p:a}))}catch(e){return null}
 if(x.status===401){toLogin();return null}if(x.status!==200)return null;
 let r;try{r=JSON.parse(x.responseText)}catch(e){return null}if(r&&typeof r.n==='number'&&r.n>own)own=r.n;return r&&r.ok?r.d:null}
window.SandpiperNative=new Proxy({},{get:(_,m)=>{if(typeof m!=='string'||m==='then'||HIDE.has(m))return undefined;if(LOCAL[m])return LOCAL[m];return(...a)=>call(m,a)},has:(_,m)=>!HIDE.has(m)});

/* 4. phone-side changes: a small notice, never an automatic reload (that could discard what you are typing) */
if(window.top===window){
 function banner(){if(document.getElementById('spRemoteBanner'))return;const b=document.createElement('button');b.id='spRemoteBanner';b.type='button';
  b.textContent='Phone data changed · tap to refresh';b.style.cssText='position:fixed;z-index:99999;left:50%;bottom:18px;transform:translateX(-50%);padding:10px 16px;border-radius:99px;border:0;background:#4cc2ff;color:#031420;font:600 14px system-ui;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.35)';
  b.onclick=()=>{try{sessionStorage.removeItem('sp_remote_boot')}catch(e){}location.reload()};document.body.appendChild(b)}
 (function poll(since){const x=new XMLHttpRequest();x.open('GET','/poll?since='+since);
  x.onload=()=>{let v=since;try{v=JSON.parse(x.responseText).v}catch(e){}
   if(x.status===401){toLogin();return}
   if(since!==-1&&v>own&&v!==since)banner();setTimeout(()=>poll(v),v===since?0:300)};
  x.onerror=()=>setTimeout(()=>poll(since),4000);x.send()})(-1);
}
})();
