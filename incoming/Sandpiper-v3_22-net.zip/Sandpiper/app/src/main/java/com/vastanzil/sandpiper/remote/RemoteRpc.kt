package com.vastanzil.sandpiper.remote

import org.json.JSONArray
import org.json.JSONObject

/**
 * The Bridge v2 envelope for Local Sync: request {v,id,m,p:[...]}, response {v,id,ok,d} or {v,id,ok:false,e:{code}}.
 * This is a dumb relay: [handle] only ever calls methods that already exist on Bridge ([known]) and are not on [DENIED].
 * Pure Kotlin so JUnit covers it.
 */
object RemoteRpc {
    const val VERSION = 1
    const val MAX_BYTES = 1_000_000

    /** Methods that open phone screens, need the phone's hardware, start the network features or save on the phone. Never relayed. */
    val DENIED: Set<String> = setOf(
        "openPermission", "openAppInfo", "openUrl", "openBrainySettings", "openAppPicker", "openDiagnostics",
        "requestNotif", "requestActivity", "pickTone", "previewTone", "stopPreview", "pickModel",
        "assistListen", "assistStop", "assistSpeak", "savePdf", "saveFile",
        "remoteStart", "remoteStop", "remoteStatus", "remotePairCode", "cloudRun", "cloudTake",
        "llmRun", "llmImport"
    )

    private fun fail(id: Any?, code: String): String =
        JSONObject().put("v", VERSION).put("id", id ?: JSONObject.NULL).put("ok", false).put("e", JSONObject().put("code", code)).toString()

    fun handle(body: String, known: Set<String>, call: (String, JSONArray) -> Any?): String {
        if (body.length > MAX_BYTES) return fail(null, "E_TOO_LARGE")
        val req = try { JSONObject(body) } catch (e: Exception) { return fail(null, "E_BAD_REQUEST") }
        val id = req.opt("id")
        if (req.optInt("v", -1) != VERSION) return fail(id, "E_VERSION")
        val m = req.optString("m", "")
        val p = req.optJSONArray("p") ?: JSONArray()
        if (m.isEmpty() || m in DENIED || m !in known) return fail(id, "E_METHOD_NOT_ALLOWED")
        return try {
            val d = call(m, p)
            JSONObject().put("v", VERSION).put("id", id ?: JSONObject.NULL).put("ok", true).put("d", d ?: JSONObject.NULL).toString()
        } catch (e: Throwable) { fail(id, "E_CALL_FAILED") }
    }
}
