package com.vastanzil.sandpiper

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.media.MediaPlayer
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File

/** JavaScript bridge exposed to the bundled page as `window.SandpiperNative`. */
class Bridge(private val a: MainActivity) {
    private val ctx: Context = a.applicationContext
    private val main = Handler(Looper.getMainLooper())

    /** Returns the next trigger time (epoch ms), or 0 if nothing could be scheduled. */
    @JavascriptInterface fun schedule(json: String): Long = try {
        val o = JSONObject(json)
        Scheduler.put(ctx, o)
        val next = Scheduler.nextTime(o, System.currentTimeMillis()) ?: 0L
        Diag.log(DLvl.I, DCat.BRIDGE, DEv.BRIDGE_SCHEDULE, DMod.ALARMS, if (next > 0L) DRes.OK else DRes.SKIP)
        next
    } catch (e: Exception) {
        Diag.log(DLvl.W, DCat.BRIDGE, DEv.BRIDGE_SCHEDULE, DMod.ALARMS, DRes.FAIL, code = Diag.codeOf(e))
        0L
    }

    /** Schedules a real alarm 10 seconds from now through the same path as normal alarms. */
    @JavascriptInterface fun testAlarm(tone: String): Long = schedule(
        JSONObject().put("id", "test_alarm").put("kind", "alarm").put("title", "Test alarm")
            .put("tone", tone.ifBlank { Tones.DEFAULT })
            .put("at", System.currentTimeMillis() + 10_000L).toString()
    )

    /** kind = "system" (ringtone picker) or "file" (any audio file). Result arrives in window.onToneChosen(). */
    @JavascriptInterface fun pickTone(kind: String) { a.pickTone(kind) }

    /** Deletes a copied custom tone file (only inside the app's own tones folder). */
    @JavascriptInterface fun deleteTone(tone: String) {
        if (!tone.startsWith("file:")) return
        runCatching {
            val f = File(tone.removePrefix("file:")).canonicalFile
            if (f.path.startsWith(File(ctx.filesDir, "tones").canonicalPath)) f.delete()
        }
    }

    private var preview: MediaPlayer? = null
    private val stopper = Runnable { stopPreviewNow() }
    private fun stopPreviewNow() {
        main.removeCallbacks(stopper)
        runCatching { preview?.stop() }
        runCatching { preview?.release() }
        preview = null
    }

    @JavascriptInterface fun previewTone(tone: String) {
        main.post {
            stopPreviewNow()
            val mp = Tones.player(ctx, tone) ?: return@post
            mp.setVolume(0.8f, 0.8f)
            mp.start()
            preview = mp
            main.postDelayed(stopper, 8000)
        }
    }

    @JavascriptInterface fun stopPreview() { main.post { stopPreviewNow() } }

    @JavascriptInterface fun cancel(id: String) { Scheduler.remove(ctx, id) }

    @JavascriptInterface fun notifEnabled(): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    /** Used by the Planner and Fitness pages: same shared request path as the Permissions panel. */
    @JavascriptInterface fun requestNotif() {
        if (Permissions.act(ctx, a, "notifications") == "granted") a.js("window.onNativePermission&&onNativePermission()")
    }

    /** Saves a file (base64): into Sandpiper/backup or Sandpiper/export when Files access is on, else Downloads/Sandpiper via MediaStore. */
    @JavascriptInterface fun saveFile(name: String, mime: String, b64: String): Boolean {
      return try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        if (StorageRoot.usingShared(ctx)) {
            // Files access is on: backups go to Sandpiper/backup, everything else to Sandpiper/export
            val dir = StorageRoot.dir(ctx, if (safe.startsWith("sandpiper-backup")) "backup" else "export")
            var f = File(dir, safe)
            if (f.exists()) f = File(dir, safe.substringBeforeLast('.') + "-" + System.currentTimeMillis() + (if (safe.contains('.')) "." + safe.substringAfterLast('.') else ""))
            f.writeBytes(bytes)
            Diag.log(DLvl.I, DCat.BRIDGE, DEv.BRIDGE_SAVE_FILE, DMod.OTHER, DRes.OK, n = bytes.size.toLong())
            return true
        }
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safe)
            put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sandpiper")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(uri)!!.use { it.write(bytes) }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        r.update(uri, v, null, null)
        Diag.log(DLvl.I, DCat.BRIDGE, DEv.BRIDGE_SAVE_FILE, DMod.OTHER, DRes.OK, n = bytes.size.toLong())
        true
    } catch (e: Exception) {
        Diag.log(DLvl.W, DCat.BRIDGE, DEv.BRIDGE_SAVE_FILE, DMod.OTHER, DRes.FAIL, code = Diag.codeOf(e))
        false
    }
    }

    @JavascriptInterface fun requestActivity() { Permissions.act(ctx, a, "activity") }

    /** Reads the step sensor, stores the sample and pushes {ok, steps, activeMin, history} to window.onSteps(). */
    @JavascriptInterface fun readSteps() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            push(JSONObject().put("ok", false).put("reason", "permission")); return
        }
        if (ctx.getSystemService(SensorManager::class.java).getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) {
            push(JSONObject().put("ok", false).put("reason", "sensor")); return
        }
        Thread {
            val total = Steps.readTotal(ctx)
            if (total != null) Steps.record(ctx, total)
            val sum = Steps.summary(ctx)
            push(sum.put("ok", true).put("reason", ""))
        }.start()
    }

    private fun push(o: JSONObject) { a.js("window.onSteps&&onSteps(" + JSONObject.quote(o.toString()) + ")") }

    // ---------- Fitness support ----------
    @JavascriptInterface fun openUrl(url: String): Boolean {
        if (!Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(url)) return false
        return try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
    }

    /** Permission flags in the shape the fitness page expects. Accessibility detection is not implemented, so it is always false. */
    @JavascriptInterface fun permState(): String = JSONObject()
        .put("usage", Permissions.ok(ctx, "usage"))
        .put("overlay", Permissions.ok(ctx, "overlay"))
        .put("a11y", Permissions.ok(ctx, "accessibility"))
        .put("notif", Permissions.ok(ctx, "notifications"))
        .put("act", Permissions.ok(ctx, "activity"))
        .toString()

    @JavascriptInterface fun openAppInfo() {
        runCatching {
            a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Today's Brainy counts plus real app usage time (needs Usage Access) in the shape setBrainrot() expects. */
    @JavascriptInterface fun brainrotToday(): String {
        val o = BrainyStore.snapshot(ctx)
        runCatching {
            val u = JSONObject(usageToday())
            if (u.optBoolean("ok")) o.put("usageMin", u.optLong("usageMin")).put("sessions", u.optInt("sessions"))
        }
        return o.toString()
    }

    /** Fitness-page settings (floating counter, blocker, budgets, quiet hours...) used by the accessibility service. */
    @JavascriptInterface fun setFitSettings(json: String) { BrainyStore.setSettings(ctx, json) }

    /** Opens the native Brainy Island settings screen (reel detection, tracked apps, island look, diagnostics). */
    @JavascriptInterface fun openBrainySettings() {
        a.runOnUiThread { runCatching { a.startActivity(Intent(a, BrainySettingsActivity::class.java)) } }
    }

    /**
     * "Pause Brainy": turns the accessibility service off from inside the app, for the moment right before opening
     * a banking/wallet app that refuses to run while an untrusted accessibility service is enabled. Returns false
     * when Brainy was not running (accessibility already off - nothing to pause).
     */
    @JavascriptInterface fun pauseBrainy(): Boolean {
        val ok = BrainyService.pause()
        Diag.log(DLvl.I, DCat.BRAINY, DEv.SERVICE_PAUSED, DMod.BRAINY, if (ok) DRes.OK else DRes.SKIP)
        return ok
    }

    /** Piper Pro workspace in Sandpiper's central database. Returns "" when nothing is stored yet. */
    @JavascriptInterface fun piperLoad(): String = PiperStore.load(ctx) ?: ""

    /** Stores the whole Piper workspace (validated JSON object with a pages array) in one transaction. */
    @JavascriptInterface fun piperSave(json: String): Boolean = PiperStore.save(ctx, json)

    /** {"ok":true,"has":true,"pages":12,"bytes":123456,"updatedAt":...}; ok=false means the database is unavailable. */
    @JavascriptInterface fun piperStatus(): String = PiperStore.status(ctx)

    /** Opens the native Diagnostics screen (self-test, module health, export of the privacy-safe diagnostic log). */
    @JavascriptInterface fun openDiagnostics() {
        a.runOnUiThread { runCatching { a.startActivity(Intent(a, DiagnosticsActivity::class.java)) } }
    }

    /** Fitness-page ids (a11y, usage, overlay, notif, act) mapped onto the shared Permissions actions. */
    @JavascriptInterface fun openPermission(which: String): Boolean {
        val id = when (which) { "a11y" -> "accessibility"; "notif" -> "notifications"; "act" -> "activity"; "usage", "overlay" -> which; else -> return false }
        return Permissions.act(ctx, a, id) != "na"
    }

    /** Today's foreground time and session count for TikTok, Instagram, Facebook and YouTube (needs Usage Access). */
    @JavascriptInterface fun usageToday(): String {
        if (!Permissions.usageOn(ctx)) return JSONObject().put("ok", false).toString()
        val pk = IslandStore.monitoredApps(ctx)   // the apps chosen in Brainy Island (built-in list until changed)
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        val now = System.currentTimeMillis()
        val um = ctx.getSystemService(android.app.usage.UsageStatsManager::class.java)
        val ev = um.queryEvents(cal.timeInMillis, now)
        val e = android.app.usage.UsageEvents.Event()
        val start = HashMap<String, Long>()
        var total = 0L
        var sessions = 0
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.packageName !in pk) continue
            when (e.eventType) {
                android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED -> start[e.packageName] = e.timeStamp
                android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED -> start.remove(e.packageName)?.let { t0 ->
                    val d = e.timeStamp - t0
                    if (d >= 5000) { total += d; sessions++ }
                }
            }
        }
        start.values.forEach { total += now - it } // still open right now
        return JSONObject().put("ok", true).put("usageMin", total / 60000).put("sessions", sessions).toString()
    }

    // ---------- Settings and Permissions panels ----------
    /** assets/features.json: permissions, features and every setting definition. */
    @JavascriptInterface fun registry(): String = try { FeatureRegistry.json(ctx) } catch (e: Exception) { "" }

    /** Live state of every permission: [{"id":..,"state":"granted|not_granted|permanently_denied|special|na"}]. */
    @JavascriptInterface fun permissions(log: Boolean): String = try { Permissions.statesJson(ctx, a, log) } catch (e: Exception) { "[]" }

    /** Grant / Fix button: requested | opened | appinfo | granted | na. */
    @JavascriptInterface fun permissionAction(id: String): String = try { Permissions.act(ctx, a, id) } catch (e: Exception) { "na" }

    @JavascriptInterface fun settingGet(feature: String, key: String): String? = SettingsStore.get(ctx, feature, key)
    @JavascriptInterface fun settingSet(feature: String, key: String, value: String): Boolean = SettingsStore.set(ctx, feature, key, value)
    @JavascriptInterface fun settingsAll(): String = SettingsStore.all(ctx).toString()
    @JavascriptInterface fun settingsReplace(json: String): Boolean = try { SettingsStore.replaceAll(ctx, JSONObject(json)) } catch (e: Exception) { false }

    /** Brainy Island settings as strings (tracking, always, browser = true/false; style, look = enum name; gap = 0..3). */
    @JavascriptInterface fun islandGet(key: String): String? = when (key) {
        "tracking" -> IslandStore.tracking(ctx).toString()
        "always" -> IslandStore.islandAlways(ctx).toString()
        "browser" -> IslandStore.browserSupport(ctx).toString()
        "style" -> IslandStore.style(ctx).name
        "look" -> IslandStore.look(ctx).name
        "gap" -> IslandStore.gapLevel(ctx).toString()
        else -> null
    }

    @JavascriptInterface fun islandSet(key: String, value: String): Boolean {
        return try {
            when (key) {
                "tracking" -> IslandStore.setTracking(ctx, value == "true")
                "always" -> IslandStore.setIslandAlways(ctx, value == "true")
                "browser" -> IslandStore.setBrowserSupport(ctx, value == "true")
                "style" -> IslandStore.setStyle(ctx, IslandStyle.valueOf(value))
                "look" -> IslandStore.setLook(ctx, IslandLook.valueOf(value))
                "gap" -> IslandStore.setGapLevel(ctx, value.toInt())
                else -> return false
            }
            true
        } catch (e: Exception) { false }
    }

    @JavascriptInterface fun appGet(key: String): String? = AppSettings.get(ctx, key)
    @JavascriptInterface fun appSet(key: String, value: String): Boolean = AppSettings.set(ctx, key, value)

    @JavascriptInterface fun trackedAppsCount(): Int = IslandStore.monitoredApps(ctx).size
    @JavascriptInterface fun openAppPicker() { a.runOnUiThread { runCatching { a.startActivity(Intent(a, BrainyAppPickerActivity::class.java)) } } }

    @JavascriptInterface fun appVersion(): String = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    /** Records that a setting of [feature] changed. Only the feature enum is logged, never the key or value. */
    @JavascriptInterface fun logSettingChange(feature: String) {
        val mod = when (feature) {
            "brainy" -> DMod.BRAINY; "alarms" -> DMod.ALARMS; "finance" -> DMod.FINANCE; "notes" -> DMod.NOTES; "planner" -> DMod.PLANNER
            "steps" -> DMod.STEPS; "habits" -> DMod.HABITS; "general", "backup", "diagnostics", "about" -> DMod.APP; else -> DMod.OTHER
        }
        Diag.log(DLvl.I, DCat.SETTINGS, DEv.SETTINGS_CHANGED, mod, DRes.OK)
    }

    @JavascriptInterface fun logBackup(restore: Boolean, ok: Boolean) {
        Diag.log(if (ok) DLvl.I else DLvl.W, if (restore) DCat.RESTORE else DCat.BACKUP, if (restore) DEv.BACKUP_RESTORED else DEv.BACKUP_EXPORTED, DMod.APP, if (ok) DRes.OK else DRes.FAIL)
    }

    // ---- Sprout SMS capture (providers the user selected only; OTP and non-transaction messages are dropped) ----
    /** JSON array of provider names Sprout may read, e.g. ["bKash","City Bank"]. Empty = nothing is read. Returns how many were kept. */
    @JavascriptInterface fun smsSetProviders(json: String): Int = try { SmsStore.setProviders(ctx, json) } catch (e: Exception) { 0 }
    @JavascriptInterface fun smsPending(): Int = try { SmsStore.pending(ctx) } catch (e: Exception) { 0 }
    /** Up to [limit] captured messages, oldest first: [{id,sender,body,ts}]. */
    @JavascriptInterface fun smsTake(limit: Int): String = try { SmsStore.take(ctx, limit) } catch (e: Exception) { "[]" }
    /** Sprout has processed these ids (JSON array): their text is erased. */
    @JavascriptInterface fun smsAck(idsJson: String): Int = try { SmsStore.ack(ctx, idsJson) } catch (e: Exception) { 0 }
    /** Looks back [days] days in the inbox for messages from the selected providers. -1 = permission missing. */
    @JavascriptInterface fun smsScan(days: Int): Int = try { SmsStore.scan(ctx, days) } catch (e: Exception) { -1 }
    /** Lists inbox senders that look like banks / wallets for the user to choose from: {"ok":true,"threads":[{sender,total,tx,last,preview}]} or {"ok":false}. */
    @JavascriptInterface fun smsDiscover(days: Int): String = try { SmsStore.discover(ctx, days) ?: "{\"ok\":false}" } catch (e: Exception) { "{\"ok\":false}" }
    @JavascriptInterface fun smsStatus(): String = try { SmsStore.status(ctx) } catch (e: Exception) { "{}" }

    // ---- Sprout (finance pro): the whole app state is one document in the central database ----
    /** The stored Sprout snapshot, or "" when none. */
    @JavascriptInterface fun sproutLoad(): String = try { SproutStore.load(ctx) } catch (e: Exception) { "" }
    /** Saves the snapshot (empty string erases it). Returns false when it was refused or failed. */
    @JavascriptInterface fun sproutSave(json: String): Boolean = try { SproutStore.save(ctx, json) } catch (e: Exception) { false }
    @JavascriptInterface fun sproutStatus(): String = try { SproutStore.status(ctx) } catch (e: Exception) { "{}" }

    // ---- Planner list (Daily / Weekly / Monthly) ----
    @JavascriptInterface fun plannerList(period: String): String = try {
        val a = org.json.JSONArray(); PlannerStore.listTasks(ctx, period).forEach { a.put(PlannerCore.taskJson(it)) }; a.toString()
    } catch (e: Exception) { "[]" }
    /** Returns the new task id, or "" when the text is empty / the period is unknown. */
    @JavascriptInterface fun plannerAdd(period: String, text: String): String = try { (PlannerStore.add(ctx, period, text) ?: "").also { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(ctx) } } catch (e: Exception) { "" }
    @JavascriptInterface fun plannerToggle(id: String, done: Boolean): Boolean = try { PlannerStore.setDone(ctx, id, done).also { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(ctx) } } catch (e: Exception) { false }
    @JavascriptInterface fun plannerDelete(id: String): Boolean = try { PlannerStore.deleteTask(ctx, id).also { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(ctx) } } catch (e: Exception) { false }
    @JavascriptInterface fun plannerHistory(limit: Int): String = try {
        val a = org.json.JSONArray(); PlannerStore.history(ctx, limit).forEach { a.put(PlannerCore.histJson(it)) }; a.toString()
    } catch (e: Exception) { "[]" }
    /** Whole planner (tasks + history) for the JSON backup. */
    @JavascriptInterface fun plannerBackupBlob(): String = try { PlannerStore.exportAll(ctx).toString() } catch (e: Exception) { "{}" }
    /** Restore from a backup blob. Returns how many tasks were written, or -1. */
    @JavascriptInterface fun plannerRestoreBlob(json: String, merge: Boolean): Int = try { PlannerStore.importAll(ctx, org.json.JSONObject(json), merge).also { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(ctx) } } catch (e: Exception) { -1 }
    /** Reserved for the future Sandpiper Pro workspace: same pattern as Piper (module_doc row), nothing is stored yet. */
    @JavascriptInterface fun sandpiperProStatus(): String = org.json.JSONObject().put("module", ProStore.MODULE).put("docKey", ProStore.DOC_KEY).put("reserved", true).put("stored", false).toString()

    // ---- Activity ledger (history for the Home Activity card and Track Record) ----
    /** Batch of events from the web layer. Returns how many were stored, or -1 on error. */
    @JavascriptInterface fun activityLog(json: String): Int = try { ActivityStore.log(ctx, ActivityCore.parse(json)).also { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(ctx) } } catch (e: Exception) { -1 }
    @JavascriptInterface fun activityDelete(id: String): Boolean = try { ActivityStore.delete(ctx, id) } catch (e: Exception) { false }
    @JavascriptInterface fun activityDay(day: String): String = try { ActivityStore.day(ctx, day) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun activitySeries(metric: String, from: String, to: String): String = try { ActivityStore.series(ctx, metric, from, to) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun activityRebuild(): Int = try {
        val n = ActivityStore.rebuild(ctx)
        Diag.log(DLvl.I, DCat.DB, DEv.ACTIVITY_REBUILT, DMod.ACTIVITY, DRes.OK, n = n.toLong())
        n
    } catch (e: Exception) { -1 }
    @JavascriptInterface fun activityStatus(): String = try { ActivityStore.status(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun activityExport(): String = try { ActivityStore.export(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun activityImport(json: String): Int = try {
        val n = ActivityStore.import(ctx, json)
        Diag.log(DLvl.I, DCat.RESTORE, DEv.ACTIVITY_IMPORTED, DMod.ACTIVITY, DRes.OK, n = n.toLong())
        n
    } catch (e: Exception) { -1 }
    /** Frozen per-day record (closed-day results). Contains task names, so it is never logged. */
    @JavascriptInterface fun daySummarySave(day: String, closed: Boolean, json: String): Boolean = try { ActivityStore.daySave(ctx, day, closed, json) } catch (e: Exception) { false }
    @JavascriptInterface fun daySummaryGet(day: String): String = try { ActivityStore.dayGet(ctx, day) } catch (e: Exception) { "" }

    // ---- Native storage: finance + voice notes + the Sandpiper folder ----
    @JavascriptInterface fun finList(): String = try { FinanceStore.list(ctx).toString() } catch (e: Exception) { "[]" }
    @JavascriptInterface fun finAdd(json: String): Boolean = try { FinanceStore.add(ctx, org.json.JSONObject(json)) } catch (e: Exception) { false }
    @JavascriptInterface fun finDelete(id: String): Boolean = try { FinanceStore.delete(ctx, id) } catch (e: Exception) { false }
    @JavascriptInterface fun finReplaceAll(json: String): Int = try { FinanceStore.replaceAll(ctx, org.json.JSONArray(json)) } catch (e: Exception) { -1 }
    @JavascriptInterface fun voiceList(): String = try { VoiceStore.list(ctx).toString() } catch (e: Exception) { "[]" }
    @JavascriptInterface fun voicePut(id: String, index: Int, b64: String): Boolean = try { VoiceStore.put(ctx, id, index, b64) } catch (e: Exception) { false }
    @JavascriptInterface fun voiceDone(id: String, mime: String, title: String, created: Double, dur: Double): Boolean = try { VoiceStore.done(ctx, id, mime, title, created.toLong(), dur.toLong()) } catch (e: Exception) { false }
    @JavascriptInterface fun voiceSize(id: String): Double = try { VoiceStore.size(ctx, id).toDouble() } catch (e: Exception) { 0.0 }
    @JavascriptInterface fun voiceChunk(id: String, offset: Double, len: Int): String = try { VoiceStore.chunk(ctx, id, offset.toLong(), len) } catch (e: Exception) { "" }
    @JavascriptInterface fun voiceDelete(id: String): Boolean = try { VoiceStore.delete(ctx, id) } catch (e: Exception) { false }
    @JavascriptInterface fun voiceExport(id: String): String = try { VoiceStore.exportCopy(ctx, id) } catch (e: Exception) { "" }
    @JavascriptInterface fun storageInfo(): String = try {
        org.json.JSONObject().put("shared", StorageRoot.usingShared(ctx)).put("access", StorageRoot.hasAccess(ctx)).put("label", StorageRoot.label(ctx))
            .put("dbShared", DbLocation.shared).put("recordings", VoiceStore.count(ctx)).put("transactions", FinanceStore.count(ctx))
            .put("restart", StorageRoot.usingShared(ctx) && !DbLocation.shared).toString()
    } catch (e: Exception) { "{}" }
    /** Files in one Sandpiper sub-folder ("backup", "import", "export"), newest first: [{name,size,mtime}]. */
    @JavascriptInterface fun folderList(sub: String): String = try {
        val out = org.json.JSONArray()
        if (sub in StorageRoot.SUBS) StorageRoot.dir(ctx, sub).listFiles { f -> f.isFile && !f.name.startsWith(".") }?.sortedByDescending { it.lastModified() }
            ?.forEach { out.put(org.json.JSONObject().put("name", it.name).put("size", it.length()).put("mtime", it.lastModified())) }
        out.toString()
    } catch (e: Exception) { "[]" }
    /** Text of a small file (a JSON backup) from backup/ or import/; "" when missing or over 40 MB. */
    @JavascriptInterface fun folderRead(sub: String, name: String): String = try {
        if (sub != "backup" && sub != "import") "" else StorageRoot.find(ctx, sub, name)?.takeIf { it.length() < 40_000_000L }?.readText() ?: ""
    } catch (e: Exception) { "" }

    // ---- Home-screen widgets: records the widgets wrote natively that the web layer imports (finance list, focus garden, voice notes). ----
    @JavascriptInterface fun widgetInboxTake(limit: Int): String = try { com.vastanzil.sandpiper.widget.WidgetStore.take(ctx, limit).toString() } catch (e: Exception) { "[]" }
    @JavascriptInterface fun widgetInboxAck(idsJson: String): Int = try { com.vastanzil.sandpiper.widget.WidgetStore.ack(ctx, org.json.JSONArray(idsJson)) } catch (e: Exception) { 0 }
    @JavascriptInterface fun widgetInboxPending(): Int = try { com.vastanzil.sandpiper.widget.WidgetStore.pending(ctx) } catch (e: Exception) { 0 }
    @JavascriptInterface fun widgetSelfTest(): String = try { com.vastanzil.sandpiper.widget.WidgetSelfTest.run(ctx).toString() } catch (e: Exception) { "[]" }
    // the ONE focus timer (the Zen screen and the Focus widget are both views of it)
    @JavascriptInterface fun focusState(): String = try { com.vastanzil.sandpiper.widget.FocusTimer.json(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun focusStart(mode: String): String = try { com.vastanzil.sandpiper.widget.FocusTimer.start(ctx, mode); com.vastanzil.sandpiper.widget.FocusTimer.json(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun focusPause(): String = try { com.vastanzil.sandpiper.widget.FocusTimer.pause(ctx); com.vastanzil.sandpiper.widget.FocusTimer.json(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun focusReset(mode: String): String = try { com.vastanzil.sandpiper.widget.FocusTimer.reset(ctx, mode); com.vastanzil.sandpiper.widget.FocusTimer.json(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun focusSeed(sessions: Int) { try { com.vastanzil.sandpiper.widget.FocusTimer.seed(ctx, sessions) } catch (e: Exception) { } }
    @JavascriptInterface fun widgetsRefresh() { com.vastanzil.sandpiper.widget.Widgets.refreshSoon(ctx) }

    // ---- Little brain (on-device LLM). No network. Results arrive as window.onLlmResult(requestId, json); the web layer stays silent on failures. ----
    @JavascriptInterface fun llmStatus(): String = try { com.vastanzil.sandpiper.llm.Brain.status(ctx) } catch (e: Exception) { "{}" }
    @JavascriptInterface fun llmRun(task: String, input: String, requestId: String): String = try {
        com.vastanzil.sandpiper.llm.Brain.run(ctx, task, input, requestId) { id, json ->
            a.js("window.onLlmResult&&onLlmResult(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")")
        }
        "{\"queued\":true}"
    } catch (e: Exception) { "{\"queued\":false}" }
    @JavascriptInterface fun llmCancel(requestId: String): Boolean = try { com.vastanzil.sandpiper.llm.Brain.cancel(ctx, requestId) } catch (e: Exception) { false }
    @JavascriptInterface fun llmModels(): String = try { com.vastanzil.sandpiper.llm.Brain.models(ctx) } catch (e: Exception) { "[]" }
    @JavascriptInterface fun llmUsage(): String = try { com.vastanzil.sandpiper.llm.Brain.usage(ctx) } catch (e: Exception) { "[]" }
    @JavascriptInterface fun llmImportPick() { a.pickModel() }
    @JavascriptInterface fun llmRemove(id: String): Boolean = try { com.vastanzil.sandpiper.llm.Brain.remove(ctx, id) } catch (e: Exception) { false }

    @JavascriptInterface fun logSeeded(count: Int) { Diag.log(DLvl.I, DCat.SETTINGS, DEv.SETTINGS_SEEDED, DMod.APP, DRes.OK, n = count.toLong()) }

    // ---------- Assist: sleep estimate, voice, PDF ----------
    private val voice by lazy { AssistVoice(a) }

    /** Estimated sleep for the night that ended on [day] (yyyy-MM-dd), from screen-off time. Needs Usage Access. {"ok":false,"why":..} when unavailable. */
    @JavascriptInterface fun sleepEstimate(day: String): String = try {
        if (!Permissions.usageOn(ctx)) JSONObject().put("ok", false).put("why", "usage").toString()
        else {
            val d = java.time.LocalDate.parse(day)
            val zone = java.time.ZoneId.systemDefault()
            val start = d.atStartOfDay(zone).minusHours(6).toInstant().toEpochMilli()
            val end = minOf(d.atStartOfDay(zone).plusHours(14).toInstant().toEpochMilli(), System.currentTimeMillis())
            val ev = ctx.getSystemService(android.app.usage.UsageStatsManager::class.java).queryEvents(start, end)
            val e = android.app.usage.UsageEvents.Event()
            val off = ArrayList<LongArray>()
            var offAt = -1L
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == android.app.usage.UsageEvents.Event.SCREEN_NON_INTERACTIVE) offAt = e.timeStamp
                else if (e.eventType == android.app.usage.UsageEvents.Event.SCREEN_INTERACTIVE && offAt >= 0) { off.add(longArrayOf(offAt, e.timeStamp)); offAt = -1L }
            }
            if (offAt >= 0) off.add(longArrayOf(offAt, end))
            (SleepCore.estimate(off, start, end)?.json() ?: JSONObject().put("ok", false).put("why", "none")).toString()
        }
    } catch (e: Exception) { JSONObject().put("ok", false).put("why", "error").toString() }

    /** Push-to-talk. Text arrives in window.onAssistHeard(text, final, error). lang = auto | en | bn. */
    @JavascriptInterface fun assistListen(lang: String) { voice.listen(lang) }
    @JavascriptInterface fun assistStop() { voice.stop() }
    @JavascriptInterface fun assistSpeak(text: String, lang: String) { voice.speak(text, lang) }
    fun assistShutdown() { voice.shutdown() }

    /** Plain-text report as a PDF (system fonts, so Bengali and the taka sign render). Saved like any other export. */
    @JavascriptInterface fun savePdf(name: String, title: String, text: String): Boolean = try {
        val doc = android.graphics.pdf.PdfDocument()
        val w = 595; val h = 842; val m = 40
        val paint = android.graphics.Paint().apply { isAntiAlias = true; textSize = 11f; color = android.graphics.Color.BLACK }
        val head = android.graphics.Paint(paint).apply { textSize = 18f; isFakeBoldText = true }
        var page: android.graphics.pdf.PdfDocument.Page? = null
        var n = 0
        var y = 0f
        fun fresh() {
            page?.let { doc.finishPage(it) }
            n++
            page = doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(w, h, n).create())
            y = m + 14f
            if (n == 1) { page!!.canvas.drawText(title.take(60), m.toFloat(), y, head); y += 28f }
        }
        fresh()
        for (line in text.take(60_000).split("\n")) {
            var rest = line
            do {
                val k = paint.breakText(rest, true, (w - 2 * m).toFloat(), null).coerceAtLeast(1)
                if (y > h - m) fresh()
                page!!.canvas.drawText(rest.substring(0, minOf(k, rest.length)), m.toFloat(), y, paint)
                y += 16f
                rest = rest.substring(minOf(k, rest.length))
            } while (rest.isNotEmpty())
        }
        page?.let { doc.finishPage(it) }
        val out = java.io.ByteArrayOutputStream()
        doc.writeTo(out); doc.close()
        saveFile(name, "application/pdf", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
    } catch (e: Exception) { false }

    // ---------- Local Sync (LAN, opt-in) and encrypted Cloud Backup (opt-in): see docs/architecture/SANDPIPER_NET_ARCHITECTURE_PLAN.md ----------
    @JavascriptInterface fun remoteStart(port: Int, remember: Boolean): String = com.vastanzil.sandpiper.remote.RemoteSyncServer.start(a, port, remember)
    @JavascriptInterface fun remoteStop(): String { com.vastanzil.sandpiper.remote.RemoteSyncServer.stop(); return com.vastanzil.sandpiper.remote.RemoteSyncServer.status() }
    @JavascriptInterface fun remoteStatus(): String = com.vastanzil.sandpiper.remote.RemoteSyncServer.status()
    @JavascriptInterface fun remotePairCode(): String = com.vastanzil.sandpiper.remote.RemoteSyncServer.pairCode()
    @JavascriptInterface fun cloudRun(op: String, pass: String, json: String) { com.vastanzil.sandpiper.backup.CloudBackup.run(a, op, pass, json) }
    @JavascriptInterface fun cloudTake(): String = com.vastanzil.sandpiper.backup.CloudBackup.take()
}
