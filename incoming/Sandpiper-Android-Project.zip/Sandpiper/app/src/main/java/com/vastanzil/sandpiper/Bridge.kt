package com.vastanzil.sandpiper

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.media.MediaPlayer
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

/** JavaScript bridge exposed to the bundled page as `window.SandpiperNative`. */
class Bridge(private val a: MainActivity) {
    private val ctx: Context = a.applicationContext
    private val main = Handler(Looper.getMainLooper())

    /** Returns the next trigger time (epoch ms), or 0 if nothing could be scheduled. */
    @JavascriptInterface fun schedule(json: String): Long = try {
        val o = JSONObject(json)
        Scheduler.put(ctx, o)
        Scheduler.nextTime(o, System.currentTimeMillis()) ?: 0L
    } catch (e: Exception) { 0L }

    /** Schedules a real alarm 10 seconds from now through the same path as normal alarms. */
    @JavascriptInterface fun testAlarm(tone: String): Long = schedule(
        JSONObject().put("id", "test_alarm").put("kind", "alarm").put("title", "Test alarm")
            .put("tone", tone.ifBlank { Tones.DEFAULT })
            .put("at", System.currentTimeMillis() + 10_000L).toString()
    )

    /** kind = "system" (ringtone picker) or "file" (any audio file). Result arrives in window.onToneChosen(). */
    @JavascriptInterface fun pickTone(kind: String) { a.pickTone(kind) }

    /** Deletes a copied custom tone file (only inside the app's own tones folder). */
    @JavascriptInterface fun deleteTone(tone: String) {
        if (!tone.startsWith("file:")) return
        runCatching {
            val f = File(tone.removePrefix("file:")).canonicalFile
            if (f.path.startsWith(File(ctx.filesDir, "tones").canonicalPath)) f.delete()
        }
    }

    private var preview: MediaPlayer? = null
    private val stopper = Runnable { stopPreviewNow() }
    private fun stopPreviewNow() {
        main.removeCallbacks(stopper)
        runCatching { preview?.stop() }
        runCatching { preview?.release() }
        preview = null
    }

    @JavascriptInterface fun previewTone(tone: String) {
        main.post {
            stopPreviewNow()
            val mp = Tones.player(ctx, tone) ?: return@post
            mp.setVolume(0.8f, 0.8f)
            mp.start()
            preview = mp
            main.postDelayed(stopper, 8000)
        }
    }

    @JavascriptInterface fun stopPreview() { main.post { stopPreviewNow() } }

    @JavascriptInterface fun alarmStatus(): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ch = nm.getNotificationChannel(Notifier.CH_RING)
        val pm = ctx.getSystemService(PowerManager::class.java)
        return JSONObject()
            .put("notif", notifEnabled())
            .put("chBlocked", ch != null && ch.importance == NotificationManager.IMPORTANCE_NONE)
            .put("fullScreen", Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent())
            .put("battery", pm.isIgnoringBatteryOptimizations(ctx.packageName))
            .put("exact", canExact())
            .toString()
    }

    @JavascriptInterface fun openAlarmSettings(which: String) {
        val pkg = Uri.parse("package:" + ctx.packageName)
        val i = when (which) {
            "notif" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            "fullscreen" -> if (Build.VERSION.SDK_INT >= 34) Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg)
                            else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
            "battery" -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { a.startActivity(i) } catch (e: Exception) {
            runCatching { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    @JavascriptInterface fun cancel(id: String) { Scheduler.remove(ctx, id) }

    @JavascriptInterface fun notifEnabled(): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    @JavascriptInterface fun requestNotif() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) a.askPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        else if (!notifEnabled()) {
            a.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } else a.js("window.onNativePermission&&onNativePermission()")
    }

    @JavascriptInterface fun canExact(): Boolean =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    @JavascriptInterface fun openExactSettings() {
        if (Build.VERSION.SDK_INT >= 31) runCatching {
            a.startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Saves a file (base64) into Downloads/Sandpiper via MediaStore; no storage permission needed. */
    @JavascriptInterface fun saveFile(name: String, mime: String, b64: String): Boolean = try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safe)
            put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sandpiper")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(uri)!!.use { it.write(bytes) }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        r.update(uri, v, null, null)
        true
    } catch (e: Exception) { false }

    @JavascriptInterface fun requestActivity() {
        a.askPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION))
    }

    /** One-shot read of TYPE_STEP_COUNTER; result is pushed to window.onSteps(). */
    @JavascriptInterface fun readSteps() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            push(false, 0, "permission"); return
        }
        val sm = ctx.getSystemService(SensorManager::class.java)
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (sensor == null) { push(false, 0, "sensor"); return }
        main.post {
            sm.registerListener(object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    sm.unregisterListener(this)
                    push(true, stepsToday(e.values[0].toLong()), "")
                }
                override fun onAccuracyChanged(s: Sensor?, acc: Int) {}
            }, sensor, SensorManager.SENSOR_DELAY_NORMAL, main)
        }
    }

    // The step counter reports total steps since boot. Keep a per-day baseline.
    private fun stepsToday(total: Long): Long {
        val p = ctx.getSharedPreferences("sp_steps", Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        var base = p.getLong("base", -1L)
        val rebooted = total < base
        if (p.getString("date", "") != today || base < 0L || rebooted) {
            base = if (rebooted && p.getString("date", "") == today) 0L else total
            p.edit().putString("date", today).putLong("base", base).apply()
        }
        return total - base
    }

    private fun push(ok: Boolean, steps: Long, reason: String) {
        val j = JSONObject().put("ok", ok).put("steps", steps).put("reason", reason).toString()
        a.js("window.onSteps&&onSteps(" + JSONObject.quote(j) + ")")
    }
}
