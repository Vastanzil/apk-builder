package com.vastanzil.sandpiper

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Brainy: counts short videos / videos / feed items in four apps and applies the Fitness page's settings
 * (floating counter, status notification, warnings, focus lock over 60% of the screen).
 * It looks only at the foreground package name, scroll events and view-ID names. It never reads text or messages.
 * Detection is heuristic (app view IDs change between versions), which is why counts are shown as "Estimated".
 */
class BrainyService : AccessibilityService() {
    private var fg = ""                       // platform key of the foreground app, or ""
    private var surfaceShort = false
    private var watching = false
    private val lastShort = HashMap<String, Long>()
    private val lastFeed = HashMap<String, Long>()
    private var offStart = 0L
    private var lockView: View? = null
    private var bubble: TextView? = null
    private val ime = HashSet<String>()
    private lateinit var wm: WindowManager

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) offStart = System.currentTimeMillis()
            else if (i.action == Intent.ACTION_SCREEN_ON) {
                if (offStart > 0) {
                    if (BrainyStore.addLockOff(this@BrainyService, System.currentTimeMillis() - offStart)) hideLock()
                    offStart = 0
                }
                refreshUi()
            }
        }
    }

    override fun onServiceConnected() {
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(InputMethodManager::class.java)?.enabledInputMethodList?.forEach { ime.add(it.packageName) }
        ContextCompat.registerReceiver(
            this, screenRx,
            IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        channels()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        runCatching { unregisterReceiver(screenRx) }
        hideAll()
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (pkg == packageName || pkg in ime || pkg == "com.android.systemui") return
            val key = BrainyStore.keyFor(pkg) ?: ""
            if (key != fg) { fg = key; surfaceShort = false; watching = false; if (key.isEmpty()) { hideAll(); return } }
            refreshUi()
            evalSurface(key, entering = true)
        } else if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val key = BrainyStore.keyFor(pkg) ?: return
            if (key != fg) { fg = key; refreshUi() }
            onScroll(key)
        }
    }

    // ---------- detection ----------
    private fun hasId(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.any { id -> root.findAccessibilityNodeInfosByViewId(id).isNotEmpty() }

    private fun hasIdContaining(root: AccessibilityNodeInfo, s: String): Boolean {
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root); var n = 0
        while (q.isNotEmpty() && n < 300) {
            val x = q.removeFirst(); n++
            if (x.viewIdResourceName?.contains(s, true) == true) return true
            for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it) }
        }
        return false
    }

    private fun isShort(key: String): Boolean {
        if (key == "tiktok") return true // the TikTok main screen is a short-video feed
        val root = rootInActiveWindow ?: return surfaceShort
        return when (key) {
            "instagram" -> hasId(root, listOf("com.instagram.android:id/clips_viewer_view_pager", "com.instagram.android:id/clips_video_container", "com.instagram.android:id/root_clips_layout"))
            "youtube" -> hasId(root, listOf("com.google.android.youtube:id/reel_recycler", "com.google.android.youtube:id/reel_player_page_container", "com.google.android.youtube:id/shorts_container"))
            "facebook" -> hasIdContaining(root, "reel")
            else -> false
        }
    }

    private fun isWatching(key: String): Boolean {
        if (key != "youtube") return false
        val root = rootInActiveWindow ?: return watching
        return hasId(root, listOf("com.google.android.youtube:id/watch_player", "com.google.android.youtube:id/watch_while_layout"))
    }

    private fun evalSurface(key: String, entering: Boolean) {
        if (key.isEmpty()) return
        val short = isShort(key)
        if (short && !surfaceShort) { surfaceShort = true; count(key, "short") } else if (!short) surfaceShort = false
        if (!short) {
            val w = isWatching(key)
            if (w && !watching) count(key, "reg")
            watching = w
        }
    }

    private fun onScroll(key: String) {
        val now = SystemClock.uptimeMillis()
        if (isShort(key)) {
            surfaceShort = true
            if (now - (lastShort[key] ?: 0L) >= 900) { lastShort[key] = now; count(key, "short") }
        } else {
            surfaceShort = false
            if (key != "tiktok" && now - (lastFeed[key] ?: 0L) >= 1500) { lastFeed[key] = now; count(key, "feed") }
        }
    }

    private fun count(key: String, kind: String) {
        val o = BrainyStore.add(this, key, kind)
        val set = BrainyStore.settings(this)
        val now = System.currentTimeMillis()
        val muted = BrainyStore.inQuiet(set) || set.optLong("snoozeUntil") > now
        if (!muted && kind == "short") {
            val sh = o.optInt("short")
            if (sh >= set.optInt("warn1", 10) && BrainyStore.once(this, "w1")) warn("First warning", "$sh short videos today", false, set)
            if (sh >= set.optInt("warn2", 20) && BrainyStore.once(this, "w2")) warn("Strong warning", "$sh short videos today. Time for a break?", true, set)
            if (sh >= set.optInt("daily", 25) && BrainyStore.once(this, "daily")) warn("Daily limit reached", "$sh short videos today", true, set)
            if (set.optBoolean("block") && BrainyStore.reelsInWindow(o, set.optInt("win", 120)) >= set.optInt("limit", 20)) BrainyStore.setLocked(this, true)
        }
        refreshUi()
    }

    // ---------- UI ----------
    private fun refreshUi() {
        if (fg.isEmpty()) { hideAll(); return }
        val set = BrainyStore.settings(this)
        val o = BrainyStore.state(this)
        val muted = BrainyStore.inQuiet(set) || set.optLong("snoozeUntil") > System.currentTimeMillis()
        if (set.optBoolean("float")) showBubble(o) else hideBubble()
        if (set.optBoolean("notif")) postStatus(o) else cancelStatus()
        if (o.optBoolean("locked") && set.optBoolean("block") && !muted) showLock() else hideLock()
    }

    private fun overlayType(): Int =
        if (Settings.canDrawOverlays(this)) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showLock() {
        if (lockView != null) return
        val dm = resources.displayMetrics
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Color.parseColor("#F2160A10")); setStroke(dp(2), Color.parseColor("#FF4D6D")) }
        }
        fun text(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        val off = BrainyStore.state(this).optLong("lockOffMs") / 1000
        box.addView(text("BRAINROT LOCK", 24f, Color.parseColor("#FF4D6D"), true))
        box.addView(text("Over your reel budget. Turn your screen off for 5 minutes to clear it.", 16f, Color.WHITE))
        box.addView(text("%d:%02d / 5:00 screen-off time".format(off / 60, off % 60), 15f, Color.parseColor("#FFC46B"), true))
        box.addView(text("Status bar, calls, Home and Recents still work. Closing the reel app hides this until you open one again.", 12f, Color.parseColor("#B8C4BF")))
        box.addView(Button(this).apply {
            text = "Close the reel app"; isAllCaps = false
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_HOME) }
        })
        val lp = WindowManager.LayoutParams(
            dm.widthPixels - dp(24), (dm.heightPixels * 0.6).toInt(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(36) }
        try { wm.addView(box, lp); lockView = box } catch (e: Exception) { lockView = null }
    }

    private fun hideLock() { lockView?.let { runCatching { wm.removeView(it) } }; lockView = null }

    private fun showBubble(o: JSONObject) {
        val label = "🧠 ${o.optInt("short")}"
        bubble?.let { it.text = label; return }
        val t = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.parseColor("#CC101B17")) }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(120) }
        try { wm.addView(t, lp); bubble = t } catch (e: Exception) { bubble = null }
    }

    private fun hideBubble() { bubble?.let { runCatching { wm.removeView(it) } }; bubble = null }
    private fun hideAll() { hideLock(); hideBubble(); cancelStatus() }

    private fun channels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Brainy status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_WARN, "Brainy warnings", NotificationManager.IMPORTANCE_DEFAULT).apply { enableVibration(false) })
    }

    private fun postStatus(o: JSONObject) {
        val n = Notification.Builder(this, CH_STATUS).setSmallIcon(R.drawable.ic_stat_bird).setContentTitle("Brainy")
            .setContentText("${o.optInt("short")} short videos · ${BrainyStore.bp(o)} BP today").setOngoing(true).setOnlyAlertOnce(true).build()
        getSystemService(NotificationManager::class.java).notify(ID_STATUS, n)
    }

    private fun cancelStatus() { getSystemService(NotificationManager::class.java).cancel(ID_STATUS) }

    private fun warn(title: String, msg: String, strong: Boolean, set: JSONObject) {
        val n = Notification.Builder(this, CH_WARN).setSmallIcon(R.drawable.ic_stat_bird).setContentTitle("Brainy · $title")
            .setContentText(msg).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(ID_WARN + (if (strong) 1 else 0), n)
        if (set.optBoolean("vib", true)) {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(if (strong) 600L else 250L, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    companion object {
        @Volatile var running = false
        const val CH_STATUS = "sandpiper_brainy_status_v1"
        const val CH_WARN = "sandpiper_brainy_warn_v1"
        const val ID_STATUS = 4040
        const val ID_WARN = 4050
    }
}
