package com.vastanzil.sandpiper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import org.json.JSONObject

object Notifier {
    const val CH_ALARM = "sandpiper_alarm_v1"
    const val CH_REMIND = "sandpiper_reminder_v1"
    const val ACTION_SNOOZE = "com.vastanzil.sandpiper.SNOOZE"
    const val ACTION_DISMISS = "com.vastanzil.sandpiper.DISMISS"
    private const val SNOOZE_MS = 10 * 60_000L

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val tone: Uri = RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val alarm = NotificationChannel(CH_ALARM, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Rings when an alarm is due"
            setSound(tone, attrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 700, 400, 700)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val remind = NotificationChannel(CH_REMIND, "Reminders and focus timer", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Reminders, task alerts and focus-session timers"
        }
        nm.createNotificationChannel(alarm)
        nm.createNotificationChannel(remind)
    }

    private fun flags() = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun show(c: Context, id: String, kind: String, title: String) {
        channels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val nid = id.hashCode()
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), flags())
        val icon = Icon.createWithResource(c, R.drawable.ic_stat_bird)

        if (kind == "alarm") {
            val ring = Intent(c, AlarmActivity::class.java)
                .putExtra("id", id).putExtra("title", title)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val full = PendingIntent.getActivity(c, nid, ring, flags())
            val snooze = action(c, ACTION_SNOOZE, id, title, nid + 1)
            val dismiss = action(c, ACTION_DISMISS, id, title, nid + 2)
            val n = Notification.Builder(c, CH_ALARM)
                .setSmallIcon(R.drawable.ic_stat_bird)
                .setContentTitle(title)
                .setContentText("Alarm")
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .setTimeoutAfter(10 * 60_000L)
                .addAction(Notification.Action.Builder(icon, "Snooze 10 min", snooze).build())
                .addAction(Notification.Action.Builder(icon, "Dismiss", dismiss).build())
                .build()
            n.flags = n.flags or Notification.FLAG_INSISTENT // keep sounding until dismissed or timed out
            nm.notify(nid, n)
        } else {
            val n = Notification.Builder(c, CH_REMIND)
                .setSmallIcon(R.drawable.ic_stat_bird)
                .setContentTitle("Sandpiper")
                .setContentText(title)
                .setStyle(Notification.BigTextStyle().bigText(title))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(nid, n)
        }
    }

    private fun action(c: Context, act: String, id: String, title: String, req: Int): PendingIntent {
        val i = Intent(c, ActionReceiver::class.java).setAction(act)
            .setData(Uri.parse("sandpiper://action/" + Uri.encode(id) + "/" + act.substringAfterLast('.')))
            .putExtra("id", id).putExtra("title", title)
        return PendingIntent.getBroadcast(c, req, i, flags())
    }

    fun dismiss(c: Context, id: String) {
        c.getSystemService(NotificationManager::class.java).cancel(id.hashCode())
    }

    fun snooze(c: Context, id: String, title: String) {
        dismiss(c, id)
        val sid = if (id.startsWith("snooze_")) id else "snooze_$id"
        Scheduler.put(
            c, JSONObject().put("id", sid).put("kind", "alarm").put("title", title)
                .put("at", System.currentTimeMillis() + SNOOZE_MS)
        )
    }
}
