package com.vastanzil.sandpiper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fires when AlarmManager triggers an alarm or reminder. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val o = Scheduler.get(c, id) ?: return
        Notifier.show(c, id, o.optString("kind"), o.optString("title", "Sandpiper"))
        if (Scheduler.isRepeating(o)) Scheduler.arm(c, o, System.currentTimeMillis() + 1000)
        else Scheduler.remove(c, id)
    }
}

/** Snooze / Dismiss buttons on the alarm notification. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val title = i.getStringExtra("title") ?: "Alarm"
        if (i.action == Notifier.ACTION_SNOOZE) Notifier.snooze(c, id, title) else Notifier.dismiss(c, id)
    }
}

/** Re-arms everything after reboot, app update, clock change or time-zone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.channels(c)
        Scheduler.rearmAll(c)
    }
}
