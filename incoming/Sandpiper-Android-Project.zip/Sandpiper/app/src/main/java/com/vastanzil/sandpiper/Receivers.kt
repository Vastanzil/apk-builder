package com.vastanzil.sandpiper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Fires when AlarmManager triggers an alarm or reminder. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val o = Scheduler.get(c, id) ?: return
        val kind = o.optString("kind")
        val title = o.optString("title", "Sandpiper")
        val tone = o.optString("tone", Tones.DEFAULT).ifBlank { Tones.DEFAULT }
        if (kind == "alarm") {
            try {
                ContextCompat.startForegroundService(
                    c, Intent(c, AlarmService::class.java).putExtra("id", id).putExtra("title", title).putExtra("tone", tone)
                )
            } catch (e: Exception) {
                Notifier.show(c, id, kind, title, tone)
            }
        } else Notifier.show(c, id, kind, title)
        if (Scheduler.isRepeating(o)) Scheduler.arm(c, o, System.currentTimeMillis() + 1000)
        else Scheduler.remove(c, id)
    }
}

/** Snooze / Dismiss buttons on the alarm notification. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val title = i.getStringExtra("title") ?: "Alarm"
        val tone = i.getStringExtra("tone") ?: Tones.DEFAULT
        if (i.action == Notifier.ACTION_SNOOZE) Notifier.snooze(c, id, title, tone) else Notifier.dismiss(c, id)
    }
}

/** Re-arms everything after reboot, app update, clock change or time-zone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.channels(c)
        Scheduler.rearmAll(c)
    }
}
