@echo off
cd /d "%~dp0"
if "%ANDROID_HOME%%ANDROID_SDK_ROOT%"=="" if not exist local.properties (
  echo Set ANDROID_HOME or create local.properties with: sdk.dir=C:\\Users\\you\\AppData\\Local\\Android\\Sdk
  exit /b 1
)
call gradlew.bat assembleDebug || exit /b 1
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
