package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

class DiagnosticsTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun ev(t: Long = 1, ev: DEv = DEv.ALARM_FIRED, res: DRes = DRes.OK, n: Long = 0, code: DCode? = null) =
        DiagEvent(t, DLvl.I, DCat.ALARM, ev, DMod.ALARMS, res, 0, n, code)

    private fun unzip(bytes: ByteArray): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) { m[e.name] = String(z.readBytes(), Charsets.UTF_8); e = z.nextEntry }
        }
        return m
    }

    private fun export(log: DiagLog, health: List<HealthItem> = emptyList(), version: String = "1.0.0"): Map<String, String> {
        val out = ByteArrayOutputStream()
        DiagExport.write(out, log, ExportInfo(version, 34, 1_700_000_000_000L), health)
        return unzip(out.toByteArray())
    }

    // ---------------------------------------------------------------- schema
    @Test fun everyEventValidatesAgainstTheSchema() {
        assertTrue(DiagSchema.isValid(ev().toJson()))
        assertTrue(DiagSchema.isValid(ev(code = DCode.E_IO, res = DRes.FAIL, n = 42).toJson()))
        for (e in DEv.values()) assertTrue(e.name, DiagSchema.isValid(ev(ev = e).toJson()))
    }

    @Test fun anythingOutsideTheSchemaIsRejected() {
        val good = ev().toJson()
        assertFalse(DiagSchema.isValid(good.replace("ALARM_FIRED", "my note about money")))
        assertFalse(DiagSchema.isValid(good.dropLast(1) + ",\"msg\":\"hello\"}"))
        assertFalse(DiagSchema.isValid(good.replace("\"code\":null", "\"code\":\"free text\"")))
        assertFalse(DiagSchema.isValid("CANARY_NOTE_7731"))
        assertFalse(DiagSchema.isValid(""))
    }

    @Test fun negativeNumbersAreClampedSoTheyStillValidate() {
        assertTrue(DiagSchema.isValid(ev(t = -5, n = -1).toJson()))
    }

    // ---------------------------------------------------------------- privacy: canary
    @Test fun canaryStringsNeverReachTheExport() {
        val canaries = listOf("CANARY_NOTE_7731", "CANARY_NAME", "CANARY_AMOUNT_98765", "https://canary.example/secret", "com.canary.private.app")
        val dir = tmp.newFolder("diag")
        val log = DiagLog(File(dir, "diag.jsonl"))
        log.attach(File(dir, "diag.jsonl"), 14L * 24 * 3600 * 1000, System.currentTimeMillis())

        // The one realistic leak vector: exceptions whose message carries user text. They are reduced to an enum by class.
        val leaky = listOf(
            RuntimeException(canaries[0] + " " + canaries[2]),
            IllegalArgumentException(canaries[1]),
            java.io.IOException(canaries[3]),
            IllegalStateException(canaries[4]),
            NumberFormatException(canaries[2])
        )
        var t = 0L
        for (x in leaky) log.log(DiagEvent(t++, DLvl.W, DCat.BACKUP, DEv.EXPORT_DONE, DMod.NOTES, DRes.FAIL, 3, 7, DiagCodes.of(x)))
        for (e in DEv.values()) log.log(ev(t = t++, ev = e))

        val health = listOf(HealthItem(DEv.CHK_PERM_NOTIFICATIONS, DMod.ALARMS, DRes.OK, 0), HealthItem(DEv.CHK_STORE_ALARMS, DMod.ALARMS, DRes.FAIL, 3))
        val files = export(log, health)

        assertEquals(setOf("manifest.json", "health.json", "log.jsonl"), files.keys)
        for ((name, text) in files) for (c in canaries) assertFalse("$name leaked $c", text.contains(c))
        files.getValue("log.jsonl").trim().lines().forEach { assertTrue(it, DiagSchema.isValid(it)) }
        assertTrue(files.getValue("health.json").contains("\"overall\":\"ERROR\""))
    }

    @Test fun exceptionsMapToEnumsByClassOnly() {
        assertEquals(DCode.E_IO, DiagCodes.of(java.io.FileNotFoundException("x")))
        assertEquals(DCode.E_SECURITY, DiagCodes.of(SecurityException("x")))
        assertEquals(DCode.E_ARG, DiagCodes.of(NumberFormatException("x")))
        assertEquals(DCode.E_STATE, DiagCodes.of(IllegalStateException("x")))
        assertEquals(DCode.E_MEMORY, DiagCodes.of(OutOfMemoryError("x")))
        assertEquals(DCode.E_UNKNOWN, DiagCodes.of(UnsupportedOperationException("x")))
        assertEquals(DCode.E_UNKNOWN, DiagCodes.of(null))
    }

    @Test fun versionStringIsSanitised() {
        val log = DiagLog()
        assertTrue(export(log, version = "1.0.0").getValue("manifest.json").contains("\"appVersion\":\"1.0.0\""))
        assertTrue(export(log, version = "1.0 \"quoted\" CANARY NAME").getValue("manifest.json").contains("\"appVersion\":\"unknown\""))
    }

    // ---------------------------------------------------------------- type safety ("lint" gate)
    private fun enumOrPrimitive(c: Class<*>) = c.isEnum || c.isPrimitive

    @Test fun loggerAcceptsOnlyEnumsAndNumbers() {
        val logFns = Diag::class.java.methods.filter { it.name == "log" }
        assertTrue("Diag.log not found", logFns.isNotEmpty())
        for (m in logFns) for (p in m.parameterTypes) assertTrue("Diag.log takes ${p.name}", enumOrPrimitive(p) || p == DCode::class.java)
        for (c in DiagEvent::class.java.constructors) for (p in c.parameterTypes) assertTrue("DiagEvent takes ${p.name}", enumOrPrimitive(p))
    }

    // ---------------------------------------------------------------- bounds
    @Test fun fileStaysBounded() {
        val f = File(tmp.newFolder("b"), "diag.jsonl")
        val log = DiagLog(f, maxFileBytes = 4_000)
        for (i in 0 until 2_000) log.log(ev(t = i.toLong()))
        assertTrue("size=${f.length()}", f.length() <= 4_000 + 300)
        assertTrue(log.lines().isNotEmpty())
        assertTrue(log.lines().all { DiagSchema.isValid(it) })
    }

    @Test fun ringIsBoundedWithoutAFile() {
        val log = DiagLog(ringSize = 10)
        for (i in 0 until 100) log.log(ev(t = i.toLong()))
        assertEquals(10, log.lines().size)
    }

    @Test fun oldLogFileIsDroppedOnAttach() {
        val f = File(tmp.newFolder("old"), "diag.jsonl")
        f.writeText(ev().toJson() + "\n")
        f.setLastModified(System.currentTimeMillis() - 20L * 24 * 3600 * 1000)
        val log = DiagLog()
        log.attach(f, 14L * 24 * 3600 * 1000, System.currentTimeMillis())
        assertEquals(0, log.lines().size)
    }

    @Test fun eventsLoggedBeforeAttachAreKept() {
        val f = File(tmp.newFolder("pre"), "diag.jsonl")
        val log = DiagLog()
        log.log(ev(t = 1)); log.log(ev(t = 2))
        log.attach(f, 14L * 24 * 3600 * 1000, System.currentTimeMillis())
        log.log(ev(t = 3))
        assertEquals(3, f.readLines().size)
    }

    @Test fun clearEmptiesRingAndFile() {
        val f = File(tmp.newFolder("c"), "diag.jsonl")
        val log = DiagLog(f)
        log.log(ev())
        log.clear()
        assertEquals(0, log.lines().size)
        assertFalse(f.exists())
    }

    // ---------------------------------------------------------------- health roll-up
    @Test fun overallState() {
        fun h(res: DRes) = listOf(HealthItem(DEv.CHK_STORE_BRAINY, DMod.BRAINY, DRes.OK, 0), HealthItem(DEv.CHK_PERM_USAGE, DMod.FITNESS, res, 0))
        assertEquals("READY", DiagExport.overall(h(DRes.OK)))
        assertEquals("READY", DiagExport.overall(h(DRes.SKIP)))
        assertEquals("LIMITED", DiagExport.overall(h(DRes.DENIED)))
        assertEquals("LIMITED", DiagExport.overall(h(DRes.UNAVAILABLE)))
        assertEquals("ERROR", DiagExport.overall(h(DRes.FAIL)))
    }
}
