package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DocChunkerTest {
    private fun noLoneSurrogates(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (Character.isHighSurrogate(c)) {
                if (i + 1 >= s.length || !Character.isLowSurrogate(s[i + 1])) return false
                i += 2
            } else if (Character.isLowSurrogate(c)) return false else i++
        }
        return true
    }

    @Test fun emptyDocumentIsOnePart() {
        assertEquals(listOf(""), DocChunker.split(""))
        assertEquals("", DocChunker.join(DocChunker.split("")))
    }

    @Test fun roundTripIsExactForEverySize() {
        val text = "ab😀cd日本語😀😀ef" + "x".repeat(50) + "🌱"
        for (size in 1..20) {
            val parts = DocChunker.split(text, size)
            assertEquals("size=$size", text, DocChunker.join(parts))
            assertTrue("size=$size", parts.all { it.isNotEmpty() })
        }
    }

    @Test fun neverCutsThroughAnEmoji() {
        val text = "😀".repeat(1000)
        for (size in listOf(1, 2, 3, 5, 7, 100, 999)) {
            for (p in DocChunker.split(text, size)) assertTrue("size=$size", noLoneSurrogates(p))
        }
    }

    @Test fun partsRespectTheSizeLimit() {
        val text = "a".repeat(1_000_000)
        val parts = DocChunker.split(text)
        assertEquals(5, parts.size)
        assertTrue(parts.all { it.length <= DocChunker.CHUNK_CHARS })
        assertEquals(text, DocChunker.join(parts))
    }

    @Test fun sha256MatchesKnownVectors() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", DocChunker.sha256("abc"))
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", DocChunker.sha256(""))
    }

    @Test fun hashDetectsAnyDamage() {
        val text = "{\"pages\":[{\"title\":\"Soil 😀\"}]}"
        val h = DocChunker.sha256(text)
        val parts = DocChunker.split(text, 4).toMutableList()
        assertEquals(h, DocChunker.sha256(DocChunker.join(parts)))
        parts[1] = parts[1] + "x"                                   // altered piece
        assertFalse(h == DocChunker.sha256(DocChunker.join(parts)))
        parts.removeAt(0)                                           // missing piece
        assertFalse(h == DocChunker.sha256(DocChunker.join(parts)))
    }
}
