package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WebReelsTest {
    private fun site(raw: String) = WebReels.classify(raw)

    @Test fun reelPathsUseTheNormalRule() {
        assertEquals(WebReels.Site("instagram", WebReels.Mode.REEL), site("https://www.instagram.com/reels/abc123/"))
        assertEquals(WebReels.Site("youtube", WebReels.Mode.REEL), site("m.youtube.com/shorts/xyz"))
        assertEquals(WebReels.Site("facebook", WebReels.Mode.REEL), site("facebook.com/reel/1"))
        assertEquals(WebReels.Site("facebook", WebReels.Mode.REEL), site("facebook.com/watch/?v=1"))
    }

    @Test fun domainOnlyAddressIsStrict() {
        assertEquals(WebReels.Site("instagram", WebReels.Mode.HOST), site("instagram.com"))
        assertEquals(WebReels.Site("youtube", WebReels.Mode.HOST), site("https://www.youtube.com/"))
    }

    @Test fun tiktokIsAlwaysReels() {
        assertEquals(WebReels.Site("tiktok", WebReels.Mode.REEL), site("tiktok.com/@someone/video/1"))
        assertEquals(WebReels.Site("tiktok", WebReels.Mode.REEL), site("www.tiktok.com"))
    }

    @Test fun otherPagesAndSearchTextAreIgnored() {
        assertNull(site("youtube.com/watch?v=abc"))
        assertNull(site("instagram.com/someprofile/"))
        assertNull(site("google.com"))
        assertNull(site("how to cook rice.fast"))   // typed text with a space is not a URL
        assertNull(site("no dots here"))
    }

    @Test fun lookAlikeDomainsDoNotMatch() {
        assertNull(site("notinstagram.com/reels/1"))
        assertNull(site("youtube.com.evil.example/shorts/1"))
    }
}
