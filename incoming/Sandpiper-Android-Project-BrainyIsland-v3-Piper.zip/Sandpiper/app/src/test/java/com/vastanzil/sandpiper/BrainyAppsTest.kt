package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BrainyAppsTest {
    @Test fun moddedAndLiteAppsMapToTheirPlatform() {
        assertEquals("youtube", BrainyApps.platformOf("app.revanced.android.youtube"))
        assertEquals("instagram", BrainyApps.platformOf("com.instagram.lite"))
        assertEquals("facebook", BrainyApps.platformOf("com.facebook.lite"))
        assertEquals("tiktok", BrainyApps.platformOf("com.ss.android.ugc.trill"))
    }

    @Test fun originalBrainyPackagesStillMap() {
        assertEquals("tiktok", BrainyStore.keyFor("com.zhiliaoapp.musically"))
        assertEquals("instagram", BrainyStore.keyFor("com.instagram.android"))
        assertEquals("facebook", BrainyStore.keyFor("com.facebook.katana"))
        assertEquals("youtube", BrainyStore.keyFor("com.google.android.youtube"))
        assertNull(BrainyStore.keyFor("com.example.unknown"))
    }

    @Test fun everyBuiltInAppHasAPlatformAndNoBrowserIsTracked() {
        BrainyApps.BUILT_IN_APPS.forEach { assertTrue(it, BrainyApps.platformOf(it) != null) }
        assertTrue(BrainyApps.BUILT_IN_APPS.none { it in BrainyApps.BROWSERS })
    }
}
