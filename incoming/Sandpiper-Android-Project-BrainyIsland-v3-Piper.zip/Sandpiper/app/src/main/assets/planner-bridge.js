/* Connects the imported planner to Android. The planner file itself is untouched:
   this script only (a) schedules its reminders with Android's AlarmManager so they fire when the app is closed,
   and (b) makes its "Notify me" button request the Android notification permission. */
(function(){
  var N=window.SandpiperNative||(window.parent&&window.parent!==window&&window.parent.SandpiperNative)||null;
  if(!N)return;
  var KEY='sandpiper_reminders',IDS='sp_native_ids',orig=Storage.prototype.setItem;
  function call(f){try{var a=[].slice.call(arguments,1);return N[f]?N[f].apply(N,a):null}catch(e){return null}}
  function sync(){
    var items=[],prev=[];
    try{items=JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){}
    try{prev=JSON.parse(localStorage.getItem(IDS)||'[]')}catch(e){}
    if(!Array.isArray(items))items=[];if(!Array.isArray(prev))prev=[];
    var want={};
    items.forEach(function(it){
      if(!it||it.done||!it.date||!it.id)return;
      var t=(it.time||'09:00').split(':'),id='pl_'+it.id;want[id]=1;
      call('schedule',JSON.stringify({id:id,kind:'reminder',title:String(it.title||'Reminder'),date:it.date,h:+t[0]||0,m:+t[1]||0,repeat:'none'}));
    });
    prev.forEach(function(id){if(!want[id])call('cancel',id)});
    try{orig.call(localStorage,IDS,JSON.stringify(Object.keys(want)))}catch(e){}
  }
  Storage.prototype.setItem=function(k){var r=orig.apply(this,arguments);if(k===KEY)sync();return r};
  function ui(){
    var b=document.getElementById('cm-notify');if(!b)return;
    var upd=function(){b.textContent=call('notifEnabled')?'Notify me ✓':'Notify me'};
    upd();b.onclick=function(){call('requestNotif');setTimeout(upd,1200);setTimeout(upd,4000)};
    var n=document.querySelector('.cm-note');
    if(n)n.textContent='Reminders are saved on this device and delivered by Android, even when Sandpiper is closed.';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){ui();sync()});else{ui();sync()}
})();

/* ---- Close the Day -> Sandpiper Day Hub ----
   Wraps the planner's own resolve() (called by the Close the Day button). The planner file is not edited.
   1. Captures what the planner had that day (tasks, weights, points, streak).
   2. Asks the host to drain the open Fitness ports (daily reports, stars) and record Zen + Planner + Fitness data.
   3. Banks the host's bonus points (Fitness stars, focus sessions) into the planner's own points total. */
(function(){
  var hub=null;try{hub=window.parent&&window.parent!==window?window.parent.SpHub:null}catch(e){}
  if(!hub||typeof window.resolve!=='function')return;
  var orig=window.resolve;
  window.resolve=function(kind){
    var snap=null;
    try{
      var done=tasks.filter(function(t){return t.n}).map(function(t){return{n:String(t.n),w:t.w|0,done:!!t.done,tree:!!t.id}});
      snap={kind:kind,pointsDone:pts(),pointsPlanned:denom(),tasks:done};
    }catch(e){}
    var out=orig.apply(this,arguments);
    try{
      if(snap){
        snap.streak=S.streak;snap.stars=S.stars.length;snap.day=S.day;snap.mastered=S.mast?S.mast.size:0;
        var res=hub.closeDay(snap);
        if(res&&res.bonus>0){S.pts+=res.bonus;hud()}
        if(res&&res.message)setTimeout(function(){toast(res.message)},3600);
        snap.pointsTotal=S.pts;
      }
    }catch(e){}
    return out;
  };
})();
