package com.vastanzil.sandpiper

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** In-memory ring buffer (package short-name + numbers only, never persisted) for the Diagnostics screen. */
internal object BrainyDiag {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized fun add(text: String) {
        lines.addLast(fmt.format(Date()) + "  " + text)
        while (lines.size > 200) lines.removeFirst()
    }
    @Synchronized fun dump(): String = lines.joinToString("\n")
    @Synchronized fun clear() = lines.clear()
}
