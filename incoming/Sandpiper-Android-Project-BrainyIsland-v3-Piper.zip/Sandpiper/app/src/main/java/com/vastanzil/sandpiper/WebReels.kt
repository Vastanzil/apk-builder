package com.vastanzil.sandpiper

/**
 * Recognises Instagram / YouTube / Facebook / TikTok web pages from the browser address-bar text
 * (ported from Reel Counter's `classifyUrl`). Pure Kotlin, JVM unit-tested.
 *
 *  - [Mode.REEL] : the visible address is a reel / short page, so the normal swipe rule applies
 *  - [Mode.HOST] : only the domain is visible (Chrome hides the path), so the strict near-exact page-swipe rule applies
 *  - no site     : anything else; events are dropped
 */
internal object WebReels {
    enum class Mode { HOST, REEL }

    /** [key] is the Brainy platform key. */
    data class Site(val key: String, val mode: Mode)

    fun classify(raw: String): Site? {
        val u = raw.trim().lowercase().removePrefix("https://").removePrefix("http://")
        if (!u.contains('.') || u.contains(' ')) return null            // typed search text, not a URL
        val host = u.substringBefore('/').removePrefix("www.").removePrefix("m.").removePrefix("mobile.")
        val path = u.substringAfter('/', "").trimStart('/')

        fun on(domain: String) = host == domain || host.endsWith(".$domain")
        fun site(key: String, reel: Boolean): Site? =
            if (path.isEmpty()) Site(key, Mode.HOST) else if (reel) Site(key, Mode.REEL) else null

        return when {
            on("instagram.com") -> site("instagram", path.startsWith("reel"))
            on("youtube.com") -> site("youtube", path.startsWith("shorts"))
            on("facebook.com") || host == "fb.watch" -> site("facebook", path.startsWith("reel") || path.startsWith("watch"))
            on("tiktok.com") -> Site("tiktok", Mode.REEL)
            else -> null
        }
    }
}
