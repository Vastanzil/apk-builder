package com.vastanzil.sandpiper

import android.content.Context

enum class IslandStyle(val label: String) {
    AUTO("Automatic"),
    ISLAND("Camera island"),
    STATUS_BAR("Status bar band"),
    FLOAT("Floating pill")
}

enum class IslandLook(val label: String) {
    DARK_GLASS("Liquid Glass – Dark"),
    SKY_GLASS("Liquid Glass – Sky"),
    CLASSIC("Solid Black")
}

/**
 * Brainy Island settings (ported from Reel Counter's CounterStore). Stored in their own preferences file so the
 * Fitness page's settings and Brainy's daily state (BrainyStore) are untouched.
 *
 * The number on the island is NOT stored here: it is Brainy's "short videos today", so the island, the
 * Fitness > Mental tab, warnings and the focus lock always agree.
 * Every setter tells a running [BrainyService] to re-apply; [setDebug] deliberately does not (the overlay calls it).
 */
internal object IslandStore {
    private const val PREFS = "sp_brainy_island"
    private const val KEY_TRACKING = "tracking"
    private const val KEY_ALWAYS = "always"
    private const val KEY_STYLE = "style"
    private const val KEY_BROWSER = "browser"
    private const val KEY_GAP = "gap"
    private const val KEY_LOOK = "look"
    private const val KEY_CHOSEN = "chosen_apps"
    private const val KEY_DEBUG = "debug"

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun changed() { BrainyService.instance?.onIslandSettingsChanged() }

    /** Today's reel count, from Brainy. */
    fun count(c: Context): Int = BrainyStore.state(c).optInt("short")

    /** Master pause: when false Brainy stops counting (Reel Counter's Start / Pause tracking). Default on. */
    fun tracking(c: Context): Boolean = prefs(c).getBoolean(KEY_TRACKING, true)
    fun setTracking(c: Context, on: Boolean) { prefs(c).edit().putBoolean(KEY_TRACKING, on).apply(); changed() }

    /** false = island only while a tracked app is in front (default, matches "Floating Brainy: over supported apps"); true = always. */
    fun islandAlways(c: Context): Boolean = prefs(c).getBoolean(KEY_ALWAYS, false)
    fun setIslandAlways(c: Context, on: Boolean) { prefs(c).edit().putBoolean(KEY_ALWAYS, on).apply(); changed() }

    fun style(c: Context): IslandStyle =
        runCatching { IslandStyle.valueOf(prefs(c).getString(KEY_STYLE, null) ?: "AUTO") }.getOrDefault(IslandStyle.AUTO)
    fun setStyle(c: Context, s: IslandStyle) { prefs(c).edit().putString(KEY_STYLE, s.name).apply(); changed() }

    fun look(c: Context): IslandLook =
        runCatching { IslandLook.valueOf(prefs(c).getString(KEY_LOOK, null) ?: "DARK_GLASS") }.getOrDefault(IslandLook.DARK_GLASS)
    fun setLook(c: Context, l: IslandLook) { prefs(c).edit().putString(KEY_LOOK, l.name).apply(); changed() }

    /** Extra dp of black either side of the camera hole: 0 compact, 1 standard, 2 wide, 3 extra wide. */
    fun gapLevel(c: Context): Int = prefs(c).getInt(KEY_GAP, 2).coerceIn(0, 3)
    fun gapExtraDp(c: Context): Int = intArrayOf(8, 18, 30, 44)[gapLevel(c)]
    fun setGapLevel(c: Context, l: Int) { prefs(c).edit().putInt(KEY_GAP, l.coerceIn(0, 3)).apply(); changed() }

    /**
     * Web reels in browsers. Off by default in Sandpiper: it is the only feature that reads on-screen text
     * (the address bar), so it is opt-in and explained before it is switched on.
     */
    fun browserSupport(c: Context): Boolean = prefs(c).getBoolean(KEY_BROWSER, false)
    fun setBrowserSupport(c: Context, on: Boolean) { prefs(c).edit().putBoolean(KEY_BROWSER, on).apply(); changed() }

    /** Apps picked from the installed-apps list (null = never chosen -> built-in defaults). */
    fun chosenApps(c: Context): Set<String>? =
        prefs(c).getString(KEY_CHOSEN, null)?.split('\n')?.map { it.trim() }?.filter { it.isNotEmpty() }?.toSet()
    fun setChosenApps(c: Context, apps: Set<String>) { prefs(c).edit().putString(KEY_CHOSEN, apps.joinToString("\n")).apply(); changed() }
    fun monitoredApps(c: Context): Set<String> = chosenApps(c) ?: BrainyApps.BUILT_IN_APPS

    /** Last camera / layout diagnosis written by the overlay, shown in settings. */
    fun debug(c: Context): String = prefs(c).getString(KEY_DEBUG, "") ?: ""
    fun setDebug(c: Context, text: String) { prefs(c).edit().putString(KEY_DEBUG, text).apply() }
}
