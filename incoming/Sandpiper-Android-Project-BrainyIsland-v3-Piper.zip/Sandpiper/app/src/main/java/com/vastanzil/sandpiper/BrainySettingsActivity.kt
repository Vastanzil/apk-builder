package com.vastanzil.sandpiper

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Brainy Island settings: the Reel Counter app's controls, inside Sandpiper.
 * Opened from the Zen Garden "Brainy Island" card (SandpiperNative.openBrainySettings()).
 * The Fitness > Mental tab keeps the Brainy settings it already had (floating counter on/off, warnings, budget, lock...);
 * this screen holds everything that is specific to how reels are detected and how the island looks.
 */
class BrainySettingsActivity : AppCompatActivity() {
    private lateinit var countLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var cameraLabel: TextView
    private lateinit var trackButton: Button
    private lateinit var styleButton: Button
    private lateinit var lookButton: Button
    private lateinit var gapButton: Button
    private lateinit var visibilityButton: Button
    private lateinit var browserButton: Button
    private lateinit var appsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = FOREST; window.navigationBarColor = FOREST
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::countLabel.isInitialized) refreshUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24)); setBackgroundColor(FOREST)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        content.addView(label("🧠  Brainy Island", 27f, WARM_WHITE, Gravity.CENTER, top = 12, bottom = 4))
        content.addView(label("How Brainy counts your reels and how the counter looks.", 14f, MINT, Gravity.CENTER, bottom = 20))
        countLabel = label("", 44f, WARM_WHITE, Gravity.CENTER, top = 8, bottom = 0).also { content.addView(it) }
        content.addView(label("reels today", 13f, SAGE, Gravity.CENTER, bottom = 8))
        statusLabel = label("", 13f, MINT, Gravity.CENTER, bottom = 8).also { content.addView(it) }
        cameraLabel = label("", 11f, SAGE, Gravity.CENTER, bottom = 16).also { content.addView(it) }

        content.addView(button("Set up swipe detection") { showDisclosure() })
        if (Build.VERSION.SDK_INT >= 33) content.addView(button("Unlock restricted settings") { openAppInfo() })
        trackButton = button("") { toggleTracking() }.also { content.addView(it) }
        content.addView(button("Reset today's reel count") { confirmReset() })
        styleButton = button("") { cycleStyle() }.also { content.addView(it) }
        lookButton = button("") {
            val all = IslandLook.values()
            IslandStore.setLook(this, all[(IslandStore.look(this).ordinal + 1) % all.size]); refreshUi()
        }.also { content.addView(it) }
        gapButton = button("") { IslandStore.setGapLevel(this, (IslandStore.gapLevel(this) + 1) % 4); refreshUi() }.also { content.addView(it) }
        visibilityButton = button("") { IslandStore.setIslandAlways(this, !IslandStore.islandAlways(this)); refreshUi() }.also { content.addView(it) }
        content.addView(button("Preview animation") { preview() })
        browserButton = button("") { toggleBrowser() }.also { content.addView(it) }
        appsButton = button("") { startActivity(Intent(this, BrainyAppPickerActivity::class.java)) }.also { content.addView(it) }
        content.addView(button("Diagnostics") { showDiagnostics() })

        content.addView(label(
            "A reel is counted only after a full-page vertical swipe has settled. Taps, partial drags, horizontal carousels and " +
                "swiping back over a reel you already counted are ignored. Android has no official per-reel signal, so this is a close estimate.\n\n" +
                "The number is the same “short videos today” you see in Fitness > Mental, and it drives your warnings, daily limit and focus lock. " +
                "The Floating Brainy switch in Fitness > Mental still turns the island on or off; warnings, budget and lock are set there too.\n\n" +
                "Play Protect blocked the install? Tap More details > Install anyway. You do not need to turn Play Protect off.",
            12f, SAGE, Gravity.START, top = 20, bottom = 12))
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        refreshUi()
    }

    // ---------------------------------------------------------------- actions
    private fun toggleTracking() {
        if (!IslandStore.tracking(this)) {
            if (!isServiceEnabled()) { showDisclosure(); return }
            IslandStore.setTracking(this, true)
        } else IslandStore.setTracking(this, false)
        refreshUi()
    }

    private fun cycleStyle() {
        val all = IslandStyle.values()
        IslandStore.setStyle(this, all[(IslandStore.style(this).ordinal + 1) % all.size]); refreshUi()
    }

    private fun preview() {
        val s = BrainyService.instance
        if (s == null) Toast.makeText(this, "Turn on Sandpiper Brainy in Accessibility first", Toast.LENGTH_SHORT).show() else s.previewIsland()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset today's reel count?")
            .setMessage("Today's reel count goes back to 0. This also restarts today's reel warnings, the reel budget window and clears an active focus lock. Feed items and regular videos are kept.")
            .setPositiveButton("Reset") { _, _ -> BrainyStore.resetReels(this); BrainyService.instance?.onIslandSettingsChanged(); refreshUi() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleBrowser() {
        if (IslandStore.browserSupport(this)) { IslandStore.setBrowserSupport(this, false); refreshUi(); return }
        AlertDialog.Builder(this)
            .setTitle("Count web reels in browsers?")
            .setMessage("Brainy will read ONLY the browser's address bar to tell whether you are on Instagram, YouTube, Facebook or TikTok. " +
                "It is held in memory to recognise the site and is never stored or sent anywhere. Nothing else on the page is read.\n\n" +
                "Chrome shows only the domain, so on those sites it uses a stricter full-page swipe rule and normal scrolling can occasionally count.")
            .setPositiveButton("Turn on") { _, _ -> IslandStore.setBrowserSupport(this, true); refreshUi() }
            .setNegativeButton("Not now", null)
            .show()
    }

    private fun showDiagnostics() {
        val body = BrainyDiag.dump().ifEmpty { "No scroll events seen yet.\nTurn tracking on, scroll in a tracked app, then open this screen again." }
        val tv = TextView(this).apply {
            text = body; textSize = 11f; typeface = Typeface.MONOSPACE
            setPadding(dp(16), dp(8), dp(16), dp(8)); setTextIsSelectable(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Diagnostics")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Brainy diagnostics", BrainyDiag.dump()))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Clear") { _, _ -> BrainyDiag.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    /** Prominent disclosure (shown before sending the user to Accessibility settings). */
    private fun showDisclosure() {
        AlertDialog.Builder(this)
            .setTitle("Allow swipe detection?")
            .setMessage("Sandpiper Brainy uses Android Accessibility only to notice vertical swipes in the apps you track (Instagram, Facebook, YouTube and TikTok by default) and to draw the counter island at the top of the screen.\n\n" +
                "It does not read messages, passwords or other screen content, record video, or send any data anywhere. Everything stays on this phone. " +
                "If you switch on Web reels in browsers, it also reads only the browser address bar.\n\nOn the next screen, open Sandpiper Brainy and switch it on.")
            .setPositiveButton("Agree and continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Not now", null)
            .show()
    }

    /** Android 13+: apps installed outside a store have "restricted settings" until allowed here. */
    private fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        statusLabel.text = "Tap the ⋮ menu (top right) > Allow restricted settings, then go back and enable Sandpiper Brainy."
    }

    private fun isServiceEnabled(): Boolean {
        val cn = ComponentName(this, BrainyService::class.java)
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    private fun refreshUi() {
        countLabel.text = "🧠  ${IslandStore.count(this)}"
        cameraLabel.text = IslandStore.debug(this)
        trackButton.text = "Tracking: " + if (IslandStore.tracking(this)) "On (tap to pause)" else "Paused (tap to resume)"
        appsButton.text = "Tracked apps (${IslandStore.monitoredApps(this).size})"
        lookButton.text = "Appearance: ${IslandStore.look(this).label}"
        gapButton.text = "Cutout spacing: " + listOf("Compact", "Standard", "Wide", "Extra wide")[IslandStore.gapLevel(this)]
        visibilityButton.text = "Show island: " + if (IslandStore.islandAlways(this)) "Always" else "Over tracked apps"
        browserButton.text = "Web reels in browsers: " + if (IslandStore.browserSupport(this)) "On" else "Off"
        styleButton.text = "Display mode: ${IslandStore.style(this).label}"
        statusLabel.text = when {
            !isServiceEnabled() -> "Swipe detection is off. Tap “Set up swipe detection”."
            !IslandStore.tracking(this) -> "Tracking paused"
            else -> "Tracking active"
        }
    }

    // ---------------------------------------------------------------- small UI helpers
    private fun label(text: String, size: Float, color: Int, gravity: Int, top: Int = 0, bottom: Int = 0) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); this.gravity = gravity; setPadding(0, dp(top), 0, dp(bottom))
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(WARM_WHITE)
        backgroundTintList = ColorStateList.valueOf(BUTTON)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(10) }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private companion object {
        val FOREST = Color.rgb(0x10, 0x1B, 0x17)      // @color/forest
        const val MINT = 0xFFB9D9C4.toInt()           // @color/mint
        const val SAGE = 0xFF708F7D.toInt()           // @color/sage
        const val WARM_WHITE = 0xFFE9EEE8.toInt()     // @color/warm_white
        const val BUTTON = 0xFF2E5A45.toInt()
    }
}
