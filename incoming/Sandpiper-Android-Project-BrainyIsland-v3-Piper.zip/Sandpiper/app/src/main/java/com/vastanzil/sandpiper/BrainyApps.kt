package com.vastanzil.sandpiper

/**
 * Apps and browsers Brainy knows about (ported from Reel Counter).
 * [BUILT_IN_APPS] is the default tracked list until the user picks their own in Brainy Island settings.
 */
internal object BrainyApps {
    /** YouTube (+Vanced/ReVanced), Instagram (+Lite/Instander), Facebook (+Lite), TikTok variants. */
    val BUILT_IN_APPS: Set<String> = setOf(
        "com.google.android.youtube", "com.vanced.android.youtube", "app.revanced.android.youtube", "app.rvx.android.youtube",
        "com.instagram.android", "com.instagram.lite", "com.instander.android",
        "com.facebook.katana", "com.facebook.lite",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go", "com.ss.android.ugc.aweme"
    )

    val BROWSERS: Set<String> = setOf(
        "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary", "org.chromium.chrome",
        "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix", "org.mozilla.focus",
        "com.brave.browser", "com.brave.browser_beta", "com.microsoft.emmx", "com.sec.android.app.sbrowser",
        "com.opera.browser", "com.opera.mini.native", "com.opera.gx", "com.duckduckgo.mobile.android",
        "com.vivaldi.browser", "com.kiwibrowser.browser", "com.mi.globalbrowser", "mark.via.gp"
    )

    /** View-ID names of browser address bars (the only thing read in a browser, and only when Web reels is on). */
    val URL_IDS: List<String> = listOf(
        "url_bar", "url_field", "location_bar_edit_text", "mozac_browser_toolbar_url_view",
        "url_bar_title", "omnibarTextInput", "display_url", "url_edit_text", "url"
    )

    private val PLATFORM: Map<String, String> = mapOf(
        "com.google.android.youtube" to "youtube", "com.vanced.android.youtube" to "youtube",
        "app.revanced.android.youtube" to "youtube", "app.rvx.android.youtube" to "youtube",
        "com.instagram.android" to "instagram", "com.instagram.lite" to "instagram", "com.instander.android" to "instagram",
        "com.facebook.katana" to "facebook", "com.facebook.lite" to "facebook",
        "com.zhiliaoapp.musically" to "tiktok", "com.ss.android.ugc.trill" to "tiktok",
        "com.zhiliaoapp.musically.go" to "tiktok", "com.ss.android.ugc.aweme" to "tiktok"
    )

    /** Brainy platform key (tiktok / instagram / facebook / youtube) for a package, or null if it is not one of those. */
    fun platformOf(pkg: String): String? = PLATFORM[pkg]
}
