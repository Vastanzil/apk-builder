package com.vastanzil.sandpiper

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONObject
import java.util.Calendar

/**
 * Stores alarms/reminders in SharedPreferences and arms them with AlarmManager.
 * Times are recomputed from local wall-clock values (hour, minute, weekday, date),
 * so reboot, time-zone and clock changes are handled by re-arming everything.
 */
object Scheduler {
    private const val PREFS = "sp_items"
    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun put(c: Context, o: JSONObject) {
        prefs(c).edit().putString(o.getString("id"), o.toString()).apply()
        arm(c, o, System.currentTimeMillis())
    }

    fun remove(c: Context, id: String) {
        disarm(c, id)
        prefs(c).edit().remove(id).apply()
    }

    fun get(c: Context, id: String): JSONObject? =
        prefs(c).getString(id, null)?.let { runCatching { JSONObject(it) }.getOrNull() }

    /** Re-arms every stored item (idempotent: the same PendingIntent is replaced, never duplicated). Returns how many succeeded. */
    fun rearmAll(c: Context): Int {
        val now = System.currentTimeMillis()
        var ok = 0
        for (v in prefs(c).all.values.toList()) {
            if (runCatching { arm(c, JSONObject(v as String), now) }.isSuccess) ok++
        }
        return ok
    }

    /**
     * For the self-test: [stored items, unreadable items, items that should be armed but have no PendingIntent].
     * Only counts leave this function, never item content.
     */
    fun health(c: Context): IntArray {
        val now = System.currentTimeMillis()
        var total = 0
        var bad = 0
        var unarmed = 0
        for ((id, v) in prefs(c).all) {
            total++
            val o = runCatching { JSONObject(v as String) }.getOrNull()
            if (o == null) { bad++; continue }
            val due = runCatching { nextTime(o, now) }.getOrNull()
            if (due != null && !isArmed(c, id)) unarmed++
        }
        return intArrayOf(total, bad, unarmed)
    }

    /** True if Android still holds our PendingIntent for [id] (it is dropped by force-stop). Necessary, not sufficient, for "armed". */
    fun isArmed(c: Context, id: String): Boolean =
        PendingIntent.getBroadcast(c, id.hashCode(), fireIntent(c, id), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) != null

    /** Next trigger time in epoch millis after [now], or null if there is none. */
    fun nextTime(o: JSONObject, now: Long): Long? {
        val at = o.optLong("at", 0L)
        if (at > 0L) return if (at > now) at else null
        val h = o.optInt("h")
        val m = o.optInt("m")

        if (o.optString("kind") == "alarm") {
            val days = HashSet<Int>()
            o.optJSONArray("days")?.let { a -> for (i in 0 until a.length()) days.add(a.getInt(i)) }
            for (i in 0..7) {
                val c = Calendar.getInstance()
                c.timeInMillis = now
                c.add(Calendar.DAY_OF_YEAR, i)
                c.set(Calendar.HOUR_OF_DAY, h)
                c.set(Calendar.MINUTE, m)
                c.set(Calendar.SECOND, 0)
                c.set(Calendar.MILLISECOND, 0)
                if (c.timeInMillis > now && (days.isEmpty() || days.contains(c.get(Calendar.DAY_OF_WEEK)))) {
                    return c.timeInMillis
                }
            }
            return null
        }

        val parts = o.optString("date").split("-")
        if (parts.size != 3) return null
        val c = Calendar.getInstance()
        c.clear()
        c.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt(), h, m, 0)
        val repeat = o.optString("repeat", "none")
        val anchor = o.optInt("day", parts[2].toInt()).let { if (it <= 0) parts[2].toInt() else it }
        var guard = 0
        while (c.timeInMillis <= now) {
            if (repeat == "none" || guard++ > 4000) return null
            when (repeat) {
                "daily" -> c.add(Calendar.DAY_OF_YEAR, 1)
                "weekly" -> c.add(Calendar.DAY_OF_YEAR, 7)
                "monthly" -> {
                    c.set(Calendar.DAY_OF_MONTH, 1)
                    c.add(Calendar.MONTH, 1)
                    c.set(Calendar.DAY_OF_MONTH, minOf(anchor, c.getActualMaximum(Calendar.DAY_OF_MONTH)))
                }
                else -> return null
            }
        }
        return c.timeInMillis
    }

    fun isRepeating(o: JSONObject): Boolean {
        if (o.optLong("at", 0L) > 0L) return false
        return if (o.optString("kind") == "alarm") (o.optJSONArray("days")?.length() ?: 0) > 0
        else o.optString("repeat", "none") != "none"
    }

    fun arm(c: Context, o: JSONObject, now: Long) {
        Diag.init(c)
        val id = o.getString("id")
        val t = nextTime(o, now)
        if (t == null) {
            Diag.log(DLvl.I, DCat.ALARM, DEv.ALARM_EXPIRED, DMod.ALARMS, DRes.SKIP)
            remove(c, id)
            return
        }
        val am = c.getSystemService(AlarmManager::class.java)
        try {
            if (o.optString("kind") == "alarm") {
                val show = PendingIntent.getActivity(
                    c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi(c, id))
            } else if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, id))
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, id))
            }
        } catch (e: SecurityException) {
            Diag.log(DLvl.W, DCat.ALARM, DEv.ALARM_FALLBACK, DMod.ALARMS, DRes.DENIED, code = DCode.E_SECURITY)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, id))
        }
        Diag.log(DLvl.I, DCat.ALARM, DEv.ALARM_ARMED, DMod.ALARMS)
    }

    private fun disarm(c: Context, id: String) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id))
    }

    private fun fireIntent(c: Context, id: String): Intent =
        Intent(c, AlarmReceiver::class.java)
            .setAction("com.vastanzil.sandpiper.FIRE")
            .setData(Uri.parse("sandpiper://item/" + Uri.encode(id)))
            .putExtra("id", id)

    private fun pi(c: Context, id: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, id.hashCode(), fireIntent(c, id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
