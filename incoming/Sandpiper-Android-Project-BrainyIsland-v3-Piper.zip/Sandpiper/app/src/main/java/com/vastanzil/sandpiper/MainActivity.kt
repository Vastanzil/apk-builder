package com.vastanzil.sandpiper

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var pendingMic: PermissionRequest? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        pendingMic?.let { r ->
            if (res[Manifest.permission.RECORD_AUDIO] == true) r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else r.deny()
            pendingMic = null
        }
        js("window.onNativePermission&&onNativePermission()")
    }

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    private var toneKind = ""
    private val toneLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        onToneResult(r.resultCode, r.data)
    }

    private fun pushTone(o: JSONObject) = js("window.onToneChosen&&onToneChosen(" + JSONObject.quote(o.toString()) + ")")

    fun pickTone(kind: String) = runOnUiThread {
        toneKind = kind
        val i = if (kind == "system") Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose alarm tone")
        else Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
        try { toneLauncher.launch(i) } catch (e: Exception) { pushTone(JSONObject().put("error", "No picker available on this phone.")) }
    }

    @Suppress("DEPRECATION")
    private fun onToneResult(code: Int, data: Intent?) {
        if (code != RESULT_OK || data == null) { pushTone(JSONObject().put("cancel", true)); return }
        if (toneKind == "system") {
            val u: Uri? = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (u == null) { pushTone(JSONObject().put("cancel", true)); return }
            val name = runCatching { RingtoneManager.getRingtone(this, u)?.getTitle(this) }.getOrNull() ?: "Phone tone"
            pushTone(JSONObject().put("tone", "uri:$u").put("name", name))
        } else {
            val u = data.data
            if (u == null) { pushTone(JSONObject().put("cancel", true)); return }
            Thread {
                try {
                    val name = contentResolver.query(u, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        if (c.moveToFirst() && i >= 0) c.getString(i) else null
                    } ?: "My music"
                    val dir = File(filesDir, "tones").apply { mkdirs() }
                    val ext = name.substringAfterLast('.', "audio").filter { it.isLetterOrDigit() }.take(5).ifBlank { "audio" }
                    val out = File(dir, "tone_${System.currentTimeMillis()}.$ext")
                    var total = 0L
                    contentResolver.openInputStream(u)!!.use { inp ->
                        out.outputStream().use { o ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                total += n
                                require(total <= 30L * 1024 * 1024) { "too large" }
                                o.write(buf, 0, n)
                            }
                        }
                    }
                    // make sure Android can actually decode it
                    val mp = android.media.MediaPlayer()
                    try { mp.setDataSource(out.absolutePath); mp.prepare() } finally { mp.release() }
                    pushTone(JSONObject().put("tone", "file:" + out.absolutePath).put("name", name.substringBeforeLast('.')))
                } catch (e: Exception) {
                    pushTone(JSONObject().put("error", "Could not use that audio file (max 30 MB, must be a playable audio format)."))
                }
            }.start()
        }
    }

    /** Re-arms stored alarms/reminders on every cold start (Android drops them on force-stop). Idempotent; off the main thread. */
    private fun reconcileAlarms() {
        val app = applicationContext
        Thread {
            val t = System.nanoTime()
            try {
                val n = Scheduler.rearmAll(app)
                Diag.log(DLvl.I, DCat.ALARM, DEv.ALARMS_RECONCILED, DMod.ALARMS, DRes.OK, (System.nanoTime() - t) / 1_000_000L, n.toLong())
            } catch (e: Exception) {
                Diag.log(DLvl.W, DCat.ALARM, DEv.ALARMS_RECONCILED, DMod.ALARMS, DRes.FAIL, code = Diag.codeOf(e))
            }
        }.start()
    }

    /** Shows a JS alert (confirmable=false) or confirm (confirmable=true) natively. Always answers the JsResult exactly once. */
    private fun jsDialog(message: String?, result: JsResult, confirmable: Boolean): Boolean {
        runOnUiThread {
            try {
                val b = AlertDialog.Builder(this)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                if (confirmable) b.setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                b.show()
            } catch (e: Exception) { result.cancel() }
        }
        return true
    }

    fun askPermissions(p: Array<String>) = runOnUiThread { permLauncher.launch(p) }
    fun js(code: String) = runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.channels(this)
        Diag.init(applicationContext)
        Diag.log(DLvl.I, DCat.STARTUP, DEv.MAIN_CREATED, DMod.APP)
        if (savedInstanceState == null) reconcileAlarms()
        androidx.work.WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "sp_steps", androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            androidx.work.PeriodicWorkRequestBuilder<StepWorker>(15, java.util.concurrent.TimeUnit.MINUTES).build()
        )

        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(0xFF101B17.toInt())

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true // localStorage + IndexedDB for app data and voice notes
            allowFileAccess = false
            allowContentAccess = false
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                val scheme = request.url.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) {
                runOnUiThread {
                    val audioOnly = r.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (r.origin.host != HOST || !audioOnly) { r.deny(); return@runOnUiThread }
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED
                    ) r.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    else { pendingMic = r; permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
                }
            }

            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { fileLauncher.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }

            // Native dialogs for JS alert/confirm/prompt (Piper Pro uses them for delete, rename and restore prompts).
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean =
                jsDialog(message, result, false)

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean =
                jsDialog(message, result, true)

            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                runOnUiThread {
                    try {
                        val input = EditText(this@MainActivity)
                        input.setText(defaultValue ?: "")
                        input.setSelectAllOnFocus(true)
                        input.setSingleLine()
                        AlertDialog.Builder(this@MainActivity)
                            .setMessage(message ?: "")
                            .setView(input)
                            .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                            .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                            .setOnCancelListener { result.cancel() }
                            .show()
                    } catch (e: Exception) { result.cancel() }
                }
                return true
            }
        }

        web.addJavascriptInterface(Bridge(this), "SandpiperNative")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.sandpiperBack?sandpiperBack():false") { if (it != "true") finish() }
            }
        })

        if (savedInstanceState == null) web.loadUrl("https://$HOST/assets/index.html")
        else web.restoreState(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        js("window.onNativePermission&&onNativePermission()") // refresh permission state after returning from Settings
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("SandpiperNative")
        super.onDestroy()
    }

    companion object { const val HOST = "appassets.androidplatform.net" }
}
