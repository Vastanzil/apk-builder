package com.vastanzil.sandpiper

import java.security.MessageDigest

/**
 * Splits a large JSON document into pieces that each fit comfortably inside an Android CursorWindow (2 MB), and
 * hashes it so a read can prove it got back exactly what was written. Pure Kotlin: JVM unit-tested.
 */
object DocChunker {
    const val CHUNK_CHARS = 200_000   // <= ~800 KB as UTF-8, well under the 2 MB cursor window

    /** Never cuts through a surrogate pair (an emoji would otherwise be corrupted). Always returns at least one part. */
    fun split(s: String, size: Int = CHUNK_CHARS): List<String> {
        if (s.isEmpty()) return listOf("")
        val step = if (size < 2) 2 else size
        val out = ArrayList<String>()
        var i = 0
        while (i < s.length) {
            var end = minOf(s.length, i + step)
            if (end < s.length && Character.isLowSurrogate(s[end]) && Character.isHighSurrogate(s[end - 1])) end--
            out.add(s.substring(i, end))
            i = end
        }
        return out
    }

    fun join(parts: List<String>): String = parts.joinToString("")

    fun sha256(bytes: ByteArray): String {
        val d = MessageDigest.getInstance("SHA-256").digest(bytes)
        val sb = StringBuilder(d.size * 2)
        for (b in d) {
            val v = b.toInt() and 0xff
            sb.append("0123456789abcdef"[v ushr 4]).append("0123456789abcdef"[v and 0x0f])
        }
        return sb.toString()
    }

    fun sha256(s: String): String = sha256(s.toByteArray(Charsets.UTF_8))
}
