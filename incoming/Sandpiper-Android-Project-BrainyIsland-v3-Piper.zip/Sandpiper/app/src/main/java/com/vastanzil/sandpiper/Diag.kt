package com.vastanzil.sandpiper

import android.Manifest
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.OutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Android side of the diagnostics pipeline (see DiagCore.kt for the rules).
 *
 * Usage: Diag.log(DLvl.I, DCat.ALARM, DEv.ALARM_FIRED, DMod.ALARMS). The signature has no String parameter on purpose.
 * Logging is asynchronous (one background thread), works before [init] (memory only), and never throws.
 */
object Diag {
    private val t0 = System.nanoTime()
    private val core = DiagLog()
    @Volatile private var inited = false
    private val exec: ExecutorService by lazy {
        Executors.newSingleThreadExecutor { r -> Thread(r, "sp-diag").apply { isDaemon = true } }
    }

    /** Idempotent. Starts writing to app-private storage (filesDir/diag/diag.jsonl, 2 MB, 14 days). */
    fun init(c: Context) {
        if (inited) return
        synchronized(this) {
            if (inited) return
            inited = true
        }
        try {
            val f = File(c.applicationContext.filesDir, "diag/diag.jsonl")
            val now = System.currentTimeMillis()
            exec.execute { core.attach(f, 14L * 24 * 60 * 60 * 1000, now) }
        } catch (e: Exception) { /* memory-only */ }
        log(DLvl.I, DCat.STARTUP, DEv.PROCESS_START, DMod.APP)
    }

    fun log(
        lvl: DLvl, cat: DCat, ev: DEv, mod: DMod = DMod.NONE, res: DRes = DRes.OK,
        dur: Long = 0L, n: Long = 0L, code: DCode? = null
    ) {
        try {
            val e = DiagEvent((System.nanoTime() - t0) / 1_000_000L, lvl, cat, ev, mod, res, dur, n, code)
            exec.execute { core.log(e) }
        } catch (x: Exception) { /* never break the app */ }
    }

    fun codeOf(t: Throwable?): DCode = DiagCodes.of(t)

    /** Waits (briefly) until everything logged so far has been written. Call from a background thread. */
    fun flush() {
        try { exec.submit(Runnable { }).get(3, TimeUnit.SECONDS) } catch (x: Exception) { /* ignore */ }
    }

    fun clear() {
        flush()
        core.clear()
        log(DLvl.I, DCat.SELFTEST, DEv.LOG_CLEARED)
    }

    /** Writes the diagnostics zip to [out]. Background thread only. */
    fun exportTo(c: Context, out: OutputStream, health: List<HealthItem>) {
        flush()
        val version = try {
            c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "unknown"
        } catch (x: Exception) { "unknown" }
        DiagExport.write(out, core, ExportInfo(version, Build.VERSION.SDK_INT, System.currentTimeMillis()), health)
        log(DLvl.I, DCat.SELFTEST, DEv.EXPORT_DONE, DMod.NONE, DRes.OK, n = health.size.toLong())
    }
}

/**
 * Self-test: probes every store, every module-to-module link that exists today and every permission, logs one typed
 * event per check and returns the rows used by the Diagnostics screen and health.json. Reads counts and booleans only.
 */
object SelfTest {
    fun run(c0: Context): List<HealthItem> {
        val c = c0.applicationContext
        Diag.init(c)
        val started = System.nanoTime()
        Diag.log(DLvl.I, DCat.SELFTEST, DEv.SELFTEST_STARTED)
        val out = ArrayList<HealthItem>()

        // ---- stores (counts only)
        probe(out, DCat.DB, DEv.CHK_STORE_BRAINY, DMod.BRAINY) {
            DRes.OK to BrainyStore.state(c).optInt("short").toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_ISLAND, DMod.ISLAND) {
            DRes.OK to IslandStore.monitoredApps(c).size.toLong()
        }
        val alarms = try { Scheduler.health(c) } catch (e: Exception) { null }
        probe(out, DCat.DB, DEv.CHK_STORE_ALARMS, DMod.ALARMS) {
            val h = alarms ?: throw IllegalStateException()
            val r = if (h[1] == 0) DRes.OK else DRes.FAIL
            r to h[0].toLong()
        }
        probe(out, DCat.ALARM, DEv.CHK_ALARMS_ARMED, DMod.ALARMS) {
            val h = alarms ?: throw IllegalStateException()
            val r = if (h[2] == 0) DRes.OK else DRes.FAIL
            r to h[2].toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_PIPER, DMod.PIPER) {
            // Piper workspace: stored document verifies against its SHA-256 and the page index matches it
            val v = PiperStore.verify(c)
            val r = if (v[2] == 1) DRes.OK else DRes.FAIL
            r to v[0].toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_STEPS, DMod.STEPS) {
            DRes.OK to Steps.summary(c).getJSONArray("history").length().toLong()
        }

        // ---- module links that exist today (plan 3.5 ports: brainy.daily.v1)
        probe(out, DCat.PORT, DEv.CHK_LINK_ISLAND_BRAINY, DMod.ISLAND) {
            val shown = IslandStore.count(c)
            val r = if (shown == BrainyStore.state(c).optInt("short")) DRes.OK else DRes.FAIL
            r to shown.toLong()
        }
        probe(out, DCat.PORT, DEv.CHK_LINK_FITNESS_BRAINY, DMod.FITNESS) {
            val sent = BrainyStore.snapshot(c).optInt("short")
            val r = if (sent == BrainyStore.state(c).optInt("short")) DRes.OK else DRes.FAIL
            r to sent.toLong()
        }

        // ---- services and sensors
        probe(out, DCat.BRAINY, DEv.CHK_BRAINY_SERVICE, DMod.BRAINY) {
            val r = if (BrainyService.running) DRes.OK else DRes.UNAVAILABLE
            r to (if (IslandStore.tracking(c)) 1L else 0L)
        }
        probe(out, DCat.STEPS, DEv.CHK_STEP_SENSOR, DMod.STEPS) {
            val has = c.getSystemService(SensorManager::class.java)?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null
            val r = if (has) DRes.OK else DRes.UNAVAILABLE
            r to 0L
        }

        // ---- permissions: always checked live, never remembered (plan principle 4)
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_NOTIFICATIONS, DMod.ALARMS) {
            granted(NotificationManagerCompat.from(c).areNotificationsEnabled())
        }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_MICROPHONE, DMod.NOTES) {
            granted(ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_ACTIVITY, DMod.STEPS) {
            granted(ContextCompat.checkSelfPermission(c, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED)
        }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_ACCESSIBILITY, DMod.BRAINY) { granted(accessibilityOn(c)) }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_USAGE, DMod.FITNESS) { granted(usageOn(c)) }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_OVERLAY, DMod.BRAINY) { granted(Settings.canDrawOverlays(c)) }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_EXACT_ALARM, DMod.ALARMS) {
            granted(Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
        }
        probe(out, DCat.PERMISSION, DEv.CHK_PERM_FULL_SCREEN, DMod.ALARMS) {
            granted(Build.VERSION.SDK_INT < 34 || c.getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
        }
        probe(out, DCat.PERMISSION, DEv.CHK_BATTERY_OPT, DMod.ALARMS) {
            val ignoring = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
            val r = if (ignoring) DRes.OK else DRes.SKIP      // informational: not required for alarms to work
            r to 0L
        }

        val ms = (System.nanoTime() - started) / 1_000_000L
        val ok = DiagExport.overall(out) != "ERROR"
        Diag.log(if (ok) DLvl.I else DLvl.W, DCat.SELFTEST, DEv.SELFTEST_DONE, DMod.NONE, if (ok) DRes.OK else DRes.FAIL, ms, out.size.toLong())
        return out
    }

    private fun granted(b: Boolean): Pair<DRes, Long> = (if (b) DRes.OK else DRes.DENIED) to 0L

    private fun probe(out: MutableList<HealthItem>, cat: DCat, ev: DEv, mod: DMod, body: () -> Pair<DRes, Long>) {
        val t = System.nanoTime()
        var res = DRes.FAIL
        var n = 0L
        var code: DCode? = null
        try {
            val r = body()
            res = r.first; n = r.second
        } catch (e: Exception) {
            code = Diag.codeOf(e)
        }
        out.add(HealthItem(ev, mod, res, n))
        Diag.log(if (res == DRes.FAIL) DLvl.W else DLvl.I, cat, ev, mod, res, (System.nanoTime() - t) / 1_000_000L, n, code)
    }

    private fun accessibilityOn(c: Context): Boolean {
        val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(c, BrainyService::class.java)
        return list.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    private fun usageOn(c: Context): Boolean = try {
        val ops = c.getSystemService(AppOpsManager::class.java)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }
}
