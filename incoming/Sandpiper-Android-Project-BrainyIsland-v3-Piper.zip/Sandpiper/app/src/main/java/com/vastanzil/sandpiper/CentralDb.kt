package com.vastanzil.sandpiper

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

/**
 * Sandpiper's central on-device database. Uses the platform SQLite (no extra Gradle dependency).
 *
 * Generic part (any module can use it later):
 *   module_doc        header per versioned document: schema, size, chunk count, SHA-256, time
 *   module_doc_chunk  the document body in <= 200k-char pieces (CursorWindow-safe)
 * Piper part (derived, rebuilt inside the same transaction as every save):
 *   piper_page        one row per Piper page/folder: id, parent, title, icon, favorite, updated, block count
 *   piper_setting     Piper workspace settings (string/number/boolean values)
 */
internal class CentralDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, NAME, null, VERSION) {
    override fun onConfigure(db: SQLiteDatabase) {
        db.setWriteAheadLoggingEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE module_doc(module TEXT NOT NULL, doc_key TEXT NOT NULL, schema_v INTEGER NOT NULL, " +
                "bytes INTEGER NOT NULL, chunks INTEGER NOT NULL, sha256 TEXT NOT NULL, updated_at INTEGER NOT NULL, " +
                "PRIMARY KEY(module, doc_key))"
        )
        db.execSQL(
            "CREATE TABLE module_doc_chunk(module TEXT NOT NULL, doc_key TEXT NOT NULL, seq INTEGER NOT NULL, " +
                "part TEXT NOT NULL, PRIMARY KEY(module, doc_key, seq))"
        )
        db.execSQL(
            "CREATE TABLE piper_page(id TEXT PRIMARY KEY, parent_id TEXT, title TEXT NOT NULL, icon TEXT, " +
                "favorite INTEGER NOT NULL, updated_at TEXT, blocks INTEGER NOT NULL)"
        )
        db.execSQL("CREATE TABLE piper_setting(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 is the first schema. Future versions add tables/columns here, never drop user data.
    }

    companion object {
        const val NAME = "sandpiper_central.db"
        const val VERSION = 1
        @Volatile private var inst: CentralDb? = null

        fun get(c: Context): CentralDb =
            inst ?: synchronized(this) { inst ?: CentralDb(c.applicationContext).also { inst = it } }
    }
}

/**
 * Piper Pro workspace storage. The whole workspace (pages, blocks, tables, boards, templates, config...) is one
 * versioned JSON document, exactly what Piper itself keeps in memory, so no Piper feature depends on the schema.
 * Every save is one SQLite transaction that (1) keeps the previous revision as a safety copy, (2) writes the new
 * document in chunks with a SHA-256, and (3) rebuilds the page and settings index. Reads verify the hash and fall
 * back to the previous revision if the current one is damaged.
 */
internal object PiperStore {
    private const val MODULE = "piper"
    private const val CUR = "workspace"
    private const val PREV = "workspace.prev"
    private const val SCHEMA = 5
    const val MAX_CHARS = 32_000_000

    @Synchronized
    fun save(c: Context, json: String): Boolean {
        val t0 = System.nanoTime()
        try {
            if (json.length > MAX_CHARS) {
                Diag.log(DLvl.W, DCat.DB, DEv.PIPER_SAVE, DMod.PIPER, DRes.FAIL, code = DCode.E_ARG)
                return false
            }
            val root = JSONObject(json)
            val pages = root.optJSONArray("pages")
            if (pages == null || pages.length() == 0) {
                Diag.log(DLvl.W, DCat.DB, DEv.PIPER_SAVE, DMod.PIPER, DRes.FAIL, code = DCode.E_ARG)
                return false
            }
            val bytes = json.toByteArray(Charsets.UTF_8)
            val sha = DocChunker.sha256(bytes)
            val db = CentralDb.get(c).writableDatabase

            // Identical to what is already stored: nothing to write.
            db.rawQuery("SELECT sha256 FROM module_doc WHERE module=? AND doc_key=?", arrayOf(MODULE, CUR)).use { cur ->
                if (cur.moveToFirst() && cur.getString(0) == sha) return true
            }

            val parts = DocChunker.split(json)
            db.beginTransaction()
            try {
                // 1) current -> previous (the old previous is dropped)
                db.delete("module_doc", "module=? AND doc_key=?", arrayOf(MODULE, PREV))
                db.delete("module_doc_chunk", "module=? AND doc_key=?", arrayOf(MODULE, PREV))
                val toPrev = ContentValues()
                toPrev.put("doc_key", PREV)
                db.update("module_doc", toPrev, "module=? AND doc_key=?", arrayOf(MODULE, CUR))
                db.update("module_doc_chunk", toPrev, "module=? AND doc_key=?", arrayOf(MODULE, CUR))

                // 2) new current
                val h = ContentValues()
                h.put("module", MODULE)
                h.put("doc_key", CUR)
                h.put("schema_v", root.optInt("schemaVersion", SCHEMA))
                h.put("bytes", bytes.size)
                h.put("chunks", parts.size)
                h.put("sha256", sha)
                h.put("updated_at", System.currentTimeMillis())
                db.insertOrThrow("module_doc", null, h)
                for (i in parts.indices) {
                    val v = ContentValues()
                    v.put("module", MODULE)
                    v.put("doc_key", CUR)
                    v.put("seq", i)
                    v.put("part", parts[i])
                    db.insertOrThrow("module_doc_chunk", null, v)
                }

                // 3) derived index: pages/folders and settings
                db.delete("piper_page", null, null)
                db.delete("piper_setting", null, null)
                for (i in 0 until pages.length()) {
                    val p = pages.optJSONObject(i) ?: continue
                    val id = p.optString("id", "")
                    if (id.isEmpty()) continue
                    val v = ContentValues()
                    v.put("id", id)
                    v.put("parent_id", if (p.isNull("parentId")) null else p.optString("parentId", ""))
                    v.put("title", p.optString("title", "").take(200))
                    v.put("icon", p.optString("icon", "").take(16))
                    v.put("favorite", if (p.optBoolean("favorite", false)) 1 else 0)
                    v.put("updated_at", p.optString("updatedAt", ""))
                    v.put("blocks", p.optJSONArray("blocks")?.length() ?: 0)
                    db.insertWithOnConflict("piper_page", null, v, SQLiteDatabase.CONFLICT_REPLACE)
                }
                val cfg = root.optJSONObject("config")
                if (cfg != null) {
                    val ks = cfg.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val value = cfg.opt(k)
                        if (value is String || value is Number || value is Boolean) {
                            val v = ContentValues()
                            v.put("k", k.take(100))
                            v.put("v", value.toString().take(500))
                            db.insertWithOnConflict("piper_setting", null, v, SQLiteDatabase.CONFLICT_REPLACE)
                        }
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            Diag.log(DLvl.I, DCat.DB, DEv.PIPER_SAVE, DMod.PIPER, DRes.OK, (System.nanoTime() - t0) / 1_000_000L, (bytes.size / 1024).toLong())
            return true
        } catch (e: Exception) {
            Diag.log(DLvl.W, DCat.DB, DEv.PIPER_SAVE, DMod.PIPER, DRes.FAIL, (System.nanoTime() - t0) / 1_000_000L, 0L, Diag.codeOf(e))
            return false
        }
    }

    /** The stored workspace JSON, or null when nothing valid is stored (first run). Falls back to the previous revision. */
    @Synchronized
    fun load(c: Context): String? {
        val t0 = System.nanoTime()
        try {
            val db = CentralDb.get(c).readableDatabase
            val cur = readDoc(db, CUR)
            if (cur != null) {
                Diag.log(DLvl.I, DCat.DB, DEv.PIPER_LOAD, DMod.PIPER, DRes.OK, (System.nanoTime() - t0) / 1_000_000L, (cur.length / 1024).toLong())
                return cur
            }
            val prev = readDoc(db, PREV)
            if (prev != null) {
                Diag.log(DLvl.W, DCat.DB, DEv.PIPER_RECOVERED, DMod.PIPER, DRes.OK, (System.nanoTime() - t0) / 1_000_000L, (prev.length / 1024).toLong())
                return prev
            }
            Diag.log(DLvl.I, DCat.DB, DEv.PIPER_LOAD, DMod.PIPER, DRes.SKIP)
            return null
        } catch (e: Exception) {
            Diag.log(DLvl.W, DCat.DB, DEv.PIPER_LOAD, DMod.PIPER, DRes.FAIL, 0L, 0L, Diag.codeOf(e))
            return null
        }
    }

    /** Small JSON for the UI pill: {ok, has, pages, bytes, updatedAt}. Reads headers only (cheap). */
    @Synchronized
    fun status(c: Context): String {
        val o = JSONObject()
        try {
            val db = CentralDb.get(c).readableDatabase
            var has = false
            var bytes = 0L
            var upd = 0L
            db.rawQuery("SELECT bytes, updated_at FROM module_doc WHERE module=? AND doc_key=?", arrayOf(MODULE, CUR)).use { cur ->
                if (cur.moveToFirst()) { has = true; bytes = cur.getLong(0); upd = cur.getLong(1) }
            }
            var pages = 0
            db.rawQuery("SELECT COUNT(*) FROM piper_page", null).use { cur ->
                if (cur.moveToFirst()) pages = cur.getInt(0)
            }
            o.put("ok", true)
            o.put("has", has)
            o.put("pages", pages)
            o.put("bytes", bytes)
            o.put("updatedAt", upd)
        } catch (e: Exception) {
            try { o.put("ok", false) } catch (x: Exception) { /* ignore */ }
        }
        return o.toString()
    }

    /**
     * Self-test: [pages in the stored document, pages in the index, 1 if healthy else 0].
     * Nothing stored yet counts as healthy. Reads the CURRENT revision only, so damage is not masked by the fallback.
     */
    @Synchronized
    fun verify(c: Context): IntArray {
        val db = CentralDb.get(c).readableDatabase
        var has = false
        db.rawQuery("SELECT 1 FROM module_doc WHERE module=? AND doc_key=?", arrayOf(MODULE, CUR)).use { cur -> has = cur.moveToFirst() }
        if (!has) return intArrayOf(0, 0, 1)
        val s = readDoc(db, CUR) ?: return intArrayOf(0, 0, 0)
        val arr = JSONObject(s).optJSONArray("pages")
        val ids = HashSet<String>()
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val id = arr.optJSONObject(i)?.optString("id", "") ?: ""
                if (id.isNotEmpty()) ids.add(id)
            }
        }
        var idx = 0
        db.rawQuery("SELECT COUNT(*) FROM piper_page", null).use { cur -> if (cur.moveToFirst()) idx = cur.getInt(0) }
        return intArrayOf(ids.size, idx, if (ids.size == idx) 1 else 0)
    }

    private fun readDoc(db: SQLiteDatabase, key: String): String? {
        var chunks = -1
        var sha = ""
        db.rawQuery("SELECT chunks, sha256 FROM module_doc WHERE module=? AND doc_key=?", arrayOf(MODULE, key)).use { cur ->
            if (!cur.moveToFirst()) return null
            chunks = cur.getInt(0)
            sha = cur.getString(1)
        }
        val sb = StringBuilder()
        var n = 0
        db.rawQuery("SELECT part FROM module_doc_chunk WHERE module=? AND doc_key=? ORDER BY seq", arrayOf(MODULE, key)).use { cur ->
            while (cur.moveToNext()) { sb.append(cur.getString(0)); n++ }
        }
        if (n != chunks) return null
        val s = sb.toString()
        return if (DocChunker.sha256(s) == sha) s else null
    }
}
