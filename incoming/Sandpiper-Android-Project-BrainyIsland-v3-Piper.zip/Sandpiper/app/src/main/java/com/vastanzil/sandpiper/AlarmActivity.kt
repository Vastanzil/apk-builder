package com.vastanzil.sandpiper

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full-screen ringing UI shown over the lock screen. Sound comes from the notification channel. */
class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getStringExtra("id") ?: ""
        val title = intent.getStringExtra("title") ?: "Alarm"
        val tone = intent.getStringExtra("tone") ?: Tones.DEFAULT
        val dp = resources.displayMetrics.density

        fun label(text: String, size: Float, color: Int) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        }
        fun button(text: String, bg: Int, fg: Int, onClick: () -> Unit) = Button(this).apply {
            this.text = text; textSize = 20f; setBackgroundColor(bg); setTextColor(fg); isAllCaps = false
            setPadding(0, (22 * dp).toInt(), 0, (22 * dp).toInt())
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = (16 * dp).toInt() }
            setOnClickListener { onClick() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF101B17.toInt())
            val p = (32 * dp).toInt(); setPadding(p, p, p, p)
        }
        root.addView(label(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()), 56f, 0xFFE9EEE8.toInt()))
        root.addView(label(title, 22f, 0xFFB9D9C4.toInt()))
        root.addView(button("Snooze 10 min", 0x22FFFFFF, 0xFFE9EEE8.toInt()) {
            Notifier.snooze(this, id, title, tone); finish()
        })
        root.addView(button("Dismiss", 0xFFB9D9C4.toInt(), 0xFF10231D.toInt()) {
            Notifier.dismiss(this, id); finish()
        })
        setContentView(root)
    }
}
