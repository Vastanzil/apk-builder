package com.vastanzil.sandpiper

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * More > Diagnostics. Runs the self-test, shows module health / connection checks / permission state, and exports the
 * diagnostic log as a zip through the system file picker. The log holds enums and numbers only (see DiagCore.kt):
 * no notes, amounts, names, URLs, app package names, device ids or exception messages.
 */
class DiagnosticsActivity : AppCompatActivity() {
    private lateinit var summary: TextView
    private lateinit var body: TextView
    @Volatile private var last: List<HealthItem> = emptyList()

    private val saver = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) exportTo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Diag.init(applicationContext)
        window.statusBarColor = FOREST; window.navigationBarColor = FOREST
        buildUi()
        runSelfTest()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(16)); setBackgroundColor(FOREST)
        }
        root.addView(label("Diagnostics", 26f, WARM_WHITE, Gravity.START, bottom = 4))
        root.addView(label(
            "Checks that Sandpiper's storage, links between modules and permissions work. The exported log contains only " +
                "event types, results and counts. It never contains your notes, money, names, links or app names.",
            13f, MINT, Gravity.START, bottom = 12))
        summary = label("Running self-test…", 15f, WARM_WHITE, Gravity.START, bottom = 8).also { root.addView(it) }

        root.addView(button("Run self-test") { runSelfTest() })
        root.addView(button("Export full diagnostic log") {
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            try { saver.launch("sandpiper-diagnostics-$stamp.zip") } catch (e: Exception) { toast("No file picker available.") }
        })
        root.addView(button("Clear log") {
            Thread { Diag.clear(); runOnUiThread { toast("Diagnostic log cleared.") } }.start()
        })

        body = TextView(this).apply {
            textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(WARM_WHITE); setTextIsSelectable(true)
            setPadding(0, dp(8), 0, dp(8))
        }
        val scroll = ScrollView(this).apply { addView(body) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun runSelfTest() {
        summary.text = "Running self-test…"
        Thread {
            val rows = try { SelfTest.run(applicationContext) } catch (e: Exception) { emptyList() }
            last = rows
            runOnUiThread { render(rows) }
        }.start()
    }

    private fun render(rows: List<HealthItem>) {
        if (rows.isEmpty()) { summary.text = "Self-test could not run."; body.text = ""; return }
        summary.text = "Overall: " + DiagExport.overall(rows) + "  (" + rows.size + " checks)"
        val sb = StringBuilder()
        var section = ""
        for (r in rows) {
            val name = r.ev.name
            val group = when {
                name.startsWith("CHK_STORE") -> "Storage"
                name.startsWith("CHK_LINK") || name == "CHK_ALARMS_ARMED" -> "Connections"
                name.startsWith("CHK_PERM") || name == "CHK_BATTERY_OPT" -> "Permissions"
                else -> "Services"
            }
            if (group != section) { section = group; if (sb.isNotEmpty()) sb.append('\n'); sb.append(group).append('\n') }
            val tag = when (r.res) {
                DRes.OK -> "OK     "
                DRes.FAIL -> "FAIL   "
                DRes.DENIED -> "DENIED "
                DRes.UNAVAILABLE -> "N/A    "
                DRes.SKIP -> "INFO   "
            }
            sb.append("  ").append(tag).append(name.removePrefix("CHK_").lowercase().replace('_', ' '))
            if (r.n > 0 && !name.startsWith("CHK_PERM")) sb.append("  (").append(r.n).append(')')
            sb.append('\n')
        }
        body.text = sb.toString()
    }

    private fun exportTo(uri: android.net.Uri) {
        Thread {
            try {
                val rows = last.ifEmpty { SelfTest.run(applicationContext) }
                val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException()
                out.use { Diag.exportTo(applicationContext, it, rows) }
                runOnUiThread { toast("Diagnostic log saved.") }
            } catch (e: Exception) {
                Diag.log(DLvl.W, DCat.SELFTEST, DEv.EXPORT_DONE, DMod.NONE, DRes.FAIL, code = Diag.codeOf(e))
                runOnUiThread { toast("Could not save the diagnostic log.") }
            }
        }.start()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun label(text: String, size: Float, color: Int, gravity: Int, bottom: Int = 0) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); this.gravity = gravity; setPadding(0, 0, 0, dp(bottom))
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(WARM_WHITE)
        backgroundTintList = ColorStateList.valueOf(BUTTON)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { bottomMargin = dp(8) }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private companion object {
        val FOREST = Color.rgb(0x10, 0x1B, 0x17)      // @color/forest
        const val MINT = 0xFFB9D9C4.toInt()
        const val WARM_WHITE = 0xFFE9EEE8.toInt()
        const val BUTTON = 0xFF2E5A45.toInt()
    }
}
