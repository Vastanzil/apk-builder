package com.vastanzil.sandpiper

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Liquid-glass dynamic island, drawn by Brainy's accessibility service (TYPE_ACCESSIBILITY_OVERLAY, no overlay permission).
 * Ported from the Reel Counter app; the number shown comes from [countProvider] (Brainy's "short videos today").
 *  - centred punch-hole -> pill wrapped around the camera: [mascot] (camera) [count]
 *  - wide notch         -> status-bar band
 *  - no / off-centre cut-out, or landscape -> small floating pill
 * Motion: spring entrance from the camera, odometer count roll, squash-and-stretch, mascot wiggle,
 * light sweep + rim glow on every reel, bigger celebration every 10 / 100 reels, quiet idle sheen.
 * All motion respects the system "remove animations" / animator-scale-0 setting and battery saver.
 * Mascot = view id R.id.reel_mascot in res/layout/overlay_island.xml.
 */
internal class IslandOverlay(private val ctx: Context, private val countProvider: () -> Int) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val glass = LiquidGlassDrawable(ctx.resources.displayMetrics.density)
    private val ui = Handler(Looper.getMainLooper())
    private val anims = HashMap<String, ValueAnimator>()
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var appliedKey = ""
    private var symmetric = false

    val isShowing get() = root != null

    private val idleSweep = object : Runnable {
        override fun run() {
            if (root == null) return
            if (!powerSave()) glass.sweep(1100)
            ui.postDelayed(this, IDLE_MS)
        }
    }

    fun show() {
        if (root != null) return
        val view = LayoutInflater.from(ContextThemeWrapper(ctx, R.style.Theme_Sandpiper)).inflate(R.layout.overlay_island, null)
        view.background = glass
        val p = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, dp(32),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        view.setOnApplyWindowInsetsListener { _, insets -> relayout(insets); insets }
        try {
            wm.addView(view, p)
            root = view; params = p; appliedKey = ""
            view.findViewById<TextView>(R.id.reel_count).text = countProvider().toString()
            applyLook(view)
            syncSlots(view)
            view.requestApplyInsets()
            animateIn(view)
            ui.postDelayed(idleSweep, 2500L)
        } catch (e: Exception) {
            root = null; params = null
            Diag.log(DLvl.W, DCat.ISLAND, DEv.ISLAND_SHOW_FAILED, DMod.ISLAND, DRes.FAIL, code = Diag.codeOf(e))
        }
    }

    fun hide(animated: Boolean = true) {
        ui.removeCallbacks(idleSweep)
        glass.cancel()
        anims.values.toList().forEach { it.cancel() }
        anims.clear()
        val v = root ?: return
        root = null; params = null; appliedKey = ""
        val remove = { try { wm.removeView(v) } catch (e: Exception) { } }
        if (animated && ValueAnimator.areAnimatorsEnabled()) {
            v.animate().alpha(0f).scaleX(0.4f).scaleY(0.6f).setDuration(180).withEndAction(remove).start()
        } else remove()
    }

    /** Re-evaluate cut-out / rotation / style / look. */
    fun refresh() {
        val v = root ?: return
        appliedKey = ""; applyLook(v)
        relayout(null)                 // works even if Android does not re-dispatch insets
        v.requestApplyInsets()
    }

    fun render(value: Int, animate: Boolean) {
        val v = root ?: return
        val count = v.findViewById<TextView>(R.id.reel_count)
        if (!animate) { count.text = value.toString(); syncSlots(v); return }
        bump(v, value, if (value > 0 && value % 100 == 0) 2 else if (value > 0 && value % 10 == 0) 1 else 0)
    }

    /** Plays the celebration without changing the count (used by the in-app preview button). */
    fun preview() { root?.let { bump(it, countProvider(), 1) } }

    // ------------------------------------------------------------------ motion
    private fun animateIn(v: View) {
        if (!ValueAnimator.areAnimatorsEnabled()) return
        v.alpha = 0f; v.scaleX = 0.35f; v.scaleY = 0.55f
        play("in", 560) { t -> v.scaleX = 0.35f + 0.65f * t; v.scaleY = 0.55f + 0.45f * t; v.alpha = (t * 2.5f).coerceIn(0f, 1f) }
        glass.sweep(900)
    }

    private fun bump(v: View, value: Int, tier: Int) {
        val count = v.findViewById<TextView>(R.id.reel_count)
        val mascot = v.findViewById<View>(R.id.reel_mascot)
        val rise = dp(9).toFloat()
        var swapped = false
        play("cnt", 300, LinearInterpolator()) { t ->                    // odometer roll
            if (t < 0.3f) { val k = t / 0.3f; count.translationY = -rise * k; count.alpha = 1f - k }
            else {
                if (!swapped) { swapped = true; count.text = value.toString(); syncSlots(v) }
                val k = 1f - (1f - (t - 0.3f) / 0.7f).let { it * it * it }
                count.translationY = rise * (1f - k); count.alpha = k
            }
        }
        val amp = when (tier) { 2 -> 0.22f; 1 -> 0.15f; else -> 0.09f }
        play("squash", 520) { t -> val k = 1f - t; v.scaleX = 1f + amp * k; v.scaleY = 1f - amp * 0.6f * k }   // squash & stretch
        val pop = 0.16f + 0.1f * tier
        play("brain", if (tier > 0) 900 else 600) { t ->
            val k = 1f - t
            mascot.scaleX = 1f + pop * k; mascot.scaleY = 1f + pop * k
            mascot.rotation = if (tier > 0) (360f * t) % 360f else -14f * k
        }
        glass.sweep(if (tier > 0) 900 else 600)
        glass.pulseGlow(if (tier > 0) 900 else 520, if (tier > 0) 1f else 0.65f)
    }

    private fun play(key: String, ms: Long, interp: TimeInterpolator = SPRING, onFrame: (Float) -> Unit) {
        anims.remove(key)?.cancel()
        if (!ValueAnimator.areAnimatorsEnabled()) { onFrame(1f); return }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms; a.interpolator = interp
        a.addUpdateListener { onFrame(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onFrame(1f); if (anims[key] === animation) anims.remove(key) }
        })
        anims[key] = a
        a.start()
    }

    private fun powerSave() = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode

    private fun applyLook(v: View) {
        glass.look = IslandStore.look(ctx)
        val sky = glass.look == IslandLook.SKY_GLASS && !glass.band
        v.findViewById<TextView>(R.id.reel_count).setTextColor(if (sky) 0xFF06324D.toInt() else Color.WHITE)
    }

    // ------------------------------------------------------------------ layout
    /** Camera cut-out rectangles from every source Android offers (the insets callback alone is unreliable on overlays). */
    private fun cutoutRects(insets: WindowInsets?): List<Rect> {
        if (Build.VERSION.SDK_INT < 28) return emptyList()
        fun rects(c: android.view.DisplayCutout?): List<Rect> = c?.boundingRects.orEmpty()
        var r = rects(insets?.displayCutout)
        if (r.isEmpty() && Build.VERSION.SDK_INT >= 30) r = runCatching { rects(wm.currentWindowMetrics.windowInsets.displayCutout) }.getOrDefault(emptyList())
        if (r.isEmpty()) r = runCatching { rects(root?.rootWindowInsets?.displayCutout) }.getOrDefault(emptyList())
        if (r.isEmpty() && Build.VERSION.SDK_INT >= 31) r = runCatching { rects(ctx.display?.cutout) }.getOrDefault(emptyList())
        return r
    }

    private fun relayout(insets: WindowInsets?) {
        val v = root ?: return
        val p = params ?: return
        val screen = screenSize()
        val sbH = statusBarHeight()
        // Punch-holes are usually NOT touching the screen edge (top > 0), so accept anything inside the top band.
        val band = max(sbH, (screen.y * 0.07f).toInt())
        val rect = cutoutRects(insets)
            .filter { it.width() > 0 && it.top >= 0 && it.top < band && it.bottom <= band * 2 }
            .minByOrNull { abs(it.exactCenterX() - screen.x / 2f) }
        val landscape = screen.x > screen.y
        val centered = rect != null && abs(rect.exactCenterX() - screen.x / 2f) <= screen.x * 0.1f
        val wide = rect != null && (rect.width() > screen.x * 0.14f || rect.height() > dp(40))
        val auto = when { landscape || !centered -> IslandStyle.FLOAT; wide -> IslandStyle.STATUS_BAR; else -> IslandStyle.ISLAND }
        val pref = IslandStore.style(ctx)
        val style = when { pref == IslandStyle.AUTO -> auto; landscape || pref == IslandStyle.FLOAT -> IslandStyle.FLOAT; else -> pref }
        // If the user forces Island / Status bar but Android reports no cut-out, assume a small centred hole.
        val assumed = Rect(screen.x / 2 - dp(9), dp(10), screen.x / 2 + dp(9), dp(28))
        val cam: Rect? = when (style) {
            IslandStyle.ISLAND -> rect ?: assumed
            IslandStyle.STATUS_BAR -> if (centered) rect else assumed
            else -> null
        }
        val sb = max(sbH, cam?.bottom ?: 0)

        val gap: Int; val w: Int; val h: Int; val x: Int; val y: Int; val pad: Int
        if (style == IslandStyle.ISLAND && cam != null) {
            gap = max(cam.width() + 2 * dp(IslandStore.gapExtraDp(ctx)), dp(40))
            h = max(dp(30), cam.height() + dp(12))
            y = max(0, cam.top - (h - cam.height()) / 2)
            x = (cam.exactCenterX() - screen.x / 2f).roundToInt()
            w = ViewGroup.LayoutParams.WRAP_CONTENT; pad = dp(10)
        } else if (style == IslandStyle.STATUS_BAR && cam != null) {
            gap = max(cam.width() + 2 * dp(IslandStore.gapExtraDp(ctx)), dp(40)); h = sb; y = 0; x = 0
            w = ViewGroup.LayoutParams.MATCH_PARENT; pad = 0
        } else {
            gap = dp(4) + (dp(IslandStore.gapExtraDp(ctx)) * 1.2f).roundToInt()   // gap setting also spaces the floating pill
            h = dp(32); x = 0
            y = max(dp(4), (sb - h) / 2)
            w = ViewGroup.LayoutParams.WRAP_CONTENT; pad = dp(12)
        }

        val key = "$style|$gap|$w|$h|$x|$y"
        if (key == appliedKey) return
        appliedKey = key
        IslandStore.setDebug(ctx, (if (rect != null) "Cutout found: ${rect.width()}×${rect.height()} px, " + (if (centered) "centred" else "off-centre")
            else "No cutout reported by Android") + " · showing: ${style.label}")
        symmetric = style != IslandStyle.FLOAT
        glass.band = style == IslandStyle.STATUS_BAR
        applyLook(v)
        v.setPadding(pad, 0, pad, 0)
        v.findViewById<View>(R.id.reel_cutout_gap).let { g -> g.layoutParams = g.layoutParams.apply { width = gap } }
        p.width = w; p.height = h; p.x = x; p.y = y
        syncSlots(v)
        try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
    }

    /** Keeps mascot slot and count slot the same width so the camera hole stays centred. */
    private fun syncSlots(v: View) {
        val count = v.findViewById<TextView>(R.id.reel_count)
        val width = if (symmetric) max(dp(26), ceil(count.paint.measureText(count.text.toString())).toInt() + dp(2))
                    else ViewGroup.LayoutParams.WRAP_CONTENT
        for (id in intArrayOf(R.id.reel_left_slot, R.id.reel_right_slot)) {
            val s = v.findViewById<View>(id)
            if (s.layoutParams.width != width) s.layoutParams = s.layoutParams.apply { this.width = width }
        }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.let { Point(it.width(), it.height()) }
        else Point().also { wm.defaultDisplay.getRealSize(it) }

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), ctx.resources.displayMetrics).roundToInt()

    private companion object {
        const val IDLE_MS = 9_000L
        /** Damped spring: ~20 % overshoot, settles by the end of the duration. */
        val SPRING = TimeInterpolator { t -> if (t >= 1f) 1f else (1.0 - exp(-6.5 * t) * cos(2.0 * PI * 2.0 * t)).toFloat() }
    }
}
