package com.vastanzil.sandpiper

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import java.io.File

/**
 * Alarm tone ids:
 *   gentle_morning | classic_tick | bell | digital_beep | birds   built-in, original, bundled in res/raw
 *   system                                                         the phone's default alarm tone
 *   uri:<content uri>                                              a tone chosen in the system ringtone picker
 *   file:<absolute path>                                           an audio file copied into app-private storage
 */
object Tones {
    const val DEFAULT = "gentle_morning"
    val BUILTIN = setOf("gentle_morning", "classic_tick", "bell", "digital_beep", "birds")
    val ATTRS: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    /** Builds a prepared, looping player for [tone]; falls back to the default built-in tone, then the system tone. */
    fun player(c: Context, tone: String): MediaPlayer? {
        for (t in listOf(tone, DEFAULT, "system")) {
            val mp = runCatching { build(c, t) }.getOrNull()
            if (mp != null) return mp
        }
        return null
    }

    private fun build(c: Context, tone: String): MediaPlayer {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(ATTRS)
            when {
                tone in BUILTIN -> {
                    val id = c.resources.getIdentifier("tone_$tone", "raw", c.packageName)
                    c.resources.openRawResourceFd(id).use { mp.setDataSource(it.fileDescriptor, it.startOffset, it.length) }
                }
                tone.startsWith("file:") -> {
                    val f = File(tone.removePrefix("file:"))
                    require(f.exists() && f.length() > 0)
                    mp.setDataSource(f.absolutePath)
                }
                tone.startsWith("uri:") -> mp.setDataSource(c, Uri.parse(tone.removePrefix("uri:")))
                else -> mp.setDataSource(
                    c,
                    RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                )
            }
            mp.isLooping = true
            mp.prepare()
            return mp
        } catch (e: Exception) {
            mp.release()
            throw e
        }
    }
}
