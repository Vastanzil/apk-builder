# sandpiper.  — a little more breathing room

Offline-first Android app by Tanzil Hasan (@vastanzil). Native Kotlin shell (alarms, notifications,
file saving, step sensor) around a bundled web UI (`app/src/main/assets/index.html`). No INTERNET permission.

## One-click build
**Android Studio (easiest):** File > Open > this folder, wait for Gradle sync, press Run. APK: Build > Build APK(s).
**Command line:** install JDK 17 + Android SDK (platform 34), then run `./build-debug.sh` (Windows: `build-debug.bat`).
Output: `app/build/outputs/apk/debug/app-debug.apk`. Release: `./gradlew assembleRelease` (debug-signed; add your own keystore before publishing).
First build downloads Gradle 8.7 and dependencies, so it needs internet once.

## What works (see FEATURE_STATUS.md for details)
Money tracker with real totals + CSV, your full star-planner (daily plan, skill tree, smart calendar and reminders,
imported whole into the Planner tab), alarms that ring through a foreground service (reboot / time-zone safe), focus timer + bonsai growth, notes + voice notes, habits, hydration, sleep,
investments (manual values), calculator, JSON backup/restore, step counter, 3-tap About easter egg on the logo.

## Edit the UI
Change `app/src/main/assets/index.html`, rebuild. Data lives in WebView localStorage/IndexedDB (app-private).

## Planner
`app/src/main/assets/planner.html` is your Sandpiper planner file, unchanged except for one added line that loads
`planner-bridge.js`. The bridge schedules the planner's reminders with Android so they fire when the app is closed.
Note: as in your original file, the daily plan, points and skill-tree progress are not saved between launches; only reminders are.

## If an alarm does not ring
Open More > Alarm & Clock. The "alarm health" list shows what is blocking alarms (notifications off, full-screen
screen not allowed, battery optimisation) with a Fix button for each. "Test alarm" rings in 10 seconds; lock the phone first
to test the lock-screen path.

## Alarm tones
Each alarm has its own sound: Gentle Morning (default), Classic Tick, Traditional Bell, Digital Beep, Nature / Birds
(all original, generated, in `res/raw`), the phone's default alarm tone, any tone from the phone's picker, or your own audio file
(copied into app-private storage, max 30 MB). Use the ▶ button to preview. If a chosen file is missing, Sandpiper falls back to Gentle Morning.

## Zen Garden, Fitness and Close the day
Zen Garden = one card with the Pomodoro timer (left) and your garden (right), then a **Fitness** button that opens the full fitness page in its own full-screen window (no title bar; leave with the Android Back button or gesture), then "Closed days".
`fitness.html` is your fitness file, unchanged except one added line that loads `fitness-bridge.js`.
Its two ports (daily report, stars) are connected to the host app's Day Hub, so reports and stars are delivered even if they were queued while the app was closed.
Pressing **Close the day** in the Planner (the planner's own `resolve()` is wrapped by `planner-bridge.js`) now:
1. drains the open Fitness ports,
2. records one day entry with the Planner (tasks, weights, points, streak), Zen (focus sessions and minutes) and Fitness (steps, workouts, stars, latest report),
3. banks bonus points into the planner's points total: 10 points per net Fitness star and 5 per focus session today (constants `FIT_STAR_PTS`, `FOCUS_PTS` in `app.js`). Each day is banked once; closing again updates the record without double-banking.
Entries appear in Zen Garden > Closed days (CSV export) and are part of the JSON backup.

## Brainy (Fitness > Mental tab) permissions
Settings > Accessibility > **Sandpiper Brainy** (counts short videos/feed items in the apps you track, TikTok, Instagram, Facebook and YouTube by default; reads only the app name, scroll events and view-ID names, never text or messages. The one exception is the opt-in **Web reels in browsers** switch, which also reads only the browser address bar),
Settings > Apps > Special access > **Display over other apps** (focus lock; the counter island itself needs no overlay permission), and **Usage access** (real app time).
If the Accessibility switch is greyed out on Android 13+: App info > ⋮ > *Allow restricted settings*, then try again. The Turn on buttons in the Fitness page open the right screen and show these steps.
Without the overlay permission the lock falls back to an accessibility overlay. The lock clears after 5 minutes of total screen-off time; closing the reel app hides it until you open one again.
## Brainy Island (reel counter)
The reel counter from the standalone *Reel Counter* app now runs inside Brainy. Open **Zen Garden > Brainy Island** (native screen). The island's number is Brainy's own "short videos today", so the island, Fitness > Mental, the warnings, the daily limit and the focus lock always agree.
- **Counting engine** (`SwipeDetector`, with its unit tests): scroll events are collected and judged only when the swipe settles: about one screen of net vertical travel, once per gesture, several nested scrolling views tracked separately, horizontal carousels / taps / small drags ignored, swiping back over a counted reel never recounts. `notificationTimeout` in the accessibility config is now `0` (the old 200 ms made Android drop scroll events and under-measure swipes).
- **Island** (`IslandOverlay`, `LiquidGlassDrawable`): reads the real camera cut-out (camera island / status-bar band / floating pill), liquid-glass Dark or Sky or Solid Black, spring entrance, odometer roll, celebration every 10th and 100th reel. Settings: Display mode, Appearance, Cutout spacing, **Show island** (over tracked apps, or always), Preview animation.
- **Tracked apps**: pick from the installed apps (modded YouTube, Lite apps and TikTok variants are built in). Apps you add count as short videos but have no feed/platform bar.
- **Web reels in browsers** (off by default): Chrome, Firefox, Brave, Edge, Samsung Internet and others on instagram.com / youtube.com / facebook.com / tiktok.com. Reads ONLY the address bar, in memory; Chrome shows just the domain so a stricter swipe rule applies there.
- **Tracking on/off**, **Reset today's reel count** (also restarts today's reel warnings, the budget window and any lock; feed items and regular videos are kept), and **Diagnostics** (in-memory log of raw scroll events and each swipe decision; Copy and paste it when an app misbehaves).
- The **Floating Brainy** switch in Fitness > Mental is still the master switch for the island; warnings, budget, quiet hours, snooze and the lock are still set there. Island-specific settings are stored separately (`sp_brainy_island`) and are not part of the JSON backup.
- Behaviour change: entering a reel screen no longer counts as a reel by itself (only swipes do, as in Reel Counter). A page-sized swipe on a YouTube watch page is counted as a feed item, not a reel.

Font: Bricolage Grotesque (SIL Open Font License, `assets/bricolage-OFL.txt`).

## Diagnostics and architecture docs
More > Diagnostics runs a self-test and exports a log containing only event types, results and counts. Developer docs are in `docs/architecture/` (not packaged in the APK). See `SANDPIPER_SYSTEM_SCHEMATIC.md` for which parts of the backend plan are implemented.

## Notes and Piper Pro
Notes has a Notes / Piper Pro switch in its heading. Piper Pro is the full Glasspage Pro workspace (rebranded Piper) with its editor, blocks, tables, databases, boards and templates intact. Its pages are stored in Sandpiper's central database (`sandpiper_central.db`) instead of the browser. Known limits: Piper's AI action needs network access and Sandpiper has no internet permission by design; PDF/Print export is not available inside Android WebView; Piper's local snapshot history stays in the WebView; the Sandpiper JSON backup (More > Profile & backup) does not include Piper, use Piper's own Export workspace backup.
