#!/usr/bin/env bash
# One-click debug build. Needs JDK 17 and the Android SDK (ANDROID_HOME, or local.properties with sdk.dir).
set -e
cd "$(dirname "$0")"
if [ -z "$ANDROID_HOME$ANDROID_SDK_ROOT" ] && [ ! -f local.properties ]; then
  echo "Set ANDROID_HOME (Android SDK path) or create local.properties with: sdk.dir=/path/to/Android/sdk"; exit 1
fi
./gradlew assembleDebug
echo; echo "APK: app/build/outputs/apk/debug/app-debug.apk"
