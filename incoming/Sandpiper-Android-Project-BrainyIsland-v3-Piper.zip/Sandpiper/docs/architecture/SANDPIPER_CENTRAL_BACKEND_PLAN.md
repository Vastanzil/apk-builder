# Sandpiper Central Backend: Plan, Schematics and the One Command

> Offline-first. One source of truth. Modules talk through typed ports. Permissions are checked live. Backups are complete.
> **No INTERNET permission. No personal data in any log.**

Developer/maintainer document. Keep it in `docs/architecture/`, never in `assets/` or `res/` (it must not ship in the APK).

---

## 0. How to use this file

1. Put this file in the project at `docs/architecture/SANDPIPER_CENTRAL_BACKEND_PLAN.md`.
2. Open the project in **Claude Code, in an environment that has JDK 17 and the Android SDK (platform 34)**. Without a real Gradle run, nothing in this plan can be called "debugged".
3. Paste the command in **section 14** as one message. It runs every stage in order, with a build-and-test gate after each one, and stops on the first failed gate.

---

## 1. Principles (unchanged philosophy)

| # | Principle | Consequence |
|---|---|---|
| 1 | Offline-first | No `INTERNET` permission, no cloud, no accounts, no analytics |
| 2 | One source of truth | Exactly one authoritative store for persistent data |
| 3 | Modules, not a monolith | Segments talk only through declared ports |
| 4 | Permissions are live | Never trust a remembered grant; re-check before use |
| 5 | Never lose user data | Legacy sources are read-only until migration is verified, then archived, not deleted |
| 6 | Optional stays optional | Denying a permission disables only that feature |
| 7 | Honest verification | "written", "unit-tested", "device-tested" are different claims |
| 8 | Privacy by construction | Diagnostics can only contain allow-listed, typed, non-personal fields |

---

## 2. What already exists (reuse, do not rebuild)

| Capability | Exists today | Plan action |
|---|---|---|
| Brainy count → Island | Island reads `BrainyStore` "short today" (no second counter) | Declare as a port; add a test |
| Brainy → Fitness Mental tab | `brainrotToday()` → `setBrainrot()` | Declare as a port |
| Planner / Fitness / Zen → Day Hub | `SandpiperPlannerPort`, `SandpiperStarsPort`, `SpHub` | Wrap in port contracts; keep the reward logic untouched |
| Alarm re-arm after boot / time change / update | `Scheduler` + `BootReceiver` | Make the DB the source; reconcile on start |
| Detection engine | `SwipeDetector`, `WebReels`, `BrainyApps` (+ tests) | Keep and keep passing |
| Fitness settings push | `setFitSettings` | Replace by the Settings Engine |

**Known gaps to fix:** five or six fragmented stores; the JSON backup (v2) misses most of them; planner daily plan/points/skill tree do not persist across launches; voice notes live only in IndexedDB; native steps and alarms use their own prefs/files.

---

## 3. Target architecture

### 3.1 System context

```mermaid
flowchart LR
  U([User]) --> APP[Sandpiper app]
  APP --> OS[(Android OS services)]
  OS --- AL[AlarmManager]
  OS --- NT[Notifications]
  OS --- AC[Accessibility service]
  OS --- SS[Step sensor]
  OS --- UA[Usage access]
  APP --> SAF[(User-chosen files via Storage Access Framework)]
  APP -. "never" .-> NET((Internet))
```

### 3.2 Components

```mermaid
flowchart TB
  subgraph UI[WebView UI - HTML/CSS/JS]
    HOME[Home] --- FIN[Finance] --- PLN[Planner] --- ZEN[Zen] --- FIT[Fitness]
    SET[More > Settings Center]
    DIA[Diagnostics screen]
  end
  UI -->|"async JSON, request id, schema v"| BR[Bridge v2 - allow-listed methods]
  BR --> CTRL[Module controllers - validate input]
  subgraph CORE[Central core - Kotlin]
    CTRL --> REPO[Repositories]
    REPO --> DB[(Room database)]
    CTRL --> HUB[Port / Connection hub]
    HUB --> EVT[Event dispatcher - after commit only]
    SETE[Settings engine] --> DB
    PERM[Permission manager + safety check]
    BAK[Backup / restore engine]
    MIG[Legacy migrator]
    DIAG[Diagnostics logger - PII-safe]
  end
  REPO --> BAK
  MIG --> DB
  subgraph NATIVE[Android native layer]
    BS[BrainyService + Island]
    SCH[Scheduler / AlarmService]
    STP[Step worker]
  end
  BS --> CACHE[(In-memory cache + batched write)] --> REPO
  SCH --> REPO
  STP --> REPO
  CORE --> DIAG
  NATIVE --> DIAG
```

### 3.3 Data-flow pattern (every segment)

```mermaid
flowchart LR
  A[User action or module event] --> B[Validate input]
  B --> C[Controller]
  C --> D[Repository]
  D --> E[Room transaction]
  E -->|commit ok| F[Event dispatcher]
  E -->|fail| X[Typed error + diag event]
  F --> G[Connected modules via ports]
  F --> H[Bridge push to WebView]
  G --> I[Aggregates e.g. Day Hub]
```

Rules: validate before save; one transaction per related change; emit events **only after commit**; idempotency key on every cross-module event; no module writes another module's state directly; DB work is never on the main thread; hot paths (Brainy scroll events) read an in-memory cache and flush in batches.

### 3.4 Database (decision: thin relational core + versioned documents)

Normalise what is stable and queryable. Keep still-evolving web payloads (planner tree, fitness blob) as **versioned JSON documents** inside Room. Normalise those later, one module at a time. Do **not** create 16 fully relational tables on day one.

```mermaid
erDiagram
  SETTING { string key PK  string module  string valueJson  int schemaV  long updatedAt }
  FINANCE_TX { string id PK  long amountMinor  string category  long date  string note }
  NOTE { string id PK  string body  long createdAt  long updatedAt }
  MEDIA { string id PK  string kind  string fileName  long sizeBytes  string sha256  string noteId FK }
  HABIT { string id PK  string name  string scheduleJson }
  HABIT_LOG { string habitId FK  string day  int done }
  WATER_DAY { string day PK  int ml  int goalMl }
  SLEEP_DAY { string day PK  int minutes  string windowJson }
  INVESTMENT { string id PK  string name  long costMinor  long valueMinor }
  STEP_DAY { string day PK  int steps  int activeMin }
  ALARM { string id PK  string kind  string title  long nextAt  string repeatJson  string tone  int enabled }
  BRAINY_DAY { string day PK  int shortCount  int regCount  int feedCount  string platformJson  string warnJson  int locked }
  BRAINY_REEL { long ts  string day FK  string platform }
  MODULE_DOC { string moduleId  string docKey  int schemaV  string json  long updatedAt }
  DAY_RECORD { string day PK  string outcome  int bonusPoints  int bankedTotal  string summaryJson }
  MIGRATION_LOG { string step PK  string status  string checksum  long finishedAt }
  NOTE ||--o{ MEDIA : has
  HABIT ||--o{ HABIT_LOG : logs
  BRAINY_DAY ||--o{ BRAINY_REEL : has
```

Rules: `exportSchema = true`; explicit `Migration` objects, **no** `fallbackToDestructiveMigration`; stable string IDs; dates stored as local `yyyy-MM-dd` plus UTC epoch where needed; `BRAINY_REEL` is bounded (~400 rows rolling); raw scroll events are never stored. Money stored as integer minor units.

Money, notes, names and any free text exist **only** in the database, never in diagnostics.

### 3.5 Modules and ports

```mermaid
flowchart LR
  BRY[Brainy] -->|"brainy.daily.v1"| ISL[Brainy Island]
  BRY -->|"brainy.daily.v1"| FIT[Fitness]
  BRY -->|"brainy.counts.v1"| LCK[Warnings / Focus lock]
  PLN[Planner] -->|"day.planner.v1"| DH[Day Hub]
  ZEN[Zen Garden] -->|"day.zen.v1"| DH
  FIT -->|"day.fitness.v1"| DH
  DH -->|"day.bonus.v1"| PLN
  PLN -->|"alarm.request.v1"| ALM[Alarm engine]
  FIT -->|"alarm.request.v1"| ALM
  ALL[All modules] -->|"settings.read.v1"| SE[Settings engine]
  ALL -->|"backup.contribute.v1"| BE[Backup engine]
```

Design (kept deliberately small): a module declares `id`, `version`, `dependsOn`, `inputPorts`, `outputPorts`, `settings`, `backupContributor`, `requiredCapabilities`. A port declares `id`, direction, payload type, `schemaV`, required/optional. The connection hub validates: both ends exist and are enabled, payload `schemaV` matches, required permission present, no declared-dependency cycle. A failing optional connection is isolated and logged; it never crashes another module. No dynamic code loading. Adding a module = register it in one Kotlin file; no engine changes.

### 3.6 Permissions

```mermaid
stateDiagram-v2
  [*] --> Unknown
  Unknown --> Onboarding: first install only
  Unknown --> Checking: existing install
  Onboarding --> Checking: user finished or skipped
  Checking --> READY: all enabled features satisfied
  Checking --> LIMITED: only optional features lack access
  Checking --> ACTION_REQUIRED: a selected feature lacks a prerequisite
  Checking --> ERROR: database or critical service failed
  LIMITED --> Checking: resume / settings return / service restart
  ACTION_REQUIRED --> Checking: resume / settings return
  READY --> Checking: resume / before feature use
```

| Access | Feature | How granted | If denied |
|---|---|---|---|
| POST_NOTIFICATIONS | Reminders, warnings | Runtime request | Alarms use full-screen/ring only; warnings silent |
| RECORD_AUDIO | Voice notes | Runtime request, in context | Voice notes disabled |
| ACTIVITY_RECOGNITION | Steps | Runtime request | Steps off |
| Accessibility service | Brainy counting + island | User enables in Settings | Brainy off |
| Usage access | App time | Settings screen | Real app-time hidden |
| Display over apps | Focus lock (optional) | Settings screen | Lock falls back to accessibility overlay |
| Exact alarms | Precise alarms | Settings screen (API 31+) | Inexact fallback + warning |
| Full-screen intent | Lock-screen alarm | Settings (API 34) | Heads-up notification |
| RECEIVE_BOOT_COMPLETED, WAKE_LOCK, VIBRATE, FOREGROUND_SERVICE(_MEDIA_PLAYBACK) | Alarm reliability | Install-time | n/a |

Audit every manifest entry; remove only what is verified unused. Live status is **never** stored as truth; only user choices (skipped, dismissed) are stored. Onboarding is for **new installs only** and stays reachable under Settings → Permissions & Privacy. There is no "one universal dialog": the guided flow walks the user through each request one at a time. Optional denial never blocks the app.

### 3.7 Backup and restore

```mermaid
sequenceDiagram
  participant U as User
  participant UI as Settings > Data & Backup
  participant BM as BackupManager
  participant DB as Room
  participant FS as App files
  participant SAF as Document picker
  U->>UI: Create backup
  UI->>BM: start (request id)
  BM->>DB: consistent read (one transaction)
  BM->>FS: collect voice + tones
  BM->>BM: build manifest + SHA-256 per file
  BM->>SAF: write .zip to user-chosen location
  BM-->>UI: result (counts, sizes, no content)
  U->>UI: Restore
  UI->>BM: open archive
  BM->>BM: validate zip, size, paths, manifest, checksums
  BM-->>UI: preview (counts per module) + replace/merge
  BM->>DB: snapshot current data (rollback point)
  BM->>DB: apply in one transaction
  alt failure
    BM->>DB: roll back to snapshot
  end
```

Archive: `manifest.json`, `database/data.json`, `settings/settings.json`, `media/voice/*`, `media/alarm_tones/*`, `integrity/checksums.json`. Manifest holds app id, format version, app version, DB schema version, module list, file inventory. Rejects `..`/absolute paths, oversize archives and checksum mismatches. Legacy JSON v2 stays importable via a v2→current converter. Permission grants are never exported. Password protection is deferred (add later with a vetted AEAD, only when needed).

### 3.8 Legacy migration

```mermaid
stateDiagram-v2
  [*] --> NotStarted
  NotStarted --> Snapshot: auto-backup of all legacy sources
  Snapshot --> Extract: JS hands localStorage/IndexedDB to native once
  Extract --> Validate
  Validate --> Write: single transaction per module
  Write --> Verify: counts + checksums match
  Verify --> Marked: MIGRATION_LOG row = done
  Marked --> Archived: legacy keys renamed, not deleted
  Write --> Resume: interrupted (process death)
  Resume --> Extract: idempotent re-run
  Validate --> Failed: keep legacy active, report code
```

Sources: `sandpiper_state_v2`, `sandpiper_reminders`, `sandpiper.fitness.v1`, `sp_brainy`, `sp_brainy_island`, native step storage, alarm/reminder config, IndexedDB `sandpiper` (voice), custom tone files, and any other prefs/files found in the audit. The web layer runs a one-time exporter that posts its data to Bridge v2. Each module's migration is independently idempotent and keyed in `MIGRATION_LOG`. New non-default data is never overwritten by old defaults. Legacy data is archived only after verification passes.

### 3.9 Bridge v2 contract

```
Request : { "v":1, "id":"<uuid>", "m":"<allow-listed method>", "p":{...} }
Response: { "v":1, "id":"<same>", "ok":true|false, "d":{...}, "e":{"code":"E_*","msg":"generic"} }
```

Rules: method allow-list only; schema version and max payload size (e.g. 1 MB) enforced; every payload validated; DB work off the main thread; response posted on the UI thread; no raw SQL or generic "query" method; keep `allowFileAccess=false`, `allowContentAccess=false`, asset-loader origin, safe external-URL handling. The WebView keeps UI state only; localStorage becomes a disposable cache.

### 3.10 Diagnostics pipeline (privacy by construction)

```mermaid
flowchart LR
  EV[Typed DiagEvent - allow-listed fields only] --> RB[(Ring buffer, in memory)]
  EV --> FL[(Bounded JSONL file, app-private)]
  RB --> EXP[Export]
  FL --> EXP
  EXP --> ZIP[diagnostics zip: log.jsonl, health.json, manifest.json]
  ZIP --> SAF2[User-chosen location]
  EV -. "no free text, no user content" .-> X((blocked by type system))
```

---

## 4. Diagnostics specification

**Goal:** the export is a complete record of *what the app did and whether it worked*, never *what the user has*.

### 4.1 Event schema (the only shape that can be logged)

```json
{"t":12345678,"lvl":"I","cat":"MIGRATION","ev":"module_done","mod":"finance","res":"ok","dur":42,"n":128,"code":null}
```

| Field | Rule |
|---|---|
| `t` | Milliseconds since process start (relative); one absolute export time in the manifest |
| `lvl` | D / I / W / E |
| `cat` | Enum: STARTUP, DB, MIGRATION, SETTINGS, PERMISSION, PORT, BRIDGE, BRAINY, ISLAND, ALARM, BACKUP, RESTORE, STEPS, DAYHUB, SELFTEST |
| `ev` | Enum constant, never a built string |
| `mod` | Module id enum |
| `res` | ok / fail / skip / denied / unavailable |
| `dur` | Duration ms |
| `n` | Counts only (rows, bytes, items) |
| `code` | Error code enum (`E_DB_MIGRATION`, `E_PORT_INCOMPATIBLE`…), never exception messages |

The logger API accepts **only enums and numbers**, so `log("text")` and `log(exception.message)` are impossible by compilation.

### 4.2 What it must cover (functionality log)

Startup sequence and timings · DB open, integrity check, schema version · every migration step and result · settings loads and validation failures · permission checks (boolean per access, with state names) · every port connection check and every event dispatched (source, destination, port id, ok/fail) · bridge calls (method enum, duration, result code) · Brainy lifecycle (service connected/unbound, tracking on/off, batches flushed, **counts only**, no per-event detail) · Island show/hide · alarm schedule/reconcile/fire results · step worker runs · backup/restore stages with counts · Day Hub close operations (idempotency hits, double-bank prevented) · self-test results.

### 4.3 Never logged (hard list)

Notes, voice content or filenames, transaction amounts/descriptions/categories, habit names, investment names, planner task titles, profile name, currency/goal values, URLs or addresses from browsers, installed or tracked **package names** (use platform enum or `other`), device identifiers (IMEI, Android ID, ad ID, serials, MAC), account/email/phone, location, clipboard, exception messages and stack traces containing user strings (export only exception *class names* mapped to enum codes), raw scroll/accessibility events, file paths containing user-chosen names.

### 4.4 Diagnostics screen (Settings → Diagnostics)

Run **Self-test** (executes each module's health probe and every connection check, writes results) · **Module health** table · **Connection validation** · **Migration status** · **Database health** · **Export full diagnostic log** (SAF save, zip) · **Clear log**. Export also contains `health.json` (module status matrix, permission state matrix, schema version, app version, OS API level) and `manifest.json`. Log is bounded (e.g. 2 MB / 14 days rolling), app-private, and only leaves the device when the user exports it.

### 4.5 Privacy tests (mandatory gate)

A **canary test** seeds the database with recognisable fake personal data (e.g. `CANARY_NOTE_7731`, `CANARY_NAME`, `CANARY_AMOUNT_98765`, a fake URL and package name), runs the full app flow (migration, all module actions, backup, restore, self-test, export), then asserts the exported diagnostic archive contains **none** of the canary strings and that every line validates against the schema. A second lint-style test fails the build if the logger is called with a non-enum string argument.

---

## 5. Stages and gates (all run inside the one command)

Each stage ends with `./gradlew testDebugUnitTest assembleDebug`. A stage is **not done** until its gate passes; on failure, fix and re-run; never skip.

| Stage | Work | Gate |
|---|---|---|
| **S0 Safety net** | Git branch + clean-tree check; Gradle baseline build; existing 3 test classes pass; full-coverage legacy snapshot exporter (all stores incl. voice, tones) | Baseline green; snapshot round-trips |
| **S1 Inventory** | `docs/architecture/STORAGE_INVENTORY.md`: every key, file, pref, owner, readers, writers, size bound | Table complete; every manifest permission mapped to a feature |
| **S2 Database** | KSP + Room (versions compatible with Kotlin 1.9.24), entities, DAOs, repositories, converters, migrations, schema export | DAO + migration tests pass |
| **S3 Diagnostics core** | Typed logger, ring buffer + JSONL, export zip, canary + schema tests (built early so every later stage is logged) | Canary test passes |
| **S4 Legacy migration** | Native receivers + one-time web exporter, per-module idempotent migration, interruption recovery, archive-not-delete | Migration, idempotency and interrupt tests pass |
| **S5 Bridge v2 + data integration** | Async bridge, allow-list, size limits; web layer switched from localStorage to bridge; Brainy/steps/alarms use repositories with cache + batched writes | Round-trip tests; Brainy cache test |
| **S6 Settings engine + Center** | Registry, typed accessors, More → Settings Center (6 categories), shortcuts redirect to it, Brainy/Island settings moved in | Settings tests; no duplicate setting sources |
| **S7 Permissions** | Registry, safety check (4 states), onboarding (new installs), live re-checks | All permission-matrix tests pass |
| **S8 Ports + connections** | Module registry, port contracts, hub, existing wiring, read-only graph with enable/disable | Connection tests incl. invalid/missing/cycle; Day Hub double-bank test |
| **S9 Backup v3** | Zip format, validation, rollback, legacy v2 import, SAF UI | Round-trip, corruption, rollback, repeat-import tests |
| **S10 Docs + packaging** | `docs/architecture/SANDPIPER_SYSTEM_SCHEMATIC.md` generated from the real code; confirm it is absent from the APK | `unzip -l app-debug.apk` shows no docs |
| **S11 Final verification** | Full test run, lint, debug APK, final report | All gates green |

---

## 6. Settings categories (More → Settings Center)

General (profile, currency, goals, appearance, data prefs) · Segments (Finance, Planner, Zen, Focus Timer, Fitness, Brainy, Brainy Island, Notes, Habits, Water, Sleep, Investments, Steps, Alarms) · Integrations & Connections · Permissions & Privacy · Data & Backup · Diagnostics. Each setting: id, module, category, type, default, validation, required permission, restart-needed flag, schema version. Typed accessors only; no module reads raw rows.

---

## 7. Test matrix

| Area | Must cover |
|---|---|
| Database | Init, CRUD, transactions, relations, every migration |
| Migration | Each legacy source, voice, legacy backup, interruption, idempotency |
| Ports | Valid, invalid, missing module/dependency, incompatible version, disabled, cycle, recovery |
| Permissions | All granted, optional denied, critical denied, revoked later, no sensor, no notifications, special access unavailable |
| Backup | Export, import, round trip, corrupt archive, missing media, legacy v2, bad version, repeat import (no duplicates), rollback |
| Integration | Island = Brainy count; Fitness gets Brainy stats; Planner/Zen/Fitness → Day Hub; reminders reach scheduler; no double bonus; settings reflected everywhere |
| Diagnostics | Canary no-leak, schema validity, bounded size, export contents |
| Existing | `BrainyAppsTest`, `SwipeDetectorTest`, `WebReelsTest` untouched and green |
| Packaging | APK contains no `docs/`; no `INTERNET` permission in the merged manifest |

---

## 8. Definition of done and honest reporting

Done only if: all gates green; `./gradlew assembleDebug` produces an APK; merged manifest has no `INTERNET`; schematic absent from the APK; canary test passes. The final report must label each claim as **compiled**, **unit-tested** or **device-tested**, and must say plainly if anything was not run (for example, no physical-device test happened). Never invent results.

---

## 9. Risk register

| Risk | Mitigation |
|---|---|
| Web state is in WebView storage that Kotlin cannot read | One-time JS exporter + native receiver; snapshot first |
| Brainy hot path vs database | In-memory cache, batched flush, bounded reel table |
| KSP/Room version mismatch | Pin KSP `1.9.24-1.0.x` compatible with Kotlin 1.9.24 |
| Interrupted migration | Per-module idempotent steps + `MIGRATION_LOG` |
| Alarm loss during migration/restore | Reconcile scheduler from DB after both |
| Over-engineering | Thin core, documents for evolving data, no new frameworks |
| Logging leaks | Type-restricted logger + canary test + lint gate |

---

## 10. Explicit non-goals

Cloud sync, accounts, analytics, ads, Hilt/Koin, event-bus libraries, dynamic code loading, password-protected backups (deferred), editable drag-and-drop graph (deferred), full relational normalisation of planner/fitness (later, per module).

---

## 14. THE ONE COMMAND (paste this as a single message into Claude Code)

```text
You are a senior Android architect and Kotlin engineer working in the existing Sandpiper project
(package com.vastanzil.sandpiper; AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7, Java 17, compileSdk/targetSdk 34,
minSdk 29; Kotlin shell + WebView UI; offline-first). Execute the entire plan in
docs/architecture/SANDPIPER_CENTRAL_BACKEND_PLAN.md in ONE continuous run, stages S0 through S11 in order.

RULES
1. Implement; do not propose. Preserve every existing feature, UI behaviour, reward calculation and test.
2. Before editing: inspect git status, create branch `central-backend`, protect any pre-existing changes,
   commit after each stage. No destructive git operations.
3. After EVERY stage run: ./gradlew testDebugUnitTest assembleDebug. If it fails, fix and re-run.
   Do not start the next stage until the current gate in section 5 passes.
   If a gate cannot pass, STOP and report the exact blocker; never skip or fake it.
4. Never delete legacy data before migration is verified; archive instead. No destructive Room migrations.
5. Never add the INTERNET permission, cloud, accounts, analytics, ads, DI/event-bus frameworks or dynamic code loading.
   Keep allowFileAccess=false and allowContentAccess=false; use the Storage Access Framework for files.
6. PRIVACY: the diagnostics logger accepts only enums and numbers (see plan section 4). Never log notes, amounts,
   names, titles, URLs, package names of user-selected apps, device identifiers, exception messages or raw events.
   Build the logger in S3 and use it in every later stage. The canary-leak test is a mandatory gate.
7. Follow the Mermaid schematics and tables in the plan exactly; if the real code forces a deviation, document why
   in the schematic. Document only what is actually implemented.
8. Diagnostics (Settings -> Diagnostics) must include: self-test, module health, connection validation, migration
   status, database health, and "Export full diagnostic log" (zip via SAF) covering every functionality listed in
   plan section 4.2, with no personal data.
9. Final deliverables: working code, all tests, docs/architecture/STORAGE_INVENTORY.md,
   docs/architecture/SANDPIPER_SYSTEM_SCHEMATIC.md (developer-only, verified absent from the APK via unzip -l),
   a debug APK, and a final report listing: architecture, entities/DAOs/repositories, every legacy source migrated
   (and any that could not be), settings categories, final port table, permission inventory, backup format,
   tests run with real results, build result, remaining issues.
10. Label every claim compiled / unit-tested / device-tested. If you could not run Gradle or a device, say so
    explicitly. Do not invent results.

Begin with S0 now and continue until S11 is complete or a gate blocks you.
```

---

*Plan version 1.0. Update this file and the generated schematic whenever the architecture changes.*
