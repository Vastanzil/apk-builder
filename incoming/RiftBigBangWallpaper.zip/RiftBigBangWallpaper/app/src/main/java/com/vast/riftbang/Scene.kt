package com.vast.riftbang

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random
import kotlin.math.PI

private fun argb(a: Float, rgb: Int): Int = ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24) or (rgb and 0xFFFFFF)
private fun rgbOf(r: Int, g: Int, b: Int): Int = (r shl 16) or (g shl 8) or b

/**
 * One cycle (~102 s):
 *  0-4 s   spacetime rift opens, mass pours through
 *  0-11 s  Oppenheimer-Snyder collapse of a 9 r_s star, gravitational redshift, horizon
 *  11-22 s black hole: lensed sky, Keplerian accretion disk with Doppler beaming
 *  22-34 s Einstein-Rosen throat (Flamm paraboloid) pinches off, bounce
 *  34-102  Big Bang -> LCDM expansion -> now (13.8 Gyr) -> far future, then a new random universe
 */
class Scene {
    companion object {
        const val SHOW_HUD = true          // set false for a clean wallpaper
        const val TIME_SCALE = 1.0         // >1 = faster
        const val T_HORIZON = 11.0
        const val T_RIFT = 22.0
        const val T_PINCH = 33.0
        const val T_BANG = 34.0
        const val T_END = 68.0             // seconds after the bang
        private val KT = doubleArrayOf(0.0, 2.2, 9.0, 13.0, 18.0, 22.0, 27.0, 36.0, 49.0, 53.0, 62.0)
        private val KL = doubleArrayOf(-30.0, -28.0, -12.0, -6.0, -3.2, -2.4, -1.6, -0.8, -0.04, 0.04, 0.3)
        private val INCL = 78.0 * PI / 180.0
        private val COS_I = cos(INCL)
        private val SIN_I = sin(INCL)
        private const val THETA_E = 2.598          // photon-sphere critical impact parameter, in r_s
        private const val NS = 420
        private const val ND = 4800
        private const val NB_DISK = 56
        private const val CK = 128
    }

    private var w = 0
    private var h = 0
    private var cx = 0f
    private var cy = 0f
    private var rsPx = 1f
    private var u1 = 1f
    private var t = 0.0

    private val ADD = PorterDuffXfermode(PorterDuff.Mode.ADD)

    // ---- starfield ----
    private val sdx = FloatArray(NS)
    private val sdy = FloatArray(NS)
    private val slv = IntArray(NS)
    private val scl = IntArray(NS)
    private val starBase = floatArrayOf(0.45f, 0.7f, 1.0f)
    private val starRgb = intArrayOf(rgbOf(255, 255, 255), rgbOf(170, 200, 255), rgbOf(255, 235, 180), rgbOf(255, 190, 150))
    private val starPaints = Array(12) { Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; xfermode = ADD } }
    private val starBatch = Batcher(NS, 12)

    // ---- accretion disk ----
    private val dr = FloatArray(ND)
    private val dphi = FloatArray(ND)
    private val dh = FloatArray(ND)
    private val diskPaints = Array(NB_DISK) { Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; xfermode = ADD } }
    private val diskFar = Batcher(ND, NB_DISK)
    private val diskNear = Batcher(ND, NB_DISK)
    private val diskAlpha = floatArrayOf(0.18f, 0.35f, 0.6f, 0.95f)

    // ---- rift ----
    private val crackX = FloatArray(CK + 1)
    private val crackPath = Path()
    private val riftPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; xfermode = ADD
    }

    // ---- misc paints ----
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val addFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = ADD }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; xfermode = ADD }
    private val funnelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; xfermode = ADD }
    private val funnelPath = Path()
    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    // ---- universe (Zel'dovich approximation on a periodic box of width 1, height = aspect) ----
    private var nU = 0
    private var uqx = FloatArray(0)
    private var uqy = FloatArray(0)
    private var upx = FloatArray(0)
    private var upy = FloatArray(0)
    private var upxx = FloatArray(0)
    private var upxy = FloatArray(0)
    private var upyy = FloatArray(0)
    private var uBatch = Batcher(1, 6)
    private val uPaints = Array(6) { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; xfermode = ADD } }
    private val galRgb = intArrayOf(
        rgbOf(90, 60, 190), rgbOf(70, 100, 220), rgbOf(120, 160, 255),
        rgbOf(200, 215, 255), rgbOf(255, 215, 150), rgbOf(255, 255, 255)
    )
    private val galA = floatArrayOf(0.10f, 0.20f, 0.38f, 0.58f, 0.80f, 1.0f)

    fun resize(width: Int, height: Int) {
        w = width; h = height
        cx = w / 2f; cy = h * 0.46f
        rsPx = w * 0.05f
        u1 = w / 1000f
        seedCycle()
    }

    private fun seedCycle() {
        t = 0.0
        genStars(); genDisk(); genCrack()
        seedUniverse()
    }

    // ======================= seeding =======================

    private fun genStars() {
        for (i in 0 until NS) {
            sdx[i] = (Random.nextFloat() - 0.5f) * w * 1.5f
            sdy[i] = (Random.nextFloat() - 0.5f) * h * 1.25f
            val r = Random.nextFloat()
            slv[i] = if (r < 0.7f) 0 else if (r < 0.95f) 1 else 2
            scl[i] = Random.nextInt(4)
        }
    }

    private fun genDisk() {
        for (i in 0 until ND) {
            // surface density ~ 1/r between ISCO (3 r_s) and 8 r_s
            dr[i] = (3.0 * (8.0 / 3.0).pow(Random.nextDouble())).toFloat()
            dphi[i] = (Random.nextDouble() * 2 * PI).toFloat()
            dh[i] = (Random.nextFloat() - 0.5f) * 0.10f
        }
    }

    private fun genCrack() {
        crackX.fill(0f)
        fun mid(lo: Int, hi: Int, disp: Float) {
            if (hi - lo < 2) return
            val m = (lo + hi) / 2
            crackX[m] = (crackX[lo] + crackX[hi]) / 2f + (Random.nextFloat() - 0.5f) * disp
            mid(lo, m, disp * 0.58f); mid(m, hi, disp * 0.58f)
        }
        mid(0, CK, 1.0f)
    }

    private fun seedUniverse() {
        val aspect = h.toDouble() / w
        val nx = 96
        val ny = max(1, (nx * aspect).roundToInt())
        val n = nx * ny
        if (n != nU) {
            nU = n
            uqx = FloatArray(n); uqy = FloatArray(n); upx = FloatArray(n); upy = FloatArray(n)
            upxx = FloatArray(n); upxy = FloatArray(n); upyy = FloatArray(n)
            uBatch = Batcher(n, 6)
        }
        // Gaussian random field: random Fourier modes, P(k) ~ k^-2.6 (amplitude k^-1.3), Rayleigh amplitudes
        val mWanted = 56
        val kx = DoubleArray(mWanted); val ky = DoubleArray(mWanted); val k2 = DoubleArray(mWanted)
        val amp = DoubleArray(mWanted); val ph = DoubleArray(mWanted)
        var m = 0
        var guard = 0
        while (m < mWanted && guard++ < 20000) {
            val mi = Random.nextInt(-7, 8)
            val ni = Random.nextInt(-16, 17)
            val kX = 2 * PI * mi
            val kY = 2 * PI * ni / aspect
            val k = hypot(kX, kY)
            if (k < 2 * PI * 1.0 || k > 2 * PI * 7.5) continue
            kx[m] = kX; ky[m] = kY; k2[m] = k * k
            amp[m] = k.pow(-1.3) * sqrt(-2.0 * ln(Random.nextDouble().coerceAtLeast(1e-9)))
            ph[m] = Random.nextDouble() * 2 * PI
            m++
        }
        var s2 = 0.0
        for (i in 0 until m) s2 += amp[i] * amp[i] / 2
        val norm = 1.15 / sqrt(max(s2, 1e-12))     // rms density contrast today ~ 1.15 -> caustics / filaments
        for (i in 0 until m) amp[i] *= norm

        for (iy in 0 until ny) for (ix in 0 until nx) {
            val i = iy * nx + ix
            val x = (ix + Random.nextDouble()) / nx
            val y = (iy + Random.nextDouble()) / ny * aspect
            var psx = 0.0; var psy = 0.0; var pxx = 0.0; var pxy = 0.0; var pyy = 0.0
            for (k in 0 until m) {
                val th = kx[k] * x + ky[k] * y + ph[k]
                val f = amp[k] / k2[k]
                val sn = sin(th) * f
                val cs = cos(th) * f
                psx -= kx[k] * sn; psy -= ky[k] * sn           // psi = -sum k/|k|^2 A sin(k.q + phi)
                pxx -= kx[k] * kx[k] * cs                        // grad psi
                pxy -= kx[k] * ky[k] * cs
                pyy -= ky[k] * ky[k] * cs
            }
            uqx[i] = x.toFloat(); uqy[i] = y.toFloat()
            upx[i] = psx.toFloat(); upy[i] = psy.toFloat()
            upxx[i] = pxx.toFloat(); upxy[i] = pxy.toFloat(); upyy[i] = pyy.toFloat()
        }
    }

    // ======================= update =======================

    fun update(dtReal: Double) {
        val dt = dtReal * TIME_SCALE
        t += dt
        if (t >= T_BANG + T_END) { seedCycle(); return }
        if (t > T_HORIZON - 1.0 && t < T_PINCH) {
            // Keplerian rotation, Omega = sqrt(GM / r^3), GM = r_s/2;  1 code unit = 0.054 s
            val k = (dt / 0.054).toFloat()
            for (i in 0 until ND) {
                val r = dr[i]
                dphi[i] += k * sqrt(0.5f / (r * r * r))
                if (dphi[i] > 6.2831855f) dphi[i] -= 6.2831855f
                // slow viscous inflow, recycled at the outer edge
                var rr = r - (0.03f / sqrt(r)) * dt.toFloat()
                if (rr < 3.0f) rr = 7.2f + Random.nextFloat() * 0.8f
                dr[i] = rr
            }
        }
    }

    private fun laAt(tb: Double): Double {
        if (tb <= KT[0]) return KL[0]
        for (i in 1 until KT.size) {
            if (tb <= KT[i]) {
                val f = (tb - KT[i - 1]) / (KT[i] - KT[i - 1])
                return KL[i - 1] + (KL[i] - KL[i - 1]) * f
            }
        }
        return KL[KL.size - 1]
    }

    // ======================= draw =======================

    fun draw(c: Canvas) {
        if (w == 0) return
        c.drawColor(Color.BLACK)
        val tb = t - T_BANG
        if (t < T_BANG) drawBlackHole(c) else drawUniverse(c, laAt(tb))

        // white flash around the bounce, black fade at the very end
        val whiteA = if (t < T_BANG) smooth(t, T_PINCH, T_BANG) else 1.0 - smooth(t, T_BANG + 0.2, T_BANG + 3.2)
        if (whiteA > 0.002) {
            fillPaint.shader = null; fillPaint.xfermode = null
            fillPaint.color = argb(whiteA.toFloat(), rgbOf(255, 248, 240))
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fillPaint)
        }
        val endA = if (t > T_BANG) smooth(tb, T_END - 6.0, T_END) else 0.0
        if (endA > 0.002) {
            fillPaint.color = argb(endA.toFloat(), 0x000000)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fillPaint)
        }
        if (SHOW_HUD) drawHud(c, (1.0 - whiteA) * (1.0 - endA))
    }

    // ----------------------- black hole phase -----------------------

    private fun drawBlackHole(c: Canvas) {
        val starsA = (1.0 - smooth(t, T_PINCH - 1.0, T_BANG)).toFloat()
        val lensGain = smooth(t, 1.0, 4.0).toFloat()
        drawStars(c, THETA_E.toFloat() * rsPx * lensGain, starsA)
        drawRift(c)

        val diskA = (smooth(t, T_HORIZON + 0.2, T_HORIZON + 5.0) * (1.0 - smooth(t, T_RIFT, T_RIFT + 3.0))).toFloat()
        if (diskA > 0.01f) {
            computeDisk()
            for (k in 0 until NB_DISK) {
                val tIdx = k / 4; val lv = k % 4
                val temp = 2500.0 * (24000.0 / 2500.0).pow(tIdx / 13.0)
                diskPaints[k].strokeWidth = 3.4f * u1
                diskPaints[k].color = argb(diskAlpha[lv] * diskA, Light.blackbody(temp))
            }
            diskFar.flush(c, diskPaints)
        }

        // shadow of the black hole (b_crit = 3*sqrt(3)/2 r_s)
        val shR = THETA_E.toFloat() * rsPx
        val shA = smooth(t, 2.5, 4.5).toFloat() * starsA
        if (shA > 0.01f) {
            fillPaint.shader = null; fillPaint.xfermode = null
            fillPaint.color = argb(shA, 0x000000)
            c.drawCircle(cx, cy, shR, fillPaint)
        }

        drawStar(c)

        // photon ring
        val ringA = (smooth(t, T_HORIZON, T_HORIZON + 2.5) * (1.0 - smooth(t, T_RIFT + 3.0, T_PINCH))).toFloat()
        if (ringA > 0.01f) {
            ringPaint.strokeWidth = 0.55f * rsPx; ringPaint.color = argb(0.07f * ringA, rgbOf(255, 220, 180))
            c.drawCircle(cx, cy, shR + 0.2f * rsPx, ringPaint)
            ringPaint.strokeWidth = 0.10f * rsPx; ringPaint.color = argb(0.55f * ringA, rgbOf(255, 235, 210))
            c.drawCircle(cx, cy, shR + 0.04f * rsPx, ringPaint)
        }

        if (diskA > 0.01f) diskNear.flush(c, diskPaints)

        // Einstein-Rosen throat
        val funA = smooth(t, T_RIFT, T_RIFT + 3.0).toFloat()
        if (funA > 0.01f) {
            val p = smooth(t, T_RIFT + 3.0, T_PINCH)
            drawFunnel(c, funA, 1.0 - 0.97 * p)
            val core = smooth(t, T_RIFT + 3.0, T_PINCH + 0.6).toFloat()
            if (core > 0.01f) {
                val rad = rsPx * (3.5f + 3f * core)
                addFill.shader = RadialGradient(cx, cy, rad, argb(0.9f * core, rgbOf(255, 250, 245)), argb(0f, rgbOf(150, 190, 255)), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, rad, addFill)
                addFill.shader = null
            }
        }
    }

    private fun drawStars(c: Canvas, thetaE: Float, a: Float) {
        if (a <= 0.01f) return
        for (i in 0 until NS) {
            val dx = sdx[i]; val dy = sdy[i]
            val beta = hypot(dx, dy)
            if (beta < 1f) continue
            var th = beta
            var lv = slv[i]
            if (thetaE > 1f) {
                val hb = beta / 2f
                th = hb + sqrt(hb * hb + thetaE * thetaE)                 // primary image (thin lens)
                val u = beta / thetaE
                val mu = (u * u + 2f) / (2f * u * sqrt(u * u + 4f)) + 0.5f   // magnification
                if (mu > 1.6f) lv = min(2, lv + 1)
            }
            val k = th / beta
            val x = cx + dx * k
            val y = cy + dy * k
            if (x < -10f || x > w + 10f || y < -10f || y > h + 10f) continue
            starBatch.add(x, y, scl[i] * 3 + lv)
        }
        for (k in 0 until 12) {
            val lv = k % 3
            starPaints[k].strokeWidth = (1.5f + 1.1f * lv) * u1 * 1.3f
            starPaints[k].color = argb(starBase[lv] * a, starRgb[k / 3])
        }
        starBatch.flush(c, starPaints)
    }

    private fun drawRift(c: Canvas) {
        val grow = smooth(t, 0.0, 3.0).toFloat()
        val a = smooth(t, 0.0, 1.0).toFloat() * (1f - smooth(t, 3.6, 6.5).toFloat())
        if (a <= 0.01f) return
        val len = 0.20f * h * grow
        crackPath.reset()
        for (i in 0..CK) {
            val x = cx + crackX[i] * 0.10f * w * grow
            val y = cy + (-1f + 2f * i / CK) * len
            if (i == 0) crackPath.moveTo(x, y) else crackPath.lineTo(x, y)
        }
        riftPaint.strokeWidth = 16f * u1; riftPaint.color = argb(0.18f * a, rgbOf(140, 190, 255))
        c.drawPath(crackPath, riftPaint)
        riftPaint.strokeWidth = 5f * u1; riftPaint.color = argb(0.5f * a, rgbOf(200, 225, 255))
        c.drawPath(crackPath, riftPaint)
        riftPaint.strokeWidth = 1.8f * u1; riftPaint.color = argb(a, rgbOf(255, 255, 255))
        c.drawPath(crackPath, riftPaint)
        val rad = 0.16f * w * (0.4f + 0.6f * grow)
        addFill.shader = RadialGradient(cx, cy, rad, argb(0.35f * a, rgbOf(150, 190, 255)), argb(0f, rgbOf(150, 190, 255)), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad, addFill)
        addFill.shader = null
    }

    private fun drawStar(c: Canvas) {
        val u = min(1.0, 0.9836 * t / T_HORIZON)
        val r = Collapse.radius(u)
        if (r <= 1.0) return
        val gz = sqrt(max(0.0, 1.0 - 1.0 / r))                        // sqrt(1 - r_s/R): gravitational redshift factor
        val rApp = ((if (r > 1.5) r / gz else THETA_E) * rsPx).toFloat()             // apparent radius seen from infinity
        val tObs = 6000.0 * (Collapse.R0 / r) * gz                        // adiabatic heating, then redshifted
        val bb = Light.blackbody(tObs)
        val a = (smooth(t, 2.2, 4.5) * gz.pow(1.5)).toFloat()
        if (a < 0.01f) return
        val glowR = rApp * 1.7f
        addFill.shader = RadialGradient(cx, cy, glowR, argb(0.28f * a, bb), argb(0f, bb), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, glowR, addFill)
        addFill.shader = null
        val dark = rgbOf(((bb shr 16) and 255) * 6 / 10, ((bb shr 8) and 255) * 6 / 10, (bb and 255) * 6 / 10)
        fillPaint.xfermode = null
        fillPaint.shader = RadialGradient(
            cx, cy, rApp, intArrayOf(argb(a, bb), argb(a * 0.85f, dark), argb(0f, dark)),
            floatArrayOf(0f, 0.82f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rApp, fillPaint)
        fillPaint.shader = null
    }

    private fun computeDisk() {
        val te = THETA_E
        for (i in 0 until ND) {
            val r = dr[i].toDouble()
            val phi = dphi[i].toDouble()
            val cph = cos(phi); val sph = sin(phi)
            val v = sqrt(0.5 / (r - 1.0))                                // circular orbit speed seen by a static observer
            val gam = 1.0 / sqrt(1.0 - v * v)
            val vn = -v * cph * SIN_I                                    // velocity component toward the observer
            val dopp = 1.0 / (gam * (1.0 - vn))
            val gg = sqrt(1.0 - 1.0 / r) * dopp                          // Doppler x gravitational shift
            val inten = 0.55 * gg.pow(3.0) * (3.0 / r).pow(0.35)         // beaming
            if (inten < 0.05) continue
            val temp = 20000.0 * r.pow(-0.75) * gg                       // T(r) ~ r^-3/4, shifted
            val tIdx = ((ln(temp) - ln(2500.0)) / (ln(24000.0) - ln(2500.0)) * 13.0).roundToInt().coerceIn(0, 13)
            var lv = if (inten < 0.12) 0 else if (inten < 0.3) 1 else if (inten < 0.6) 2 else 3
            val x = r * cph
            val z = r * sph
            val yv = dh[i] * r
            var sx = x
            var sy = -z * COS_I - yv * SIN_I
            if (z > 0) {
                // far side of the disk: light is bent over the hole (primary image of the thin lens)
                val beta = hypot(sx, sy)
                if (beta < 1e-4) continue
                val hb = beta / 2
                val th = hb + sqrt(hb * hb + te * te)
                val u = beta / te
                val mu = (u * u + 2) / (2 * u * sqrt(u * u + 4)) + 0.5
                if (mu > 1.8 && lv < 3) lv++
                val k = th / beta
                sx *= k; sy *= k
                diskFar.add((cx + sx * rsPx).toFloat(), (cy + sy * rsPx).toFloat(), tIdx * 4 + lv)
            } else {
                diskNear.add((cx + sx * rsPx).toFloat(), (cy + sy * rsPx).toFloat(), tIdx * 4 + lv)
            }
        }
    }

    /** Flamm's paraboloid z = 2 sqrt(r_s (r - r_s)): the spatial geometry of the Einstein-Rosen bridge, two sheets. */
    private fun drawFunnel(c: Canvas, alpha: Float, b: Double) {
        val rsF = 0.075f * w
        val sinE = 0.766f; val cosE = 0.643f
        val kr = 12; val seg = 56; val nm = 16
        val sig = DoubleArray(kr + 1) { 3.8 * (it / kr.toDouble()).pow(1.5) }
        funnelPaint.strokeWidth = max(1.1f, 1.1f * u1)
        for (sheet in 0..1) {
            val sgn = if (sheet == 0) 1f else -1f
            val sa = alpha * (if (sheet == 0) 0.65f else 0.4f)
            funnelPaint.color = argb(sa, rgbOf(140, 190, 255))
            funnelPath.reset()
            for (j in 0..kr) {
                val rho = (b + sig[j]).toFloat()
                val hh = (2.0 * sqrt(sig[j])).toFloat() * sgn
                for (s in 0..seg) {
                    val th = (2.0 * PI * s / seg).toFloat()
                    val x = cx + rho * cos(th) * rsF
                    val y = cy + (rho * sin(th) * sinE - hh * cosE) * rsF
                    if (s == 0) funnelPath.moveTo(x, y) else funnelPath.lineTo(x, y)
                }
            }
            c.drawPath(funnelPath, funnelPaint)
            funnelPath.reset()
            for (m in 0 until nm) {
                val th = (2.0 * PI * m / nm).toFloat()
                for (j in 0..kr) {
                    val rho = (b + sig[j]).toFloat()
                    val hh = (2.0 * sqrt(sig[j])).toFloat() * sgn
                    val x = cx + rho * cos(th) * rsF
                    val y = cy + (rho * sin(th) * sinE - hh * cosE) * rsF
                    if (j == 0) funnelPath.moveTo(x, y) else funnelPath.lineTo(x, y)
                }
            }
            c.drawPath(funnelPath, funnelPaint)
        }
    }

    // ----------------------- universe phase -----------------------

    private fun drawUniverse(c: Canvas, la: Double) {
        val a = 10.0.pow(la)
        val s = 1.3 * 10.0.pow((la + 3.0) * 0.045)                    // on-screen scale of the comoving box (camera zoom)
        val sF = s.toFloat()
        val scale = w * sF
        val aspect = h.toFloat() / w
        val ox = cx - 0.5f * scale
        val oy = cy - 0.5f * aspect * scale
        val rc = 0.5f * w * sF * (1f + 5f * smooth(s, 0.7, 1.0).toFloat())
        val rc2 = rc * rc

        // radiation: blackbody of the primordial plasma, then the red CMB afterglow
        val tK = Cosmo.tempK(la)
        val bbRgb = Light.blackbody(tK)
        val wRec = smooth(la, -3.3, -2.8)
        val glowA = (0.9 * (1 - wRec) + 0.05 * (1 - smooth(la, -2.6, -1.4))).toFloat()
        val gR = max(rc * 1.2f, 30f * u1)
        if (glowA > 0.003f) {
            addFill.shader = RadialGradient(cx, cy, gR, argb(glowA, bbRgb), argb(0f, bbRgb), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, gR, addFill)
            if (s < 1.0) {
                val hR = gR * 3.2f
                addFill.shader = RadialGradient(cx, cy, hR, argb(glowA * 0.22f, bbRgb), argb(0f, bbRgb), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, hR, addFill)
            }
            addFill.shader = null
        }

        // matter: Zel'dovich displacement x = q + D(a) psi(q); density = 1 / |det(I + D grad psi)|
        val d = Cosmo.growthNorm(a).toFloat()
        val wCol = smooth(la, -3.0, -2.0).toFloat()
        val gate = smooth(la, -2.2, -1.7).toFloat()
        val plasmaA = (0.35 * (1 - wRec)).toFloat()
        val ps = max(1.6f, w / 480f)
        for (k in 0 until 6) {
            val sc = galRgb[k]
            val pr = (bbRgb shr 16) and 255; val pg = (bbRgb shr 8) and 255; val pb = bbRgb and 255
            val rr = (pr + (((sc shr 16) and 255) - pr) * wCol).toInt()
            val gg = (pg + (((sc shr 8) and 255) - pg) * wCol).toInt()
            val bl = (pb + ((sc and 255) - pb) * wCol).toInt()
            uPaints[k].strokeWidth = ps
            uPaints[k].color = argb(plasmaA + galA[k] * (0.08f + 0.92f * gate) * wCol.coerceAtLeast(0.0f), rgbOf(rr, gg, bl))
        }
        for (i in 0 until nU) {
            var x = uqx[i] + d * upx[i]
            x -= floor(x)
            var y = uqy[i] + d * upy[i]
            y -= floor(y / aspect) * aspect
            val sx = ox + x * scale
            val sy = oy + y * scale
            if (sx < -6f || sx > w + 6f || sy < -6f || sy > h + 6f) continue
            val dx = sx - cx; val dy = sy - cy
            if (dx * dx + dy * dy > rc2) continue
            val jx = 1f + d * upxx[i]; val jy = 1f + d * upyy[i]; val jxy = d * upxy[i]
            val rho = 1f / max(abs(jx * jy - jxy * jxy), 0.04f)
            val bin = if (rho < 0.5f) 0 else if (rho < 1.5f) 1 else if (rho < 3f) 2 else if (rho < 8f) 3 else if (rho < 25f) 4 else 5
            uBatch.add(sx, sy, bin)
        }
        uBatch.flush(c, uPaints)
    }

    // ----------------------- HUD -----------------------

    private fun drawHud(c: Canvas, a: Double) {
        if (a < 0.02) return
        val la = laAt(t - T_BANG)
        val pair = hudLines(la)
        val y = h * 0.885f
        hudPaint.textSize = w * 0.036f
        hudPaint.color = argb((0.85 * a).toFloat(), rgbOf(235, 240, 255))
        c.drawText(pair.first, w / 2f, y, hudPaint)
        hudPaint.textSize = w * 0.027f
        hudPaint.color = argb((0.6 * a).toFloat(), rgbOf(200, 215, 245))
        c.drawText(pair.second, w / 2f, y + w * 0.05f, hudPaint)
    }

    private fun hudLines(la: Double): Pair<String, String> {
        if (t < T_BANG) {
            if (t < 4.0) return Pair("Spacetime rift", "vacuum instability · mass pours through")
            if (t < T_HORIZON) {
                val r = Collapse.radius(min(1.0, 0.9836 * t / T_HORIZON))
                val gz = sqrt(max(1e-4, 1.0 - 1.0 / max(r, 1.0001)))
                val z = min(99.0, 1.0 / gz - 1.0)
                return Pair("Stellar core collapse", String.format(java.util.Locale.US, "R = %.1f r_s · gravitational redshift z = %.2f", r, z))
            }
            if (t < T_RIFT) return Pair("Black hole · event horizon", "M = 25 M☉ · r_s = 73.8 km · photon sphere 1.5 r_s")
            if (t < T_PINCH) return Pair("Einstein–Rosen throat", "wormhole pinch-off · singularity bounce")
            return Pair("Bounce", "t = 0 · density → Planck scale")
        }
        val ts = if (la < -28.0) "t < 10⁻³² s" else "t = " + Fmt.time(Cosmo.timeSec(la))
        val ep = Cosmo.epoch(la)
        val name = if (ep == "NOW") "Now · the present day" else ep
        val tempS = "T = " + Fmt.temp(Cosmo.tempK(la))
        val z = 1.0 / 10.0.pow(la) - 1.0
        val zs = if (z > 1e5) "" else if (z > 0.01) String.format(java.util.Locale.US, " · z = %.2f", z) else ""
        return Pair(name, "$ts · $tempS$zs")
    }
}
