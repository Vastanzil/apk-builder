package com.vast.riftbang

import android.graphics.Canvas
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import kotlin.math.min

class RiftBangWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = RiftEngine()

    inner class RiftEngine : Engine(), Choreographer.FrameCallback {

        private val TARGET_FPS = 60          // 30 = half the battery use
        private val minDt = 1.0 / TARGET_FPS - 0.002
        private val scene = Scene()
        private var visible = false
        private var lastNs = 0L

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            scene.resize(width, height)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            val ch = Choreographer.getInstance()
            ch.removeFrameCallback(this)
            if (v) { lastNs = 0L; ch.postFrameCallback(this) }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            super.onDestroy()
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            if (lastNs == 0L) lastNs = frameTimeNanos
            val dt = (frameTimeNanos - lastNs) / 1e9
            if (dt >= minDt) {
                lastNs = frameTimeNanos
                scene.update(min(dt, 0.05))
                draw()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun draw() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = try { holder.lockHardwareCanvas() } catch (e: Exception) { holder.lockCanvas() }
                if (c != null) scene.draw(c)
            } catch (e: Exception) {
                // surface not ready, skip frame
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
        }
    }
}
