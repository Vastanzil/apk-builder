package com.vast.riftbang

import android.graphics.Canvas
import android.graphics.Paint

/** Collects points tagged with a bucket (colour class), then draws each bucket with one drawPoints call. */
class Batcher(private val cap: Int, private val nb: Int) {
    private val xy = FloatArray(cap * 2)
    private val bk = IntArray(cap)
    private val cnt = IntArray(nb)
    private val off = IntArray(nb)
    private val pos = IntArray(nb)
    private val out = FloatArray(cap * 2)
    var n = 0
        private set

    fun add(x: Float, y: Float, b: Int) {
        if (n >= cap) return
        xy[n * 2] = x; xy[n * 2 + 1] = y
        bk[n] = b; cnt[b]++; n++
    }

    fun flush(c: Canvas, paints: Array<Paint>) {
        if (n == 0) return
        var s = 0
        for (b in 0 until nb) { off[b] = s; pos[b] = s; s += cnt[b] }
        for (i in 0 until n) {
            val p = pos[bk[i]]++
            out[p * 2] = xy[i * 2]; out[p * 2 + 1] = xy[i * 2 + 1]
        }
        for (b in 0 until nb) {
            val k = cnt[b]
            if (k > 0) c.drawPoints(out, off[b] * 2, k * 2, paints[b])
            cnt[b] = 0
        }
        n = 0
    }
}
