package com.vast.riftbang

import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.PI

fun smooth(x: Double, a: Double, b: Double): Double {
    val t = ((x - a) / (b - a)).coerceIn(0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)
}

/** Flat Lambda-CDM (Planck 2018 like): Friedmann equation, cosmic time table, linear growth factor. */
object Cosmo {
    const val H0 = 2.184e-18          // 67.4 km/s/Mpc in 1/s
    const val OR = 9.1e-5
    const val OM = 0.315
    const val OL = 0.685
    const val YR = 3.15576e7
    private const val LA0 = -31.0
    private const val LA1 = 1.0
    private const val N = 620
    private val logT = DoubleArray(N + 1)

    fun hubble(a: Double): Double = H0 * sqrt(OR / a.pow(4) + OM / a.pow(3) + OL)

    init {
        val step = (LA1 - LA0) / N
        val a0 = 10.0.pow(LA0)
        var t = a0 * a0 / (2.0 * H0 * sqrt(OR))        // radiation era start
        logT[0] = log10(t)
        var prev = 1.0 / hubble(a0)
        for (i in 1..N) {
            val cur = 1.0 / hubble(10.0.pow(LA0 + step * i))
            t += 0.5 * (prev + cur) * ln(10.0) * step   // dt = dln(a) / H
            prev = cur
            logT[i] = log10(t)
        }
    }

    /** cosmic time in seconds at log10(a) */
    fun timeSec(la: Double): Double {
        val x = ((la - LA0) / (LA1 - LA0) * N).coerceIn(0.0, N - 1e-9)
        val i = floor(x).toInt()
        val f = x - i
        return 10.0.pow(logT[i] * (1 - f) + logT[i + 1] * f)
    }

    fun tempK(la: Double): Double = 2.725 / 10.0.pow(la)

    private fun g(a: Double): Double {
        val e2 = OM / (a * a * a) + OL
        val om = OM / (a * a * a) / e2
        val ol = OL / e2
        return a * 2.5 * om / (om.pow(4.0 / 7.0) - ol + (1 + om / 2) * (1 + ol / 70))
    }

    /** linear growth factor D(a), normalised to D(1)=1 (Carroll-Press-Turner) */
    fun growthNorm(a: Double): Double = g(a) / g(1.0)

    fun epoch(la: Double): String {
        val t = tempK(la)
        return when {
            la < -28.0 -> "Inflation"
            t > 1e15 -> "Reheating · electroweak era"
            t > 1e12 -> "Quark–gluon plasma"
            t > 1e10 -> "Hadrons → leptons"
            t > 3e8 -> "Big Bang nucleosynthesis"
            la < -3.25 -> "Opaque photon–baryon plasma"
            la < -2.85 -> "Recombination · CMB released"
            la < -2.2 -> "Dark ages"
            la < -1.2 -> "Cosmic dawn · first stars"
            la < -0.2 -> "Galaxies and the cosmic web"
            la < -0.05 -> "Dark energy takes over"
            la < 0.05 -> "NOW"
            else -> "Future · accelerating expansion"
        }
    }
}

object Light {
    /** blackbody colour (Tanner Helland fit), packed 0xRRGGBB */
    fun blackbody(tK: Double): Int {
        val t = tK.coerceIn(1000.0, 40000.0) / 100.0
        val r = if (t <= 66) 255.0 else 329.698727446 * (t - 60).pow(-0.1332047592)
        val g = if (t <= 66) 99.4708025861 * ln(t) - 161.1195681661 else 288.1221695283 * (t - 60).pow(-0.0755148492)
        val b = if (t >= 66) 255.0 else if (t <= 19) 0.0 else 138.5177312231 * ln(t - 10) - 305.0447927307
        return (r.coerceIn(0.0, 255.0).toInt() shl 16) or (g.coerceIn(0.0, 255.0).toInt() shl 8) or b.coerceIn(0.0, 255.0).toInt()
    }
}

/** Oppenheimer–Snyder dust-ball collapse, units r_s = 1, G = c = 1/2 style (GM = 1/2). */
object Collapse {
    const val R0 = 9.0
    /** star surface radius (in r_s) for fraction u of the proper collapse time (u = 1 is the singularity) */
    fun radius(u: Double): Double {
        val target = u.coerceIn(0.0, 1.0) * PI          // eta + sin(eta) = pi * tau / tau_max
        var lo = 0.0
        var hi = PI
        repeat(40) {
            val m = 0.5 * (lo + hi)
            if (m + sin(m) < target) lo = m else hi = m
        }
        val eta = 0.5 * (lo + hi)
        return R0 / 2.0 * (1.0 + cos(eta))
    }
}

object Fmt {
    private const val SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹"
    fun sci(x: Double): String {
        if (x <= 0.0 || x.isNaN() || x.isInfinite()) return "0"
        var e = floor(log10(x)).toInt()
        var m = x / 10.0.pow(e)
        if (m >= 9.95) { m /= 10.0; e += 1 }
        val sign = if (e < 0) "⁻" else ""
        val digits = abs(e).toString().map { SUP[it - '0'] }.joinToString("")
        return String.format(Locale.US, "%.1f×10%s%s", m, sign, digits)
    }

    fun time(sec: Double): String {
        val yr = sec / Cosmo.YR
        return when {
            sec < 1.0 -> sci(sec) + " s"
            sec < 60.0 -> String.format(Locale.US, "%.1f s", sec)
            sec < 3600.0 -> String.format(Locale.US, "%.0f min", sec / 60.0)
            yr < 1.0 -> String.format(Locale.US, "%.0f days", sec / 86400.0)
            yr < 1e6 -> String.format(Locale.US, "%.0f yr", yr)
            yr < 1e9 -> String.format(Locale.US, "%.0f Myr", yr / 1e6)
            else -> String.format(Locale.US, "%.2f Gyr", yr / 1e9)
        }
    }

    fun temp(k: Double): String = when {
        k >= 1e5 -> sci(k) + " K"
        k >= 100.0 -> String.format(Locale.US, "%.0f K", k)
        else -> String.format(Locale.US, "%.3f K", k)
    }
}
