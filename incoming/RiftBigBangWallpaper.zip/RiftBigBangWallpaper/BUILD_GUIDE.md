# Rift to Big Bang: build guide

## Build the APK
1. Install Android Studio (latest stable): https://developer.android.com/studio
2. Unzip this project. File > Open > select the `RiftBigBangWallpaper` folder.
3. Wait for Gradle sync (first run downloads Gradle + Android SDK 34; accept licences).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) > "locate".
   File: `app/build/outputs/apk/debug/app-debug.apk`

## Install on the OnePlus 13R
1. Copy the APK to the phone, open it in Files, allow "Install unknown apps", install
   ("Install anyway" if Play Protect warns about an unsigned debug build).
2. Open the "Rift to Big Bang" app. It jumps to the wallpaper preview. Tap "Set wallpaper".
   (USB alternative: `adb install app-debug.apk`)

CLI build: `gradle wrapper --gradle-version 8.7` then `./gradlew assembleDebug` (JDK 17 + Android SDK needed).
Signed release: Build > Generate Signed Bundle / APK > APK.

## What you will see (one ~102 s cycle, then a brand-new random universe)
| Time | Scene | Physics used |
|------|-------|--------------|
| 0-4 s | Spacetime rift opens, mass arrives | schematic |
| 0-11 s | Star collapses to a black hole | Oppenheimer-Snyder dust collapse, gravitational redshift sqrt(1-rs/R), apparent radius R/sqrt(1-rs/R), blackbody colour |
| 11-22 s | Black hole, lensed sky, accretion disk | thin-lens equation, photon-sphere shadow 2.598 rs, Keplerian orbits, Doppler beaming, T ~ r^-3/4, far side of disk bent over the hole |
| 22-34 s | Einstein-Rosen throat pinches off, bounce | Flamm paraboloid z = 2 sqrt(rs(r-rs)), two sheets (bounce idea is a hypothesis, not established) |
| 34 s on | Big Bang, expansion to NOW (13.8 Gyr) and beyond | flat LCDM Friedmann equation (cosmic time integrated numerically), T = 2.725 K / a, blackbody plasma colour, recombination at ~370 kyr, linear growth factor D(a), Zel'dovich approximation for the cosmic web (density = 1/|det(I + D grad psi)|), periodic box |

Honest notes: the rift and the 2D projection of the cosmic web are schematic, the camera zoom is logarithmic, inflation is shown only as the first fast expansion, and the black-hole-to-universe bounce is speculative cosmology. Everything else follows the real equations.
Never repeats: black-hole mass profile, starfield, disk, rift crack and the entire density field (random Gaussian field) are re-rolled every cycle.

## Tweaks
`Scene.kt` (top of companion object): `SHOW_HUD` (epoch / time / temperature text, set false for clean look), `TIME_SCALE` (2.0 = twice as fast), key schedule `KT`/`KL` (expansion timeline).
`RiftBangWallpaperService.kt`: `TARGET_FPS` (60 smooth, 30 to save battery).
Universe detail: `nx = 96` in `seedUniverse()` (about 20k particles; raise for denser web, lower for battery).

## Troubleshooting
- Gradle JDK error: Settings > Build Tools > Gradle > Gradle JDK = 17 (bundled JBR).
- Not in the live wallpaper list: uninstall, reinstall, open the app once.
- If frames stutter: lower `nx`, set `TARGET_FPS = 30`.
