# Feature status (honest)
Legend: **Logic-tested** = web logic run in a simulated browser (jsdom) with a fake native bridge. **Not device-tested** = written but never compiled or run on a phone.

| Feature | Status |
|---|---|
| UI layout: Habits on Zen Garden, Investment tracker on Finance, Brainy Island under Settings, no settings gear (More is the only entry), Settings card last in More | Logic-tested (simulated browser) |
| Settings > Backup now holds Closed days, Export transactions and Piper export/import (real Piper page exported and re-imported in a simulated browser); Notes header is the toggle; Zen cards spaced | Logic-tested |
| Permissions panel: all 14 permissions once, live states, Grant / Open settings / App info, by-feature view, shared "why" sheet, nothing requested on open | Logic-tested (simulated browser + fake native bridge). Kotlin probes compile-checked; not device-tested |
| Settings panel: 41 settings from one registry, search, Action-required links, dual-write to the central database, authority rules | Logic-tested; native adapters compile-checked; not device-tested |
| Backup v3 + validated restore with safety copy; v2 backups still restore | Logic-tested |
| Registry consistency (manifest <-> registry <-> features, unique ids, defaults) | Run for real against the manifest (7 checks); JUnit versions in `FeatureRegistryTest` |
| Transactions, balance, savings rate, CSV | Logic-tested |
| Planner: Smart calendar (Monday-first, selected-day reminders, complete/reopen/delete, Notify me), tasks, repeat + month-end clamp | Logic-tested |
| Focus timer survives restarts, counts each session once, bonsai stages | Logic-tested |
| Alarms: JS scheduling + one-time/repeat roll-over | Logic-tested |
| Alarms: AlarmManager + foreground-service ringing, snooze, reboot re-arm, health checks (Kotlin) | Not device-tested |
| Notifications, permission prompts (Kotlin) | Not device-tested |
| Voice notes (WebView MediaRecorder, stored in IndexedDB) | Not device-tested; format is WebM/Opus, not AAC |
| Save CSV / JSON / audio to Downloads/Sandpiper | Bridge logic-tested; MediaStore code not device-tested |
| Step counter (daily baseline, counts from first open each day) | Not device-tested |
| Alarm tone choice: 5 built-in original tones, phone alarm tones, your own audio file, preview | Web logic-tested; playback, picker and file copy (Kotlin) not device-tested |
| Zen Garden layout: timer + garden in one card, Fitness card with your full fitness page | Logic-tested in a simulated browser |
| Fitness ports, stars and reports -> Close the day -> day record, bonus points, CSV | Logic-tested end to end (simulated browser) |
| Fitness opens from a button into its own full-screen window; Back/Android back close it | Logic-tested in a simulated browser |
| Fitness native hooks: steps, active minutes, history, permission state, Usage Access minutes, links, workout reminders (Kotlin) | Not device-tested |
| Accessibility service (reel/short/feed counting), warnings, floating counter, status notification, lock overlay over 60% of the screen, screen-off unlock (Kotlin) | Not compiled, not device-tested |
| Display-over-apps, Usage Access and Accessibility permission screens now list Sandpiper (permissions + service declared) | Not device-tested |
| Offline Bricolage Grotesque font (OFL licence included) | Bundled; loads from local file |
| Brainy Island: reel counting by settled swipe (SwipeDetector), web-reel address classification, app/package mapping | Unit tests written (JVM, ported from the working Reel Counter and extended), **not run here** (no Kotlin toolchain available) |
| Brainy Island: BrainyService rewired to the detector + island, settings screen, app picker, diagnostics, reset, tracking pause (Kotlin) | Not compiled, not device-tested (the Reel Counter originals of the detector, island and picker were working on a phone) |
| Brainy Island card in Zen Garden opens the native settings screen | JS syntax-checked; not device-tested |
| Pause Brainy for one app (Settings > Brainy Island): `BrainyService.disableSelf()` from a Bridge call, for banking/wallet apps that refuse to run while Brainy's accessibility switch is on | Written; not compiled, not device-tested (same caveat as the rest of the Brainy stack) |
| Habits, hydration, sleep, investments, backup/restore, calculator, About easter egg | Logic-tested |
| Notes / Piper Pro toggle: sliding switch in the Notes heading; Piper = uploaded Glasspage Pro (rebranded) in an iframe, workspace stored in `sandpiper_central.db` (SQLite, chunked, SHA-256 verified, previous-revision safety copy) | Written; storage adapter tested in Node with a mock bridge, SQL tested on real SQLite; **not run on a device or compiled** |
| Native JS alert/confirm/prompt dialogs (Piper needs them) | Written; not compiled |
| Diagnostics: typed privacy-safe logger, self-test, health, zip export via file picker (Kotlin) + JVM tests incl. canary-leak test | Written; **not compiled, tests not run** |
| Alarms re-armed on every cold start (Android drops them on force-stop) | Written; not compiled, not device-tested |
| Gradle build / APK | **Not built** (no Android SDK available when this was written) |

## Known limits
Brainy detection is heuristic: it recognises Reels/Shorts/TikTok screens by app view IDs and scroll events, which can change when those apps update, so counts are labelled Estimated. Facebook detection is the least reliable. Step and active-minute history comes from a ~15-minute background sampler (WorkManager); force-stopping the app or aggressive battery savers can pause it, and the first day after install is partial. Active minutes are an estimate (brisk-cadence steps / 100). On Android 13+ a sideloaded app may need App info > ⋮ > Allow restricted settings before the Accessibility switch can be turned on.
The planner's own daily plan and skill-tree progress are not saved between launches (same as your original file). No custom alarm music, no XLSX/PDF export, no app lock, no budgets/transfers/multiple accounts, no wake-up sound loop beyond the notification's insistent alarm tone (10 min max).
Voice notes are not included in the JSON backup. Recording may stop if the app is sent to the background.

## v3.5 changes (production pass)
- Cards: single edge. Real 1px border removed; the `::after` gradient ring is the only outline (now has a hairline floor so edges stay uniform). Padding +1px to keep layout identical.
- Brainy Island: `BrainySettingsActivity` reduced to Set up detection / Unlock restricted settings / Reset / Preview / Diagnostics. Tracking, style, look, gap, visibility, browser, tracked apps live only in Settings > Brainy Island. The browser address-bar consent dialog moved to the web toggle (`brainy.browser`).
- Piper Pro: host header bar hidden while Piper is active; a "‹ Notes" button is injected into Piper's own topbar from the host (piper.html untouched).
- Release build: R8 minify + resource shrink, signing key required (no debug-key fallback), `build-release.sh/.bat`. versionCode 3 / 1.2.0.
- Not compiled or device-tested here (no Android SDK): build and smoke-test the release APK before shipping, especially Settings rows (JS bridge under R8) and Piper back button.

## v3.6 (Activity card + Track Record)
- Home: Activity card at the bottom (range 7/30/90d, metrics Focus/Steps/Water/Sleep/Reels/Spend, goal/limit line, streaks). Tap a bar or "Track Record" to open the day sheet.
- Track Record: per-day sheet (date picker, prev/next) built from existing data: Planner closed-day snapshot, habits, focus sessions, steps, water, sleep, money, notes, reels, merged timeline. Empty days read "Nothing recorded", never zero.
- Reels history: BrainyStore keeps `rh` (per-day short/reg/feed/points, 400 days) from this version on; earlier days have no reel data. Steps history retention raised 30 -> 400 days.
- Not yet: hour-by-hour reels, per-app daily split, alarm history, Planner tasks for days that were not closed (planner state is not persisted by design). These need the activity database from the plan.
- Logic smoke-tested in jsdom; Kotlin change not compiled here. versionCode 4 / 1.3.0.

## v3.7 (activity ledger)
- DB v3 (`sandpiper_central.db`): `activity_event` (append-only, deterministic ids, tombstone deletes) + `daily_metric` (derived rollup, rebuilt via `activityRebuild`). Closed metric list in `ActivityCore` (numbers/enums only, no free text). Events older than 400 days are compacted; rollups stay.
- Native writers (work with the app closed): steps + active minutes (StepWorker), alarm fired/snoozed/dismissed, Brainy hourly reel buckets + per-platform reels + regular videos + feed (written when a day rolls over; today's live buckets come from `brainrotToday().hb/ps`). v3.6 `rh` totals are migrated once.
- Web writer: one diff-based sync (`actSync`, called from `save()`, 1.5 s debounce) covers focus, water, sleep, steps, money, habits, notes, closed-day planner/fitness results. Only changed events are sent; removed items become tombstones.
- UI: Activity card and Track Record read the ledger for past days (live app data for today) and fall back to app data. Track Record gains the hour-by-hour reels chart, platform split, alarms section and reels peak in the timeline.
- Backup v4 includes `activity` events; restore merges by id (v2/v3 backups still restore).
- Not done: Diagnostics `ACTIVITY` category/self-test (use `activityStatus()` meanwhile), `day_summary`/`metric_def` tables (closed-day snapshots stay in app data, labels live in JS), voice-note counts, Planner tasks for unclosed days.
- Verified: JS logic in jsdom with a fake ledger. NOT compiled or run on a device: all Kotlin (ActivityCore/Store, CentralDb v3 upgrade, Brainy/Steps/Alarm hooks, Bridge) and `ActivityCoreTest`.

## v3.8 (ledger hardening)
- CentralDb v4: `day_summary` (frozen closed-day record, kept forever, backed up, never logged). Closed days saved from the web sync; Track Record falls back to it when app data no longer has the day.
- Diagnostics: `ACTIVITY` category/module, `CHK_STORE_ACTIVITY` self-test (rollups match events + write/delete round trip, auto-rebuild), `ACTIVITY_REBUILT` / `ACTIVITY_IMPORTED` events.
- `StepWorker` flushes Brainy day rollover every ~15 min. Voice notes log `voice.count`. Backup `activity` now includes day summaries. Dead Piper sync-pill polling removed.
- Docs: `docs/architecture/ACTIVITY_LEDGER.md` (tables, writers, add-a-metric checklist, schema rules).
- Skipped on purpose: Planner snapshot of unclosed days (depends on donor-file internals), app lock (separate feature), `metric_def` table (one definition list in code instead).
- JS verified in jsdom with a fake ledger. Kotlin (incl. selfTest, day_summary, DB v4 upgrade) NOT compiled or run on a device. versionCode 6 / 1.5.0.

## v3.9 (auto day submission)
- Setting `planner.autoClose` (Settings > Planner > "Submit each day automatically", on by default). When a day ends the app saves it to Closed days itself (outcome "auto", `auto:true`): Zen sessions, Fitness (workouts, stars, steps), and reels/feed/active minutes taken from the activity ledger. No bonus points are awarded and no Planner tasks are recorded (the Planner keeps no plan between launches); Track Record shows "Submitted automatically" and no day score for these days.
- Triggers: 3 s after the clock passes midnight while the app is open; on app start; on returning to the app. Catch-up covers up to the last 7 days, skips days you already closed, skips days with no data at all, and never rewrites a day that exists.
- If the app was closed at midnight, the ledger still records everything natively; the Closed days entry is created at the next open.
- Verified in jsdom (on / manual-close-wins / off). Not run on a device.

## v3.10 (one close per day)
- Close the Day now works once per calendar day, for today only. Root cause of "many days in one sitting": the Planner's own `resolve()` advances streak, stars and its day counter on every press, while the host recorded every press under today's date.
- Gate lives in `planner-bridge.js` (wraps `resolve`, donor file untouched) asking `SpHub.canClose()`; `closeDay` re-checks as defence in depth. A blocked press shows "Today is already closed. The next day can be closed tomorrow." and the End-day button is dimmed until the date changes. Automatic submissions (past days only) never block today.
- Existing records count: a day already closed (any rev) stays closed. Past days can no longer be closed manually, only auto-submitted.
- Verified with a stub test of the wrapper (3 presses -> 1 planner resolve, 1 hub close). Not run on a device.

## v3.11 (planner tasks in history, tasks kept for forgotten days)
- `planner-bridge.js` watches the planner's task list (names, weights, done flags) every 3 s and when the page is hidden, and sends changes to `SpHub.planSnapshot`. The planner file is not edited.
- Host keeps `S.plan.log[date]` (tasks completed that day, filed under the date they were observed, so a task done before midnight stays on that day even if the plan is still open after midnight) and `S.plan.open[date]` (tasks still pending). Un-ticking removes the entry. Manual Close the day also folds in tasks ticked in its last seconds. Both are part of the JSON backup (inside `state`).
- Auto day submission now records those tasks: done/not-done list, points (done weight / max(6, total weight)) and percent, so a day you forgot to close keeps its tasks and a day score. Days with no captured plan still read "Planner not recorded".
- Track Record: the tasks of any day (closed, auto, or still open) appear under Accomplished, "Tasks done" shows n/m, and the timeline lists "Task done: ...". Activity card has a Tasks chip; ledger metric `planner.tasks` (tasks done per day).
- Limits: the plan is captured only while the Planner page has been loaded (open the Planner tab at least once per launch); tasks removed from the plan in an earlier launch stay in that day's open list; planner streak/stars/mastery still only advance when you press Close the day.
- Verified in jsdom (host tracking, auto-close with tasks, Track Record, bridge watcher). Not run on a device.

## v3.12 (day-end reminder)
- Daily notification 2 hours before midnight (22:00 by default) asking you to update the day. One of five lines, picked at random and never the same as the previous night (`DayEndCore.MESSAGES`, exactly as written).
- Native, through the existing `Scheduler`/AlarmManager path (reminder, repeat daily, id `day_end`), so it fires with the app closed and is re-armed on boot/update/time change like every reminder. `DayEnd.sync` runs at app start and whenever the setting changes.
- Quiet when the day was already closed: the web layer writes `dayClosed` (yyyy-MM-dd) into app settings at Close the day, and the receiver skips the notification for that date.
- Settings > Planner: "Day-end reminder" (on by default) and "Remind me" (1, 2 or 3 hours before the day ends). Needs notification permission (the Planner chip shows it).
- Tapping the notification opens Sandpiper (not yet straight into the Planner).
- Unit tests: `DayEndTest` (lines, no-repeat, hour mapping, item shape); `AppSettingsTest` also checks the new choice list. Kotlin NOT compiled or run on a device. versionCode 10 / 1.8.0.

## v3.13 (Planner list + Sandpiper Pro toggle)
- Planner tab now opens on the plain Daily / Weekly / Monthly list, with the pill toggle Planner | Sandpiper (same pattern as Notes | Piper Pro). "Sandpiper" = the existing planner.html, unchanged. Last-used mode is remembered (`S.plannerProOn`, localStorage state only); Android Back leaves Sandpiper Pro first.
- The sparkle icon (`.brand-mark`) in the Sandpiper Pro hero card now returns to the plain Planner. Attached by `planner-bridge.js`; the icon and planner.html are not touched or restyled.
- CentralDb v5: `planner_task` + `planner_history` (additive). `PlannerCore` (pure rules, unit-tested) + `PlannerStore` (SQLite; every mutation = one transaction writing the task row AND its history row; delete writes history before removing the row). Bridge: `plannerList/Add/Toggle/Delete/History/BackupBlob/RestoreBlob`, all synchronous returns (no window.on... callbacks needed).
- Backup format 5 adds `planner` {tasks, history}. Restore merges (newer copy wins, history added by id); backups without `planner` (formats 2-4) restore as before.
- Diagnostics: `DCat.PLANNER`, events TASK_ADDED/COMPLETED/REOPENED/DELETED, PLANNER_IMPORTED, self-test `CHK_STORE_PLANNER` (orphan check). Counts only, never task text (`PlannerCoreTest.taskTextNeverAppearsInALogLine`).
- Completing a list task also files it under today in the day's task history, so Track Record, the day-end reminder flow and automatic day submission see it.
- Sandpiper Pro storage contract reserved: module `sandpiper_pro`, doc key `workspace` (`ProStore`, `sandpiperProStatus()`); excluded from the simple JSON backup like Piper. Load/Save are NOT implemented: planner.html is the Pro UI today and keeps its own storage.
- Deliberate differences from the command: DB version is 5 (v3 and v4 were already used by the activity ledger), backup format is 5 (4 was taken), no `plannerPro.*` registry entries (no new settings), and no new `onPlannerTasks` callbacks.
- Verified in jsdom (list add/toggle/delete, history logging, mode switch, Back, sparkle, browser and native adapters). Kotlin (PlannerStore, v5 upgrade, bridge, diagnostics) NOT compiled or run on a device. versionCode 11 / 1.9.0.

## v3.14 (Planner list -> Sandpiper Pro auto-sync)
- Automatic, no button. Today's DAILY list tasks appear in the Sandpiper plan by themselves; finishing a task on either side marks it on the other, so it earns points once.
- Desired state = pending daily tasks + daily tasks finished today, minus tasks removed from the Sandpiper plan today. Keyed by the list task id (`lid` on the plan task), so repeated syncs never add a second copy; the user's own Sandpiper tasks (no `lid`) are never touched. Weekly/monthly tasks and tasks finished on earlier days are not sent.
- No new tables and no copies in SQLite: the plan is only an in-memory view. Host bookkeeping is one tiny entry per task touched today in `S.plan.link` ({day, weight, removed}); entries older than today are pruned on every sync. List history rows are written only by real user actions on the list.
- Limits and rules: a plan holds 9 tasks, extra list tasks wait and are added as room frees up; after Close the day nothing is pushed until the next day (one close per day); pending tasks carry over to the next day's plan; a task removed from the Sandpiper plan returns tomorrow if still pending; default weight 2 stars, changing it in Sandpiper is remembered for the day.
- Setting: Settings > Planner > "Sync Planner tasks to Sandpiper" (on by default). `proAccess()` in index.html is the single hook for the future Pro licence check (currently always true).
- Mechanics: `planner-bridge.js` adds `__spReconcile(desired)` and reports the plan right after it changes it; host functions `plDesired / plPush / plFromPro`; triggers: list add/complete/delete, opening Sandpiper, returning to the app, midnight, planner load (`SpHub.proReady`).
- Verified in jsdom with the real bridge + a stub planner (open, add x2 pushes = one copy, list done -> plan done, plan done -> list done and logged once, removed task stays out, 12 extra tasks -> plan holds 9 and list unchanged, nothing after close). Not run against the real planner.html on a device. versionCode 12 / 1.10.0.

## v3.15 (Sprout, pro finance)
- Finance | Sprout pill centred at the top of the Finance page (same pattern as Planner). Sprout = `sprout.html` (two edits: CSP + bridge script tag) in a full-bleed iframe; its leaf icon returns to Finance.
- Central database: Sprout's whole state is one checksummed, chunked document with a previous-revision fallback (`SproutStore`, module `sprout`), bridge `sproutLoad/Save/Status`. No localStorage copy is kept. Diagnostics: `CHK_STORE_SPROUT`. Backup format 6 includes `sprout`.
- Settings and permission moved to Sandpiper: new Settings > Sprout (11 rows) and Permissions row "SMS access (Sprout)" under a new "In-app consent" group (`kind: consent`, `AppSettings.smsConsent`, no Android permission). Sprout's own Settings tab is hidden by the bridge.
- Finance -> Sprout sync: automatic, one "Sandpiper" account, keyed by transaction id (no duplicates, deletes void). Setting to turn it off.
- Honest limits: the SMS consent only gates Sprout's own SMS-text processing (pasted/shared); no Android SMS permission exists and the inbox is never read. Provider presets by country are replaced by a typed sender list. Currency is a display setting independent of Finance's BDT/USD/EUR. Sprout follows the system light/dark theme, not Sandpiper's in-app toggle. Transactions made inside Sprout do not appear in the simple Finance page or Track Record.
- Verified in jsdom with the real sprout.html + bridge + host (storage seed/save, settings applied, tab hidden, sync, idempotence, delete->void, restart persistence, logo, downloads, erase, registry/permission rendering). Kotlin (SproutStore, Diag probe, consent permission, bridge) NOT compiled or run on a device; new `SproutCoreTest`. versionCode 13 / 1.11.0.

## v3.16 (Sprout: real SMS capture)  -- supersedes the SMS notes in v3.15
- Correction: SMS access is now a REAL Android permission (RECEIVE_SMS + READ_SMS, registry kind runtime, one Permissions row "SMS access (Sprout)"). The in-app "consent" kind and `smsConsent` setting were removed.
- Only providers the user selects are read: native filter by sender (`SmsFilter`), OTP / verification messages dropped before storage, only transaction-looking text kept. `SmsReceiver` for new messages (app closed), `SmsStore.scan` for the inbox (auto once after selecting providers, plus a "Scan existing messages now" action, look-back 7/30/90/180 days). Captured messages wait in `sms_inbox` (CentralDb v6) and are erased (text + sender) once Sprout has saved them; only the id remains.
- Sprout: sender decides the provider; bank<->wallet debit+credit pairs become one Transfer; ATM and cash out -> Cash in hand (with fee), cash in -> out of Cash in hand; duplicates blocked by transaction id; a Comment button on every ledger row (stored as the row's note). Sprout is loaded in a hidden frame when SMS is pending so the ledger updates without opening it.
- New: provider picker (Settings > Sprout > Choose providers from a list), `sprout-providers.json` (generated from Sprout's own lists), bridge `smsSetProviders/Pending/Take/Ack/Scan/Status`, Diagnostics `SMS_ACCEPTED/SMS_SCAN/SMS_DELIVERED` (counts only) and permission row `CHK_PERM_SMS`. Tests: `SmsFilterTest`.
- Verified in jsdom with the real sprout.html + bridge: OTP dropped, income credit, City Bank -> bKash transfer paired, ATM, cash out with fee, cash in, duplicate blocked, Nagad purchase, balances match each SMS, comments, SMS acknowledged/erased. Kotlin (receiver, store, permission, manifest) NOT compiled or run on a device; real SMS delivery needs a device test. versionCode 14 / 1.12.0.
