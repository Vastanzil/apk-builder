package com.vastanzil.sandpiper

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SproutCoreTest {
    @Test fun acceptsASproutSnapshot() {
        assertTrue(SproutCore.isValid("""{"app":"sprout","version":"1.0.0","schema":1,"accounts":[{"id":1,"name":"Cash","type":"cash","balance":0}],"ledger":[]}"""))
    }

    @Test fun refusesEverythingElse() {
        assertFalse(SproutCore.isValid(""))
        assertFalse(SproutCore.isValid("not json"))
        assertFalse(SproutCore.isValid("""{"app":"sandpiper","accounts":[]}"""))      // someone else's backup
        assertFalse(SproutCore.isValid("""{"app":"sprout"}"""))                          // no accounts
        assertFalse(SproutCore.isValid("""{"app":"sprout","accounts":{}}"""))            // accounts must be an array
        assertFalse(SproutCore.isValid("x".repeat(SproutCore.MAX_CHARS + 1)))
    }

    @Test fun moduleNamesAreReserved() {
        assertTrue(SproutCore.MODULE == "sprout" && SproutCore.CUR == "state" && SproutCore.PREV == "state.prev")
    }
}
