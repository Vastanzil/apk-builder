package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmsFilterTest {
    private val providers = listOf("bKash", "Nagad", "City Bank")

    @Test fun senderNamesMatchLoosely() {
        assertTrue(SmsFilter.senderMatches("bKash", providers))
        assertTrue(SmsFilter.senderMatches("CITYBANK", providers))
        assertTrue(SmsFilter.senderMatches("CityBank Alert", providers))
        assertTrue(SmsFilter.senderMatches("NAGAD", providers))
    }

    @Test fun otherSendersAreNeverKept() {
        assertFalse(SmsFilter.senderMatches("Grameenphone", providers))
        assertFalse(SmsFilter.senderMatches("+8801712345678", providers))   // a person
        assertFalse(SmsFilter.senderMatches("AB", providers))
        assertFalse(SmsFilter.senderMatches("bKash", emptyList()))            // nothing selected = nothing read
        assertFalse(SmsFilter.senderMatches("bKash", listOf("bk")))           // names under 3 characters never match
    }

    @Test fun otpIsDroppedBeforeAnythingIsStored() {
        assertTrue(SmsFilter.isOtp("Your OTP for bKash transaction is 583921. Do not share this code."))
        assertTrue(SmsFilter.isOtp("Use verification code 4421 to confirm payment of Tk 500"))
        assertFalse(SmsFilter.accept("bKash", "Your OTP for bKash transaction is 583921.", providers))
    }

    @Test fun onlyTransactionsPass() {
        assertTrue(SmsFilter.accept("bKash", "You have received Tk 2,500.00 from 017XXXXXXXX. TrxID 8N7K2P1. Balance Tk 14,840.00", providers))
        assertTrue(SmsFilter.accept("CityBank Alert", "Tk 10,000.00 debited from your card. Trans ID: BK3302955. Avail Bal: BDT 69,690.00", providers))
        assertTrue(SmsFilter.accept("bKash", "Cash Out Tk 2,000.00 from agent. TrxID 1K9P7T2. Balance Tk 67,690.00", providers))
        assertTrue(SmsFilter.accept("CITYBANK", "ATM withdrawal of BDT 5,000 at Gulshan. Avail Bal BDT 21,000", providers))
        assertFalse(SmsFilter.accept("bKash", "Get 10% cashback on your next recharge! Visit our app.", providers))
        assertFalse(SmsFilter.accept("Grameenphone", "You have received Tk 50 from a friend. Balance Tk 10", providers))
        assertFalse(SmsFilter.accept("bKash", "   ", providers))
    }

    @Test fun sameMessageGetsTheSameIdOnce() {
        val a = SmsFilter.id("bKash", 1_762_000_000_000L, "You have received Tk 100. TrxID A1")
        assertEquals(a, SmsFilter.id("BKASH", 1_762_000_000_000L, " You have received Tk 100. TrxID A1 "))
        assertNotEquals(a, SmsFilter.id("bKash", 1_762_000_000_001L, "You have received Tk 100. TrxID A1"))
        assertEquals(32, a.length)
    }

    @Test fun providerListParsing() {
        assertEquals(listOf("bKash", "City Bank"), SmsFilter.parseProviders("""["bKash"," City Bank ","bk","bKash"]"""))
        assertTrue(SmsFilter.parseProviders("not json").isEmpty())
    }
}
