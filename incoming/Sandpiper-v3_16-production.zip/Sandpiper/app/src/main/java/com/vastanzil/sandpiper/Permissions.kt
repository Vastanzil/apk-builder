package com.vastanzil.sandpiper

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

enum class PState(val wire: String) {
    GRANTED("granted"), NOT_GRANTED("not_granted"), PERMANENTLY_DENIED("permanently_denied"),
    SPECIAL("special"), NOT_APPLICABLE("na")
}

/**
 * The one place that knows how to probe and request every permission/special access. Used by the Permissions panel,
 * the self-test, the Fitness page's permission rows and the alarm checks. Live probes only: state is never cached.
 * Permission ids match assets/features.json.
 */
internal object Permissions {
    private const val PREFS = "sp_perm_asked"

    /** SMS capture needs both: RECEIVE_SMS (new messages, even with the app closed) and READ_SMS (scan the inbox). */
    val SMS_PERMS = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)

    /** The runtime permission behind an id, or null for special/install ones. */
    fun runtimePermission(id: String): String? = when (id) {
        "notifications" -> if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else null
        "microphone" -> Manifest.permission.RECORD_AUDIO
        "activity" -> Manifest.permission.ACTIVITY_RECOGNITION
        else -> null
    }

    fun markAsked(c: Context, perms: Array<String>) {
        val e = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        perms.forEach { e.putBoolean(it, true) }
        e.apply()
    }

    private fun asked(c: Context, perm: String) =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(perm, false)

    private fun runtimeState(c: Context, a: Activity?, perm: String): PState {
        if (ContextCompat.checkSelfPermission(c, perm) == PackageManager.PERMISSION_GRANTED) return PState.GRANTED
        // Android gives no direct "never ask again" flag: asked before + no rationale = the system will not show the prompt again
        return if (a != null && asked(c, perm) && !a.shouldShowRequestPermissionRationale(perm)) PState.PERMANENTLY_DENIED else PState.NOT_GRANTED
    }

    fun accessibilityOn(c: Context): Boolean {
        val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(c, BrainyService::class.java)
        return list.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    fun usageOn(c: Context): Boolean = try {
        val ops = c.getSystemService(AppOpsManager::class.java)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    fun check(c0: Context, id: String, a: Activity? = null): PState {
        val c = c0.applicationContext
        return when (id) {
            "notifications" -> {
                if (NotificationManagerCompat.from(c).areNotificationsEnabled()) PState.GRANTED
                else {
                    val rp = runtimePermission(id)
                    if (rp != null && ContextCompat.checkSelfPermission(c, rp) != PackageManager.PERMISSION_GRANTED) runtimeState(c, a, rp)
                    else PState.SPECIAL // switched off in the system notification settings
                }
            }
            "microphone" -> if (!c.packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)) PState.NOT_APPLICABLE
                            else runtimeState(c, a, Manifest.permission.RECORD_AUDIO)
            "activity" -> if (c.getSystemService(SensorManager::class.java)?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) PState.NOT_APPLICABLE
                          else runtimeState(c, a, Manifest.permission.ACTIVITY_RECOGNITION)
            "exact_alarm" -> if (Build.VERSION.SDK_INT < 31) PState.NOT_APPLICABLE
                             else if (c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) PState.GRANTED else PState.SPECIAL
            "full_screen" -> if (Build.VERSION.SDK_INT < 34) PState.NOT_APPLICABLE
                             else if (c.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) PState.GRANTED else PState.SPECIAL
            "battery" -> if (c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)) PState.GRANTED else PState.SPECIAL
            "accessibility" -> if (accessibilityOn(c)) PState.GRANTED else PState.SPECIAL
            "usage" -> if (usageOn(c)) PState.GRANTED else PState.SPECIAL
            "overlay" -> if (Settings.canDrawOverlays(c)) PState.GRANTED else PState.SPECIAL
            "sms" -> {
                val missing = SMS_PERMS.firstOrNull { ContextCompat.checkSelfPermission(c, it) != PackageManager.PERMISSION_GRANTED }
                if (missing == null) PState.GRANTED else runtimeState(c, a, missing)
            }
            else -> PState.GRANTED // install-time permissions are granted when the app is installed
        }
    }

    /** True when the thing works (granted, or not applicable on this device). */
    fun ok(c: Context, id: String): Boolean = check(c, id).let { it == PState.GRANTED || it == PState.NOT_APPLICABLE }

    // ---- diagnostics mapping (one row per self-test check) ----
    class DiagRow(val id: String, val ev: DEv, val mod: DMod, val perm: DPerm, val informational: Boolean = false)

    val DIAG_ROWS = listOf(
        DiagRow("notifications", DEv.CHK_PERM_NOTIFICATIONS, DMod.ALARMS, DPerm.NOTIFICATIONS),
        DiagRow("microphone", DEv.CHK_PERM_MICROPHONE, DMod.NOTES, DPerm.MICROPHONE),
        DiagRow("activity", DEv.CHK_PERM_ACTIVITY, DMod.STEPS, DPerm.ACTIVITY),
        DiagRow("accessibility", DEv.CHK_PERM_ACCESSIBILITY, DMod.BRAINY, DPerm.ACCESSIBILITY),
        DiagRow("usage", DEv.CHK_PERM_USAGE, DMod.FITNESS, DPerm.USAGE),
        DiagRow("overlay", DEv.CHK_PERM_OVERLAY, DMod.BRAINY, DPerm.OVERLAY),
        DiagRow("exact_alarm", DEv.CHK_PERM_EXACT_ALARM, DMod.ALARMS, DPerm.EXACT_ALARM),
        DiagRow("full_screen", DEv.CHK_PERM_FULL_SCREEN, DMod.ALARMS, DPerm.FULL_SCREEN),
        DiagRow("battery", DEv.CHK_BATTERY_OPT, DMod.ALARMS, DPerm.BATTERY, informational = true),
        DiagRow("sms", DEv.CHK_PERM_SMS, DMod.SPROUT, DPerm.SMS, informational = true)   // optional: only Sprout SMS capture needs it
    )

    fun diagResult(c: Context, row: DiagRow): DRes = when (check(c, row.id)) {
        PState.GRANTED, PState.NOT_APPLICABLE -> DRes.OK
        else -> if (row.informational) DRes.SKIP else DRes.DENIED
    }

    /** Live state of every permission in the registry as [{"id":..,"state":..}]. Logs one PERMISSION_CHECKED per row when [log]. */
    fun statesJson(c: Context, a: Activity?, log: Boolean): String {
        val reg = FeatureRegistry.parsed(c).getJSONArray("permissions")
        val out = JSONArray()
        for (i in 0 until reg.length()) {
            val id = reg.getJSONObject(i).getString("id")
            val st = check(c, id, a)
            out.put(JSONObject().put("id", id).put("state", st.wire))
            if (log) DIAG_ROWS.firstOrNull { it.id == id }?.let {
                val res = when (st) { PState.GRANTED, PState.NOT_APPLICABLE -> DRes.OK; else -> if (it.informational) DRes.SKIP else DRes.DENIED }
                Diag.log(DLvl.I, DCat.PERMISSION, DEv.PERMISSION_CHECKED, it.mod, res, n = it.perm.ordinal.toLong())
            }
        }
        return out.toString()
    }

    /**
     * What the Grant / Fix button does. Never called just because a panel opened.
     * Returns: requested (system prompt shown) | opened (Android settings page) | appinfo (App info) | granted | na
     */
    fun act(c0: Context, a: MainActivity, id: String): String {
        val c = c0.applicationContext
        val st = check(c, id, a)
        if (st == PState.GRANTED) return "granted"
        if (st == PState.NOT_APPLICABLE) return "na"
        val pkg = Uri.parse("package:" + c.packageName)
        fun open(i: Intent): String {
            return try { a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "opened" } catch (e: Exception) {
                try { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "appinfo" } catch (e2: Exception) { "na" }
            }
        }
        if (st == PState.NOT_GRANTED && id == "sms") { markAsked(c, SMS_PERMS); a.askPermissions(SMS_PERMS); return "requested" }
        if (st == PState.NOT_GRANTED) {
            val rp = runtimePermission(id)
            if (rp != null) { markAsked(c, arrayOf(rp)); a.askPermissions(arrayOf(rp)); return "requested" }
        }
        if (st == PState.PERMANENTLY_DENIED) return open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)).let { if (it == "opened") "appinfo" else it }
        return when (id) {
            "notifications" -> open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName))
            "exact_alarm" -> open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg))
            "full_screen" -> open(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
            "battery" -> open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            "accessibility" -> open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "usage" -> open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            "overlay" -> open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
            else -> open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        }
    }
}
