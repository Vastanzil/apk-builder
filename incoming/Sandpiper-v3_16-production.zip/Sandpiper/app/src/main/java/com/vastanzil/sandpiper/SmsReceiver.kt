package com.vastanzil.sandpiper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/**
 * Incoming SMS (works with the app closed). Only messages from the providers the user selected, that are not OTPs and look like a
 * transaction, are kept (see [SmsFilter]); everything else is dropped without being stored. Needs the SMS permission to be granted.
 */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
            if (msgs == null || msgs.isEmpty()) return
            val sender = msgs[0].originatingAddress ?: return
            val body = msgs.joinToString("") { it.messageBody ?: "" }
            val ts = msgs[0].timestampMillis.let { if (it > 0L) it else System.currentTimeMillis() }
            SmsStore.accept(c.applicationContext, sender, body, ts)
        } catch (e: Exception) { }
    }
}
