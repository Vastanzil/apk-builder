package com.vastanzil.sandpiper

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONObject

/** Pure rules for the Sprout document (no Android imports, so plain JUnit covers them). */
object SproutCore {
    const val MODULE = "sprout"
    const val CUR = "state"
    const val PREV = "state.prev"
    const val MAX_CHARS = 32_000_000

    /** A Sprout snapshot: an object made by the app "sprout" that holds an accounts array. Anything else is refused. */
    fun isValid(json: String): Boolean {
        if (json.isEmpty() || json.length > MAX_CHARS) return false
        return try {
            val o = JSONObject(json)
            o.optString("app") == "sprout" && o.optJSONArray("accounts") != null
        } catch (e: Exception) { false }
    }
}

/**
 * Sprout's whole state as ONE document in sandpiper_central.db (module_doc / module_doc_chunk, via DocChunker), the same
 * pattern as Piper: every save keeps the previous revision as a safety copy, is checksummed, and is skipped when nothing
 * changed. load() verifies the hash and falls back to the previous revision if the current one is damaged.
 * The document holds the user's own finance data (accounts, ledger, budgets, goals): it is never logged, only sizes are.
 */
internal object SproutStore {
    @Synchronized
    fun save(c: Context, json: String): Boolean {
        val t0 = System.nanoTime()
        try {
            val db = CentralDb.get(c).writableDatabase
            if (json.isEmpty()) {   // erase
                db.beginTransaction()
                try {
                    for (k in arrayOf(SproutCore.CUR, SproutCore.PREV)) {
                        db.delete("module_doc", "module=? AND doc_key=?", arrayOf(SproutCore.MODULE, k))
                        db.delete("module_doc_chunk", "module=? AND doc_key=?", arrayOf(SproutCore.MODULE, k))
                    }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                Diag.log(DLvl.I, DCat.DB, DEv.SPROUT_SAVE, DMod.SPROUT, DRes.SKIP)
                return true
            }
            if (!SproutCore.isValid(json)) {
                Diag.log(DLvl.W, DCat.DB, DEv.SPROUT_SAVE, DMod.SPROUT, DRes.FAIL, code = DCode.E_ARG)
                return false
            }
            val bytes = json.toByteArray(Charsets.UTF_8)
            val sha = DocChunker.sha256(bytes)
            db.rawQuery("SELECT sha256 FROM module_doc WHERE module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.CUR)).use {
                if (it.moveToFirst() && it.getString(0) == sha) return true   // identical: nothing to write
            }
            val parts = DocChunker.split(json)
            db.beginTransaction()
            try {
                db.delete("module_doc", "module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.PREV))
                db.delete("module_doc_chunk", "module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.PREV))
                val toPrev = ContentValues(); toPrev.put("doc_key", SproutCore.PREV)
                db.update("module_doc", toPrev, "module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.CUR))
                db.update("module_doc_chunk", toPrev, "module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.CUR))
                val h = ContentValues()
                h.put("module", SproutCore.MODULE); h.put("doc_key", SproutCore.CUR); h.put("schema_v", 1)
                h.put("bytes", bytes.size); h.put("chunks", parts.size); h.put("sha256", sha); h.put("updated_at", System.currentTimeMillis())
                db.insertOrThrow("module_doc", null, h)
                for (i in parts.indices) {
                    val v = ContentValues()
                    v.put("module", SproutCore.MODULE); v.put("doc_key", SproutCore.CUR); v.put("seq", i); v.put("part", parts[i])
                    db.insertOrThrow("module_doc_chunk", null, v)
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
            Diag.log(DLvl.I, DCat.DB, DEv.SPROUT_SAVE, DMod.SPROUT, DRes.OK, (System.nanoTime() - t0) / 1_000_000L, (bytes.size / 1024).toLong())
            return true
        } catch (e: Exception) {
            Diag.log(DLvl.W, DCat.DB, DEv.SPROUT_SAVE, DMod.SPROUT, DRes.FAIL, (System.nanoTime() - t0) / 1_000_000L, 0L, Diag.codeOf(e))
            return false
        }
    }

    /** The stored snapshot, or "" when nothing valid is stored (first run / erased). */
    @Synchronized
    fun load(c: Context): String {
        val t0 = System.nanoTime()
        try {
            val db = CentralDb.get(c).readableDatabase
            val cur = readDoc(db, SproutCore.CUR)
            if (cur != null) {
                Diag.log(DLvl.I, DCat.DB, DEv.SPROUT_LOAD, DMod.SPROUT, DRes.OK, (System.nanoTime() - t0) / 1_000_000L, (cur.length / 1024).toLong())
                return cur
            }
            val prev = readDoc(db, SproutCore.PREV)
            if (prev != null) {
                Diag.log(DLvl.W, DCat.DB, DEv.SPROUT_RECOVERED, DMod.SPROUT, DRes.OK, (System.nanoTime() - t0) / 1_000_000L, (prev.length / 1024).toLong())
                return prev
            }
            Diag.log(DLvl.I, DCat.DB, DEv.SPROUT_LOAD, DMod.SPROUT, DRes.SKIP)
            return ""
        } catch (e: Exception) {
            Diag.log(DLvl.W, DCat.DB, DEv.SPROUT_LOAD, DMod.SPROUT, DRes.FAIL, 0L, 0L, Diag.codeOf(e))
            return ""
        }
    }

    @Synchronized
    fun status(c: Context): String {
        val o = JSONObject()
        try {
            var has = false; var bytes = 0L; var upd = 0L
            CentralDb.get(c).readableDatabase.rawQuery("SELECT bytes, updated_at FROM module_doc WHERE module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.CUR)).use {
                if (it.moveToFirst()) { has = true; bytes = it.getLong(0); upd = it.getLong(1) }
            }
            o.put("ok", true).put("has", has).put("bytes", bytes).put("updatedAt", upd)
        } catch (e: Exception) { try { o.put("ok", false) } catch (x: Exception) { } }
        return o.toString()
    }

    /** Self-test: 1 when nothing is stored or the CURRENT revision reads back with a matching checksum. Does not use the fallback. */
    @Synchronized
    fun verify(c: Context): Int {
        val db = CentralDb.get(c).readableDatabase
        var has = false
        db.rawQuery("SELECT 1 FROM module_doc WHERE module=? AND doc_key=?", arrayOf(SproutCore.MODULE, SproutCore.CUR)).use { has = it.moveToFirst() }
        if (!has) return 1
        val s = readDoc(db, SproutCore.CUR) ?: return 0
        return if (SproutCore.isValid(s)) 1 else 0
    }

    private fun readDoc(db: SQLiteDatabase, key: String): String? {
        var chunks = -1
        var sha = ""
        db.rawQuery("SELECT chunks, sha256 FROM module_doc WHERE module=? AND doc_key=?", arrayOf(SproutCore.MODULE, key)).use {
            if (!it.moveToFirst()) return null
            chunks = it.getInt(0); sha = it.getString(0 + 1)
        }
        val parts = ArrayList<String>()
        db.rawQuery("SELECT part FROM module_doc_chunk WHERE module=? AND doc_key=? ORDER BY seq", arrayOf(SproutCore.MODULE, key)).use {
            while (it.moveToNext()) parts.add(it.getString(0))
        }
        if (parts.size != chunks) return null
        val s = DocChunker.join(parts)
        return if (DocChunker.sha256(s) == sha) s else null
    }
}
