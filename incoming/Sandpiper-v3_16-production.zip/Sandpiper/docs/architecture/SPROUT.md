# Sprout (pro finance)

Sprout is the pro version of Finance. It is the delivered `sprout.html` app, hosted in an iframe like the Sandpiper planner, behind a Finance | Sprout pill at the top of the Finance page. Two edits only were made to `sprout.html`: its Content-Security-Policy allows the bundled script, and `sprout-bridge.js` is loaded in `<head>`. Everything else is wiring in `sprout-bridge.js` (inside Sprout) and the "Finance <-> Sprout" block in `index.html` (host).

## Navigation
Pill Finance | Sprout (last mode remembered in `S.sproutOn`). The Sprout leaf icon (top-left of Sprout) returns to Finance; Android Back closes Sprout's add sheet first, then leaves Sprout.

## Storage (central database)
Sprout's whole state is ONE document in `sandpiper_central.db` (`module_doc` / `module_doc_chunk`, module `sprout`, key `state`), same pattern as Piper: chunked by `DocChunker`, SHA-256 checked, previous revision kept as `state.prev`, identical saves skipped, automatic fallback to the previous revision if the current one is damaged. Native: `SproutStore`; bridge: `sproutLoad()`, `sproutSave(json)` (empty string erases), `sproutStatus()`. The bridge seeds Sprout's own loader from the database before its script runs, intercepts Sprout's `localStorage` writes, and deletes the transient localStorage copy once Sprout has loaded, so there is a single copy. If the database refuses a save, Sprout shows its own "changes are not being saved" warning.

## Settings and permission (owned by Sandpiper)
Sprout's own Settings tab is hidden. Settings > Sprout holds: sync on/off, region, currency, language, navigation bar position, auto-hide, add-button corner, providers to read (typed list + "Choose providers from a list"), scan look-back, "Scan existing messages now", demo mode, erase. Values are `S.spr*` keys (mirrored to the central `setting` table) and are pushed into Sprout on every load and change (`sprPush` -> `__spApply`). "SMS access (Sprout)" is a real Android runtime permission (RECEIVE_SMS + READ_SMS) in Settings > Permissions.

## SMS capture (real)
1. Nothing is read until the permission is granted AND at least one provider is selected. Selected provider names are stored natively (`smsSetProviders`).
2. New messages: `SmsReceiver` (works with the app closed). Existing inbox: `SmsStore.scan(days)` (automatic once after the first selection, and on "Scan existing messages now"). Both go through `SmsFilter`: sender must match a selected provider (names normalised: "CityBank Alert" = City Bank), OTP / verification-code messages are dropped, and the text must look like a transaction. Everything else is never stored (the inbox scan does not even copy other senders' messages).
3. Kept messages wait in `sms_inbox` (central database, CentralDb v6). The web layer pumps them to Sprout (`smsTake` -> `__spIngest`), loading Sprout in a hidden frame if needed so the ledger updates without opening it. After Sprout has saved them the host acknowledges (`smsAck`): sender and text are erased, only the id stays (so a rescan cannot import a message twice).
4. In Sprout (`sprout-bridge.js`): the SENDER decides the provider (a City Bank message that mentions bKash stays a City Bank message); OTPs never create anything; credited/debited/received/paid and the stated balance go through Sprout's own reader and set the account balance; ATM withdrawal and MFS cash out move money from the account to Cash in hand (fee recorded), cash in / cash deposit moves Cash in hand to the account; a bank debit and a wallet credit of the same amount within 10 minutes (one worded like a transfer, or naming the other provider) become ONE Transfer, not an expense plus income, in either arrival order. Duplicates are caught by transaction id.
5. Every ledger row has a Comment button; the comment is the row's note (shown, exported to CSV, backed up).
Limits: parsing quality depends on each provider's wording (unknown wording goes to Sprout's review inbox, never silently dropped); the 10-minute pairing window and fees on transfers are simple rules, not bank-specific. Google Play restricts READ_SMS/RECEIVE_SMS to a narrow set of apps: fine for a sideloaded build, but a Play Store release would need Google's declaration form. On Android 13+ a sideloaded app may need App info > menu > Allow restricted settings before the permission can be granted.

## Finance -> Sprout sync
Transactions added on the simple Finance page appear in Sprout automatically, in one account named "Sandpiper" (source `sandpiper`), each keyed `refId = sp:<transaction id>`. Repeated syncs never add a second copy; deleting a transaction on the Finance page voids it in Sprout (balance reversed); a transaction voided inside Sprout stays voided. Category = same name if Sprout has it, otherwise Sprout's payee auto-categoriser. One-way (Finance -> Sprout); transactions created inside Sprout stay in Sprout. Turn off in Settings > Sprout > "Sync Finance transactions into Sprout".

## Backup
Backup format 6 carries `sprout` (the snapshot). Restore writes it back (and reloads Sprout if open); backups without a `sprout` key leave Sprout untouched. Sprout's own Import/Export tab still works; saved files go to Downloads/Sandpiper through the app.

## Diagnostics
`DMod.SPROUT`, events SPROUT_SAVE / SPROUT_LOAD / SPROUT_RECOVERED (sizes only, never content) and self-test `CHK_STORE_SPROUT` (current revision reads back with a matching checksum).
