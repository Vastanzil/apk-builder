package com.vastanzil.sandpiper

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Rings an alarm: looping alarm-stream sound with rising volume + vibration.
 * Runs as a foreground service only while an alarm is actually ringing (max 10 minutes).
 */
class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var volume = 0.15f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("id") ?: "alarm"
        val title = intent?.getStringExtra("title") ?: "Alarm"
        stopRinging()
        try {
            Notifier.channels(this)
            val n = Notifier.ringNotification(this, id, title)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(id.hashCode(), n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else startForeground(id.hashCode(), n)
        } catch (e: Exception) {
            // Could not become a foreground service: fall back to a notification that carries the sound itself.
            Notifier.show(this, id, "alarm", title, forceSound = true)
            stopSelf()
            return START_NOT_STICKY
        }
        startRinging()
        handler.postDelayed({ Notifier.dismiss(this, id) }, 10 * 60_000L)
        return START_NOT_STICKY
    }

    private fun startRinging() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(this@AlarmService, uri)
                isLooping = true
                setWakeMode(this@AlarmService, PowerManager.PARTIAL_WAKE_LOCK)
                prepare()
                setVolume(volume, volume)
                start()
            }
            val ramp = object : Runnable {
                override fun run() {
                    volume = minOf(1f, volume + 0.05f)
                    player?.setVolume(volume, volume)
                    if (volume < 1f) handler.postDelayed(this, 3000)
                }
            }
            handler.postDelayed(ramp, 3000)
        } catch (e: Exception) {
            runCatching {
                RingtoneManager.getRingtone(this, uri)?.apply {
                    audioAttributes = attrs
                    isLooping = true
                    play()
                }
            }
        }
        vibrator = getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 400, 700, 1200), 0))
    }

    private fun stopRinging() {
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { vibrator?.cancel() }
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }
}
