# Feature status (honest)
Legend: **Logic-tested** = web logic run in a simulated browser (jsdom) with a fake native bridge. **Not device-tested** = written but never compiled or run on a phone.

| Feature | Status |
|---|---|
| Transactions, balance, savings rate, CSV | Logic-tested |
| Planner: Smart calendar (Monday-first, selected-day reminders, complete/reopen/delete, Notify me), tasks, repeat + month-end clamp | Logic-tested |
| Focus timer survives restarts, counts each session once, bonsai stages | Logic-tested |
| Alarms: JS scheduling + one-time/repeat roll-over | Logic-tested |
| Alarms: AlarmManager + foreground-service ringing, snooze, reboot re-arm, health checks (Kotlin) | Not device-tested |
| Notifications, permission prompts (Kotlin) | Not device-tested |
| Voice notes (WebView MediaRecorder, stored in IndexedDB) | Not device-tested; format is WebM/Opus, not AAC |
| Save CSV / JSON / audio to Downloads/Sandpiper | Bridge logic-tested; MediaStore code not device-tested |
| Step counter (daily baseline, counts from first open each day) | Not device-tested |
| Habits, hydration, sleep, investments, backup/restore, calculator, About easter egg | Logic-tested |
| Gradle build / APK | **Not built** (no Android SDK available when this was written) |

## Known limits
The planner's own daily plan and skill-tree progress are not saved between launches (same as your original file). No custom alarm music, no XLSX/PDF export, no app lock, no budgets/transfers/multiple accounts, no wake-up sound loop beyond the notification's insistent alarm tone (10 min max).
Voice notes are not included in the JSON backup. Recording may stop if the app is sent to the background.
