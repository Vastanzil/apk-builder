# sandpiper.  — a little more breathing room

Offline-first Android app by Tanzil Hasan (@vastanzil). Native Kotlin shell (alarms, notifications,
file saving, step sensor) around a bundled web UI (`app/src/main/assets/index.html`). No INTERNET permission.

## One-click build
**Android Studio (easiest):** File > Open > this folder, wait for Gradle sync, press Run. APK: Build > Build APK(s).
**Command line:** install JDK 17 + Android SDK (platform 34), then run `./build-debug.sh` (Windows: `build-debug.bat`).
Output: `app/build/outputs/apk/debug/app-debug.apk`. Release: `./gradlew assembleRelease` (debug-signed; add your own keystore before publishing).
First build downloads Gradle 8.7 and dependencies, so it needs internet once.

## What works (see FEATURE_STATUS.md for details)
Money tracker with real totals + CSV, your full star-planner (daily plan, skill tree, smart calendar and reminders,
imported whole into the Planner tab), alarms that ring through a foreground service (reboot / time-zone safe), focus timer + bonsai growth, notes + voice notes, habits, hydration, sleep,
investments (manual values), calculator, JSON backup/restore, step counter, 3-tap About easter egg on the logo.

## Edit the UI
Change `app/src/main/assets/index.html`, rebuild. Data lives in WebView localStorage/IndexedDB (app-private).

## Planner
`app/src/main/assets/planner.html` is your Sandpiper planner file, unchanged except for one added line that loads
`planner-bridge.js`. The bridge schedules the planner's reminders with Android so they fire when the app is closed.
Note: as in your original file, the daily plan, points and skill-tree progress are not saved between launches; only reminders are.

## If an alarm does not ring
Open More > Alarm & Clock. The "alarm health" list shows what is blocking alarms (notifications off, full-screen
screen not allowed, battery optimisation) with a Fix button for each. "Test alarm" rings in 10 seconds; lock the phone first
to test the lock-screen path.
