package com.tanzil.reelcounter

import kotlin.math.abs
import kotlin.math.sign

/**
 * Pure-Kotlin state machine that turns noisy scroll samples into "one new reel" (JVM unit-tested).
 *
 *  - Samples are only collected; nothing is counted until the gesture SETTLES ([flush]).
 *  - Every scrolling view is tracked separately (modern apps emit events from several nested views; the
 *    pager with the biggest travel wins), so noise from one view never resets another.
 *  - A reel is counted when ANY of these holds for a view, once per settled gesture:
 *      A) net travel of 0.5-1.6 screen heights (0.8-1.25 in strict mode, for ambiguous web pages)
 *      B) the item index moved (apps that report indices but no distances)
 *      C) lenient: >= 5 events and 0.35-1.9 screens of travel (apps whose distances are partial)
 *      D) blind: >= 3 events carrying neither distance nor index
 *  - Direction aware: swiping back and then forward over a reel you already counted never recounts it.
 */
internal class SwipeDetector(private val cfg: Config = Config()) {

    data class Config(
        val minPageFraction: Float = 0.5f,
        val maxPageFraction: Float = 1.6f,
        val lenientMin: Float = 0.35f,
        val lenientMax: Float = 1.9f,
        val lenientMinEvents: Int = 5,
        val staleMs: Long = 1_500,
        val sessionIdleMs: Long = 300_000,
        val minCountGapMs: Long = 300,
        val maxBehind: Int = 12,
        val blindMinEvents: Int = 3
    )

    data class Sample(
        val t: Long, val session: String, val view: String,
        val dx: Int, val dy: Int, val index: Int, val itemCount: Int, val pagePx: Int,
        val altPagePx: Int = 0,       // page height in dp: browsers may report CSS px instead of device px
        val strict: Boolean = false   // ambiguous page (only the domain is known): demand a near-exact page swipe
    )

    private class ViewState {
        var pending = 0f; var events = 0; var base = -1; var latest = -1; var blind = 0; var touched = false
        fun clearGesture() { pending = 0f; events = 0; blind = 0; touched = false }
    }

    private val views = HashMap<String, ViewState>()
    private var session: String? = null
    private var lastEventAt = 0L
    private var lastCountAt = Long.MIN_VALUE / 2
    private var pagePx = 1
    private var altPx = 0
    private var strict = false
    private var behind = 0
    private val note = StringBuilder()

    /** Human-readable summary of the last [flush], for the Diagnostics screen. */
    var lastDecision: String = ""
        private set

    fun onSample(s: Sample) {
        if (session != s.session || s.t - lastEventAt > cfg.sessionIdleMs) resetSession(s.session)
        else if (s.t - lastEventAt > cfg.staleMs) views.values.forEach { it.clearGesture() }
        lastEventAt = s.t; pagePx = s.pagePx.coerceAtLeast(1); altPx = s.altPagePx; strict = s.strict

        if (s.dy == 0 && s.dx != 0) return            // horizontal only (carousel)
        val v = views.getOrPut(s.view) { ViewState() }
        v.pending += s.dy; v.events++; v.touched = true
        if (s.index >= 0 && s.itemCount > 0) {
            if (v.base < 0) v.base = s.index
            v.latest = s.index
        } else if (s.dy == 0) v.blind++
    }

    /** Call ~260 ms after the last sample. Returns true when exactly one NEW reel should be counted. */
    fun flush(now: Long): Boolean {
        note.setLength(0)
        var chosen = 0
        var bestTravel = -1f
        for ((name, v) in views) {
            if (!v.touched) continue
            val travel = abs(v.pending)
            val idx = if (v.latest >= 0 && v.base >= 0) v.latest - v.base else 0
            val step = stepFor(v, idx)
            note.append(name.substringAfterLast('.')).append(": travel=").append(v.pending.toInt())
                .append(" ev=").append(v.events).append(" idx=").append(idx).append(" -> ").append(step).append("; ")
            if (step != 0 && travel >= bestTravel) { chosen = step; bestTravel = travel }
        }
        for (v in views.values) if (v.touched) { v.touched = false; v.events = 0; v.blind = 0; if (v.latest >= 0) v.base = v.latest }
        if (chosen != 0) views.values.forEach { it.pending = 0f }
        note.append("page=").append(pagePx).append(if (strict) " strict" else "")
        lastDecision = note.toString()
        if (chosen == 0) return false

        if (chosen < 0) { behind = minOf(behind + 1, cfg.maxBehind); lastDecision += " | back"; return false }
        if (behind > 0) { behind--; lastDecision += " | revisit"; return false }
        if (now - lastCountAt < cfg.minCountGapMs) { lastDecision += " | too fast"; return false }
        lastCountAt = now
        return true
    }

    private fun stepFor(v: ViewState, idx: Int): Int {
        val a = abs(v.pending)
        val dir = if (v.pending > 0f) 1 else -1
        val lo = if (strict) 0.8f else cfg.minPageFraction
        val hi = if (strict) 1.25f else cfg.maxPageFraction
        if (a > 0f) {
            val unit = if (altPx > 0) minOf(pagePx, altPx) else pagePx
            if (a >= unit * lo) {                                           // A: page-sized travel
                val ok = (a >= pagePx * lo && a <= pagePx * hi) || (altPx > 0 && a >= altPx * lo && a <= altPx * hi)
                v.pending = 0f
                return if (ok) dir else 0
            }
            if (idx != 0 && a >= pagePx * 0.25f) { v.pending = 0f; return sign(idx.toFloat()).toInt() }   // B+
            if (!strict && v.events >= cfg.lenientMinEvents &&               // C: lenient
                (a >= pagePx * cfg.lenientMin && a <= pagePx * cfg.lenientMax)) { v.pending = 0f; return dir }
            return 0
        }
        if (idx != 0) return sign(idx.toFloat()).toInt()                    // B: index-only apps
        if (v.latest < 0 && v.blind >= cfg.blindMinEvents) return 1         // D: blind
        return 0
    }

    fun reset() = resetSession(null)

    private fun resetSession(s: String?) { session = s; views.clear(); behind = 0 }
}
