package com.tanzil.reelcounter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.text.InputType
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var countLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var styleButton: Button
    private lateinit var gapButton: Button
    private lateinit var lookButton: Button
    private lateinit var browserButton: Button
    private lateinit var appsButton: Button
    private lateinit var cameraLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 10, 18)
        window.navigationBarColor = Color.rgb(9, 10, 18)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::countLabel.isInitialized) refreshUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(Color.rgb(9, 10, 18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "🧠  Reel Counter"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        val subtitle = TextView(this).apply {
            text = "A tiny reminder to scroll intentionally."
            textSize = 14f
            setTextColor(0xFFB9B6C9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        countLabel = TextView(this).apply {
            textSize = 44f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        statusLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFB9B6C9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(countLabel)
        content.addView(statusLabel)
        cameraLabel = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFF7F7C93.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
        }
        content.addView(cameraLabel)
        content.addView(actionButton("Set up swipe detection") { showDisclosure() })
        if (Build.VERSION.SDK_INT >= 33) content.addView(actionButton("Unlock restricted settings") { openAppInfo() })
        content.addView(actionButton("Start tracking") { startCounter() })
        content.addView(actionButton("Pause tracking") { stopCounter() })
        content.addView(actionButton("Reset counter") { CounterStore.reset(this); refreshUi() })
        styleButton = actionButton("") { cycleStyle() }
        content.addView(styleButton)
        lookButton = actionButton("") {
            val all = IslandLook.values()
            CounterStore.setLook(this, all[(CounterStore.look(this).ordinal + 1) % all.size]); refreshUi()
        }
        content.addView(lookButton)
        content.addView(actionButton("Preview animation") {
            if (CounterStore.isEnabled(this)) CounterStore.preview(this)
            else Toast.makeText(this, "Tap Start tracking first", Toast.LENGTH_SHORT).show()
        })
        gapButton = actionButton("") { CounterStore.setGapLevel(this, (CounterStore.gapLevel(this) + 1) % 4); refreshUi() }
        content.addView(gapButton)
        browserButton = actionButton("") { CounterStore.setBrowserSupport(this, !CounterStore.browserSupport(this)); refreshUi() }
        content.addView(browserButton)
        appsButton = actionButton("") { startActivity(Intent(this, AppPickerActivity::class.java)) }
        content.addView(appsButton)
        content.addView(actionButton("Diagnostics") { showDiagnostics() })

        val note = TextView(this).apply {
            text = "A reel is counted only after a full-page vertical swipe has settled. Taps, partial drags, horizontal carousels and swiping back over a reel you already counted are ignored. Android has no official per-reel signal, so this is a close estimate.\n\nPlay Protect blocked the install? Tap More details > Install anyway. Web reels reads only the browser address bar; switch it off above if you prefer. You do not need to turn Play Protect off."
            textSize = 12f
            setTextColor(0xFF9693A8.toInt())
            setPadding(0, dp(20), 0, dp(12))
        }
        content.addView(note)
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        refreshUi()
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF5F43A8.toInt()))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(10) }
    }

    private fun showDiagnostics() {
        val body = DiagLog.dump().ifEmpty { "No scroll events seen yet.\nStart tracking, scroll in a tracked app, then open this screen again." }
        val tv = TextView(this).apply {
            text = body; textSize = 11f; typeface = Typeface.MONOSPACE
            setPadding(dp(16), dp(8), dp(16), dp(8)); setTextIsSelectable(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Diagnostics")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Reel Counter diagnostics", DiagLog.dump()))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Clear") { _, _ -> DiagLog.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun cycleStyle() {
        val all = IslandStyle.values()
        CounterStore.setStyle(this, all[(CounterStore.style(this).ordinal + 1) % all.size])
        refreshUi()
    }

    private fun startCounter() {
        if (!isAccessibilityServiceEnabled()) {
            statusLabel.text = "Set up swipe detection first; Android requires it before the counter can be shown."
            showDisclosure(); return
        }
        CounterStore.setEnabled(this, true)
        refreshUi()
    }

    private fun stopCounter() {
        CounterStore.setEnabled(this, false)
        refreshUi()
    }

    /** Prominent disclosure (required before sending a user to Accessibility settings). */
    private fun showDisclosure() {
        AlertDialog.Builder(this)
            .setTitle("Allow swipe detection?")
            .setMessage("Reel Counter uses Android Accessibility only to notice vertical swipes in Instagram, Facebook, YouTube and TikTok, and to draw the counter island at the top of the screen.\n\nIn supported web browsers it also reads only the address bar, to tell whether you are on Instagram, YouTube, Facebook or TikTok. It does not read messages, passwords or other screen content, record video, or send any data anywhere. Everything stays on this phone.\n\nOn the next screen, open Reel Counter and switch it on.")
            .setPositiveButton("Agree and continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Not now", null)
            .show()
    }

    /** Android 13+: apps installed outside a store have "restricted settings" until allowed here. */
    private fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        statusLabel.text = "Tap the ⋮ menu (top right) > Allow restricted settings, then go back and enable swipe detection."
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = ComponentName(this, ReelScrollAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun refreshUi() {
        countLabel.text = "🧠  ${CounterStore.count(this)}"
        cameraLabel.text = CounterStore.debug(this)
        appsButton.text = "Tracked apps (${CounterStore.monitoredApps(this).size})"
        lookButton.text = "Appearance: ${CounterStore.look(this).label}"
        gapButton.text = "Cutout spacing: " + listOf("Compact", "Standard", "Wide", "Extra wide")[CounterStore.gapLevel(this)]
        browserButton.text = "Web reels in browsers: " + if (CounterStore.browserSupport(this)) "On" else "Off"
        styleButton.text = "Display mode: ${CounterStore.style(this).label}"
        val detect = isAccessibilityServiceEnabled()
        statusLabel.text = when {
            !detect -> "Swipe detection is off. Tap “Set up swipe detection”."
            CounterStore.isEnabled(this) -> "Tracking active"
            else -> "Swipe detection ready · tap Start tracking"
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
