package com.vastanzil.sandpiper

import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/*
 * Diagnostics core (plan section 4). PURE Kotlin: no Android classes, so it is JVM unit-tested.
 *
 * PRIVACY BY CONSTRUCTION: an event can only be built from enums and numbers. There is no String parameter anywhere
 * in the logging path, so notes, amounts, names, URLs, package names, device ids or exception messages cannot be
 * logged: the code does not compile. Exceptions are reduced to an enum by [DiagCodes.of] (class only, never message).
 */

enum class DLvl(val code: String) { D("D"), I("I"), W("W"), E("E") }

enum class DCat { STARTUP, DB, MIGRATION, SETTINGS, PERMISSION, PORT, BRIDGE, BRAINY, ISLAND, ALARM, BACKUP, RESTORE, STEPS, DAYHUB, SELFTEST }

enum class DMod { APP, BRAINY, ISLAND, FITNESS, PLANNER, ZEN, FINANCE, ALARMS, STEPS, NOTES, PIPER, HABITS, WATER, SLEEP, INVESTMENTS, DAYHUB, OTHER, NONE }

/** Which permission a PERMISSION_CHECKED event is about (its ordinal goes in the event's numeric field). */
enum class DPerm { NOTIFICATIONS, MICROPHONE, ACTIVITY, ACCESSIBILITY, USAGE, OVERLAY, EXACT_ALARM, FULL_SCREEN, BATTERY }

enum class DRes { OK, FAIL, SKIP, DENIED, UNAVAILABLE }

enum class DCode { E_IO, E_SECURITY, E_PARSE, E_ARG, E_STATE, E_MEMORY, E_DB, E_UNKNOWN }

enum class DEv {
    // lifecycle
    PROCESS_START, MAIN_CREATED,
    // alarms
    ALARMS_RECONCILED, ALARM_ARMED, ALARM_EXPIRED, ALARM_FIRED, ALARM_FALLBACK, ALARMS_REARMED_BOOT,
    // brainy / island
    SERVICE_CONNECTED, SERVICE_UNBOUND, SERVICE_PAUSED, ISLAND_SETTINGS_APPLIED, ISLAND_SHOW_FAILED,
    // steps
    STEP_SAMPLE,
    // central database / Piper
    PIPER_SAVE, PIPER_LOAD, PIPER_RECOVERED,
    // bridge
    BRIDGE_SCHEDULE, BRIDGE_SAVE_FILE,
    // settings and permissions panels (never any value or name: only the feature enum, or the permission ordinal + result)
    SETTINGS_CHANGED, SETTINGS_SEEDED, PERMISSION_CHECKED, BACKUP_EXPORTED, BACKUP_RESTORED,
    // diagnostics itself
    SELFTEST_STARTED, SELFTEST_DONE, EXPORT_DONE, LOG_CLEARED,
    // self-test checks (these are also the rows of health.json)
    CHK_STORE_BRAINY, CHK_STORE_ISLAND, CHK_STORE_ALARMS, CHK_STORE_STEPS, CHK_STORE_PIPER,
    CHK_ALARMS_ARMED, CHK_LINK_ISLAND_BRAINY, CHK_LINK_FITNESS_BRAINY,
    CHK_BRAINY_SERVICE, CHK_STEP_SENSOR,
    CHK_PERM_NOTIFICATIONS, CHK_PERM_MICROPHONE, CHK_PERM_ACTIVITY, CHK_PERM_ACCESSIBILITY,
    CHK_PERM_USAGE, CHK_PERM_OVERLAY, CHK_PERM_EXACT_ALARM, CHK_PERM_FULL_SCREEN, CHK_BATTERY_OPT,
    CHK_REGISTRY, CHK_STORE_SETTINGS
}

/** The only shape that can be logged. [t] is milliseconds since process start (relative). */
data class DiagEvent(
    val t: Long, val lvl: DLvl, val cat: DCat, val ev: DEv, val mod: DMod, val res: DRes,
    val dur: Long, val n: Long, val code: DCode?
) {
    fun toJson(): String {
        val b = StringBuilder(128)
        b.append("{\"t\":").append(maxOf(0L, t))
        b.append(",\"lvl\":\"").append(lvl.code).append('"')
        b.append(",\"cat\":\"").append(cat.name).append('"')
        b.append(",\"ev\":\"").append(ev.name).append('"')
        b.append(",\"mod\":\"").append(mod.name).append('"')
        b.append(",\"res\":\"").append(res.name).append('"')
        b.append(",\"dur\":").append(maxOf(0L, dur))
        b.append(",\"n\":").append(maxOf(0L, n))
        b.append(",\"code\":")
        if (code == null) b.append("null") else b.append('"').append(code.name).append('"')
        b.append('}')
        return b.toString()
    }
}

/** Maps an exception to an enum by CLASS only. The message and stack trace are never read. */
object DiagCodes {
    fun of(t: Throwable?): DCode = when {
        t == null -> DCode.E_UNKNOWN
        t is java.io.IOException -> DCode.E_IO
        t is SecurityException -> DCode.E_SECURITY
        t.javaClass.name == "org.json.JSONException" -> DCode.E_PARSE
        t.javaClass.name.startsWith("android.database") -> DCode.E_DB
        t is IllegalArgumentException -> DCode.E_ARG      // includes NumberFormatException
        t is IllegalStateException -> DCode.E_STATE
        t is OutOfMemoryError -> DCode.E_MEMORY
        else -> DCode.E_UNKNOWN
    }
}

/** Every exported line must match this exactly; anything else is dropped from the export. */
object DiagSchema {
    private fun alt(names: List<String>) = names.joinToString("|")
    private val LINE = Regex(
        "^\\{\"t\":\\d{1,15},\"lvl\":\"(" + alt(DLvl.values().map { it.code }) + ")\"" +
            ",\"cat\":\"(" + alt(DCat.values().map { it.name }) + ")\"" +
            ",\"ev\":\"(" + alt(DEv.values().map { it.name }) + ")\"" +
            ",\"mod\":\"(" + alt(DMod.values().map { it.name }) + ")\"" +
            ",\"res\":\"(" + alt(DRes.values().map { it.name }) + ")\"" +
            ",\"dur\":\\d{1,15},\"n\":\\d{1,15}" +
            ",\"code\":(null|\"(" + alt(DCode.values().map { it.name }) + ")\")\\}$"
    )

    fun isValid(line: String): Boolean = LINE.matches(line)
}

/**
 * In-memory ring buffer plus an optional bounded JSONL file (app-private). Thread-safe. Never throws: logging must
 * not be able to break the app.
 */
class DiagLog(
    initialFile: File? = null,
    private val maxFileBytes: Long = 2L * 1024 * 1024,
    private val ringSize: Int = 500
) {
    private var file: File? = initialFile
    private val ring = java.util.ArrayDeque<String>()

    /** Starts writing to [f]. Events logged before this call (held in the ring) are written first. Old files are dropped. */
    @Synchronized
    fun attach(f: File, maxAgeMs: Long, nowMs: Long) {
        try {
            if (f.exists() && nowMs - f.lastModified() > maxAgeMs) f.delete()
            f.parentFile?.mkdirs()
        } catch (e: Exception) { /* ignore */ }
        file = f
        for (line in ring) append(f, line)
    }

    @Synchronized
    fun log(e: DiagEvent) {
        val line = e.toJson()
        ring.addLast(line)
        while (ring.size > ringSize) ring.removeFirst()
        val f = file
        if (f != null) append(f, line)
    }

    /** All valid lines: the file (previous runs included) when there is one, otherwise the ring. */
    @Synchronized
    fun lines(): List<String> {
        val f = file
        val raw: List<String> = if (f != null && f.exists()) {
            try { f.readLines(Charsets.UTF_8) } catch (e: Exception) { ring.toList() }
        } else ring.toList()
        return raw.filter { DiagSchema.isValid(it) }
    }

    @Synchronized
    fun clear() {
        ring.clear()
        try { file?.delete() } catch (e: Exception) { /* ignore */ }
    }

    private fun append(f: File, line: String) {
        try {
            if (f.exists() && f.length() > maxFileBytes) trim(f)
            f.appendText(line + "\n", Charsets.UTF_8)
        } catch (e: Exception) { /* ignore */ }
    }

    /** Keeps the newer half of the lines so the file stays bounded. */
    private fun trim(f: File) {
        val lines = f.readLines(Charsets.UTF_8)
        val keep = lines.drop(lines.size / 2)
        f.writeText(keep.joinToString("\n") + "\n", Charsets.UTF_8)
    }
}

data class HealthItem(val ev: DEv, val mod: DMod, val res: DRes, val n: Long)

class ExportInfo(val appVersion: String, val api: Int, val exportedAtMs: Long)

/** Builds the diagnostics zip: manifest.json, health.json, log.jsonl. Contains enums, numbers and one export time only. */
object DiagExport {
    private val SAFE_VERSION = Regex("[0-9A-Za-z._-]{1,24}")

    /** READY / LIMITED (an optional access is missing or unavailable) / ERROR (a self-test check failed). */
    fun overall(h: List<HealthItem>): String = when {
        h.any { it.res == DRes.FAIL } -> "ERROR"
        h.any { it.res == DRes.DENIED || it.res == DRes.UNAVAILABLE } -> "LIMITED"
        else -> "READY"
    }

    fun write(out: OutputStream, log: DiagLog, info: ExportInfo, health: List<HealthItem>) {
        val lines = log.lines()
        val version = if (SAFE_VERSION.matches(info.appVersion)) info.appVersion else "unknown"

        val manifest = StringBuilder()
        manifest.append("{\"format\":1,\"app\":\"com.vastanzil.sandpiper\"")
            .append(",\"appVersion\":\"").append(version).append('"')
            .append(",\"api\":").append(info.api)
            .append(",\"exportedAt\":\"").append(java.time.Instant.ofEpochMilli(info.exportedAtMs).toString()).append('"')
            .append(",\"events\":").append(lines.size)
            .append(",\"storage\":\"sharedprefs+webview\"")
            .append(",\"privacy\":\"enums-and-numbers-only\"}")

        val hj = StringBuilder()
        hj.append("{\"overall\":\"").append(overall(health)).append('"')
            .append(",\"appVersion\":\"").append(version).append('"')
            .append(",\"api\":").append(info.api)
            .append(",\"checks\":[")
        health.forEachIndexed { i, h ->
            if (i > 0) hj.append(',')
            hj.append("{\"check\":\"").append(h.ev.name).append("\",\"mod\":\"").append(h.mod.name)
                .append("\",\"res\":\"").append(h.res.name).append("\",\"n\":").append(maxOf(0L, h.n)).append('}')
        }
        hj.append("]}")

        ZipOutputStream(out).use { z ->
            put(z, "manifest.json", manifest.toString())
            put(z, "health.json", hj.toString())
            put(z, "log.jsonl", if (lines.isEmpty()) "" else lines.joinToString("\n") + "\n")
        }
    }

    private fun put(z: ZipOutputStream, name: String, text: String) {
        z.putNextEntry(ZipEntry(name))
        z.write(text.toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }
}
