package com.vastanzil.sandpiper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Today's short-video / video / feed counts per platform, settings from the Fitness page, and lock state. */
object BrainyStore {
    private const val P = "sp_brainy"
    val KEYS = listOf("tiktok", "instagram", "facebook", "youtube")
    const val LOCK_CLEAR_MS = 5 * 60_000L

    /** Platform key for a package (including the modded / Lite variants listed in [BrainyApps]), or null. */
    fun keyFor(pkg: String): String? = BrainyApps.platformOf(pkg)

    private fun prefs(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)
    private fun save(c: Context, o: JSONObject) { prefs(c).edit().putString("s", o.toString()).apply() }

    fun bp(o: JSONObject): Int = Math.round(o.optInt("feed") * 0.85 + o.optInt("short") * 3.4 + o.optInt("reg") * 1.7).toInt()

    @Synchronized
    fun state(c: Context): JSONObject {
        val o = runCatching { JSONObject(prefs(c).getString("s", "{}")) }.getOrDefault(JSONObject())
        val today = LocalDate.now().toString()
        if (o.optString("day") == today) return o
        val hist = o.optJSONObject("hist") ?: JSONObject()
        val prev = o.optString("day")
        if (prev.isNotEmpty()) hist.put(prev, JSONObject().put("bp", bp(o)).put("videos", o.optInt("short") + o.optInt("reg")))
        for (k in hist.keys().asSequence().toList().sorted().dropLast(30)) hist.remove(k)
        // Per-day reel history for the Home Activity card / Track Record (kept 400 days; "hist" above stays 30 days for Fitness).
        val rh = o.optJSONObject("rh") ?: JSONObject()
        if (prev.isNotEmpty()) rh.put(prev, JSONObject().put("s", o.optInt("short")).put("r", o.optInt("reg")).put("f", o.optInt("feed")).put("bp", bp(o)))
        for (k in rh.keys().asSequence().toList().sorted().dropLast(400)) rh.remove(k)
        val n = JSONObject().put("day", today).put("hist", hist).put("rh", rh).put("pf", JSONObject()).put("reels", JSONArray())
        save(c, n)
        return n
    }

    fun history(c: Context): JSONObject = state(c).optJSONObject("hist") ?: JSONObject()

    /** kind: "short" | "reg" | "feed" */
    @Synchronized
    fun add(c: Context, key: String, kind: String): JSONObject {
        val o = state(c)
        o.put(kind, o.optInt(kind) + 1)
        if (kind != "feed") {
            val pf = o.optJSONObject("pf") ?: JSONObject().also { o.put("pf", it) }
            pf.put(key, pf.optInt(key) + 1)
        }
        if (kind == "short") {
            val ps = o.optJSONObject("ps") ?: JSONObject().also { o.put("ps", it) }   // per-platform reels, so a reset can be exact
            ps.put(key, ps.optInt(key) + 1)
            val r = o.optJSONArray("reels") ?: JSONArray().also { o.put("reels", it) }
            r.put(System.currentTimeMillis())
            while (r.length() > 400) r.remove(0)
            o.put("recovery", false)
        }
        save(c, o)
        return o
    }

    /**
     * Brainy Island "Reset today's reel count": zeroes today's short-video count, the reels' platform share, the reel
     * timestamps (so the budget window restarts), today's warning flags and any lock. Feed items and regular YouTube
     * videos are kept.
     */
    @Synchronized
    fun resetReels(c: Context) {
        val o = state(c)
        val pf = o.optJSONObject("pf") ?: JSONObject().also { o.put("pf", it) }
        val ps = o.optJSONObject("ps")
        if (ps != null) for (k in ps.keys().asSequence().toList()) pf.put(k, maxOf(0, pf.optInt(k) - ps.optInt(k)))
        o.put("short", 0).put("ps", JSONObject()).put("reels", JSONArray()).put("warn", JSONObject())
            .put("locked", false).put("lockOffMs", 0L).put("recovery", false)
        save(c, o)
    }

    /** Returns true only the first time [name] is raised today (used for one warning per level per day). */
    @Synchronized
    fun once(c: Context, name: String): Boolean {
        val o = state(c)
        val w = o.optJSONObject("warn") ?: JSONObject().also { o.put("warn", it) }
        if (w.optBoolean(name)) return false
        w.put(name, true); save(c, o); return true
    }

    @Synchronized fun setLocked(c: Context, on: Boolean) { val o = state(c); if (o.optBoolean("locked") != on) { o.put("locked", on); if (on) o.put("lockOffMs", 0L); save(c, o) } }

    /** Adds screen-off time while locked; clears the lock after 5 minutes in total. Returns true if cleared. */
    @Synchronized
    fun addLockOff(c: Context, ms: Long): Boolean {
        val o = state(c)
        if (!o.optBoolean("locked")) return false
        val t = o.optLong("lockOffMs") + ms
        if (t >= LOCK_CLEAR_MS) {
            o.put("locked", false).put("lockOffMs", 0L).put("clearedAt", System.currentTimeMillis()).put("recovery", true)
            save(c, o); return true
        }
        o.put("lockOffMs", t); save(c, o); return false
    }

    fun reelsInWindow(o: JSONObject, winMin: Int): Int {
        val since = maxOf(System.currentTimeMillis() - winMin * 60_000L, o.optLong("clearedAt", 0L))
        val r = o.optJSONArray("reels") ?: return 0
        var n = 0
        for (i in 0 until r.length()) if (r.getLong(i) > since) n++
        return n
    }

    /** Shape expected by the Fitness page's setBrainrot(). Counts come from accessibility heuristics, so they are labelled "medium" (Estimated). */
    fun snapshot(c: Context): JSONObject {
        val o = state(c)
        val cleared = o.optLong("clearedAt", 0L)
        val reels = JSONArray()
        o.optJSONArray("reels")?.let { for (i in 0 until it.length()) if (it.getLong(i) > cleared) reels.put(it.getLong(i)) }
        val pf = o.optJSONObject("pf") ?: JSONObject()
        val plat = JSONObject()
        for (k in KEYS) plat.put(k, JSONObject().put("v", pf.optInt(k)).put("c", if (pf.optInt(k) > 0) "medium" else "low"))
        return JSONObject().put("feed", o.optInt("feed")).put("short", o.optInt("short")).put("reg", o.optInt("reg"))
            .put("platforms", plat).put("reels", reels).put("recovery", o.optBoolean("recovery")).put("rh", o.optJSONObject("rh") ?: JSONObject())
    }

    fun settings(c: Context): JSONObject {
        val d = JSONObject(
            """{"float":true,"notif":true,"block":false,"quiet":false,"qs":"22:00","qe":"07:00","win":120,"limit":20,"warn1":10,"warn2":20,"daily":25,"vib":true,"snoozeUntil":0}"""
        )
        runCatching { JSONObject(prefs(c).getString("set", "{}")) }.getOrNull()?.let { s -> for (k in s.keys()) d.put(k, s.get(k)) }
        return d
    }

    fun setSettings(c: Context, json: String) { runCatching { JSONObject(json) }.onSuccess { prefs(c).edit().putString("set", it.toString()).apply() } }

    fun inQuiet(s: JSONObject): Boolean {
        if (!s.optBoolean("quiet")) return false
        fun mins(t: String): Int { val p = t.split(":"); return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0) }
        val cal = java.util.Calendar.getInstance()
        val now = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        val a = mins(s.optString("qs", "22:00")); val b = mins(s.optString("qe", "07:00"))
        return if (a <= b) now in a until b else now >= a || now < b
    }
}
