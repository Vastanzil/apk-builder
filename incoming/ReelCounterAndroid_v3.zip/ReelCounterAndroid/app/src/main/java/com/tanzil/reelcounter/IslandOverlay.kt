package com.tanzil.reelcounter

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Dynamic-island style counter, drawn by the accessibility service as TYPE_ACCESSIBILITY_OVERLAY.
 * That window type needs NO "Display over other apps" permission, so only one special permission remains.
 *  - centred punch-hole -> black pill wrapped around the camera: [mascot] (camera) [count]
 *  - wide notch         -> black status-bar band
 *  - no / off-centre cut-out, or landscape -> small floating pill
 * Mascot = view id R.id.reel_mascot in res/layout/overlay_island.xml (swap the TextView for an ImageView).
 */
internal class IslandOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var appliedKey = ""
    private var symmetric = false

    val isShowing get() = root != null

    fun show() {
        if (root != null) return
        val view = LayoutInflater.from(ContextThemeWrapper(ctx, R.style.AppTheme)).inflate(R.layout.overlay_island, null)
        val p = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, dp(32),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        view.setOnApplyWindowInsetsListener { _, insets -> relayout(insets); insets }
        try {
            wm.addView(view, p)
            root = view; params = p; appliedKey = ""
            render(CounterStore.count(ctx), false)
            view.requestApplyInsets()
        } catch (_: Exception) { root = null; params = null }
    }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        root = null; params = null; appliedKey = ""
    }

    /** Re-evaluate cut-out / rotation / style. */
    fun refresh() { appliedKey = ""; root?.requestApplyInsets() }

    fun render(value: Int, animate: Boolean) {
        val v = root ?: return
        v.findViewById<TextView>(R.id.reel_count).text = value.toString()
        syncSlots(v)
        if (animate) {
            pulse(v.findViewById(R.id.reel_count), 0.78f)
            pulse(v.findViewById(R.id.reel_mascot), 0.9f)
        }
    }

    private fun relayout(insets: WindowInsets?) {
        val v = root ?: return
        val p = params ?: return
        val screen = screenSize()
        val cut = if (Build.VERSION.SDK_INT >= 28) insets?.displayCutout else null
        val rect = cut?.boundingRects
            ?.filter { it.top <= 1 && it.width() > 0 }
            ?.minByOrNull { abs(it.exactCenterX() - screen.x / 2f) }
        val landscape = screen.x > screen.y
        val centered = rect != null && abs(rect.exactCenterX() - screen.x / 2f) <= screen.x * 0.1f
        val wide = rect != null && (rect.width() > screen.x * 0.14f || rect.height() > dp(40))
        val auto = when { landscape || !centered -> IslandStyle.FLOAT; wide -> IslandStyle.STATUS_BAR; else -> IslandStyle.ISLAND }
        val pref = CounterStore.style(ctx)
        val style = when {
            pref == IslandStyle.AUTO -> auto
            pref == IslandStyle.FLOAT || landscape || !centered -> IslandStyle.FLOAT
            else -> pref
        }
        val sb = max(statusBarHeight(), rect?.bottom ?: 0)

        val gap: Int; val w: Int; val h: Int; val x: Int; val y: Int; val pad: Int
        if (style == IslandStyle.ISLAND && rect != null) {
            gap = rect.width() + dp(8)
            h = max(dp(30), rect.height() + dp(10))
            y = max(0, rect.top - (h - rect.height()) / 2)
            x = (rect.exactCenterX() - screen.x / 2f).roundToInt()
            w = ViewGroup.LayoutParams.WRAP_CONTENT; pad = dp(10)
        } else if (style == IslandStyle.STATUS_BAR && rect != null) {
            gap = rect.width() + dp(16); h = sb; y = 0; x = 0
            w = ViewGroup.LayoutParams.MATCH_PARENT; pad = 0
        } else {
            gap = dp(6); h = dp(32); x = 0
            y = max(dp(4), (sb - h) / 2)
            w = ViewGroup.LayoutParams.WRAP_CONTENT; pad = dp(12)
        }

        val key = "$style|$gap|$w|$h|$x|$y"
        if (key == appliedKey) return
        appliedKey = key
        symmetric = style != IslandStyle.FLOAT
        when (style) {
            IslandStyle.STATUS_BAR -> v.setBackgroundColor(Color.BLACK)
            IslandStyle.FLOAT -> v.setBackgroundResource(R.drawable.bg_island_float)
            else -> v.setBackgroundResource(R.drawable.bg_island)
        }
        v.setPadding(pad, 0, pad, 0)
        v.findViewById<View>(R.id.reel_cutout_gap).let { g -> g.layoutParams = g.layoutParams.apply { width = gap } }
        p.width = w; p.height = h; p.x = x; p.y = y
        syncSlots(v)
        try { wm.updateViewLayout(v, p) } catch (_: Exception) { }
    }

    /** Keeps mascot slot and count slot the same width so the camera hole stays centred. */
    private fun syncSlots(v: View) {
        val count = v.findViewById<TextView>(R.id.reel_count)
        val width = if (symmetric) max(dp(26), ceil(count.paint.measureText(count.text.toString())).toInt() + dp(2))
                    else ViewGroup.LayoutParams.WRAP_CONTENT
        for (id in intArrayOf(R.id.reel_left_slot, R.id.reel_right_slot)) {
            val s = v.findViewById<View>(id)
            if (s.layoutParams.width != width) s.layoutParams = s.layoutParams.apply { this.width = width }
        }
    }

    private fun pulse(t: View, from: Float) {
        t.animate().cancel(); t.scaleX = from; t.scaleY = from
        t.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.let { Point(it.width(), it.height()) }
        else Point().also { wm.defaultDisplay.getRealSize(it) }

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), ctx.resources.displayMetrics).roundToInt()
}
