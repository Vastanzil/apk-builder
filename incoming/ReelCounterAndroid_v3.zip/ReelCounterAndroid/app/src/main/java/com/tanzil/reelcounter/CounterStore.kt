package com.tanzil.reelcounter

import android.content.Context
import android.content.Intent

enum class IslandStyle(val label: String) {
    AUTO("Auto (detect cutout)"),
    ISLAND("Dynamic island (punch-hole)"),
    STATUS_BAR("Black status bar (notch)"),
    FLOAT("Floating pill")
}

internal object CounterStore {
    const val ACTION_COUNT_CHANGED = "com.tanzil.reelcounter.COUNT_CHANGED"
    const val ACTION_STYLE_CHANGED = "com.tanzil.reelcounter.STYLE_CHANGED"
    const val ACTION_ENABLED_CHANGED = "com.tanzil.reelcounter.ENABLED_CHANGED"
    private const val PREFS = "reel_counter_store"
    private const val KEY_COUNT = "count"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_STYLE = "style"

    fun count(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0)
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
        notify(context, ACTION_ENABLED_CHANGED)
    }

    fun style(context: Context): IslandStyle =
        runCatching { IslandStyle.valueOf(prefs(context).getString(KEY_STYLE, null) ?: "AUTO") }.getOrDefault(IslandStyle.AUTO)
    fun setStyle(context: Context, style: IslandStyle) {
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()
        notify(context, ACTION_STYLE_CHANGED)
    }

    fun increment(context: Context): Int {
        val next = count(context) + 1
        prefs(context).edit().putInt(KEY_COUNT, next).apply()
        notify(context, ACTION_COUNT_CHANGED)
        return next
    }
    fun reset(context: Context) {
        prefs(context).edit().putInt(KEY_COUNT, 0).apply()
        notify(context, ACTION_COUNT_CHANGED)
    }
    private fun notify(context: Context, action: String) = context.sendBroadcast(Intent(action).setPackage(context.packageName))
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
