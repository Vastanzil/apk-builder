package com.tanzil.reelcounter

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Collects TYPE_VIEW_SCROLLED samples from allow-listed apps and lets [SwipeDetector] decide
 * when a swipe has settled into a new reel. No window content, text or pixels are read.
 */
class ReelScrollAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val detector = SwipeDetector()
    private var lastScrollY = -1
    private var overlay: IslandOverlay? = null
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CounterStore.ACTION_COUNT_CHANGED -> overlay?.render(CounterStore.count(this@ReelScrollAccessibilityService), true)
                CounterStore.ACTION_STYLE_CHANGED -> overlay?.refresh()
                CounterStore.ACTION_ENABLED_CHANGED -> syncOverlay()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlay = IslandOverlay(this)
        val f = IntentFilter().apply {
            addAction(CounterStore.ACTION_COUNT_CHANGED); addAction(CounterStore.ACTION_STYLE_CHANGED); addAction(CounterStore.ACTION_ENABLED_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, f)
        receiverRegistered = true
        syncOverlay()
    }

    private fun syncOverlay() { if (CounterStore.isEnabled(this)) overlay?.show() else overlay?.hide() }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig); overlay?.refresh()
    }

    private fun teardown() {
        handler.removeCallbacks(settle)
        overlay?.hide()
        if (receiverRegistered) { try { unregisterReceiver(receiver) } catch (_: Exception) { }; receiverRegistered = false }
    }

    override fun onDestroy() { teardown(); super.onDestroy() }
    private val settle = Runnable {
        if (detector.flush(SystemClock.uptimeMillis())) CounterStore.increment(this@ReelScrollAccessibilityService)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return
        if (!CounterStore.isEnabled(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in SUPPORTED_PACKAGES) return

        val dx: Int
        val dy: Int
        if (Build.VERSION.SDK_INT >= 28) {
            dx = event.scrollDeltaX; dy = event.scrollDeltaY
        } else {                                   // API 26-27: derive delta from absolute offset
            val y = event.scrollY
            dy = if (y >= 0 && lastScrollY >= 0) y - lastScrollY else 0
            lastScrollY = y; dx = 0
        }
        detector.onSample(
            SwipeDetector.Sample(
                SystemClock.uptimeMillis(), pkg, event.className?.toString().orEmpty(),
                dx, dy, event.fromIndex, event.itemCount, resources.displayMetrics.heightPixels
            )
        )
        handler.removeCallbacks(settle)
        handler.postDelayed(settle, SETTLE_MS)
    }

    override fun onInterrupt() { handler.removeCallbacks(settle); detector.reset() }
    override fun onUnbind(intent: Intent?): Boolean { teardown(); return super.onUnbind(intent) }

    companion object {
        private const val SETTLE_MS = 260L
        private val SUPPORTED_PACKAGES = setOf(
            "com.instagram.android", "com.facebook.katana", "com.facebook.lite",
            "com.google.android.youtube", "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go"
        )
    }
}
