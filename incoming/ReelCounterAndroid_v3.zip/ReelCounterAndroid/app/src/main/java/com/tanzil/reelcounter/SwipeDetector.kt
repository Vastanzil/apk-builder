package com.tanzil.reelcounter

import kotlin.math.abs

/**
 * Pure-Kotlin state machine that turns noisy scroll samples into "one new reel".
 * No Android dependencies, so it is unit-tested on the JVM.
 *
 * Rules (the fix for touches / jitter / one reel counted 3-4 times):
 *  1. Samples are only collected. Nothing is counted until the gesture SETTLES ([flush]).
 *  2. A page change needs net vertical travel of 0.5-1.6 screen heights (px, so DPI-independent).
 *     Taps, drags that snap back, progress-bar scrubs and residual snap-animation events never reach it.
 *  3. Horizontal-only scrolls (carousels) are ignored.
 *  4. Direction aware: swiping back and forth over the same reel never counts it twice ([behind]).
 *  5. At most one reel per settled gesture; a flinged feed (> 1.6 pages) is rejected.
 */
internal class SwipeDetector(private val cfg: Config = Config()) {

    data class Config(
        val minPageFraction: Float = 0.5f,
        val maxPageFraction: Float = 1.6f,
        val staleMs: Long = 1_500,          // a pause longer than this starts a fresh gesture
        val sessionIdleMs: Long = 300_000,  // forget back/forward history after 5 idle minutes
        val minCountGapMs: Long = 300,
        val maxBehind: Int = 12,
        val blindMinEvents: Int = 3         // fallback for apps that send scroll events with no deltas/indices
    )

    data class Sample(
        val t: Long, val session: String, val view: String,
        val dx: Int, val dy: Int, val index: Int, val itemCount: Int, val pagePx: Int
    )

    private var session: String? = null
    private var view: String? = null
    private var lastEventAt = 0L
    private var lastCountAt = Long.MIN_VALUE / 2
    private var pendingDy = 0f
    private var baseIndex = -1
    private var latestIndex = -1
    private var blindEvents = 0
    private var pagePx = 1
    private var behind = 0
    private var touched = false

    fun onSample(s: Sample) {
        if (session != s.session || s.t - lastEventAt > cfg.sessionIdleMs) resetSession(s.session)
        if (view != s.view) { baseIndex = -1; latestIndex = -1; clearGesture() }
        else if (s.t - lastEventAt > cfg.staleMs) clearGesture()
        view = s.view; lastEventAt = s.t; pagePx = s.pagePx.coerceAtLeast(1)

        if (s.dy == 0 && s.dx != 0) return            // horizontal only
        pendingDy += s.dy
        if (s.index >= 0 && s.itemCount > 0) {
            if (baseIndex < 0) baseIndex = s.index
            latestIndex = s.index
        } else if (s.dy == 0) blindEvents++
        touched = true
    }

    /** Call ~260 ms after the last sample. Returns true when exactly one NEW reel should be counted. */
    fun flush(now: Long): Boolean {
        if (!touched) return false
        touched = false
        val a = abs(pendingDy)
        val idx = if (latestIndex >= 0 && baseIndex >= 0) latestIndex - baseIndex else 0
        var step = 0
        if (a > 0f) {
            if (a >= pagePx * cfg.minPageFraction) {
                if (a <= pagePx * cfg.maxPageFraction) step = if (pendingDy > 0f) 1 else -1
                pendingDy = 0f                         // committed or flung: discard residue
            } else if ((idx == 1 || idx == -1) && a >= pagePx * 0.25f) {
                step = idx; pendingDy = 0f             // some delta events were dropped: trust the index
            }
        } else if (latestIndex >= 0) {
            if (idx == 1 || idx == -1) step = idx
        } else if (blindEvents >= cfg.blindMinEvents) step = 1
        if (latestIndex >= 0) baseIndex = latestIndex
        blindEvents = 0
        if (step == 0) return false

        if (step < 0) { behind = minOf(behind + 1, cfg.maxBehind); return false }
        if (behind > 0) { behind--; return false }     // re-watching a reel already counted
        if (now - lastCountAt < cfg.minCountGapMs) return false
        lastCountAt = now
        return true
    }

    fun reset() = resetSession(null)

    private fun resetSession(s: String?) {
        session = s; view = null; behind = 0; baseIndex = -1; latestIndex = -1; clearGesture()
    }

    private fun clearGesture() { pendingDy = 0f; blindEvents = 0; touched = false }
}
