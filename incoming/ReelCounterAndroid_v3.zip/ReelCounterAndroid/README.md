# Reel Counter — Android Kotlin starter project

A minimal Android floating Dynamic-Island-style counter. The overlay contains exactly two visual elements: a brain emoji and a number.

## What is implemented

- Always-on-top pill using `TYPE_APPLICATION_OVERLAY`.
- Count persisted locally in `SharedPreferences`.
- Accessibility service listens only for `TYPE_VIEW_SCROLLED` events from Instagram, Facebook, YouTube and TikTok package IDs.
- Scroll events are collected and judged only when the swipe SETTLES (`SwipeDetector`): net vertical travel of 0.5-1.6 screen heights, one reel per gesture, horizontal scrolls ignored, back-and-forth over an already counted reel never recounts. Unit tests: `./gradlew test`.
- Overlay is non-touchable so it does not intercept taps or swipes in the app underneath.
- Foreground service keeps the overlay alive while enabled.
- No screen recording, screenshots, OCR, video capture, or window-content retrieval.

## Important detection limitation

Android does not provide a universal, trustworthy “Reel/Short changed” callback across these apps. This implementation counts vertical scroll accessibility events from the supported apps. Therefore it can also count scrolling in comments, search results, profiles, or ordinary feeds, and some app versions may emit too few or too many events. It is an estimate, not an exact Reel counter. The supported app package IDs can also change by region/version.

## Build

1. Open this folder in Android Studio (JDK 17).
2. Allow Gradle sync to complete.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the phone.
5. Open Reel Counter and grant **Display over other apps**.
6. Open **Enable swipe detection** and enable Reel Counter under Android Accessibility settings.
7. Return to Reel Counter and tap **Start counter**.

To stop the overlay, open the app and tap **Stop counter**. The count is retained until **Reset count** is tapped.

## Integration into an existing app

This is a standalone starter project because the existing Sandpiper Android project ZIP was not attached to this conversation. To merge it into an existing app, copy the Kotlin classes and resource XML, merge the manifest declarations and permissions, and resolve any namespace/package changes. Do not replace the existing app manifest wholesale.

## Android permission disclosure

The accessibility service is used only to receive scroll events from the explicitly allow-listed packages. `canRetrieveWindowContent` is false. The app should clearly explain this to users before directing them to enable the service.


## v2 notes
- **Dynamic island overlay** reads the real `DisplayCutout`: centred punch-hole -> pill wrapped around the camera; wide notch -> black status-bar band (hides system icons under it, switch style in the app if unwanted); no cut-out or landscape -> floating pill. Style can be forced from the app.
- **Mascot:** the brain is `@+id/reel_mascot` in `res/layout/overlay_island.xml`. Replace the TextView with an `ImageView` using the same id; no code change needed.
- Not compiled or run on a device in the authoring environment: build, run `./gradlew test`, and check on a punch-hole and a notch phone.

## v3: permissions and Play Protect
- **Only one special permission is left.** The island is now an `TYPE_ACCESSIBILITY_OVERLAY` window owned by the accessibility service, so `SYSTEM_ALERT_WINDOW`, the foreground service and the notification permission are gone. Accessibility + draw-over-apps is the combination Play Protect scans hardest.
- **Prominent disclosure** dialog appears before the user is sent to Accessibility settings.
- **Android 13+ "restricted settings"**: sideloaded apps get the accessibility switch greyed out. The app has a button to App info; then menu (three dots) > Allow restricted settings. Installing through a store or a session-based installer avoids this.
- **Play Protect "blocked" / "unsafe app" prompt**: tap More details > Install anyway (or choose Don't send). Turning Play Protect off is not required. This cannot be bypassed in code. For a stable result, sign releases with your own release keystore (not the debug key) and publish through Google Play (internal testing is enough).
- The service is not declared as an accessibility tool (`isAccessibilityTool`), because it is not one; do not add that flag to dodge restrictions.
