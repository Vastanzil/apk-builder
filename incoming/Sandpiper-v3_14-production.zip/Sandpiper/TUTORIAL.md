# Sandpiper tutorial

A hands-on guide with examples: build it, set it up, use each part, change settings, back up, and extend it.
Everything here matches the v3.1 project (Settings and Permissions panels included).

Contents
1. [Build and install](#1-build-and-install)
2. [First five minutes](#2-first-five-minutes)
3. [Permissions: grant only what you want](#3-permissions-grant-only-what-you-want)
4. [Settings panel by example](#4-settings-panel-by-example)
5. [Everyday use](#5-everyday-use)
6. [Backup and restore](#6-backup-and-restore)
7. [Extending: add a setting or a permission](#7-extending-add-a-setting-or-a-permission)
8. [Tests](#8-tests)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Build and install

You need: JDK 17, Android SDK platform 34, and internet once (Gradle downloads itself and the libraries).
The app runs on Android 10 (API 29) and newer and asks for no internet permission.

**Android Studio (easiest)**
1. File > Open > pick the `Sandpiper` folder.
2. Wait for "Gradle sync" to finish.
3. Press Run, or Build > Build APK(s).

**Command line**
```bash
# macOS / Linux
export ANDROID_HOME=$HOME/Android/Sdk      # or put sdk.dir=... in local.properties
./build-debug.sh

# Windows
build-debug.bat
```
The APK appears at `app/build/outputs/apk/debug/app-debug.apk`. Install it:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
`./gradlew assembleRelease` builds a release APK, signed with the debug key. Add your own keystore before publishing.

---

## 2. First five minutes

1. Open the app. Nothing asks for permission yet. That is intentional.
2. Add a transaction: **Finance > Add transaction**, for example `Lunch`, `250`, Expense.
3. Open **Settings**: go to **More** and use the **Settings & permissions** card at the bottom.
4. Pick the **Permissions** tab and look at what is missing. Grant only what you need (next section).
5. Create an alarm in **More > Alarm and Clock**, then press **Test alarm** (it rings in 10 seconds).

Tip: lock the phone right after pressing **Test alarm** to test the lock-screen path too.

---

## 3. Permissions: grant only what you want

Open **More > Settings & permissions > Permissions**. Each permission is listed once with a live state:

| State | Meaning | Button |
|---|---|---|
| Granted | Working | none |
| Not granted | Android can show a prompt | **Grant** |
| Permanently denied | Android will not ask again | **Open App info** |
| Special access | Needs an Android settings page | **Open settings** |
| Not applicable | Your phone or Android version does not need it | none |

Nothing is requested when the panel opens. A request happens only when you tap a button, or the first time you really use a feature (you then see a "why we need this" sheet first).

### Example A: microphone for voice notes
1. **Notes > Voice notes > Record**.
2. If the microphone is off, a sheet explains why. Tap **Continue**, then allow it in the Android prompt.
3. Back in **Settings > Permissions** the row now reads **Granted**. No restart needed.

### Example B: Brainy Island needs Accessibility
1. Open **Settings > Brainy Island**. The section header shows a chip: **Needs Accessibility service · Fix**. Tap it.
2. The Permissions tab opens with that row highlighted. Tap **Open settings**.
3. In Android, open **Sandpiper Brainy** and turn it on.
4. Come back. The chip becomes **Ready**.

If the Accessibility switch is greyed out on Android 13+: open **App info > ⋮ menu > Allow restricted settings**, then try again. (Android does this to apps installed from an APK file.)

### Example C: see it by feature
Tap **By feature** to read it the other way: "Brainy Island needs: Accessibility service (required), Display over other apps (optional), Notifications (optional)". Optional permissions never block a feature and never show as errors.

What each one enables:

| Permission | Used for |
|---|---|
| Notifications | Alarms, reminders, Brainy warnings |
| Microphone | Voice notes, only while you record |
| Activity recognition | Steps and active minutes |
| Exact alarms | Reminders at the exact minute |
| Full-screen alarm | Alarm screen over the lock screen |
| Battery optimisation | Fewer delayed alarms (optional) |
| Accessibility service | Counting short videos for Brainy |
| Usage access | Real time spent in video apps |
| Display over other apps | The island and the focus lock |

---

## 4. Settings panel by example

**Settings > Settings** shows sections on the left (a scrolling row on phones). Use the search box to find anything.

### Example: change currency
**Settings > Finance > Currency**, choose **USD ($)**. Every amount in the app changes immediately.

### Example: custom transaction categories
**Settings > Finance > Categories**, type:
```
Rent, Food , Rent, Fun
```
The list in **Add transaction** becomes `Rent`, `Food`, `Fun` (extra spaces and duplicates are removed). An empty list is rejected and your previous categories stay.

### Example: tune alarms
**Settings > Alarms and clock**
- **Snooze length**: 5, 10 or 15 minutes. The Snooze buttons on the alarm screen use it.
- **Stop ringing after**: 1, 5, 10 or 15 minutes.
- **Rising volume**: off = full volume right away.
- **Default alarm sound**: used for new alarms. Each alarm can still pick its own.

### Example: Brainy limits (Fitness and steps)
Defaults: first warning at 10, strong warning at 20, daily limit 25 short videos.
You can change them, but the order must stay **first ≤ strong ≤ daily**. Setting the strong warning to 5 while the first is 10 is refused with a message and nothing changes.

Quiet hours use 24-hour times: `22:00` to `07:00`. Anything like `25:99` is rejected.

### Example: "Action required"
Next to a control that needs a missing permission you see, for instance:
> Action required: Accessibility service is off. **Fix**

Tapping **Fix** jumps to that exact permission row.

### Example: search
Type `snooze` in the search box. The panel shows only **Alarms and clock > Snooze length**, wherever it lives.

Other rows you will find:
- **Brainy Island**: tracking, island style, look, gap below the camera, browser counting (opt-in), and **Tracked apps (N)** which opens the native picker.
- **Notes and Piper**: which one Notes opens in, the Piper storage status, and a button that opens Piper's own settings.
- **Diagnostics** and **About**.

---

## 5. Everyday use

**Planner and Close the day.** Plan tasks in **Planner**. When you press **Close the day**, Sandpiper saves one record with your planner tasks and points, your Zen focus sessions and your Fitness data, and banks bonus points into the planner total:
```
bonus points = 10 x (net Fitness stars today) + 5 x (focus sessions today)
example: 3 stars + 2 sessions = 30 + 10 = 40 points
```
Closing the same day again updates the record and never banks the same points twice. See the list in **More > Settings & permissions > Settings > Backup > Closed days** (CSV export available there).

**Zen Garden.** The timer and your garden share one card. A finished focus session grows the tree. The timer survives leaving the app and notifies you when it ends.

**Fitness.** Tap the **Fitness** button in Zen Garden to open it full screen. Leave with the Android Back button or gesture.

**Habits.** Habits live on the Zen Garden page, under the Fitness button. Add a tiny habit with a cue ("After I pour my coffee…") and tick it each day to build a streak.

**Investment tracker.** It lives on the Finance page, under Transactions. Values are entered by you and nothing there is investment advice.

**Brainy Island.** Settings > Brainy Island. The first row ("Brainy Island") opens the native screen; the rows below set tracking, style, look, gap and tracked apps.

**Voice notes.** Notes > Voice notes. Record, Pause, then **Stop and save** or **Discard**. Recordings stay on the phone.

**Notes and Piper.** The Notes / Piper Pro switch is the left side of the Notes header and toggles instantly. To change which one opens by default, use **Settings > Notes and Piper**.

---

## 6. Backup and restore

**Settings > Backup and data**

**Back up now** saves `Downloads/Sandpiper/sandpiper-backup-2026-11-05.json` (today's date). It contains:
```jsonc
{
  "app": "sandpiper",
  "version": 3,
  "state":   { /* transactions, tasks, notes, alarms, habits, ... */ },
  "planner_reminders": [ /* planner reminders */ ],
  "fitness": { /* Fitness page data */ },
  "settings": { "finance": { "finance.currency": "USD" } },
  "piper":   { /* optional Piper workspace */ },
  "includes": { "piper": true }
}
```
Turn **Include Piper workspace in backups** off to make a smaller file.

Also in **Settings > Backup**:
- **Export Piper workspace** saves `piper-backup-DATE.json` using Piper's own export.
- **Import into Piper** restores a Piper backup, or imports Markdown, CSV or HTML files. Piper asks before replacing anything.
- **Export transactions** saves your transactions as a CSV file.
- **Closed days** shows the saved day records (with their own Export CSV button). Voice recordings are not included.

**Restore from a backup**
1. Press **Restore** and choose the file.
2. Sandpiper checks the whole file first. A damaged, unknown or non-Sandpiper file is refused and **nothing** is changed.
3. You confirm. A safety copy of your current data is kept, then everything is replaced.
4. If the Piper part fails, you are told and your current Piper workspace is left alone.

Older version 2 backups still restore.

---

## 7. Extending: add a setting or a permission

Everything in Settings and Permissions is generated from one file: `app/src/main/assets/features.json`.

### Add a setting
Add an object to `settings`:
```json
{
  "id": "water.reminders",
  "feature": "habits",
  "type": "toggle",
  "label": "Water reminders",
  "help": "Nudge me during the day.",
  "store": "state",
  "key": "waterReminders",
  "default": false,
  "authority": "central"
}
```
- `type`: `toggle`, `number` (add `min`, `max`), `choice` (add `options`), `text`, `action`, `info`, `perm`.
- `store`: `state` (app data), `notesmode`, `app` (native), `island` (Brainy Island), `fit` (Fitness page).
- `requires: ["accessibility"]` adds an "Action required" link when that permission is off.

The panel now shows and saves it, mirrors it in the central database, includes it in backups and logs the change (feature name only, never the value). **Your feature code still has to read the value** (here, `S.waterReminders`).

### Add a permission
1. Add the `<uses-permission>` line to `AndroidManifest.xml`.
2. Add an entry to `permissions` in `features.json` listing that manifest name.
3. Add its id to `requires` or `optional` of at least one feature.
4. If it needs a custom check or settings page, add it in `Permissions.kt`.

### Check your work
```bash
./gradlew testDebugUnitTest
```
`FeatureRegistryTest` fails if a manifest permission is missing from the registry, an id is duplicated, a permission has no feature, or a choice default is not one of its options.

---

## 8. Tests

| Command | What it covers |
|---|---|
| `./gradlew testDebugUnitTest` | Registry consistency, alarm option values, Brainy counting, diagnostics, and more |
| More > ... > Settings > Diagnostics > Open | In-app self-test: should read READY or LIMITED, never ERROR |

Device checklist for special permissions (each one): grant it, revoke it in Android settings, return to Sandpiper, and confirm the state updates without a restart.

---

## 9. Troubleshooting

| Problem | What to do |
|---|---|
| An alarm did not ring | **Settings > Permissions**: check Notifications (required), then Full-screen alarm and Battery optimisation (optional). Use **Test alarm** with the phone locked. |
| Accessibility switch is greyed out | App info > ⋮ > **Allow restricted settings**, then retry. |
| Brainy counts nothing | Accessibility must be on and the tracking toggle (Settings > Brainy Island) enabled. Counts are estimates and depend on each app's screens. |
| "Permanently denied" | Android will not ask again. Tap **Open App info** and allow it there. |
| Changed a setting but it looks the same | Check you are in the right section. Search for it by name. Some Fitness limits can also be changed inside the Fitness page and the panel will show the live value. |
| Restore was refused | The message names the problem (damaged data, unknown version, not a Sandpiper file). Your current data was not touched. |
| Gradle sync fails | Use JDK 17, install SDK platform 34, and let the first sync download dependencies. |
| Want to undo a restore | Your previous data was stored under the `sp_pre_restore` key. Back up first if the data matters, and keep your own copies of backup files. |

Made by Tanzil Hasan. A little more breathing room.
