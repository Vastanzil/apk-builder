@echo off
cd /d "%~dp0"
call gradlew.bat clean assembleRelease bundleRelease
echo.
echo APK: app\build\outputs\apk\release\app-release.apk
echo AAB: app\build\outputs\bundle\release\app-release.aab
echo Mapping: app\build\outputs\mapping\release\mapping.txt
