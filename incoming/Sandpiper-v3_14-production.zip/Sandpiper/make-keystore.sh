#!/usr/bin/env bash
# Creates a release signing key for Sandpiper and a matching keystore.properties.
# Run once, from the project root: ./make-keystore.sh
#
# Keep release.jks and keystore.properties safe and back them up. If you lose the keystore you cannot publish an
# update to an existing install under the same applicationId - Android treats it as a different app.
set -euo pipefail
cd "$(dirname "$0")"

if [ -f release.jks ]; then
  echo "release.jks already exists here. Delete or move it first if you really want to make a new one." >&2
  exit 1
fi

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool was not found. It ships with any JDK (the same one Android Studio / Gradle uses)." >&2
  exit 1
fi

read -rp "Your name or organisation (for the certificate, e.g. 'Tanzil Hasan'): " CN
read -rp "Key alias [sandpiper]: " ALIAS
ALIAS=${ALIAS:-sandpiper}

while true; do
  read -rsp "Keystore password (used for both the store and the key): " PASS
  echo
  read -rsp "Confirm password: " PASS2
  echo
  [ "$PASS" = "$PASS2" ] && [ -n "$PASS" ] && break
  echo "Passwords did not match or were empty - try again." >&2
done

keytool -genkeypair -v \
  -keystore release.jks \
  -alias "$ALIAS" \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" \
  -dname "CN=$CN, OU=, O=, L=, ST=, C="

cat > keystore.properties <<EOF
storeFile=release.jks
storePassword=$PASS
keyAlias=$ALIAS
keyPassword=$PASS
EOF

echo
echo "Created release.jks and keystore.properties."
echo "Both are gitignored - keep them safe outside git (password manager, encrypted backup)."
echo "Next build will sign release automatically: ./gradlew assembleRelease"
