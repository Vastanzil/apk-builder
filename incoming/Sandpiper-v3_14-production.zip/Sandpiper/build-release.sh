#!/usr/bin/env bash
# Production build: signed, minified APK + Play Store bundle. Needs keystore.properties (run ./make-keystore.sh once).
set -euo pipefail
cd "$(dirname "$0")"
./gradlew clean assembleRelease bundleRelease
echo
echo "APK:     app/build/outputs/apk/release/app-release.apk"
echo "AAB:     app/build/outputs/bundle/release/app-release.aab"
echo "Mapping: app/build/outputs/mapping/release/mapping.txt  (keep it per release to decode crash traces)"
