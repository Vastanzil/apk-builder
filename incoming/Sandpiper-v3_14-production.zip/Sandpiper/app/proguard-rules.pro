# Sandpiper release rules (R8 / minifyEnabled = true)

# --- JS <-> Kotlin bridge ---------------------------------------------------
# index.html / planner-bridge.js / fitness-bridge.js call these by NAME through window.SandpiperNative.
# Renaming or removing any @JavascriptInterface method silently breaks the whole web UI.
-keepattributes JavascriptInterface,Signature,*Annotation*,InnerClasses,EnclosingMethod
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.vastanzil.sandpiper.Bridge { *; }

# --- Enums stored/sent by NAME ----------------------------------------------
# IslandStyle / IslandLook are saved in SharedPreferences and exchanged with JS as strings and read back with valueOf();
# features.json also references them. Obfuscating constant names would corrupt saved settings and break Settings.
-keepclassmembers enum com.vastanzil.sandpiper.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
    <fields>;
}
-keepnames enum com.vastanzil.sandpiper.**

# --- Android components referenced from the manifest are kept automatically by AAPT rules.
# --- WorkManager (StepWorker) ships its own consumer rules.

# Keep readable line numbers if you ever get a crash trace (mapping.txt is in app/build/outputs/mapping/release/).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
