package com.vastanzil.sandpiper

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONObject
import java.util.Random

/**
 * Planner list (Daily / Weekly / Monthly) in sandpiper_central.db. Every mutation is ONE transaction that writes the task row
 * and appends the matching planner_history row, so there is never a task change without its history.
 * Task text lives only in these tables; Diagnostics gets enums and counts, never text.
 */
internal object PlannerStore {
    fun createTables(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS planner_task(id TEXT PRIMARY KEY, period TEXT NOT NULL, text TEXT NOT NULL, " +
                "done INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, completed_at INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS planner_history(id TEXT PRIMARY KEY, task_id TEXT NOT NULL, period TEXT NOT NULL, " +
                "action TEXT NOT NULL, at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS ph_at ON planner_history(at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS pt_period ON planner_task(period, done)")
    }

    private val rnd = Random()
    private fun db(c: Context): SQLiteDatabase = CentralDb.get(c).writableDatabase

    private fun readTask(it: android.database.Cursor) = PTask(
        it.getString(0), it.getString(1), it.getString(2), it.getInt(3) == 1,
        it.getLong(4), it.getLong(5), if (it.isNull(6)) null else it.getLong(6)
    )

    private const val COLS = "id, period, text, done, created_at, updated_at, completed_at"

    fun listTasks(c: Context, period: String): List<PTask> {
        if (!PlannerCore.isPeriod(period)) return emptyList()
        val out = ArrayList<PTask>()
        db(c).rawQuery("SELECT $COLS FROM planner_task WHERE period=? ORDER BY created_at", arrayOf(period)).use { while (it.moveToNext()) out.add(readTask(it)) }
        return out
    }

    private fun getTask(d: SQLiteDatabase, id: String): PTask? =
        d.rawQuery("SELECT $COLS FROM planner_task WHERE id=?", arrayOf(id)).use { if (it.moveToFirst()) readTask(it) else null }

    private fun putTask(d: SQLiteDatabase, t: PTask) {
        val cv = ContentValues()
        cv.put("id", t.id); cv.put("period", t.period); cv.put("text", t.text); cv.put("done", if (t.done) 1 else 0)
        cv.put("created_at", t.createdAt); cv.put("updated_at", t.updatedAt)
        if (t.completedAt == null) cv.putNull("completed_at") else cv.put("completed_at", t.completedAt)
        d.insertWithOnConflict("planner_task", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun putHistory(d: SQLiteDatabase, taskId: String, period: String, action: String, at: Long) {
        val cv = ContentValues()
        cv.put("id", PlannerCore.newId("h", at, rnd)); cv.put("task_id", taskId); cv.put("period", period)
        cv.put("action", action); cv.put("at", at)
        d.insert("planner_history", null, cv)
    }

    private fun count(d: SQLiteDatabase, sql: String): Long = d.rawQuery(sql, null).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** Insert or update by id (bumps updated_at). Writes "created" for a new task, "edited" when the text changed. */
    @Synchronized
    fun upsertTask(c: Context, task: PTask): Boolean {
        val text = PlannerCore.cleanText(task.text) ?: return false
        if (!PlannerCore.isPeriod(task.period)) return false
        val d = db(c)
        val now = System.currentTimeMillis()
        d.beginTransaction()
        try {
            val old = getTask(d, task.id)
            if (old == null && count(d, "SELECT COUNT(*) FROM planner_history") >= PlannerCore.MAX_HISTORY) return false
            val t = task.copy(text = text, updatedAt = now, createdAt = old?.createdAt ?: task.createdAt)
            putTask(d, t)
            if (old == null) putHistory(d, t.id, t.period, "created", now)
            else if (old.text != t.text) putHistory(d, t.id, t.period, "edited", now)
            d.setTransactionSuccessful()
            return true
        } finally { d.endTransaction() }
    }

    /** New task; returns its id, or null for empty text / unknown period. */
    fun add(c: Context, period: String, text: String): String? {
        val clean = PlannerCore.cleanText(text) ?: return null
        if (!PlannerCore.isPeriod(period)) return null
        val now = System.currentTimeMillis()
        val id = PlannerCore.newId("t", now, rnd)
        if (!upsertTask(c, PTask(id, period, clean, false, now, now, null))) return null
        Diag.log(DLvl.I, DCat.PLANNER, DEv.TASK_ADDED, DMod.PLANNER, DRes.OK, n = 1L)
        return id
    }

    @Synchronized
    fun setDone(c: Context, id: String, done: Boolean): Boolean {
        val d = db(c)
        val now = System.currentTimeMillis()
        d.beginTransaction()
        try {
            val old = getTask(d, id) ?: return false
            val action = PlannerCore.toggleAction(old.done, done) ?: return true   // nothing to change
            putTask(d, old.copy(done = done, updatedAt = now, completedAt = if (done) now else null))
            putHistory(d, id, old.period, action, now)
            d.setTransactionSuccessful()
            Diag.log(DLvl.I, DCat.PLANNER, if (done) DEv.TASK_COMPLETED else DEv.TASK_REOPENED, DMod.PLANNER, DRes.OK, n = 1L)
            return true
        } finally { d.endTransaction() }
    }

    /** The history row is written BEFORE the task row is removed, in the same transaction. */
    @Synchronized
    fun deleteTask(c: Context, id: String): Boolean {
        val d = db(c)
        val now = System.currentTimeMillis()
        d.beginTransaction()
        try {
            val old = getTask(d, id) ?: return false
            putHistory(d, id, old.period, "deleted", now)
            d.delete("planner_task", "id=?", arrayOf(id))
            d.setTransactionSuccessful()
            Diag.log(DLvl.I, DCat.PLANNER, DEv.TASK_DELETED, DMod.PLANNER, DRes.OK, n = 1L)
            return true
        } finally { d.endTransaction() }
    }

    fun history(c: Context, limit: Int): List<PHist> {
        val out = ArrayList<PHist>()
        db(c).rawQuery("SELECT id, task_id, period, action, at FROM planner_history ORDER BY at DESC LIMIT ?", arrayOf(limit.coerceIn(1, 2000).toString())).use {
            while (it.moveToNext()) out.add(PHist(it.getString(0), it.getString(1), it.getString(2), it.getString(3), it.getLong(4)))
        }
        return out
    }

    private fun allTasks(d: SQLiteDatabase): List<PTask> {
        val out = ArrayList<PTask>()
        d.rawQuery("SELECT $COLS FROM planner_task ORDER BY created_at", null).use { while (it.moveToNext()) out.add(readTask(it)) }
        return out
    }

    private fun allHistory(d: SQLiteDatabase): List<PHist> {
        val out = ArrayList<PHist>()
        d.rawQuery("SELECT id, task_id, period, action, at FROM planner_history ORDER BY at", null).use {
            while (it.moveToNext()) out.add(PHist(it.getString(0), it.getString(1), it.getString(2), it.getString(3), it.getLong(4)))
        }
        return out
    }

    /** Everything, for Backup. */
    fun exportAll(c: Context): JSONObject {
        val d = db(c)
        return PlannerCore.exportJson(allTasks(d), allHistory(d))
    }

    /**
     * Restore. merge=true keeps what is on the device (the newer copy of a task wins, history is added by id);
     * merge=false replaces the device's planner data with the backup. One transaction either way.
     */
    @Synchronized
    fun importAll(c: Context, json: JSONObject, merge: Boolean): Int {
        val (tasks, hist) = PlannerCore.parseImport(json)
        val d = db(c)
        var n = 0
        d.beginTransaction()
        try {
            if (!merge) { d.delete("planner_task", null, null); d.delete("planner_history", null, null) }
            for (t in tasks) {
                val keep = PlannerCore.mergeTask(if (merge) getTask(d, t.id) else null, t) ?: continue
                putTask(d, keep); n++
            }
            for (h in hist) {
                val cv = ContentValues()
                cv.put("id", h.id); cv.put("task_id", h.taskId); cv.put("period", h.period); cv.put("action", h.action); cv.put("at", h.at)
                d.insertWithOnConflict("planner_history", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        Diag.log(DLvl.I, DCat.RESTORE, DEv.PLANNER_IMPORTED, DMod.PLANNER, DRes.OK, n = n.toLong())
        return n
    }

    /** For the self-test: [tasks, history rows, orphan tasks]. Orphans = history for a task that is gone without a "deleted" row. */
    fun verify(c: Context): IntArray {
        val d = db(c)
        val ids = HashSet<String>()
        d.rawQuery("SELECT id FROM planner_task", null).use { while (it.moveToNext()) ids.add(it.getString(0)) }
        val hist = allHistory(d)
        return intArrayOf(ids.size, hist.size, PlannerCore.orphanCount(ids, hist))
    }
}

/** Reserved storage contract for the future Sandpiper Pro workspace: same pattern as Piper (one opaque JSON document in module_doc). */
internal object ProStore {
    const val MODULE = "sandpiper_pro"
    const val DOC_KEY = "workspace"
}
