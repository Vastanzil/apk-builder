package com.vastanzil.sandpiper

import org.json.JSONArray
import org.json.JSONObject
import java.util.Random

data class PTask(
    val id: String, val period: String, val text: String, val done: Boolean,
    val createdAt: Long, val updatedAt: Long, val completedAt: Long?
)

data class PHist(val id: String, val taskId: String, val period: String, val action: String, val at: Long)

/** Pure rules of the Planner list (no Android imports, so plain JUnit covers them). */
object PlannerCore {
    val PERIODS = listOf("daily", "weekly", "monthly")
    val ACTIONS = setOf("created", "completed", "reopened", "deleted", "edited")
    const val MAX_TEXT = 200
    /** Same order of magnitude as a Piper document cap: history is never pruned by surprise, only refused beyond this. */
    const val MAX_HISTORY = 200_000

    private val ID = Regex("^[A-Za-z0-9._:\\-]{1,64}$")
    private val SPACE = Regex("\\s+")

    fun isPeriod(p: String): Boolean = p in PERIODS

    /** Trimmed, single-spaced, capped. Null when nothing is left. */
    fun cleanText(s: String): String? {
        val t = s.trim().replace(SPACE, " ")
        return if (t.isEmpty()) null else t.take(MAX_TEXT)
    }

    fun newId(prefix: String, now: Long, rnd: Random = Random()): String =
        prefix + now.toString(36) + Integer.toString(rnd.nextInt(1_679_616), 36).padStart(4, '0')

    /** History action for a done-state change, or null when nothing changed. */
    fun toggleAction(wasDone: Boolean, nowDone: Boolean): String? =
        if (wasDone == nowDone) null else if (nowDone) "completed" else "reopened"

    fun taskJson(t: PTask): JSONObject = JSONObject().put("id", t.id).put("period", t.period).put("text", t.text)
        .put("done", t.done).put("createdAt", t.createdAt).put("updatedAt", t.updatedAt)
        .put("completedAt", if (t.completedAt == null) JSONObject.NULL else t.completedAt)

    fun histJson(h: PHist): JSONObject = JSONObject().put("id", h.id).put("taskId", h.taskId).put("period", h.period)
        .put("action", h.action).put("at", h.at)

    fun exportJson(tasks: List<PTask>, hist: List<PHist>): JSONObject {
        val ta = JSONArray(); tasks.forEach { ta.put(taskJson(it)) }
        val ha = JSONArray(); hist.forEach { ha.put(histJson(it)) }
        return JSONObject().put("v", 1).put("tasks", ta).put("history", ha)
    }

    /** Reads a backup blob. Invalid items are skipped, never stored. Works for old backups without history. */
    fun parseImport(o: JSONObject): Pair<List<PTask>, List<PHist>> {
        val tasks = ArrayList<PTask>()
        val ta = o.optJSONArray("tasks")
        if (ta != null) for (i in 0 until ta.length()) {
            val j = ta.optJSONObject(i) ?: continue
            val id = j.optString("id"); val period = j.optString("period")
            val text = cleanText(j.optString("text")) ?: continue
            if (!ID.matches(id) || !isPeriod(period)) continue
            val created = j.optLong("createdAt", 0L).let { if (it > 0L) it else 1L }
            val updated = j.optLong("updatedAt", created).let { if (it > 0L) it else created }
            val done = j.optBoolean("done", false)
            val completed = if (done) j.optLong("completedAt", updated).let { if (it > 0L) it else updated } else null
            tasks.add(PTask(id, period, text, done, created, updated, completed))
        }
        val hist = ArrayList<PHist>()
        val ha = o.optJSONArray("history")
        if (ha != null) for (i in 0 until minOf(ha.length(), MAX_HISTORY)) {
            val j = ha.optJSONObject(i) ?: continue
            val id = j.optString("id"); val tid = j.optString("taskId")
            val period = j.optString("period"); val action = j.optString("action")
            val at = j.optLong("at", 0L)
            if (!ID.matches(id) || !ID.matches(tid) || !isPeriod(period) || action !in ACTIONS || at <= 0L) continue
            hist.add(PHist(id, tid, period, action, at))
        }
        return Pair(tasks, hist)
    }

    /** On merge, the newer copy of a task wins; null means "keep what is already stored". */
    fun mergeTask(existing: PTask?, incoming: PTask): PTask? =
        if (existing == null || incoming.updatedAt > existing.updatedAt) incoming else null

    /**
     * Sanity check for Diagnostics: history rows whose task no longer exists AND that task has no "deleted" row.
     * Zero means the history explains every task that is gone.
     */
    fun orphanCount(taskIds: Set<String>, hist: List<PHist>): Int {
        val deleted = HashSet<String>()
        for (h in hist) if (h.action == "deleted") deleted.add(h.taskId)
        val orphanTasks = HashSet<String>()
        for (h in hist) if (h.taskId !in taskIds && h.taskId !in deleted) orphanTasks.add(h.taskId)
        return orphanTasks.size
    }
}
