package com.vastanzil.sandpiper

import android.content.Context
import org.json.JSONObject
import java.util.Calendar
import java.util.Random

/** Pure rules of the day-end reminder (no Android imports, so plain JUnit covers them). */
object DayEndCore {
    const val ID = "day_end"

    /** One of these is shown at random each evening. */
    val MESSAGES: List<String> = listOf(
        "Before today fades, give your progress a little attention.",
        "Your day has a story. Take a moment to update it.",
        "A quick check-in makes tomorrow's planning easier.",
        "Every little win deserves to be remembered. Update your day!",
        "As the day winds down, leave your planner up to date."
    )

    /** Random line that is never the same as the previous one (index [last], or -1 for none). */
    fun nextIndex(last: Int, rnd: Random = Random()): Int {
        if (MESSAGES.size < 2) return 0
        var i = rnd.nextInt(MESSAGES.size)
        while (i == last) i = rnd.nextInt(MESSAGES.size)
        return i
    }

    /** "N hours before the day ends" -> hour of day (2 -> 22:00). */
    fun hourFor(hoursBefore: Int): Int = 24 - hoursBefore.coerceIn(1, 3)

    /** The daily reminder in the shape [Scheduler] stores (kind "reminder", repeat "daily"). [date] is yyyy-MM-dd. */
    fun item(hoursBefore: Int, date: String, dayOfMonth: Int): JSONObject =
        JSONObject().put("id", ID).put("kind", "reminder").put("title", "Day-end check-in")
            .put("date", date).put("h", hourFor(hoursBefore)).put("m", 0).put("repeat", "daily").put("day", dayOfMonth)
}

/** Schedules the daily day-end reminder through the same AlarmManager path as every other reminder, so it fires with the app closed. */
internal object DayEnd {
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("sp_dayend", Context.MODE_PRIVATE)

    fun today(): String {
        val c = Calendar.getInstance()
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** Makes the stored schedule match the settings. Safe to call any time (cold start, settings change). */
    fun sync(c: Context) {
        try {
            if (!AppSettings.dayEnd(c)) {
                if (Scheduler.get(c, DayEndCore.ID) != null) Scheduler.remove(c, DayEndCore.ID)
                return
            }
            val h = DayEndCore.hourFor(AppSettings.dayEndHours(c))
            val cur = Scheduler.get(c, DayEndCore.ID)
            if (cur != null && cur.optInt("h") == h && cur.optInt("m") == 0 && cur.optString("repeat") == "daily") return
            Scheduler.put(c, DayEndCore.item(AppSettings.dayEndHours(c), today(), Calendar.getInstance().get(Calendar.DAY_OF_MONTH)))
        } catch (e: Exception) { }
    }

    /** Today's line (random, never the same as last time). */
    fun message(c: Context): String {
        val p = prefs(c)
        val i = DayEndCore.nextIndex(p.getInt("last", -1))
        p.edit().putInt("last", i).apply()
        return DayEndCore.MESSAGES[i]
    }

    /** True when the day was already closed in the Planner today: no reason to nag. */
    fun alreadyClosed(c: Context): Boolean = AppSettings.dayClosed(c) == today()
}
