package com.vastanzil.sandpiper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Daily steps and estimated active minutes from TYPE_STEP_COUNTER.
 * A WorkManager job samples the counter about every 15 minutes (also when the app is closed),
 * so history exists for days the app was not opened. Active minutes are an estimate:
 * steps taken in sampling windows with a brisk average cadence (>= 40 steps/min), divided by 100 steps per minute.
 */
object Steps {
    private const val P = "sp_steps2"
    private fun prefs(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    /** Blocking one-shot read; never call from the main thread. Returns null if unavailable. */
    fun readTotal(c: Context, timeoutMs: Long = 4000): Long? {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) return null
        val sm = c.getSystemService(SensorManager::class.java)
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return null
        val latch = CountDownLatch(1)
        var value: Long? = null
        val h = Handler(Looper.getMainLooper())
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { value = e.values[0].toLong(); latch.countDown() }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        h.post { sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL, h) }
        latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        h.post { sm.unregisterListener(l) }
        return value
    }

    private fun dayOf(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate().toString()

    @Synchronized
    fun record(c: Context, total: Long, now: Long = System.currentTimeMillis()) {
        val p = prefs(c)
        val o = runCatching { JSONObject(p.getString("d", "{}")) }.getOrDefault(JSONObject())
        val days = o.optJSONObject("days") ?: JSONObject().also { o.put("days", it) }
        val last = o.optLong("last", -1L)
        val lastAt = o.optLong("lastAt", 0L)
        // counter resets to a small number after a reboot: count what it reports as new steps
        val delta = if (last < 0) 0L else if (total >= last) total - last else total
        val key = dayOf(now)
        val d = days.optJSONObject(key) ?: JSONObject().put("s", 0L).put("a", 0.0).also { days.put(key, it) }
        d.put("s", d.optLong("s") + delta)
        if (last >= 0 && lastAt > 0 && delta > 0) {
            val mins = (now - lastAt) / 60000.0
            if (mins in 1.0..40.0 && delta / mins >= 40.0) d.put("a", d.optDouble("a") + delta / 100.0)
        }
        o.put("last", total).put("lastAt", now)
        val keys = days.keys().asSequence().toList().sorted()
        for (k in keys.dropLast(45)) days.remove(k)
        p.edit().putString("d", o.toString()).apply()
        ActivityStore.add(c, "steps:$key", now, "steps.count", d.optLong("s").toDouble())
        ActivityStore.add(c, "steps.active:$key", now, "steps.active_min", Math.round(d.optDouble("a")).toDouble())
    }

    /** {steps, activeMin, history:[{date,steps,activeMin,bp?,videos?}]} for the last 14 days before today. */
    fun summary(c: Context): JSONObject {
        val o = runCatching { JSONObject(prefs(c).getString("d", "{}")) }.getOrDefault(JSONObject())
        val days = o.optJSONObject("days") ?: JSONObject()
        val today = LocalDate.now().toString()
        val t = days.optJSONObject(today)
        val hist = JSONArray()
        val bh = BrainyStore.history(c)
        val dates = (days.keys().asSequence().toList() + bh.keys().asSequence().toList()).toSet().filter { it != today }.sorted().takeLast(14)
        for (k in dates) {
            val d = days.optJSONObject(k)
            val b = bh.optJSONObject(k)
            hist.put(JSONObject().put("date", k).put("steps", d?.optLong("s") ?: 0L).put("activeMin", Math.round(d?.optDouble("a") ?: 0.0))
                .put("bp", b?.optInt("bp") ?: 0).put("videos", b?.optInt("videos") ?: 0))
        }
        return JSONObject().put("steps", t?.optLong("s") ?: 0L).put("activeMin", Math.round(t?.optDouble("a") ?: 0.0)).put("history", hist)
    }
}

class StepWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        Diag.init(applicationContext)
        // Brainy writes a finished day to the ledger when its state is next read; this guarantees that happens within ~15 min of midnight.
        try { BrainyStore.state(applicationContext) } catch (e: Exception) { }
        val total = Steps.readTotal(applicationContext)
        if (total != null) {
            Steps.record(applicationContext, total)
            Diag.log(DLvl.I, DCat.STEPS, DEv.STEP_SAMPLE, DMod.STEPS)
        } else {
            Diag.log(DLvl.I, DCat.STEPS, DEv.STEP_SAMPLE, DMod.STEPS, DRes.UNAVAILABLE)
        }
        return Result.success()
    }
}
