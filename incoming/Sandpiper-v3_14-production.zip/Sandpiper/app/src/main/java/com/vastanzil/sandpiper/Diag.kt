package com.vastanzil.sandpiper

import android.Manifest
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.OutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Android side of the diagnostics pipeline (see DiagCore.kt for the rules).
 *
 * Usage: Diag.log(DLvl.I, DCat.ALARM, DEv.ALARM_FIRED, DMod.ALARMS). The signature has no String parameter on purpose.
 * Logging is asynchronous (one background thread), works before [init] (memory only), and never throws.
 */
object Diag {
    private val t0 = System.nanoTime()
    private val core = DiagLog()
    @Volatile private var inited = false
    private val exec: ExecutorService by lazy {
        Executors.newSingleThreadExecutor { r -> Thread(r, "sp-diag").apply { isDaemon = true } }
    }

    /** Idempotent. Starts writing to app-private storage (filesDir/diag/diag.jsonl, 2 MB, 14 days). */
    fun init(c: Context) {
        if (inited) return
        synchronized(this) {
            if (inited) return
            inited = true
        }
        try {
            val f = File(c.applicationContext.filesDir, "diag/diag.jsonl")
            val now = System.currentTimeMillis()
            exec.execute { core.attach(f, 14L * 24 * 60 * 60 * 1000, now) }
        } catch (e: Exception) { /* memory-only */ }
        log(DLvl.I, DCat.STARTUP, DEv.PROCESS_START, DMod.APP)
    }

    fun log(
        lvl: DLvl, cat: DCat, ev: DEv, mod: DMod = DMod.NONE, res: DRes = DRes.OK,
        dur: Long = 0L, n: Long = 0L, code: DCode? = null
    ) {
        try {
            val e = DiagEvent((System.nanoTime() - t0) / 1_000_000L, lvl, cat, ev, mod, res, dur, n, code)
            exec.execute { core.log(e) }
        } catch (x: Exception) { /* never break the app */ }
    }

    fun codeOf(t: Throwable?): DCode = DiagCodes.of(t)

    /** Waits (briefly) until everything logged so far has been written. Call from a background thread. */
    fun flush() {
        try { exec.submit(Runnable { }).get(3, TimeUnit.SECONDS) } catch (x: Exception) { /* ignore */ }
    }

    fun clear() {
        flush()
        core.clear()
        log(DLvl.I, DCat.SELFTEST, DEv.LOG_CLEARED)
    }

    /** Writes the diagnostics zip to [out]. Background thread only. */
    fun exportTo(c: Context, out: OutputStream, health: List<HealthItem>) {
        flush()
        val version = try {
            c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "unknown"
        } catch (x: Exception) { "unknown" }
        DiagExport.write(out, core, ExportInfo(version, Build.VERSION.SDK_INT, System.currentTimeMillis()), health)
        log(DLvl.I, DCat.SELFTEST, DEv.EXPORT_DONE, DMod.NONE, DRes.OK, n = health.size.toLong())
    }
}

/**
 * Self-test: probes every store, every module-to-module link that exists today and every permission, logs one typed
 * event per check and returns the rows used by the Diagnostics screen and health.json. Reads counts and booleans only.
 */
object SelfTest {
    fun run(c0: Context): List<HealthItem> {
        val c = c0.applicationContext
        Diag.init(c)
        val started = System.nanoTime()
        Diag.log(DLvl.I, DCat.SELFTEST, DEv.SELFTEST_STARTED)
        val out = ArrayList<HealthItem>()

        // ---- stores (counts only)
        probe(out, DCat.DB, DEv.CHK_STORE_BRAINY, DMod.BRAINY) {
            DRes.OK to BrainyStore.state(c).optInt("short").toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_ISLAND, DMod.ISLAND) {
            DRes.OK to IslandStore.monitoredApps(c).size.toLong()
        }
        val alarms = try { Scheduler.health(c) } catch (e: Exception) { null }
        probe(out, DCat.DB, DEv.CHK_STORE_ALARMS, DMod.ALARMS) {
            val h = alarms ?: throw IllegalStateException()
            val r = if (h[1] == 0) DRes.OK else DRes.FAIL
            r to h[0].toLong()
        }
        probe(out, DCat.ALARM, DEv.CHK_ALARMS_ARMED, DMod.ALARMS) {
            val h = alarms ?: throw IllegalStateException()
            val r = if (h[2] == 0) DRes.OK else DRes.FAIL
            r to h[2].toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_PIPER, DMod.PIPER) {
            // Piper workspace: stored document verifies against its SHA-256 and the page index matches it
            val v = PiperStore.verify(c)
            val r = if (v[2] == 1) DRes.OK else DRes.FAIL
            r to v[0].toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_STEPS, DMod.STEPS) {
            DRes.OK to Steps.summary(c).getJSONArray("history").length().toLong()
        }

        // ---- module links that exist today (plan 3.5 ports: brainy.daily.v1)
        probe(out, DCat.PORT, DEv.CHK_LINK_ISLAND_BRAINY, DMod.ISLAND) {
            val shown = IslandStore.count(c)
            val r = if (shown == BrainyStore.state(c).optInt("short")) DRes.OK else DRes.FAIL
            r to shown.toLong()
        }
        probe(out, DCat.PORT, DEv.CHK_LINK_FITNESS_BRAINY, DMod.FITNESS) {
            val sent = BrainyStore.snapshot(c).optInt("short")
            val r = if (sent == BrainyStore.state(c).optInt("short")) DRes.OK else DRes.FAIL
            r to sent.toLong()
        }

        // ---- services and sensors
        probe(out, DCat.BRAINY, DEv.CHK_BRAINY_SERVICE, DMod.BRAINY) {
            val r = if (BrainyService.running) DRes.OK else DRes.UNAVAILABLE
            r to (if (IslandStore.tracking(c)) 1L else 0L)
        }
        probe(out, DCat.STEPS, DEv.CHK_STEP_SENSOR, DMod.STEPS) {
            val has = c.getSystemService(SensorManager::class.java)?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null
            val r = if (has) DRes.OK else DRes.UNAVAILABLE
            r to 0L
        }

        // ---- permissions: probed live by the shared Permissions object (the same code the Permissions panel uses)
        for (row in Permissions.DIAG_ROWS) {
            probe(out, DCat.PERMISSION, row.ev, row.mod) { Permissions.diagResult(c, row) to 0L }
        }

        // ---- registry consistency: every manifest permission is mapped, every setting id is unique
        probe(out, DCat.SETTINGS, DEv.CHK_REGISTRY, DMod.APP) {
            val reg = FeatureRegistry.parsed(c)
            val declared = c.packageManager.getPackageInfo(c.packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toSet() ?: emptySet()
            val problems = FeatureRegistry.validate(reg, declared.filter { it.startsWith("android.permission.") }.toSet(), strict = false)
            (if (problems.isEmpty()) DRes.OK else DRes.FAIL) to problems.size.toLong()
        }
        probe(out, DCat.DB, DEv.CHK_STORE_SETTINGS, DMod.APP) {
            val n = SettingsStore.count(c)
            (if (n >= 0) DRes.OK else DRes.FAIL) to n.toLong()
        }
        // activity ledger: rollups match events, and a write/delete round trip leaves nothing behind (self-heals by rebuilding)
        probe(out, DCat.DB, DEv.CHK_STORE_ACTIVITY, DMod.ACTIVITY) {
            val healed = ActivityStore.selfTest(c)
            if (healed.rebuilt) Diag.log(DLvl.W, DCat.DB, DEv.ACTIVITY_REBUILT, DMod.ACTIVITY, DRes.OK, n = healed.events)
            (if (healed.ok) DRes.OK else DRes.FAIL) to healed.events
        }

        // planner list: every history row explains the tasks that are gone
        probe(out, DCat.DB, DEv.CHK_STORE_PLANNER, DMod.PLANNER) {
            val v = PlannerStore.verify(c)
            (if (v[2] == 0) DRes.OK else DRes.FAIL) to v[0].toLong()
        }

        val ms = (System.nanoTime() - started) / 1_000_000L
        val ok = DiagExport.overall(out) != "ERROR"
        Diag.log(if (ok) DLvl.I else DLvl.W, DCat.SELFTEST, DEv.SELFTEST_DONE, DMod.NONE, if (ok) DRes.OK else DRes.FAIL, ms, out.size.toLong())
        return out
    }


    private fun probe(out: MutableList<HealthItem>, cat: DCat, ev: DEv, mod: DMod, body: () -> Pair<DRes, Long>) {
        val t = System.nanoTime()
        var res = DRes.FAIL
        var n = 0L
        var code: DCode? = null
        try {
            val r = body()
            res = r.first; n = r.second
        } catch (e: Exception) {
            code = Diag.codeOf(e)
        }
        out.add(HealthItem(ev, mod, res, n))
        Diag.log(if (res == DRes.FAIL) DLvl.W else DLvl.I, cat, ev, mod, res, (System.nanoTime() - t) / 1_000_000L, n, code)
    }
}
