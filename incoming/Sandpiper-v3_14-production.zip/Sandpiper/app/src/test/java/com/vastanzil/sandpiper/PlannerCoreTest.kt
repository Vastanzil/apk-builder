package com.vastanzil.sandpiper

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class PlannerCoreTest {
    @Test fun textIsCleanedAndCapped() {
        assertEquals("buy milk", PlannerCore.cleanText("  buy   milk \n"))
        assertNull(PlannerCore.cleanText("   "))
        assertEquals(PlannerCore.MAX_TEXT, PlannerCore.cleanText("x".repeat(500))!!.length)
    }

    @Test fun periodsAreClosed() {
        assertTrue(PlannerCore.isPeriod("daily")); assertTrue(PlannerCore.isPeriod("weekly")); assertTrue(PlannerCore.isPeriod("monthly"))
        assertFalse(PlannerCore.isPeriod("yearly")); assertFalse(PlannerCore.isPeriod(""))
    }

    @Test fun toggleWritesTheRightHistoryAction() {
        assertEquals("completed", PlannerCore.toggleAction(false, true))
        assertEquals("reopened", PlannerCore.toggleAction(true, false))
        assertNull(PlannerCore.toggleAction(true, true))
        assertNull(PlannerCore.toggleAction(false, false))
    }

    @Test fun idsAreValidAndDistinct() {
        val r = Random(1)
        val ids = (1..500).map { PlannerCore.newId("t", 1_762_000_000_000L + it, r) }
        assertEquals(500, ids.toSet().size)
        assertTrue(ids.all { Regex("^[A-Za-z0-9]{1,64}$").matches(it) })
    }

    @Test fun exportImportRoundTrip() {
        val tasks = listOf(
            PTask("t1", "daily", "write report", true, 10, 30, 30),
            PTask("t2", "weekly", "call bank", false, 20, 20, null)
        )
        val hist = listOf(PHist("h1", "t1", "daily", "created", 10), PHist("h2", "t1", "daily", "completed", 30), PHist("h3", "t2", "weekly", "created", 20))
        val back = PlannerCore.parseImport(JSONObject(PlannerCore.exportJson(tasks, hist).toString()))
        assertEquals(tasks, back.first)
        assertEquals(hist, back.second)
    }

    @Test fun importSkipsBadItemsAndAcceptsOldBackups() {
        val o = JSONObject("""{"tasks":[
            {"id":"ok","period":"daily","text":"fine","createdAt":5},
            {"id":"bad id","period":"daily","text":"x"},
            {"id":"p","period":"yearly","text":"x"},
            {"id":"e","period":"daily","text":"   "}],
          "history":[{"id":"h","taskId":"ok","period":"daily","action":"explode","at":9}]}""")
        val (t, h) = PlannerCore.parseImport(o)
        assertEquals(listOf("ok"), t.map { it.id })
        assertTrue(h.isEmpty())
        assertTrue(PlannerCore.parseImport(JSONObject("{}")).first.isEmpty())   // backup from before the Planner existed
    }

    @Test fun mergeKeepsTheNewerCopy() {
        val old = PTask("a", "daily", "old", false, 1, 100, null)
        assertEquals("new", PlannerCore.mergeTask(old, PTask("a", "daily", "new", false, 1, 200, null))!!.text)
        assertNull(PlannerCore.mergeTask(old, PTask("a", "daily", "older", false, 1, 50, null)))
        assertEquals("first", PlannerCore.mergeTask(null, PTask("b", "daily", "first", false, 1, 1, null))!!.text)
    }

    @Test fun orphansAreHistoryWithoutAnExplanation() {
        val ids = setOf("alive")
        val hist = listOf(
            PHist("1", "alive", "daily", "created", 1),
            PHist("2", "gone", "daily", "created", 2), PHist("3", "gone", "daily", "deleted", 3),
            PHist("4", "lost", "daily", "created", 4)
        )
        assertEquals(1, PlannerCore.orphanCount(ids, hist))   // "lost" vanished without a deleted row
    }

    @Test fun taskTextNeverAppearsInALogLine() {
        // Diagnostics events carry enums and numbers only, so the text of a task has no way in.
        val canary = "CANARY_TASK_TEXT_4471"
        val ev = DiagEvent(1L, DLvl.I, DCat.PLANNER, DEv.TASK_ADDED, DMod.PLANNER, DRes.OK, 1, 0, null)
        assertFalse(ev.toJson().contains(canary))
        assertTrue(DiagSchema.isValid(ev.toJson()))
        assertFalse(DiagSchema.isValid(ev.toJson().dropLast(1) + ",\"text\":\"$canary\"}"))
    }
}
