package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Registry option lists must agree with the values native code accepts. */
class AppSettingsTest {
    @Test fun registryOptionsMatchNativeChoices() {
        val reg = org.json.JSONObject(java.io.File("src/main/assets/features.json").readText()).getJSONArray("settings")
        fun options(id: String): List<Int> {
            for (i in 0 until reg.length()) {
                val s = reg.getJSONObject(i)
                if (s.getString("id") == id) { val o = s.getJSONArray("options"); return (0 until o.length()).map { o.getJSONArray(it).getInt(0) } }
            }
            return emptyList()
        }
        assertEquals(AppSettings.SNOOZE_CHOICES.toList(), options("alarms.snoozeMin"))
        assertEquals(AppSettings.RING_CHOICES.toList(), options("alarms.ringMax"))
        assertEquals(AppSettings.DAYEND_CHOICES.toList(), options("planner.dayEndHours"))
        assertTrue(AppSettings.SNOOZE_CHOICES.all { it > 0 })
    }
}
