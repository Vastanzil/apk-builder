package com.vastanzil.sandpiper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class DayEndTest {
    @Test fun fiveLinesExactlyAsWritten() {
        assertEquals(5, DayEndCore.MESSAGES.size)
        assertEquals("Before today fades, give your progress a little attention.", DayEndCore.MESSAGES[0])
        assertEquals("As the day winds down, leave your planner up to date.", DayEndCore.MESSAGES[4])
    }

    @Test fun neverRepeatsTheLastLineAndCoversAll() {
        val rnd = Random(7)
        var last = -1
        val seen = HashSet<Int>()
        repeat(200) {
            val i = DayEndCore.nextIndex(last, rnd)
            assertNotEquals(last, i)
            assertTrue(i in DayEndCore.MESSAGES.indices)
            seen.add(i); last = i
        }
        assertEquals(5, seen.size)
    }

    @Test fun twoHoursBeforeMidnightIsTenPm() {
        assertEquals(22, DayEndCore.hourFor(2))
        assertEquals(23, DayEndCore.hourFor(1))
        assertEquals(21, DayEndCore.hourFor(3))
        assertEquals(22, DayEndCore.hourFor(2).coerceIn(0, 23))
    }

    @Test fun itemIsADailyReminder() {
        val o = DayEndCore.item(2, "2026-11-11", 11)
        assertEquals("day_end", o.getString("id"))
        assertEquals("reminder", o.getString("kind"))
        assertEquals("daily", o.getString("repeat"))
        assertEquals(22, o.getInt("h"))
        assertEquals(0, o.getInt("m"))
    }
}
