@echo off
REM Creates a release signing key for Sandpiper and a matching keystore.properties.
REM Run once, from the project root: make-keystore.bat
REM Keep release.jks and keystore.properties safe and back them up. If you lose the keystore you cannot publish
REM an update to an existing install under the same applicationId - Android treats it as a different app.
setlocal enabledelayedexpansion
cd /d "%~dp0"

if exist release.jks (
  echo release.jks already exists here. Delete or move it first if you really want to make a new one.
  exit /b 1
)

where keytool >nul 2>nul
if errorlevel 1 (
  echo keytool was not found. It ships with any JDK ^(the same one Android Studio / Gradle uses^).
  exit /b 1
)

set /p CN=Your name or organisation (for the certificate, e.g. "Tanzil Hasan"):
set /p ALIAS=Key alias [sandpiper]:
if "%ALIAS%"=="" set ALIAS=sandpiper

set /p PASS=Keystore password (used for both the store and the key):
set /p PASS2=Confirm password:
if not "%PASS%"=="%PASS2%" (
  echo Passwords did not match.
  exit /b 1
)

keytool -genkeypair -v -keystore release.jks -alias "%ALIAS%" -keyalg RSA -keysize 2048 -validity 10000 -storepass "%PASS%" -keypass "%PASS%" -dname "CN=%CN%, OU=, O=, L=, ST=, C="

(
  echo storeFile=release.jks
  echo storePassword=%PASS%
  echo keyAlias=%ALIAS%
  echo keyPassword=%PASS%
) > keystore.properties

echo.
echo Created release.jks and keystore.properties.
echo Both are gitignored - keep them safe outside git (password manager, encrypted backup).
echo Next build will sign release automatically: gradlew.bat assembleRelease
