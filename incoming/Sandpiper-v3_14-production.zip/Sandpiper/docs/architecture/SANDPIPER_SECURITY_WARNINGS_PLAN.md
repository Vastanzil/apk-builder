# Sandpiper: Play Protect and banking-app warnings (plan)

Status:
- **A1 (Pause Brainy) written** — `BrainyService.pause()` (`disableSelf()`), `Bridge.pauseBrainy()`, and a
  "Pause Brainy for one app" row in Settings > Brainy Island. Same caveat as the rest of the Brainy stack: written,
  not compiled, not device-tested.
- **C1 (real release signing) done** — `app/build.gradle.kts` signs with `keystore.properties` when present,
  falls back to the debug key otherwise. `make-keystore.sh` / `.bat` generate a key; `keystore.properties.example`
  documents the format. Gradle-level change, not an app feature, so no device test applies.
- **C2 (install guide) done** — `docs/INSTALL.md`.
- Everything else (A2–A5, B, C3, D) is still plan only.

---

## 1. What your screenshots show, and why

| Screenshot | What it is | Real cause |
|---|---|---|
| 1. "App blocked to protect your device" (Google Play Protect, install from Files) | Play Protect refuses or warns on install | Sideloaded APK, **signed with the debug key**, and it asks for the combination attackers use: an Accessibility service that can read screens, "Display over other apps", and Usage access. Play Protect scores that pattern as risky even when the app is honest. |
| 2. "Security Risk Detected: an untrusted accessibility service is enabled. Detected apps: sandpiper" (a bank/wallet app) | The other app refuses to run | Banking apps read the list of enabled accessibility services and compare it with an allow-list (installed from Play Store, or declared as an assistive tool). Sandpiper Brainy is neither, so it is reported. Banking malware abuses accessibility to read OTPs and tap buttons, so these checks are deliberate. |
| 3. App info with "Allow restricted settings" | Android 13+ blocks Accessibility and some special access for apps installed from a file | Expected for sideloaded apps. Already covered by the in-app hint, but only as a toast. |

Two facts that matter for the plan:
- **Only Brainy needs Accessibility.** Finance, Planner, Alarms, Notes, Piper, Zen and Fitness steps work without it. The bank warning appears only while the Brainy accessibility switch is on.
- Brainy already reads very little: only the foreground package name, scroll events, and view-ID names inside the apps you track. Browser address bars are read only if you opt in. It never reads messages, passwords or other apps' text.

## 2. What we will NOT do (and why)

These would "fix" the warnings by making Sandpiper harder for security checks to see. I will not build them:
- Declaring Brainy as an assistive tool (`isAccessibilityTool="true"`) when it is not one.
- Renaming or disguising the service, hiding it from the enabled-services list, or obfuscating it to dodge detection.
- Telling you to switch Play Protect or a bank's checks off.

They would weaken protection against real fraud on your phone and misrepresent what the app does. Everything below makes the app lower-risk and easier to pause, which is what the warnings are really asking for.

## 3. Plans

### Plan A: Brainy is opt-in, small, and one tap to pause (recommended)
| # | Change | Detail |
|---|---|---|
| A1 | **Pause Brainy** | Settings > Brainy Island gets "Pause for banking apps". It turns the accessibility service off from inside the app (`disableSelf()`), so the bank check passes. "Resume" opens the exact Accessibility page (Android does not allow apps to switch it back on by themselves). |
| A2 | **App-icon shortcuts** | Long-press the Sandpiper icon: "Pause Brainy" and "Resume Brainy". One tap, no digging through settings. Optional Quick Settings tile. |
| A3 | **Auto-pause list (opt-in, default empty)** | You pick your bank / wallet apps with the existing app picker. When one opens, Brainy switches itself off and posts "Brainy paused for <app>. Tap to resume." Honest limit: the very first launch can still show the bank's warning if the service was on at that moment; opening the bank app again works. |
| A4 | **Read-less guarantees, made visible** | Hard rule in code: never inspect any app that is not tracked (already true), plus a "What Brainy can see" panel in Settings and a diagnostics line. Re-test whether `flagIncludeNotImportantViews` can be dropped without losing reel detection. |
| A5 | **Clear first-run explanation** | Before the Accessibility switch: why Android and banks warn, how to pause, and that nothing else in Sandpiper needs it. The "Allow restricted settings" steps become a proper 3-step sheet instead of a toast. |
Effort: small to medium. Risk: low. Touches `BrainyService`, `Bridge`, a small shortcut activity, `features.json`, the page.

### Plan B: "Time only" detection mode (no Accessibility at all)
Setting: Detection mode = **Full** (counts reels, needs Accessibility) or **Time only** (uses Usage access for time and sessions per app, no reel counts, no screen reading). Banks do not flag Usage access the way they flag Accessibility.
Effort: medium. Trade-off: no reel counting or lock in this mode, only time-based warnings.

### Plan C: Make the install itself less alarming
| # | Change | Detail |
|---|---|---|
| C1 | **Real release signing** | Replace the debug-signed release with your own keystore (`keystore.properties`, a `make-keystore` script, instructions). A stable, non-debug signature is treated more kindly and keeps updates working. You keep the keystore; I cannot sign for you. |
| C2 | **Install guide** | In-app and README steps: Play Protect dialog > More details > Install anyway (keep Play Protect on), then Allow restricted settings. |
| C3 | **Two build flavours** | `full` (with Brainy: accessibility service, overlay, usage access) and **`lite`** (no accessibility service and no overlay/usage permissions declared at all). `lite` has no "sensitive permissions" combination and never triggers the bank warning. Brainy rows show "Not in this build". |
Effort: C1 and C2 small, C3 medium (manifest overlay, registry and test per flavour). Risk: low.

### Plan D: Distribution reality check
Google Play only allows the Accessibility API for genuine accessibility tools, so Brainy is unlikely to pass Play review. Sideload (F-Droid, your own site, GitHub releases) with a stable signature is the realistic route for `full`; `lite` (no Accessibility) is much easier to publish anywhere.

## 4. Recommended order
1. **Phase 1:** A1, A2, A5 and C1/C2 (pause, shortcuts, clearer guide, proper signing, install docs).
2. **Phase 2:** A3 (auto-pause list) and A4 (what Brainy can see).
3. **Phase 3:** C3 (`lite` flavour). Plan B only if you want a no-Accessibility Brainy.

## 5. Decisions needed (recommended in bold)
1. Start with **Phase 1**, or go straight to a `lite` build?
2. Auto-pause list: **opt-in, empty by default, suggestions shown first** (bKash, Nagad, Rocket, common banks if installed).
3. Keep one app with a Pause button (**yes**) and also ship a `lite` flavour (**yes, Phase 3**).
4. You create the release keystore and keep it safe; I provide the script and documentation.

## 6. How we will know it works
- Unit tests: registry consistency for both flavours; pause/resume bridge methods; auto-pause list logic.
- Simulated-browser tests for the new Settings rows.
- Device checklist (cannot be done in my environment): enable Brainy, open your bank app and confirm the warning; press **Pause Brainy**, confirm the bank opens; resume and confirm counting returns. Each bank uses its own allow-list, so results can differ per app.
