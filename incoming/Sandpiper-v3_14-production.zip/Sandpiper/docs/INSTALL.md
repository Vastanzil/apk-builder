# Installing Sandpiper (sideloaded APK)

Sandpiper is not on Google Play, so you'll install the APK directly. Android and your bank's own app both have
checks aimed at exactly this path - here's what each one actually means and what to do about it.

## 1. "Play Protect blocked this app" / "Unknown apps" warning
This shows for any APK installed from a file, not something specific to Sandpiper. Play Protect also weighs the
*combination* of permissions Sandpiper asks for (Accessibility + "display over other apps" + usage access) more
heavily, because that combination is also what banking malware uses.

- Tap **More details**, then **Install anyway** if you're installing your own build. Leave Play Protect itself on.
- If you don't plan to use Brainy Island at all, you can decline the Accessibility/overlay/usage prompts entirely -
  everything else in the app (Finance, Planner, Alarms, Notes, Piper, Zen, Fitness steps) works without them.

## 2. "Allow restricted settings" (Android 13+)
Android 13+ blocks Accessibility (and a few other special permissions) for any app installed from a file, as a
first line of defence against exactly the malware pattern above.

1. Open **Settings > Apps > Sandpiper**.
2. Tap the **⋮** menu (top right) > **Allow restricted settings**.
3. Go back into Accessibility and turn Sandpiper Brainy on - the switch should no longer be greyed out.

The in-app Accessibility permission sheet shows this as a 3-step walkthrough; it also appears if you tap "Fix" next
to any Brainy setting while Accessibility is off.

## 3. Your bank or wallet app says "Security Risk Detected: an untrusted accessibility service is enabled"
This is your bank's own check, separate from Android. Banking apps read the list of currently-enabled accessibility
services and compare it against their own allow-list (apps installed from Play Store, or explicitly declared
accessibility tools). Sandpiper Brainy is neither, so it's flagged - correctly, from the bank's point of view, since
this exact mechanism (an accessibility service reading your screen) is how banking malware steals OTPs and taps
buttons on your behalf.

**Only Brainy needs Accessibility.** Everything else in Sandpiper works without it. Two ways to deal with it:

- **One-off:** Settings > Brainy Island > **Pause Brainy for one app**, then open your bank app. Resume afterwards
  from Accessibility settings (Android does not allow apps to switch their own accessibility service back on).
- **Standing:** turn Sandpiper Brainy off in Accessibility settings and don't use the reel counter / focus lock at
  all. Nothing else in the app is affected.

See `../README.md` and `architecture/SANDPIPER_SECURITY_WARNINGS_PLAN.md` for the fuller plan (an auto-pause list
keyed to apps you pick, a "Time only" detection mode that never touches Accessibility, and a separate build with no
Brainy at all so it never asks for Accessibility in the first place).

## 4. Signing
A release APK built from this project is signed with your own key once you run `make-keystore.sh` /
`make-keystore.bat` (see the repo root) and `./gradlew assembleRelease`. Without that step it falls back to the
debug key, same as the AGP default template, which installs fine for testing but is treated with a little more
suspicion by Play Protect and should not be distributed to anyone else. Each device you reinstall onto after a key
change will show "app not installed" unless you uninstall the old copy first - reinstalling over the top only works
when the signature matches.
