package com.vastanzil.sandpiper

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Brainy: counts short videos / videos / feed items and applies the Fitness page's settings
 * (counter island, status notification, warnings, focus lock over 60% of the screen).
 *
 * Reel counting uses the Reel Counter engine: scroll events from the tracked apps are collected by [SwipeDetector]
 * and a reel is counted only when a swipe has SETTLED (about one screen of net vertical travel, once per gesture,
 * ignoring taps, small drags, horizontal carousels and swiping back over an already counted reel).
 * Tracked apps (built-in list or the user's own picks), browsers and the island's look come from [IslandStore].
 *
 * It looks only at the foreground package name, scroll events and view-ID names. The one exception is the opt-in
 * "Web reels in browsers" switch, which reads ONLY the browser address bar (in memory, never stored).
 * Detection is heuristic (app view IDs change between versions), which is why counts are shown as "Estimated".
 */
class BrainyService : AccessibilityService() {
    /** What the current event belongs to: Brainy platform key (or "other" for apps the user added), plus web flags. */
    private class Target(val key: String, val browser: Boolean, val strict: Boolean)

    private var fg = ""                       // platform key of the foreground app, or ""
    private var surfaceShort = false
    private var watching = false
    private val lastFeed = HashMap<String, Long>()
    private var offStart = 0L
    private var lockView: View? = null
    private var island: IslandOverlay? = null
    private val ime = HashSet<String>()
    private lateinit var wm: WindowManager

    // ---- Reel Counter engine
    private val ui = Handler(Looper.getMainLooper())
    private val detector = SwipeDetector()
    private val settle = Runnable { onSettled() }
    private var gestureKey = ""
    private var rawLogged = 0
    private var lastPausedLog = 0L
    private var lastUrlRead = 0L
    private val webState = HashMap<String, WebReels.Site?>()

    // ---- cached Brainy Island settings (reloaded by reloadSettings())
    private var apps: Set<String> = BrainyApps.BUILT_IN_APPS
    private var browserOn = false
    private var tracking = true
    private var islandAlways = false

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) offStart = System.currentTimeMillis()
            else if (i.action == Intent.ACTION_SCREEN_ON) {
                if (offStart > 0) {
                    if (BrainyStore.addLockOff(this@BrainyService, System.currentTimeMillis() - offStart)) hideLock()
                    offStart = 0
                }
                refreshUi()
            }
        }
    }

    override fun onServiceConnected() {
        running = true
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(InputMethodManager::class.java)?.enabledInputMethodList?.forEach { ime.add(it.packageName) }
        ContextCompat.registerReceiver(
            this, screenRx,
            IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        channels()
        reloadSettings()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        running = false
        if (instance === this) instance = null
        ui.removeCallbacks(settle)
        runCatching { unregisterReceiver(screenRx) }
        hideAll(animated = false)
        island = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() { ui.removeCallbacks(settle); detector.reset() }

    override fun onConfigurationChanged(newConfig: Configuration) { super.onConfigurationChanged(newConfig); island?.refresh() }

    // ---------- called from Brainy Island settings (same process, main thread) ----------
    private fun reloadSettings() {
        apps = IslandStore.monitoredApps(this) - BrainyApps.BROWSERS
        browserOn = IslandStore.browserSupport(this)
        tracking = IslandStore.tracking(this)
        islandAlways = IslandStore.islandAlways(this)
    }

    fun onIslandSettingsChanged() {
        reloadSettings()
        if (!tracking) { ui.removeCallbacks(settle); detector.reset() }
        island?.refresh()
        refreshUi()
    }

    /** Replays the celebration; shows the island briefly if it is not on screen right now. */
    fun previewIsland() {
        val ov = ensureIsland()
        val wasShowing = ov.isShowing
        if (!wasShowing) ov.show()
        ui.postDelayed({ ov.preview() }, if (wasShowing) 0L else 650L)
        if (!wasShowing) ui.postDelayed({ refreshUi() }, 3200L)
    }

    // ---------- events ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        val now = SystemClock.uptimeMillis()
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (pkg == packageName || pkg in ime || pkg == "com.android.systemui") return
            val key = resolve(pkg, now, forceUrl = true)?.key ?: ""
            if (key != fg) { fg = key; surfaceShort = false; watching = false }
            refreshUi()
            if (key.isNotEmpty() && tracking) evalSurface(key)
        } else if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val t = resolve(pkg, now, forceUrl = false) ?: return
            if (!tracking) {
                if (now - lastPausedLog > 5_000L) { lastPausedLog = now; BrainyDiag.add("scroll in ${pkg.substringAfterLast('.')} ignored: tracking is paused") }
                return
            }
            if (t.key != fg) { fg = t.key; refreshUi() }
            onScroll(e, pkg, t, now)
        }
    }

    /** Is this package something we count in? Tracked app -> its platform; browser on a reel site -> that platform. Otherwise null. */
    private fun resolve(pkg: String, now: Long, forceUrl: Boolean): Target? {
        if (pkg in apps) return Target(BrainyApps.platformOf(pkg) ?: "other", browser = false, strict = false)
        if (browserOn && pkg in BrainyApps.BROWSERS) {
            val site = webSite(pkg, now, forceUrl) ?: return null
            return Target(site.key, browser = true, strict = site.mode == WebReels.Mode.HOST)
        }
        return null
    }

    // ---------- Reel Counter engine: collect samples, judge when the swipe settles ----------
    private fun onScroll(e: AccessibilityEvent, pkg: String, t: Target, now: Long) {
        val dx = e.scrollDeltaX
        val dy = e.scrollDeltaY
        if (rawLogged < 4) {
            rawLogged++
            BrainyDiag.add("${pkg.substringAfterLast('.')} ${e.className?.toString()?.substringAfterLast('.')} dx=$dx dy=$dy " +
                "idx=${e.fromIndex}-${e.toIndex}/${e.itemCount} y=${e.scrollY}/${e.maxScrollY}")
        }
        val dm = resources.displayMetrics
        gestureKey = t.key
        detector.onSample(
            SwipeDetector.Sample(
                now, pkg, e.className?.toString().orEmpty(), dx, dy, e.fromIndex, e.itemCount,
                dm.heightPixels, if (t.browser) (dm.heightPixels / dm.density).toInt() else 0, t.strict
            )
        )
        ui.removeCallbacks(settle)
        ui.postDelayed(settle, SETTLE_MS)
    }

    private fun onSettled() {
        val counted = detector.flush(SystemClock.uptimeMillis())
        BrainyDiag.add((if (counted) "COUNTED  " else "no count ") + detector.lastDecision)
        rawLogged = 0
        val key = gestureKey
        if (key.isEmpty() || !tracking) return
        if (counted) {
            if (isWatching(key)) { feed(key) }                     // a page-sized swipe on a YouTube watch page is not a reel
            else { surfaceShort = true; count(key, "short") }
        } else if (key != "other" && !isShort(key)) feed(key)      // ordinary scrolling in a feed (no reel swipe)
    }

    private fun feed(key: String) {
        if (key !in BrainyStore.KEYS || key == "tiktok") return   // TikTok has no "feed" of its own; unknown apps are reels-only
        val now = SystemClock.uptimeMillis()
        if (now - (lastFeed[key] ?: 0L) >= 1500) { lastFeed[key] = now; count(key, "feed") }
    }

    // ---------- browsers: which site is this tab? (address-bar text only, opt-in) ----------
    private fun webSite(pkg: String, now: Long, force: Boolean): WebReels.Site? {
        if (force || now - lastUrlRead > 600L) {          // toolbar may be hidden mid-scroll: keep the last known answer
            lastUrlRead = now
            readUrl(pkg)?.let { webState[pkg] = WebReels.classify(it) }
        }
        return webState[pkg]
    }

    @Suppress("DEPRECATION")
    private fun readUrl(pkg: String): String? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != pkg) { root.recycle(); return null }
        val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
        var budget = 400
        var found: String? = null
        while (queue.isNotEmpty() && budget-- > 0 && found == null) {
            val n = queue.removeFirst()
            val id = n.viewIdResourceName
            if (id != null && BrainyApps.URL_IDS.any { id.endsWith(":id/$it") }) found = n.text?.toString()?.takeIf { it.isNotBlank() }
            if (found == null) for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
            n.recycle()
        }
        queue.forEach { it.recycle() }
        return found
    }

    // ---------- surface detection (view IDs; hints only, the swipe detector decides what is a reel) ----------
    private fun hasId(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.any { id -> root.findAccessibilityNodeInfosByViewId(id).isNotEmpty() }

    private fun hasIdContaining(root: AccessibilityNodeInfo, s: String): Boolean {
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root); var n = 0
        while (q.isNotEmpty() && n < 300) {
            val x = q.removeFirst(); n++
            if (x.viewIdResourceName?.contains(s, true) == true) return true
            for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it) }
        }
        return false
    }

    private fun isShort(key: String): Boolean {
        if (key == "tiktok") return true // the TikTok main screen is a short-video feed
        val root = rootInActiveWindow ?: return surfaceShort
        return when (key) {
            "instagram" -> hasId(root, listOf("com.instagram.android:id/clips_viewer_view_pager", "com.instagram.android:id/clips_video_container", "com.instagram.android:id/root_clips_layout"))
            "youtube" -> hasId(root, listOf("com.google.android.youtube:id/reel_recycler", "com.google.android.youtube:id/reel_player_page_container", "com.google.android.youtube:id/shorts_container"))
            "facebook" -> hasIdContaining(root, "reel")
            else -> false
        }
    }

    private fun isWatching(key: String): Boolean {
        if (key != "youtube") return false
        val root = rootInActiveWindow ?: return watching
        return hasId(root, listOf("com.google.android.youtube:id/watch_player", "com.google.android.youtube:id/watch_while_layout"))
    }

    /** On entering an app: remember whether a reel surface is open and count a regular YouTube video once per open. */
    private fun evalSurface(key: String) {
        val short = isShort(key)
        surfaceShort = short
        if (!short) {
            val w = isWatching(key)
            if (w && !watching) count(key, "reg")
            watching = w
        }
    }

    private fun count(key: String, kind: String) {
        val o = BrainyStore.add(this, key, kind)
        val set = BrainyStore.settings(this)
        val now = System.currentTimeMillis()
        val muted = BrainyStore.inQuiet(set) || set.optLong("snoozeUntil") > now
        if (!muted && kind == "short") {
            val sh = o.optInt("short")
            if (sh >= set.optInt("warn1", 10) && BrainyStore.once(this, "w1")) warn("First warning", "$sh short videos today", false, set)
            if (sh >= set.optInt("warn2", 20) && BrainyStore.once(this, "w2")) warn("Strong warning", "$sh short videos today. Time for a break?", true, set)
            if (sh >= set.optInt("daily", 25) && BrainyStore.once(this, "daily")) warn("Daily limit reached", "$sh short videos today", true, set)
            if (set.optBoolean("block") && BrainyStore.reelsInWindow(o, set.optInt("win", 120)) >= set.optInt("limit", 20)) BrainyStore.setLocked(this, true)
        }
        refreshUi(bump = kind == "short")
    }

    // ---------- UI ----------
    /**
     * Single place that decides what is on screen:
     *  - island: Fitness "Floating Brainy" is on AND tracking is on AND (a tracked app is in front, or "Always" is chosen)
     *  - status notification + focus lock: only while a tracked app / reel site is in front (unchanged behaviour)
     */
    private fun refreshUi(bump: Boolean = false) {
        if (fg.isEmpty() && !islandAlways && island?.isShowing != true) { hideLock(); cancelStatus(); return }   // nothing to show: skip the JSON work
        val set = BrainyStore.settings(this)
        val o = BrainyStore.state(this)
        if (set.optBoolean("float") && tracking && (islandAlways || fg.isNotEmpty())) showIsland(o.optInt("short"), bump) else hideIsland()
        if (fg.isEmpty()) { hideLock(); cancelStatus(); return }
        val muted = BrainyStore.inQuiet(set) || set.optLong("snoozeUntil") > System.currentTimeMillis()
        if (set.optBoolean("notif")) postStatus(o) else cancelStatus()
        if (o.optBoolean("locked") && set.optBoolean("block") && !muted) showLock() else hideLock()
    }

    private fun ensureIsland(): IslandOverlay =
        island ?: IslandOverlay(this) { BrainyStore.state(this@BrainyService).optInt("short") }.also { island = it }

    private fun showIsland(value: Int, bump: Boolean) {
        val ov = ensureIsland()
        val was = ov.isShowing
        if (!was) ov.show()
        ov.render(value, bump && was)
    }

    private fun hideIsland() { island?.hide() }

    private fun overlayType(): Int =
        if (Settings.canDrawOverlays(this)) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showLock() {
        if (lockView != null) return
        val dm = resources.displayMetrics
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Color.parseColor("#F2160A10")); setStroke(dp(2), Color.parseColor("#FF4D6D")) }
        }
        fun text(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        val off = BrainyStore.state(this).optLong("lockOffMs") / 1000
        box.addView(text("BRAINROT LOCK", 24f, Color.parseColor("#FF4D6D"), true))
        box.addView(text("Over your reel budget. Turn your screen off for 5 minutes to clear it.", 16f, Color.WHITE))
        box.addView(text("%d:%02d / 5:00 screen-off time".format(off / 60, off % 60), 15f, Color.parseColor("#FFC46B"), true))
        box.addView(text("Status bar, calls, Home and Recents still work. Closing the reel app hides this until you open one again.", 12f, Color.parseColor("#B8C4BF")))
        box.addView(Button(this).apply {
            text = "Close the reel app"; isAllCaps = false
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_HOME) }
        })
        val lp = WindowManager.LayoutParams(
            dm.widthPixels - dp(24), (dm.heightPixels * 0.6).toInt(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(36) }
        try { wm.addView(box, lp); lockView = box } catch (e: Exception) { lockView = null }
    }

    private fun hideLock() { lockView?.let { runCatching { wm.removeView(it) } }; lockView = null }

    private fun hideAll(animated: Boolean = true) { hideLock(); island?.hide(animated); cancelStatus() }

    private fun channels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Brainy status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_WARN, "Brainy warnings", NotificationManager.IMPORTANCE_DEFAULT).apply { enableVibration(false) })
    }

    private fun postStatus(o: JSONObject) {
        val n = Notification.Builder(this, CH_STATUS).setSmallIcon(R.drawable.ic_stat_bird).setContentTitle("Brainy")
            .setContentText("${o.optInt("short")} short videos · ${BrainyStore.bp(o)} BP today").setOngoing(true).setOnlyAlertOnce(true).build()
        getSystemService(NotificationManager::class.java).notify(ID_STATUS, n)
    }

    private fun cancelStatus() { getSystemService(NotificationManager::class.java).cancel(ID_STATUS) }

    private fun warn(title: String, msg: String, strong: Boolean, set: JSONObject) {
        val n = Notification.Builder(this, CH_WARN).setSmallIcon(R.drawable.ic_stat_bird).setContentTitle("Brainy · $title")
            .setContentText(msg).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(ID_WARN + (if (strong) 1 else 0), n)
        if (set.optBoolean("vib", true)) {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(if (strong) 600L else 250L, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    companion object {
        @Volatile var running = false
        /** The connected service, for Brainy Island settings (same process). Null when Accessibility is off. */
        @Volatile var instance: BrainyService? = null
        private const val SETTLE_MS = 260L
        const val CH_STATUS = "sandpiper_brainy_status_v1"
        const val CH_WARN = "sandpiper_brainy_warn_v1"
        const val ID_STATUS = 4040
        const val ID_WARN = 4050
    }
}
