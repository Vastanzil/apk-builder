# Storage inventory (plan stage S1)

Developer-only. Lives in `docs/`, outside `app/`, so Gradle never packages it into the APK.
Derived from the code in this repository. "Owner" = the layer that writes it.

## Native (Kotlin) stores
| Store | Type | Owner | Readers | Contents | Bound |
|---|---|---|---|---|---|
| `sp_items` | SharedPreferences | `Scheduler` | `AlarmReceiver`, `BootReceiver`, self-test | one JSON per alarm/reminder, key = item id | one per alarm/reminder |
| `sp_brainy` | SharedPreferences | `BrainyStore` | `BrainyService`, `Bridge`, `Steps`, `IslandStore` | key `s` = today's counts + 30-day `hist`; key `set` = Fitness-page Brainy settings | reels array capped at 400; hist 30 days |
| `sp_brainy_island` | SharedPreferences | `IslandStore` | `BrainyService`, `IslandOverlay`, settings screens | tracking, island look/style/gap, browser opt-in, chosen apps, last layout note | small |
| `sp_steps2` | SharedPreferences | `Steps` | `Bridge`, self-test | key `d` = last sensor total + per-day steps / active minutes | 45 days |
| `files/tones/` | files | `MainActivity.onToneResult` | `Tones` | user-chosen alarm audio (max 30 MB each) | per chosen tone |
| `files/diag/diag.jsonl` | file | `Diag` | export only | typed diagnostic events (enums + numbers) | 2 MB, 14 days |
| `res/raw/tone_*.wav` | APK resources | build | `Tones` | 5 built-in tones | read-only |

## Web (WebView) stores - not readable from Kotlin
| Key | Kind | Owner | Contents |
|---|---|---|---|
| `sandpiper_state_v2` | localStorage | `index.html` | finance, notes, habits, water, sleep, investments, alarms list, profile, day records |
| `sandpiper_reminders` | localStorage | planner + `planner-bridge.js` | planner reminders |
| `sandpiper.fitness.v1` | localStorage | `fitness.html` | fitness data blob |
| `sandpiper.fitness.native_ids` / `sp_native_ids` | localStorage | bridge scripts | ids of reminders handed to Android |
| `sp_ci` | localStorage | `index.html` | small UI flag |
| IndexedDB `sandpiper` / store `rec` | IndexedDB | `index.html` | voice-note audio (NOT in the JSON backup) |

## Manifest permissions -> feature
| Permission | Feature | Verdict |
|---|---|---|
| POST_NOTIFICATIONS | reminders, warnings | used |
| RECEIVE_BOOT_COMPLETED | re-arm alarms | used |
| VIBRATE | alarm, warnings | used |
| WAKE_LOCK | `MediaPlayer.setWakeMode` in `AlarmService` | used |
| FOREGROUND_SERVICE / ..._MEDIA_PLAYBACK | ringing alarm service | used |
| USE_FULL_SCREEN_INTENT | lock-screen alarm | used |
| SCHEDULE_EXACT_ALARM | precise reminders | used |
| RECORD_AUDIO, MODIFY_AUDIO_SETTINGS | voice notes (WebView capture) | used; MODIFY_AUDIO_SETTINGS kept because WebView audio capture is documented to need it |
| ACTIVITY_RECOGNITION | step counter | used |
| SYSTEM_ALERT_WINDOW | focus-lock overlay | used (optional) |
| PACKAGE_USAGE_STATS | real app time | used (optional) |
| (accessibility service) | Brainy counting + island | used |
| INTERNET | - | deliberately absent |

No permission was removed: none could be proven unused without a device run.
