# Sandpiper system schematic (as built)

Developer-only; documents what exists in this repository, not the plan. Not packaged in the APK.

## Plan status
| Stage | Status | Notes |
|---|---|---|
| S0 Safety net | partial | existing tests kept; no git branch / legacy snapshot exporter (no repo or toolchain here) |
| S1 Inventory | done | `STORAGE_INVENTORY.md` |
| S2 Room database | **not done** | needs KSP + Room and a real Gradle run to verify |
| S3 Diagnostics core | done (not compiled) | `DiagCore.kt`, `Diag.kt`, tests |
| S4 Legacy migration | **not done** | depends on S2 |
| S5 Bridge v2 | **not done** | existing synchronous bridge unchanged |
| S6 Settings engine | **not done** | |
| S7 Permissions | partial | live permission probes in self-test; no onboarding / 4-state UI |
| S8 Ports + hub | partial | the two real Brainy links are probed by self-test; no registry/hub |
| S9 Backup v3 | **not done** | JSON v2 backup unchanged (voice notes still excluded) |
| S10 Docs | done | this file |
| S11 Verification | **not run** | no Gradle / Android SDK available |

## Runtime
```mermaid
flowchart TB
  subgraph WEB[WebView UI]
    IDX[index.html] --- PLN[planner.html] --- FIT[fitness.html]
  end
  WEB -->|"window.SandpiperNative (sync, allow-listed @JavascriptInterface)"| BR[Bridge]
  BR --> SCH[Scheduler -> AlarmManager]
  BR --> STP[Steps / StepWorker]
  BR --> BS[BrainyStore]
  BR --> DG[DiagnosticsActivity]
  SVC[BrainyService + IslandOverlay] --> BS
  ISL[IslandStore] --> BS
  SCH --> RCV[AlarmReceiver -> AlarmService]
  BOOT[BootReceiver / app start] -->|rearmAll| SCH
  subgraph DIAG[Diagnostics - enums and numbers only]
    LOG[Diag.log] --> RB[(ring + diag.jsonl)] --> EXP[zip export via SAF]
    ST[SelfTest] --> LOG
  end
  SCH -.-> LOG
  SVC -.-> LOG
  BR -.-> LOG
```

## Connections verified by static audit
All 23 `SandpiperNative` methods called from the web layer exist as `@JavascriptInterface` in `Bridge`; all 9 manifest components resolve to classes; every `R.*` reference resolves; the three Kotlin->JS callbacks (`onNativePermission`, `onSteps`, `onToneChosen`) are defined in `index.html`; all inline scripts parse in Node.

## Deviations from the plan
Diagnostics use the existing SharedPreferences stores as the "source of truth" because Room is not adopted. `health.json` reports READY / LIMITED / ERROR only (no ACTION_REQUIRED state). The canary test runs on the JVM against the logger and exporter, not the whole app.
