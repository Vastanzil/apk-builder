# Feature status (honest)
Legend: **Logic-tested** = web logic run in a simulated browser (jsdom) with a fake native bridge. **Not device-tested** = written but never compiled or run on a phone.

| Feature | Status |
|---|---|
| Transactions, balance, savings rate, CSV | Logic-tested |
| Planner: Smart calendar (Monday-first, selected-day reminders, complete/reopen/delete, Notify me), tasks, repeat + month-end clamp | Logic-tested |
| Focus timer survives restarts, counts each session once, bonsai stages | Logic-tested |
| Alarms: JS scheduling + one-time/repeat roll-over | Logic-tested |
| Alarms: AlarmManager + foreground-service ringing, snooze, reboot re-arm, health checks (Kotlin) | Not device-tested |
| Notifications, permission prompts (Kotlin) | Not device-tested |
| Voice notes (WebView MediaRecorder, stored in IndexedDB) | Not device-tested; format is WebM/Opus, not AAC |
| Save CSV / JSON / audio to Downloads/Sandpiper | Bridge logic-tested; MediaStore code not device-tested |
| Step counter (daily baseline, counts from first open each day) | Not device-tested |
| Alarm tone choice: 5 built-in original tones, phone alarm tones, your own audio file, preview | Web logic-tested; playback, picker and file copy (Kotlin) not device-tested |
| Zen Garden layout: timer + garden in one card, Fitness card with your full fitness page | Logic-tested in a simulated browser |
| Fitness ports, stars and reports -> Close the day -> day record, bonus points, CSV | Logic-tested end to end (simulated browser) |
| Fitness opens from a button into its own full-screen window; Back/Android back close it | Logic-tested in a simulated browser |
| Fitness native hooks: steps, active minutes, history, permission state, Usage Access minutes, links, workout reminders (Kotlin) | Not device-tested |
| Accessibility service (reel/short/feed counting), warnings, floating counter, status notification, lock overlay over 60% of the screen, screen-off unlock (Kotlin) | Not compiled, not device-tested |
| Display-over-apps, Usage Access and Accessibility permission screens now list Sandpiper (permissions + service declared) | Not device-tested |
| Offline Bricolage Grotesque font (OFL licence included) | Bundled; loads from local file |
| Brainy Island: reel counting by settled swipe (SwipeDetector), web-reel address classification, app/package mapping | Unit tests written (JVM, ported from the working Reel Counter and extended), **not run here** (no Kotlin toolchain available) |
| Brainy Island: BrainyService rewired to the detector + island, settings screen, app picker, diagnostics, reset, tracking pause (Kotlin) | Not compiled, not device-tested (the Reel Counter originals of the detector, island and picker were working on a phone) |
| Brainy Island card in Zen Garden opens the native settings screen | JS syntax-checked; not device-tested |
| Habits, hydration, sleep, investments, backup/restore, calculator, About easter egg | Logic-tested |
| Diagnostics: typed privacy-safe logger, self-test, health, zip export via file picker (Kotlin) + JVM tests incl. canary-leak test | Written; **not compiled, tests not run** |
| Alarms re-armed on every cold start (Android drops them on force-stop) | Written; not compiled, not device-tested |
| Gradle build / APK | **Not built** (no Android SDK available when this was written) |

## Known limits
Brainy detection is heuristic: it recognises Reels/Shorts/TikTok screens by app view IDs and scroll events, which can change when those apps update, so counts are labelled Estimated. Facebook detection is the least reliable. Step and active-minute history comes from a ~15-minute background sampler (WorkManager); force-stopping the app or aggressive battery savers can pause it, and the first day after install is partial. Active minutes are an estimate (brisk-cadence steps / 100). On Android 13+ a sideloaded app may need App info > ⋮ > Allow restricted settings before the Accessibility switch can be turned on.
The planner's own daily plan and skill-tree progress are not saved between launches (same as your original file). No custom alarm music, no XLSX/PDF export, no app lock, no budgets/transfers/multiple accounts, no wake-up sound loop beyond the notification's insistent alarm tone (10 min max).
Voice notes are not included in the JSON backup. Recording may stop if the app is sent to the background.
